/**************************************************************************
.TITLE    ECMWF Utility
.NAME     SMSDATE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     23-MAR-1994 / 23-MAR-1994 / OP
.VERSION  1.0
.DATE     17-MAR-1998 / 11-MAR-1998 / OP / Baudouin Raoult
.VERSION  2.0
*         Use julian date routines instead of C-library struct tm stuff
*         julian_to_date and date_to_julian copied from mars source code
.LANGUAGE ANSI-C
.FILE     sms/smsdate.c
$  smsdate yyyymmddhh [+|-]hours
?  Compute new date by adding hours into the date given.
************************************o*************************************/

#include <stdio.h>

#ifndef TRUE
#  define TRUE  1
#  define FALSE 0
#endif

#define STR(x) (x)

char *my_name;

void usage(void)
{
  fprintf(stderr,"usage: %s [-s] yyyymmddhh [+|-]hours\n",STR(my_name));
  fprintf(stderr,"       %s [-s] -D yyyymmdd [+|-]days\n",STR(my_name));
  fprintf(stderr,"       %s [-d | -j | -J | -s] yyyymmddhh\n",STR(my_name));
  fprintf(stderr,"       -D  switch to use days instead of hours\n");
  fprintf(stderr,"       -d  prints the Julian date\n");
  fprintf(stderr,"       -j  prints the julian day number of the year\n");
  fprintf(stderr,"       -J  prints the julian day number of the year (JJJ)\n");
  fprintf(stderr,"       -s  prints the yyyymmhhdd separately (yyyy mm hh dd)\n");
  fprintf(stderr,"       Julian number is in range of [1-366]\n");
  exit(1);
}

is_number(char *s)
/**************************************************************************
?  Check if the string given is a pure number.
=  TRUE if this is a purge number, FALSE otherwise.
************************************o*************************************/
{
  if( !s ) return FALSE;
  if( !*s ) return FALSE;

  if( (*s=='+' || *s=='-' ) && isdigit(s[1]) ) s++;

  while( *s && isdigit(*s) ) s++;

  return !*s ;
}

long julian_to_date(long jdate)
{
	long x,y,d,m,e;
	long day,month,year;

	x = 4 * jdate - 6884477;
	y = (x / 146097) * 100;
	e = x % 146097;
	d = e / 4;

	x = 4 * d + 3;
	y = (x / 1461) + y;
	e = x % 1461;
	d = e / 4 + 1;

	x = 5 * d - 3;
	m = x / 153 + 1;
	e = x % 153;
	d = e / 5 + 1;

	if( m < 11 )
		month = m + 2;
	else
		month = m - 10;


	day = d;
	year = y + m / 11;

	return year * 10000 + month * 100 + day;
}

long date_to_julian(long ddate)
{
	long  m1,y1,a,b,c,d,j1;

	long month,day,year;

	year = ddate / 10000;
	ddate %= 10000;
	month  = ddate / 100;
	ddate %= 100;
	day = ddate;

	if (month > 2)
	{
		m1 = month - 3;
		y1 = year;
	}
	else
	{
		m1 = month + 9;
		y1 = year - 1;
	}
	a = 146097*(y1/100)/4;
	d = y1 % 100;
	b = 1461*d/4;
	c = (153*m1+2)/5+day+1721119;
	j1 = a+b+c;

	return(j1);
}

main(int argc, char **argv)
{
  extern int   optind;
  extern char *optarg;
  int          optch;

  int          julian_day = 0;     /* options */
  int          days       = 0;
  int          separate   = 0;
  int          usedays    = 0;

  int          rc;

  char        *c_date;
  char        *c_delta = 0;

  int     year, month, day, hour;  /* Input date           */
  long    date;                    /* Date in YYYYMMDD     */
  long    hh;                      /* Hour of the input    */
  long    julian;                  /* Julian date          */
  long    joff;

  double  d;                       /* Compute with doubles */

  long    delta;                   /* Offset in hours      */
  long    dd;

  my_name = *argv;

  while((optch=getopt(argc, argv, "DjJds")) != -1)
    switch(optch)
    {
      case 'j':
        julian_day=1;
        break;

      case 'J':
        julian_day=2;
        break;

      case 'D':
        usedays=1;
        break;

      case 'd':
        days=1;
        break;

      case 's':
        separate=1;
        break;

      default:
        usage();
    }

  argc -= optind;
  argv += optind;

  if( argc<1 || (!julian_day && !days && argc<2) ) usage();

  c_date = argv[0];

  if(argc>1)
    c_delta = argv[1];

  if( !is_number(c_date) || strlen(c_date) < 8 || (!usedays && strlen(c_date) <10) )
  {
    fprintf(stderr,"%s:invalid date string (%s) given\n",STR(my_name),STR(c_date));
    usage();
  }

  if( strlen(c_date) > 10 )
    fprintf(stderr,"%s:warning! date given is longer than 10?\n",STR(my_name));

  hour = 0;
  if(usedays)
    rc = sscanf(c_date,"%04d%02d%02d",&year ,&month ,&day) + 1;
  else
    rc = sscanf(c_date,"%04d%02d%02d%02d",&year ,&month ,&day ,&hour );

  if( rc != 4 )
  {
    fprintf(stderr,"%s:invalid date format (%s) given\n",STR(my_name),STR(c_date));
    usage();
  }

  date = year*10000 + month*100 + day;
  hh   = hour;

  /*
   *  Check the date ...
   */

  julian = date_to_julian(date);

  if( julian_to_date(julian) != date || hour<0 || hour>23 )
  {
    fprintf(stderr,"%s:invalid date (%s) given\n",STR(my_name),STR(c_date));

    fprintf(stderr,"input date is %d and input hour %d\n",date,hour);

    usage();
  }

  if( c_delta )
  {
    if( !is_number(c_delta) )
    {
      fprintf(stderr,"%s:invalid delta (%s) given\n",STR(my_name),STR(c_delta));
      usage();
    }

    delta = atol(c_delta);
  }
  else
    delta = 0;

  if(usedays)
  {
    julian += delta;
    dd = julian_to_date(julian);
  }
  else
  {
    d  = julian + hh / 24.0;
    d += delta / 24.0;

    dd = (long)d;
    hh = (d - dd)*24.0 + 0.5;

    julian = dd;
    dd = julian_to_date(dd);
  }

  if( days )
    printf("%d\n",julian);
  else if(julian_day)
  {
    long j;

    dd = dd / 10000;
    dd = dd * 10000 + 101;

    j = date_to_julian(dd);

    joff = julian - j + 1;

    printf( (julian_day == 1)? "%d\n" : "%03d\n" , joff);
  }
  else
    if(separate)
    {
      year = dd / 10000;
      dd -= year * 10000;
      month = dd / 100;
      day = dd % 100;

      if(usedays)
        printf("%d %02d %02d\n",year,month,day);
      else
        printf("%d %02d %02d %02d\n",year,month,day,hh);
    }
    else
      if(usedays)
        printf("%d\n",dd);
      else
        printf("%d%02d\n",dd,hh);

  return 0;
}

