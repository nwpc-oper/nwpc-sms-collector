/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMSPING
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-MAY-1992 / 14-OCT-1991 / OP
.VERSION  4.0
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     smsping.c
.DATE     10-AUG-1998 / 10-AUG-1998 / OP
.VERSION  4.3.21
.DATE     16-DEC-1998 / 16-DEC-1998 / OP
.VERSION  4.4
*         Tons of changes
*
*  Ping the SMS on host given.
*
*  NOTICE!  You can also use the rpcinfo -p [host] if it exists (should)
*
************************************o*************************************/

#include "smslib.h"

/*
 * Copied here to make the executable much, much smaller.
 * Modified to return clnt_stat
 */

static int prog,vers;

static int sms_client_ping_static(char *host, int quiet, int number)
/**************************************************************************
?  Check if the SMS is alive in the host given.
=  clnt_stat (0 == RPC_SUCCESS == ok)
************************************o*************************************/
{
  enum clnt_stat ans;

  if( ! host || ! *host )
    return RPC_FAILED;

  if( (ans=callrpc(host,prog,vers,NULLPROC,xdr_void,0,xdr_void,0)) != RPC_SUCCESS)
  {
    if( ! quiet )
      clnt_perrno(ans);
    return ans;
  }

  return RPC_SUCCESS;
}

main(int argc, char **argv)
{
  int ans;

  prog = (getenv("SMS_PROG"))? atoi(getenv("SMS_PROG")) : SMS_PROG;
  vers = (getenv("SMS_VERS"))? atoi(getenv("SMS_VERS")) : SMS_VERS;

  if( argc<2 )
  {
    fprintf(stderr,"usage: %s host\n",STR(*argv));
    exit(2);
  }

  if( (ans=sms_client_ping_static(*++argv,FALSE,0)) == RPC_SUCCESS )
  {
    printf("SMS in %s is OK!\n",STR(*argv));
    exit(0);
  }
  else
  {
    fprintf(stderr,"\nSMS [%d/%d] is not running in %s\n",prog,vers,STR(*argv));
    if(ans<1)   ans=1;
    if(ans>127) ans=127;
    fprintf(stderr,"exiting with RPC errorcode %d\n",ans);

    exit(ans);
  }
}

