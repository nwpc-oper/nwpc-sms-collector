/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     DIE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-MAY-1992 / 14-NOV-1991 / OP
.VERSION  4.0
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     die.c
$  Force the portmapper to unregister the program
*
*  compile: cc -o die die.c
*
************************************o*************************************/

#include "smslib.h"

int main(int argc, char **argv)
{
  int prog,vers;

  prog = (getenv("SMS_PROG"))? atoi(getenv("SMS_PROG")) : SMS_PROG;
  vers = (getenv("SMS_VERS"))? atoi(getenv("SMS_VERS")) : SMS_VERS;
  
  (void) pmap_unset(prog,vers);

  exit(0);
  return 0;
}

