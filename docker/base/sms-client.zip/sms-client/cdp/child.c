/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CHILD
.NAME     SMSABORT
.NAME     SMSCOMPLETE
.NAME     SMSEVENT
.NAME     SMSINIT
.NAME     SMSLABEL
.NAME     SMSMAIL
.NAME     SMSMETER
.NAME     SMSMSG
.NAME     SMSWAIT
.NAME     ABTT (stop using!)
.NAME     ENDT (stop using!)
.NAME     SETEV (stop using!)
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     24-SEP-1992 / 06-AUG-1991 / OP
.VERSION  4.0
.FILE     child.c
.DATE     26-FEB-1993 / 26-FEB-1993 / OP
.VERSION  4.1
.DATE     21-FEB-1994 / 13-FEB-1994 / OP
.VERSION  4.2.1
*         Added support for sending messages into SMS log file (smsmsg)
.DATE     01-MAR-1994 / 22-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
*         Added support for sending meter and label info into SMS
.DATE     02-SEP-1994 / 01-SEP-1994 / OP
.VERSION  4.3.2
*         Added support for the fast login
.DATE     24-FEB-1995 / 24-FEB-1995 / OP
.VERSION  4.3.5
*         Compatibility with 4.2 + some more prints
.DATE     22-JUL-1998 / 20-OCT-1997 / OP
.VERSION  4.3.16-21
*         Added query for meter (it's not an error to query 
*         non existing meter)
*         Env SMSTIMEOUT
*         Env SMSDENIED
.DATE     07-JAN-1999 / 10-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Old task commands, task mail, task wait
.DATE     11-JUL-2000 / 07-JUN-2000 / OP
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     13-JUN-2001 / 13-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         smsvariable and host option
$  smsabort
|  smscomplete  ["expire"]
|  smsevent     [-q] eventname
|  smsinit      [SMSRID]
|  smsmsg       text [text...]
|  smsmeter     name value
|               -q name
|  smslabel     name string [string]
|               -q name
|  smsmail      user text [text...]
|  smswait      triggermath  # like alter use more spaces
|
|  abtt
|  endt         ["expire"]
|  setev        eventname
|
?  These routines contact the SMS running in the host $SMSNODE. Or if the
|  SMS in that host is dead or refuses to accept the message connects to
|  one that accepts the message.
|
|  If the password ($SMSPASS) is empty this does absolutely nothing. This
|  allowes the same scripts to be used by the SMS itself and the operator
|  using CDP-command send. See send(cdp) for more details.
|
|  Also if environment variable NO_SMS is set (value doesn't matter as
|  long as the variable can be found) this does absolutely nothing.
|
|  Autorouting is the feature to allow the tasks to connect any SMS
|  in the network, if the one specified by the $SMSNODE doesn't respond
|  within hard coded time and number of tries. The child then broadcasts
|  in the network and waits for the SMS(s) in any machine(s) to respond.
|  Then this command tries all those SMS(s) until that/one of them accepts
|  the message. If no one accepts the message within 24 hours the jobs
|  terminates.
-SIGNALS
|  Signal SIGTERM may be send to kill the job
|  Signal SIGHUP may be send to force the child to broadcast/ping
-ENVIRONMENT
|  SMSNODE       The node name who send the job.
|  SMSNAME       My (the task) name eg /o/oof02/of918
|  SMSPASS       The password for the SMS. 
|  SMSHOSTFILE   File that lists all the extra SMS's that should be pinged
|                in case the servers are being broadcasted.
|  SMS_PROG      default  314159
|  SMS_VERS      default  1
|
|  SMSTIMEOUT    integer, in seconds for the length of time we keep trying
|  SMSDENIED     integer, if set to 1 and SMS refused access => die
-LIMITS
$:grep '^#define' child.c | cut -c9-99
=  0 when successfull, 1 otherwise with error message in stderr.
!  Currently the autorouting is under testing.
~  sms(L) cdp(L) xcdp(L)
************************************o*************************************/

#include "smslib.h"

#define INIT_TIMEOUT     10        /* Time to wait between initial tries  */
#define INIT_TRIES        5        /* Number of initital tries to SMSNODE */
#define POLL_TIMEOUT     30        /* Time between broadcasts for SMSs    */
#define TOTAL_TIMEOUT    24*3600   /* We don't try forever, only 24 hours */
#define MIN_TIMEOUT      10*60     /* Some reasonable value               */
#define LOGIN_TIMEOUT   120        /* The RPC timeout to be used          */

static int polls[] = {
  10, 15, 20, 25, 30, 35, 40, 45, 50
};

static int npolls = sizeof(polls)/sizeof(int);

/**************************************************************************
*                          The global variables
************************************o*************************************/

static char *my_name;              /* Name of the command         */
static char *task_name;            /* The full name of the job     */
static char *sms_home;             /* The original SMSNODE          */
static char *host_name;            /* The host name of the SMS       */
static char *host_file;            /* The file name of the SMS 2 ping */
static char *credential;           /* "Password of the job           */
static int   port = 0;             /* Socket number                 */

static char *av[256];              /* CMD to be executed!  */
static int   ac;                   /* Number of args in it */

static int   trying_home  = TRUE;  /* Initially we try the original SMS */

extern char *getenv();

static void catch(int sig)
/**************************************************************************
?  Catch the terminal interrupt for the repeated status.
************************************o*************************************/
{
  switch(sig)
  {
    case SIGHUP:                   /* Force 2 use the servers */
      trying_home = FALSE;
      break;
    case SIGTERM:                  /* Die gracefully! */
      if(sms_client_is_ok(HANDLE))
        sms_client_logout(HANDLE);
      exit(0);
      break;
  }
  signal(sig,catch);
}
 

char *env_get(char *name)
/**************************************************************************
?  Get an environment variable.
|  If not found exit with error message and exit code 1
************************************o*************************************/
{
  char *s = getenv(name);

  if( s )
    return s;

  fprintf(stderr,"%s:env %s missing\n",STR(my_name),STR(name));

  exit(1);

  return 0;
}

main(int argc, char **argv)
{
#include "child.h"                 /* == cmds! */

  sms_list    *l         = NULL;   /* Reply from the SMS */
  sms_list    *servers   = NULL;   /* SMSs running in the network */
  sms_list    *cmd       = NULL;
  sms_trigger *tp        = 0;

  time_t    start_time   = sms_time_t(NULL);
  int       never_polled = TRUE;
  int       message_ok   = FALSE;
  int       tries        = INIT_TRIES;
  int       cmd_len;
  int       i;
  char      tmp_name[MAXNAM];
  char      label_string[MAXLEN];
  int       timeout      = TOTAL_TIMEOUT;
  int       denied       = 0;

  int       count        = 0;
  int       is_query     = FALSE;

  signal(SIGPIPE,SIG_IGN);

#ifdef VMS
  argc--;
  argv++;

  if(argc<1)
  {
    fprintf(stderr,"child:U gotta use a symbol to invoke the child\n");
    fprintf(stderr,"eg   : smsinit :== $DISK1:[DIR.DIR]child.exe smsinit");
    exit(1);
  }
#endif

  cmd_len = strlen(*argv);
  my_name = *argv;

  /*
  //  Dispatch 2 find the command name. (Maybe the full path name!)
  */

  for(i=0 ; i<nchild_cmds ; i++)
    if( ! strncmp(*argv+cmd_len-strlen(child_cmds[i]),
                   child_cmds[i],
                   strlen(child_cmds[i])
                 ) )
      break;

  ls_open();
  ioi_open(0,NULL,NULL);

  task_name  = env_get("SMSNAME");
  sms_home   =
  host_name  = env_get("SMSNODE");
  credential = env_get("SMSPASS");
  host_file  = getenv("SMSHOSTFILE");       /* NULL will do! */

  if( getenv("SMSTIMEOUT") )
    timeout = atoi(getenv("SMSTIMEOUT"));

  if( getenv("SMSDENIED") )
    denied = atoi(getenv("SMSDENIED") );

  if( timeout > TOTAL_TIMEOUT )
    timeout = TOTAL_TIMEOUT;
  if( timeout < MIN_TIMEOUT ) 
    timeout = MIN_TIMEOUT;

  sms_._is_server = FALSE;

  sms_._prog = (getenv("SMS_PROG"))? atoi(getenv("SMS_PROG")) : SMS_PROG;
  sms_._vers = (getenv("SMS_VERS"))? atoi(getenv("SMS_VERS")) : SMS_VERS;

  if( i<0 || i>=nchild_cmds )
  {
    fprintf(stderr,"Heh heh! The someone is playing a game!\n");
    fprintf(stderr,"I don't know about %s\n",STR(my_name));
    exit(1);
  }

  if( i==CMD_ABTT || i==CMD_ENDT || i==CMD_SETEV )
  {
    int old = i;

    if( i==CMD_ABTT  ) i=CMD_SMSABORT;
    if( i==CMD_ENDT  ) i=CMD_SMSCOMPLETE;
    if( i==CMD_SETEV ) i=CMD_SMSEVENT;

    fprintf(stderr,"This is old name for the command, use the new one\n");
    fprintf(stderr,"Use %s instead of %s\n",STR(child_cmds[i]),STR(child_cmds[old]));
  }

  av[ac++] = child_cmds[i];        /* Build the SMS command for transmission */

  if( argc < sms_child_params[i]+1 )
  {
    fprintf(stderr,"%s:",STR(my_name));
    if( i==CMD_SMSEVENT  ) fprintf(stderr,"give event number/name\n");
    if( i==CMD_SMSMSG )    fprintf(stderr,"message to be send to SMS\n");
    if( i==CMD_SMSMETER )  fprintf(stderr,"give meter name and value\n");
    if( i==CMD_SMSLABEL )  fprintf(stderr,"give label name and string\n");
    if( i==CMD_SMSWAIT )  fprintf(stderr,"give trigger mathematic\n");
    exit(1);
  }

  switch( i )
  {
    case CMD_SMSABORT   :
      break;

    case CMD_SMSCOMPLETE:
      if( argc > 1 )
        if(strcmp(argv[1],sms_cmds[CMD_EXPIRE])==0)
          av[ac++] = argv[1];

      break;

    case CMD_SMSEVENT   :
      av[ac++] = *++argv;
      if(strcmp(*argv,"-q")==0)
      {
        av[ac++] = *++argv;
        is_query = TRUE;
      }
      break;

    case CMD_SMSINIT    :          /* Add the request id */
      if( --argc )
        av[ac++] = *++argv;
      break;

    case CMD_SMSMSG     :          /* Add all lines as text to be send */
      while( --argc )
        av[ac++] = *++argv;
      break;

    case CMD_SMSMETER   :          /* Add meter name and value */
      av[ac++] = *++argv;
      av[ac++] = *++argv;
      break;

    case CMD_SMSLABEL :            /* Add label name and string */
      av[ac++] = *++argv;
      if(strcmp(*argv,"-q")==0)
      {
        av[ac++] = *++argv;
        is_query = TRUE;
      }
      else
      {
        sms_play_label_argv2string(argc-2,++argv,label_string,MAXLEN);
        av[ac++] = label_string;
      }
      break;

    case CMD_SMSMAIL  :            /* Add all lines, first is user */
      while( --argc )              /* SMS will figure that out     */
        av[ac++] = *++argv;
      break;

    case CMD_SMSWAIT  :
      tp = sms_play_create_trigger(--argc, ++argv, NODE_TRIGGER);
      if(!tp)
        exit(1);
      break;
  }

  if( getenv("NO_SMS") )
  {
    printf("%s:NO_SMS is set ---> command ignored\n",STR(my_name));
    exit(0);
  }

  if( !*credential )
  {
    printf("%s:no password ---> command ignored\n",STR(my_name));
    exit(0);
  }

  if( getenv("SMSPORT") )
    port = atoi(getenv("SMSPORT"));

  ls_argv(&cmd,ac,av);
  if(tp) ls_join(&cmd,tp);

  while( ! message_ok )
  {
    if( (sms_time_t(NULL)-start_time) > timeout )
    {
      fprintf(stderr,"%s:timeout [%dsec]\n",STR(my_name),timeout);
      exit(1);
    }

    if( !trying_home )             /* Auto routing logics */
    {
      if( !servers )
      {
        sms_client_servers(&servers,0,FALSE,host_file,NULL,NULL);
        if(servers)
        {
          fprintf(stderr,"Servers found from the net/host-file\n");
          ls_fancy(&servers,stderr,80);
        }
        if(!ls_find(&servers,sms_home))
          sms_list_add_text(&servers,sms_home);
      }

      if( servers )                /* If no servers were found we'll keep */
        host_name = servers->name; /* on trying home! the original SMS    */

      port = 0;                    /* Only the SMS could have given this */
    }

    if( host_name )
    {
      int rc;

      do                           /* Stay in the loop only for the HOME-SMS */
      {
        if(tries && trying_home )  /* Tries might > 0 if signals were used */
          tries--;
        else if( trying_home )
          trying_home = FALSE;

        sms_client_login(host_name,task_name,credential,
                         LOGIN_TIMEOUT,port,&cmd,&rc );

        count++;

        switch( rc )
        {
          case SMS_E_HALTED:       /* OK right node, but SMS is not ready */
          case SMS_E_TERMINATE:
            fprintf(stderr,"SMS is pending input\n");
            sleep(INIT_TIMEOUT);
            break;

          case SMS_E_OK:           /* Command received and accepted */
            message_ok = TRUE;
            break;

          case SMS_E_NOTFOUND:     /* MUST BE SETEV or METER ! */
            fprintf(stderr,"#===================================\n");
            fprintf(stderr,"%s:NOT FOUND, BUT IGNORED\n",STR(my_name));
            fprintf(stderr,"#===================================\n");
            message_ok = TRUE;
            break;

          case SMS_E_METER:
            fprintf(stderr,"#===================================\n");
            fprintf(stderr,"%s:Can not set meter\n",STR(my_name));
            fprintf(stderr,"#===================================\n");
            message_ok = TRUE;
            break;

          case SMS_E_LABEL:
            fprintf(stderr,"#===================================\n");
            fprintf(stderr,"%s:Can not set label\n",STR(my_name));
            fprintf(stderr,"#===================================\n");
            message_ok = TRUE;
            break;

          case SMS_E_PERMISSION:   /* Printed by sms_client_login() */
            if(denied)
            {
              fprintf(stderr,"#===================================\n");
              fprintf(stderr,"%s: was denied access, exiting\n",STR(my_name));
              fprintf(stderr,"#===================================\n");
              exit(1);
            }
            break;

          case SMS_E_FAIL:
            fprintf(stderr,"%s: was asked to fail by SMS, exiting\n",STR(my_name));
            exit(1);
            break;

          case SMS_E_RPC:
            break;

          case SMS_E_QUERY:        /* Printing is done by login */
            message_ok = TRUE;
            break;

          case SMS_E_WAIT:
            fprintf(stderr,"%s: is waiting for SMS\n",STR(my_name));
            if(tries) tries++;
            break;

          default:                 /* I'll quit! */
            fprintf(stderr,"%s:Execution failed for %s in host %s\n",
              STR(my_name),STR(task_name),STR(host_name));
            trying_home = FALSE;
            break;
        }

        if( !message_ok && trying_home )
          sleep( INIT_TIMEOUT );

      } while( !message_ok && tries>0 && trying_home );

      if( servers && !message_ok ) /* Login failed -> Try the next SMS */
        sms_list_delete(&servers,servers);

      if( !message_ok )
      if(!servers && !trying_home) /* No more servers to try! */
        if( never_polled )
          never_polled = FALSE;    /* To avoid the first wait for servers */
        else
          sleep(POLL_TIMEOUT);
    }
    else                           /* None of the SMSs responded */
      sleep(POLL_TIMEOUT);
  }

  if(count>1)
    fprintf(stderr,"%s: tried %d times\n",STR(my_name),count);

  exit(0);                         /* Great we succeeded! */
}

