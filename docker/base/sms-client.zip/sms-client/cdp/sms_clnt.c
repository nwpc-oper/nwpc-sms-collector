#include <rpc/rpc.h>
#include <sys/time.h>
#include "sms.h"

#include <smsproto.h>
#define xdr_sms_login  sms_xdr_login
#define xdr_sms_list   sms_xdr_list
#define xdr_sms_status sms_xdr_status
#define xdr_sms_node   sms_xdr_node
#define xdr_sms_reply  sms_xdr_reply
#define xdr_sms_handle sms_xdr_handle


/* Default timeout can be changed using clnt_control() */
static struct timeval TIMEOUT = { 25, 0 };

sms_handle *
sms_login_1(argp, clnt)
	sms_login *argp;
	CLIENT *clnt;
{
	static sms_handle res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_LOGIN, xdr_sms_login, argp, xdr_sms_handle, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


int *
sms_logout_1(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static int res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_LOGOUT, xdr_void, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


int *
sms_news_1(argp, clnt)
	int *argp;
	CLIENT *clnt;
{
	static int res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_NEWS, xdr_int, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


sms_list *
sms_history_1(argp, clnt)
	int *argp;
	CLIENT *clnt;
{
	static sms_list res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_HISTORY, xdr_int, argp, xdr_sms_list, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


sms_status *
sms_status_1(argp, clnt)
	int *argp;
	CLIENT *clnt;
{
	static sms_status res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_STATUS, xdr_int, argp, xdr_sms_status, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


int *
sms_play_1(argp, clnt)
	sms_node *argp;
	CLIENT *clnt;
{
	static int res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_PLAY, xdr_sms_node, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


sms_reply *
sms_cmd_1(argp, clnt)
	sms_reply *argp;
	CLIENT *clnt;
{
	static sms_reply res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_CMD, xdr_sms_reply, argp, xdr_sms_reply, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


int *
sms_cmd_old_1(argp, clnt)
	char **argp;
	CLIENT *clnt;
{
	static int res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, SMS_CMD_OLD, xdr_wrapstring, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}

