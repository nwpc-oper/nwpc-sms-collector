/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CDP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     14-JUL-1992 / 21-JUN-1991 / OP
.FILE     cdp.c
*
.VERSION  4.0
.DATE     22-JUL-1993 / 27-APR-1993 / OP
.VERSION  4.2
.DATE     16-MAR-1995 / 25-FEB-1994 / OP
.VERSION  4.3.2-5
.LANGUAGE ANSI-C
.DATE     07-AUG-1998 / 07-AUG-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     21-JAN-1999 / 25-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
.DATE     04-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     13-JUN-2001 / 12-FEB-2001 / OP
.VERSION  4.4.5 ABT(c)
*
*  This is the main part of the CDP.
*  It only loads the commands into the IOI and lets IOI handle the
*  input processing and calling of the functions.
*
************************************o*************************************/

#ifndef TODAY
#define TODAY "date unknown"
#endif

#define IOI_MODULE

#include "smslib.h"

#if defined(sparc) && 0
#  include <stdio.h>
#  include <sys/ioctl.h>
#  include <sun/audioio.h>
#  define CDP_WELCOME welcome()
welcome()
{
  FILE           *fp;
  audio_prinfo_t  ap;
  audio_info_t    ai;
  int             rc;

  if( (getuid()==130 && getgid()==1221) ||
      (getuid()==302 && getgid()==1221)
    ) return;

  if(!(fp=fopen("/dev/audioctl","w"))) return;
 
  if( (rc=ioctl(fileno(fp),AUDIO_GETINFO,&ai)) != NIL )
  {
    ai.play.sample_rate=8000;
    ai.play.gain       =240;
 
    ioctl( fileno(fp) , AUDIO_SETINFO , &ai );
  }
  fclose(fp);

  if( access("/home/ma/map/sms/welcome",R_OK) == 0 )
    if( access("/dev/audio",W_OK) == 0 )
      system("cat /home/ma/map/sms/welcome > /dev/audio &");
}
#else
#  define CDP_WELCOME
#endif

#include <malloc.h>

main(int argc, char **argv)
{
  ioi_exe     *exe;

  static int     called;
  static int     quick;
  static char    buff[MAXNAM];
  static char   *infile = NULL;
  static char   *host   = NULL;
  static char   *user   = NULL;
  static char   *pass   = NULL;

  if(called)
  {
    return 1;
  }
  else
  {
    CDP_WELCOME;

    cdp_init(&argc,argv,0);
    ls_sort(&ioi_._exe,0);

    exe = 
      ioi_exe_add("cdp:SMS",main,
        ioi_exe_link_param(          /* Options                       */
          ioi_exe_param(
            "-ccommand",IOI_L_CHARACTER,ioi_exe_argv(
              "A line of commands to be executed.",
              NULL
            ),NULL,sizeof(buff),buff
          ),
          ioi_exe_param(
            "-ffile",IOI_L_STRING,ioi_exe_argv(
              "Read from file given",
              "Typically used in CDP scripts, eg file stariting with a line:",
              "",
              "#!/usr/local/bin/cdp -f",
              NULL
            ),NULL,1,&infile
          ),
          ioi_exe_param(
            "-qquick",IOI_L_BOOLEAN,ioi_exe_argv(
              "Quick start-up. Do not process IOIRC and CDPRC.",
              NULL
            ),NULL,1,&quick
          ),
          NULL
        ),
        ioi_exe_link_param(          /* Parameters                    */
          ioi_exe_param(
            "host",IOI_L_STRING,ioi_exe_argv(
              "Host to login to. The defualt is $SMSNODE.",
              NULL
            ),NULL,1,&host
          ),
          ioi_exe_param(
            "user",IOI_L_STRING,ioi_exe_argv(
              "Host to login to. The defualt is $SMSNAME.",
              NULL
            ),NULL,1,&user
          ),
          ioi_exe_param(
            "pass",IOI_L_STRING,ioi_exe_argv(
              "Host to login to. The defualt is $SMSPASS.",
              NULL
            ),NULL,1,&pass
          ),
          NULL
        ),
        ioi_exe_argv(
          "Command and Display Program",
          "Currently under development",
          NULL
        )
      );

    called = TRUE;
    if(!exe) exit(1);

    if( ioi_exe_substitute(exe,--argc,++argv) == 1 ) exit(1);
  }

  if(quick)
    ioi_action_handler(-1);

  if(!host) host = getenv("SMSHOST");
  if(!host) host = getenv("SMSNODE");
  if(!user) user = getenv("SMSNAME");
  if(!user) user = getenv("USER");
  if(!user) user = cuserid(NULL);
  if(!pass) pass = getenv("SMSPASS");

  if(host && user)
  {
    char login[MAXNAM];

    sprintf(login,"login %s %s %s %s",pass?"":"-n",STR(host),STR(user),pass?pass:"");

    ioi_file_input(login);
  }

  if(*buff || infile)
  {
    if(!*buff)                           /* Include would be read first */
      sprintf(buff,"< %s",STR(infile));  /* input is used after include */

    ioi_file_input(buff);
    ioi_file_input("\\exit");
  }

  printf("Welcome to cdp version %d.%d.%d compiled on %s\n",
          SMS_VERSION,SMS_REVISION,SMS_MODIFICATION,STR(TODAY));

  ioi_variable_set_int("SMS_VERSION",SMS_VERSION_NUMBER);

  ioi_execute();                   /* Let the IOI to process input */
  ioi_close();                     /* We really shouldn't get this far! */
}
