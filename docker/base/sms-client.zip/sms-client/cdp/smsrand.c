/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     RAND
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-JUL-1992 / 04-NOV-1991 / OP
.VERSION  4.0
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE      rand.c
$  smsrand probability
|    probability = [0.0 - 1.0)
?  exit with TRUE (0) or FALSE(1) randomly with the probability given
|  with probability == 0.0 rand exits with TRUE and
|  with probability == 1.0 rand exits with FALSE.
*
* compile: cc -o rand rand.c
*
************************************o*************************************/

#include <stdio.h>
#include <sys/types.h>

/*
 *  This 1 was taken from the file misc.c
 */

#if (! defined ( hpux )) && (! defined ( linux)) && (! defined (FUJITSU)) && (! defined (__alpha))
double sms_drand48(void)
/**************************************************************************
?  Random number with timedependent seed.
=  [0.0 - 1.0)
~  drand48(3) srand48(3) rand(3)
************************************o*************************************/
{
  extern double drand48();
  extern void   srand48();
  static int    been_here;

  if( !been_here )
  {
#if defined(RAND_ONLY) || defined(VMS)
    srand( (int) time(NULL) + getpid() );
#else
    srand48( (long) time(NULL) + getpid() );
#endif
    been_here = 1;                 /* TRUE */
  }

#if defined(RAND_ONLY) || defined(VMS)
  return (rand()&0xffff) / 65535.0001;
#else
  return drand48();
#endif
}
#endif

main(int argc, char **argv)
{
  extern double atof();
  double probability = 0.5;

  if( argc>1 )
    probability = atof(argv[1]);

  if( probability<=0.0 ) exit(0);
  if( probability>=1.0 ) exit(1);
  
  exit( (sms_drand48()+probability)<1.0 );
}

