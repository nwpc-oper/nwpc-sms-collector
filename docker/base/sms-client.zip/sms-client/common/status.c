/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     STATUS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     08-JUL-1992 / 29-AUG-1991 / OP
.VERSION  4.0
.FILE     status.c
*
.DATE     13-SEP-1994 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
*         Added support for meter and label structures
.DATE     09-JUN-1995 / 08-DEC-1994 / OP
.VERSION  4.3.5-9
*         Bug fix in status forceing for flags
*         Don't automatically re-send aborted jobs if they were killed
*         Status of label change to have a klunge... (4.3.8)
*         Delete password upon completion or abort of a task
.DATE     20-SEP-1995 / 20-SEP-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     27-SEP-1995 / 26-SEP-1995 / OP
.VERSION  4.3.11
.DATE     05-OCT-1995 / 05-OCT-1995 / OP
*         Added per node logging
*         Changed the message logging not to propagate upwards
*         Bug fix; don't clear FLAG_MESSAGE
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Added autorestore
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.16
*         Added defstatus complete for a family
.DATE     30-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
.DATE     07-AUG-1998 / 22-JUL-1998 / OP
.VERSION  4.3.21
*         Running job limit
*         Cleaning up + prototypes
.DATE     25-JAN-1999 / 23-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Zombie passwords
*         Limit (pseudo queues)
*         Aliased tasks
*
*  Modify the status of the nodes.
*
************************************o*************************************/

#include "smslib.h"

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

static char workspace[MAXLEN];

static void sms_status_tree(sms_tree *tp, sms_list **lp)
/**************************************************************************
?  Generate the listing of the nodes dependent.
=  Text added into the LP.
************************************o*************************************/
{
  if( !tp ) return;                /* If the root is empty! */

  if( tp->mtype == M_NAME )
    if( tp->math )
      if( tp->math->type == NODE_EVENT )
      {
        sprintf(workspace,"%-30s event %s",
          STR(sms_node_full_name( tp->math->parent )),
          STR(tp->math->name) );
        sms_list_add(lp,sms_node_create(workspace));
      }
      else                         /* task/family/suite */
      {
        sprintf(workspace,"%-30s currently %s",
          STR(sms_node_full_name( tp->math )),
          STR(status_name[tp->math->status]) );
        sms_list_add(lp,sms_node_create(workspace));
      }
    else
      ;                            /* It's the status name! */
  else
  {
    if( tp->left )
      sms_status_tree(tp->left,lp);

    if( tp->right )
      sms_status_tree(tp->right,lp);
  }
}

int sms_status_mask(int def, char *mask)
/**************************************************************************
?  Convert single characters in "mask" into bitpatters.
|  Return default if mask not given or is empty
=  Bit pattern of masks
************************************o*************************************/
{
  if( mask && *mask )
  {
    int i;

    def = 0;
      for( ; *mask ; mask++ )
        for( i=0 ; i<STATUS_SHUTDOWN ; i++ )
          if( status_char[i][0] == *mask )
            def |= (1<<i);
  }

  return def;
}

sms_list *sms_status_why(sms_node *np)
/**************************************************************************
?  Check what and why the node is waiting for. This is walid only for the
|  tasks that are queued. Otherwise the rule is:
|--------------------------------------------------------------------------
|  STATUS_SUSPENDED:  waiting for resume command
|  STATUS_ABORTED:    not waiting for anything
|  STATUS_COMPLETE:   not waiting for anything
|  STATUS_SUBMITTED:  waiting for the job to signal start
|  STATUS_ACTIVE:     waiting for the job to finish or abort
=  Text lines, NULL indicates that it's not waiting anything.
************************************o*************************************/
{
  sms_list *lp = NULL;

  if( !np ) return NULL;
  if( np->type == NODE_SUPER ) return NULL;

  if( np->status == STATUS_UNKNOWN )
    lp = sms_node_create("waiting for the suite to begin");
  else if( np->status == STATUS_QUEUED )
  {
    if( !(lp=sms_time_why(np)) )
      if( sms_status_trigger2(np,NODE_TRIGGER) )
      {
        lp = sms_node_create("waiting for trigger");
        sms_status_tree(np->trigger->math,&lp);
      }
      else
      switch( np->parent->status )
      {
        case STATUS_QUEUED:
        case STATUS_UNKNOWN:
          lp = sms_node_create("waiting for the parent");
          break;
        case STATUS_SUSPENDED:
          lp  = sms_node_create("the parent is suspended");
        default:
          lp = sms_node_create("Should really be running! ERROR!!!");
      }
  }
  /* else it must be obvious */

  return lp;
}

int sms_status_privilege(sms_node *np)
/**************************************************************************
?  Check if the node can be modified by the current connection. (only in SMS)
|  - User is an operator (currently password was given)
|  - Nodes user dependency, if any, is solved by the user.
=  TRUE if the user is free to modify this node, FALSE otherwise.
************************************o*************************************/
{
  sms_user *up;

  if( sms_._current_con == NULL )  /* SMS itself, most likely 2 B Ok :-) */
    return TRUE;

  if( sms_._current_con->passok & PR_OPER )
    return TRUE;

  /* if( np->type == NODE_EVENT ) */
  if( np->type != NODE_SUPER && np->type != NODE_SUITE && np->type != NODE_FAMILY &&
      np->type != NODE_TASK  && np->type != NODE_ALIAS )
    np = np->parent;

  while( np )
  {
    if( up = np->user )            /* There is user dependency */
    {
      while( up )
        if( up->uid == sms_._current_con->uid )
          return TRUE;
        else
          up = up->next;

      return FALSE;                /* User not found in this list! */
    }
    np = np->parent;
  }

  return TRUE;                     /* No user dependencies on given node */
}

int sms_status_validate(sms_node *np)
/**************************************************************************
?  Reset the node status to unknown.
************************************o*************************************/
{
  sms_trigger *tp = np->trigger;
  sms_node *original = np;

  np->status = STATUS_UNKNOWN;
  np->flags  = 0;                  /* Clear all bits */

  if(np->log)
    FLAG_SET(np,FLAG_MESSAGE);

  while(tp)                        /* Currently only one! */
  {
    tp->act_no = ++sms_._action_number;
    tp->status = TRIGGER_NORMAL;
    tp = tp->next;
  }

  if(np->type == NODE_TASK)
  {
    sms_event *ep = np->event;
    sms_meter *mp = np->meter;

    while(ep)
    {
      ep->act_no = ++sms_._action_number;
      ep->status = EVENT_CLEAR;
      ep = ep->next;
    }

    while(mp)
    {
      mp->act_no = ++sms_._action_number;
      mp->status = mp->min;
      mp = mp->next;
    }
  }
  else
  {
    np = np->kids;
    while(np)
    {
      sms_status_validate(np);
      np = np->next;
    }
  }

  SUITE_CHANGED(original);

  return 0;
}

static void force_complete(sms_node *np)
/**************************************************************************
?  Force a tree to complete
|  Used when family is complete by default
************************************o*************************************/
{
  if(!np) return;

  if( np->type == NODE_ALIAS )
    return;

  for( ; np ; np=np->next )
  {
    force_complete(np->kids);

    if( np->status == STATUS_SUSPENDED )
      np->savedstat = STATUS_COMPLETE;
    else
      np->status = STATUS_COMPLETE;

    SUITE_CHANGED(np);

    if( np->status == STATUS_COMPLETE )
    {
      sms_restore_auto(np);              /* Autorestore others     */
      sms_time_autocm(np,NODE_MIGRATE);  /* mark the automigrate   */
      sms_time_autocm(np,NODE_CANCEL);   /* mark the autocancel    */
    }
  }
}

int sms_status_default(sms_node *np)
/**************************************************************************
?  Reset the node status to the default values reqursively.
|  Used by the begin command and automatic restart of the suite,
|  requeue command, and the repeated time nodes.
************************************o*************************************/
{
  sms_node    *original = np;
  sms_trigger *tp = np->trigger;

  np->status = np->defstatus;
  np->rid    = 0;                 /* Request ID not known */
  np->flags  = 0;                 /* Clear all flags      */

  if(np->log)
    FLAG_SET(np,FLAG_MESSAGE);

  if( np->status == STATUS_SUSPENDED )
    np->savedstat = STATUS_QUEUED;
 
  sms_passwd_zombie(np);

  np->tryno = 0;

  while( tp )                    /* Currently only one! */
  {
    tp->act_no = ++sms_._action_number;
    tp->status = TRIGGER_NORMAL;
    tp = tp->next;
  }

  if( np->type == NODE_TASK || np->type == NODE_ALIAS )
  {
    sms_event *ep = np->event;
    sms_meter *mp = np->meter;

    while( ep )
    {
      ep->act_no = ++sms_._action_number;
      ep->status = EVENT_CLEAR;
      ep = ep->next;
    }

    while( mp )
    {
      mp->act_no = ++sms_._action_number;
      mp->status = mp->min;
      mp = mp->next;
    }
  }
  else
  {
    sms_node *kid = np->kids;
    int       max_kid;

    while(kid)
    {
      sms_status_default(kid);
      kid = kid->next;
    }

    if( (max_kid=sms_status_max(np->kids)) != np->status )
    {
      if(np->status == STATUS_SUSPENDED)
        np->savedstat = max_kid;
      else
        np->status = max_kid;
    }
  }

  if(np->type == NODE_FAMILY && np->defstatus == STATUS_COMPLETE)
  {
    force_complete(np->kids);
    np->status = STATUS_COMPLETE;
  }

  SUITE_CHANGED(original);

  return 0;
}

int sms_status_max(sms_node *np)
/**************************************************************************
?  Calculate the maximum status of the nodes given.  
=  MAX status of the nodes given 
|  If none is given == STATUS_UNKNOW
************************************o*************************************/
{
  int max_stat = STATUS_UNKNOWN;

  while( np )
  {
    max_stat = MAX( max_stat ,
                    np->status==STATUS_SUSPENDED?
                    np->savedstat: np->status);
    np = np->next;
  }

  return max_stat;
}

int sms_status_change_meter(sms_meter *np, int to)
/**************************************************************************
?  Change the status of a meter to the value given
=  TRUE if ok FALSE otherwise
************************************o*************************************/
{
  if( to == np->status )
    return TRUE;

  if( to < np->min || to > np->max )
    return spit(FALSE,IOI_ERR,"meter:%s: %d out of range [%d - %d]",
          STR(sms_node_full_name(np)),to,np->min,np->max);

  np->status = to;

  spit(0,IOI_LOG,"meter:%s to %d%s",STR(sms_node_full_name(np)),to,
        (np->parent->status==STATUS_SUSPENDED)?" <--- still suspended":"");
  
  SUITE_CHANGED((sms_node *)np);
  return TRUE;
}

int sms_status_change_label(sms_label *np, char *to)
/**************************************************************************
?  Change the value of a label to a sting given
=  TRUE if ok FALSE otherwise
************************************o*************************************/
{
  char *t = to;

  if( np->value )
    if( strcmp(to,np->value)==0 )
      return TRUE;

  IFFREE(np->value);
  np->value=strdup(to);

  while( *t++ )                    /* For logfile only */
    if( *t == '\n' )
      *t = '|';

  spit(0,IOI_DBG,"label:%s to %s%s",STR(sms_node_full_name(np)),STR(to),
        (np->parent->status==STATUS_SUSPENDED)?" <--- still suspended":"");
  
  SUITE_CHANGED((sms_node *)np);
  return TRUE;
}

int sms_status_change(
    sms_node *np,
    int       to,
    int       force,
    int       recursively)
/**************************************************************************
?  Change the status of the node to the given one.
|  Also update the parent by calculating the maximum value of the
|  brothers status.
|
|  Only TRUE/FALSE is allowed for the events.
|  Events doesn't "follow" the status.
|
=  TRUE if ok FALSE otherwise
************************************o*************************************/
{
  static int  level    = 0;          /* Level or recursion */

  sms_node   *brother  = NULL;
  sms_node   *tmp;
  int         max_stat = STATUS_UNKNOWN;

  sms_node   *msg_np   = sms_._node; /* Remember to put the logging node back */
  int         old_status;

  if( np->type==NODE_METER )
    return sms_status_change_meter((sms_meter *)np,to);
  if( np->type==NODE_LABEL )
    return sms_status_change_label((sms_label *)np,(char *)to);

  if( np->type != NODE_SUPER  && np->type != NODE_SUITE &&
      np->type != NODE_FAMILY && np->type != NODE_TASK  &&
      np->type != NODE_ALIAS  && np->type != NODE_EVENT )
    return FALSE;

  if( to == np->status && (np->type==NODE_EVENT || to != STATUS_SUSPENDED) )
    return TRUE;

  if( to<STATUS_RESUME || to>((np->type==NODE_EVENT)? EVENT_SET:STATUS_USABLE) )
    return FALSE;

  if( ! IS_RUNNING && np->type==NODE_SUPER )
    return TRUE;

  if( IS_DYING )                   /* DONNO BOUT THIS */
    return spit(FALSE,IOI_WAR,"status-change:currently dead");

  if( np->type == NODE_EVENT )
  {
    np->status = to;

    spit(0,IOI_LOG,"%s:%s%s",
          STR(event_name[to]), STR(sms_node_full_name(np)) ,
          (np->parent->status==STATUS_SUSPENDED)?" <--- still suspended":""
        );
  }
  else
  {
#if 0
    if(sms_._node)
      LOGGING(np);
#endif

    old_status = (np->status==STATUS_SUSPENDED)? np->savedstat : np->status;

    switch( to )
    {
      case STATUS_RESUME:
        if( np->status != STATUS_SUSPENDED ) return TRUE;       /* It's OK! */

        np->status    = np->savedstat;
        np->savedstat = (np->status==STATUS_SUSPENDED)?
                        STATUS_QUEUED : STATUS_UNKNOWN;         /* FIX THIS */
        level++;

        if(recursively)
          if( np->status != STATUS_SUSPENDED )
            for( tmp=np->kids ; tmp ; tmp=tmp->next )
            {
              if(msg_np) LOGGING(tmp);
              sms_status_change(tmp,to,force,recursively);
            }
        LOGGING(msg_np);

        if( ! --level )
          spit(0,IOI_MSG,"resume%s:%s back to %s",
               (recursively)? ":recursively" : "" ,
               STR(sms_node_full_name(np)),STR(status_name[np->status]));
        break;

      case STATUS_SUSPENDED:
        if( np->status == STATUS_UNKNOWN )
        {
          np->defstatus = to;
          SUITE_CHANGED(np);

          spit(0,IOI_WAR,"status:default for %s changed to %s",
               STR(sms_node_full_name(np)),STR(status_name[to]));

          if(recursively)
            spit(0,IOI_WAR,"suspend:option recursively ignored");

          return TRUE;
        }

        if( np->status != STATUS_SUSPENDED )
        {
          np->savedstat = np->status;
          np->status    = to;
        }

        level++;

        if(recursively)
          for( tmp=np->kids ; tmp ; tmp=tmp->next )
          {
            if(msg_np) LOGGING(tmp);
            sms_status_change(tmp,to,force,recursively);
          }
        LOGGING(msg_np);

        if( ! --level )
          spit(0,IOI_MSG,"suspend%s:%s at status %s",
               (recursively)? ":recursively" : "" ,
               STR(sms_node_full_name(np)),STR(status_name[np->savedstat]));
        break;

      default:
        if( np->type == NODE_EVENT )
          np->status = to;
        else
        {
          if( np->status == STATUS_SUSPENDED )
            np->savedstat = to;
          else
            np->status = to;
        }

        if(force)                  /* Stop SMS from resendning force-aborted task */
          if(to==STATUS_ABORTED)
            FLAG_SET(np,FLAG_FORCE_ABORT);
          else
            FLAG_CLEAR(np,FLAG_FORCE_ABORT);
        else
          if(to==STATUS_ABORTED && np->type == NODE_TASK)
            FLAG_SET(np,FLAG_TASK_ABORTED);

        spit(0,(to==STATUS_ABORTED)? IOI_ERR:IOI_LOG,"%s:%s%s",
             STR(status_name[to]),
             STR(sms_node_full_name(np)) ,
             (np->status==STATUS_SUSPENDED)?" <--- still suspended":""
            );

        if(  (to==STATUS_ABORTED || to==STATUS_QUEUED  ||
              to==STATUS_ACTIVE  || to==STATUS_SUBMITTED ) &&
             (np->type == NODE_TASK || np->type == NODE_FAMILY) )
        {
          sms_node *parent = np->parent;

          while( parent && parent->type != NODE_SUITE )
            parent = parent->parent;

          np->stime = parent? parent->stime : 0;
        }

    } /* switch */
  }

  SUITE_CHANGED(np);

  if( np->type == NODE_TASK &&
     (to==STATUS_COMPLETE || to==STATUS_QUEUED || to==STATUS_ABORTED) )
    sms_passwd_zombie(np);

  if( (np->type==NODE_TASK || np->type==NODE_ALIAS) &&
      (to != STATUS_ACTIVE) &&
      (old_status==STATUS_ACTIVE || old_status==STATUS_SUBMITTED) )
    sms_limit_remove(np);

  if( !force && np->type != NODE_EVENT && np->action )
  {
    sms_action *ap = np->action;

    while( ap )
    {
      if( ap->when == np->status )
        spit(0,IOI_WAR,"action:%s for %s not taken (sorry!)",STR(ap->name),
             STR(sms_node_full_name(np)));
      ap = ap->next;
    }
  }

  if( np->status == STATUS_COMPLETE )
  {
    np->rid = 0;
    sms_time_used( np );

#ifdef SMS_STATISTICS
    if( np->type == NODE_SUITE )   /* The autorepat for the suite */
      smss_._suite_complete++;
#endif

    sms_repeat_node(np);
  }

  if( np->status == STATUS_COMPLETE )  /* If it's still complete */
  {
    sms_restore_auto(np);              /* Autorestore others     */
    sms_time_autocm(np,NODE_MIGRATE);  /* mark the automigrate   */
    sms_time_autocm(np,NODE_CANCEL);   /* mark the autocancel    */
  }

  if( to == STATUS_SUSPENDED && level )
    return TRUE;

  if( np->parent && np->type != NODE_EVENT && np->type != NODE_ALIAS )
  {
    int rc;

    LOGGING(0);
    rc = sms_status_change(np->parent,sms_status_max(np->parent->kids),
                           FALSE,FALSE);         /* NOT RECURSIVELY */
    LOGGING(msg_np);
    return rc;
  }
  return TRUE;
}

double sms_status_evaluate(sms_tree *node)
/**************************************************************************
?  Calculate the value of the expression.
|  Copied from the IOI/MATH.C (with modifications)
************************************o*************************************/
{
#ifdef CRAY
  void (* sig)() = signal(SIGFPE,SIG_IGN);
#endif

  double left=0.0 , right=0.0 , rc=0.0;

  if( !node ) return( 0.0 );       /* If the root is empty! */

  if( node->mtype == M_NAME )
    if( node->math )
      return (double) node->math->status ;
    else
    {
      int value;

      value = ioi_user_cmdf(node->name,status_name,NULL,STATUS_USABLE);

      if( value == NIL )
        value = ioi_user_cmdf(node->name,event_name,NULL,EVENT_MAX);

      if( isdigit(node->name[0]) )
        value=atoi(node->name);

#ifdef SMS_CROSS_SUITE             /* The SMS must work anyway */
      if(value == NIL)
        value = STATUS_UNKNOWN;    /* External unknown node */
#endif

      return (double) value;
    }

  if( node->left )
    left = sms_status_evaluate(node->left);

  if( node->right )
    right = sms_status_evaluate(node->right);

  switch( node->mtype )
  {
    case M_OR   : rc = (left || right); break;
    case M_AND  : rc = (left && right); break;
    case M_EQ   : rc = (left == right); break;
    case M_NE   : rc = (left != right); break;
    case M_LT   : rc = (left <  right); break;
    case M_LE   : rc = (left <= right); break;
    case M_GT   : rc = (left >  right); break;
    case M_GE   : rc = (left >= right); break;
    case M_ADD  : rc = (left +  right); break;
    case M_SUB  : rc = (left -  right); break;
    case M_MUL  : rc = (left *  right); break;
    case M_DIV  : rc = (left /  right); break;
    case M_MOD  : rc = (((int)left) % ((int)right)); break;
    case M_POW  : rc = pow(left,right); break;
    case M_NOT  : rc = (right)?0:1; break;
    case M_UNARY: rc = -right; break;
    case M_OPEN : rc = right; break;
  }

  return rc;
}

int sms_status_trigger_wait(sms_node *np, sms_trigger *tp)
/**************************************************************************
?  Calculate the status of the task wait trigger.
|  Is the running task held by the trigger?
=  BOOLEAN status.
|  TRUE  == DEPENDENT, 
|  FALSE == FREE to go
************************************o*************************************/
{
  if( !np ) return FALSE;
  if( ! tp ) return FALSE;

  sms_node_get_trigger(tp->math,np);

  if( sms_status_evaluate(tp->math) == 0.0 )
  {
    if( ! FLAG_ISSET(np, FLAG_WAIT) )
      SUITE_CHANGED(np);
    FLAG_SET(np, FLAG_WAIT);
    return TRUE;
  }

  if( FLAG_ISSET(np, FLAG_WAIT) )
    SUITE_CHANGED(np);

  FLAG_CLEAR(np, FLAG_WAIT);
  return FALSE;
}

int sms_status_trigger2(sms_node *np, int type)
/**************************************************************************
?  Calculate the status of the trigger. Is the node held by the trigger?
=  BOOLEAN status.
|  TRUE  == DEPENDENT, 
|  FALSE == FREE to go (might also be freed by the operator)
************************************o*************************************/
{
  sms_trigger *tp = 0;

  if( !np ) return FALSE;

  {
    sms_node *tmp = np;

    while( tmp )
      if( tmp->status == STATUS_SUSPENDED )
        return TRUE;
      else
        tmp = tmp->parent;
  }

  if( type == NODE_TRIGGER )
    tp = np->trigger;
  if( type == NODE_COMPLETE )
    tp = np->complete;

  if( ! tp ) return FALSE;

#ifdef SMS_CROSS_SUITE
  if(tp->mod_no < sms_._modify_number)
  {
    sms_node_get_trigger(tp->math,np);
    tp->mod_no = sms_._modify_number;
  }
#endif

  if(tp->status == TRIGGER_FREE)   /* Operator has deleted it */
    return FALSE;

  if( sms_status_evaluate( tp->math ) == 0.0 )
    return TRUE;
  else
    return FALSE;
}

int sms_status_trigger(sms_trigger *tp)
/**************************************************************************
?  Calculate the status of the trigger.
=  BOOLEAN status.
|  TRUE  == DEPENDENT, 
|  FALSE == FREE to go (might also be freed by the operator)
|  Old broken version of status processing
************************************o*************************************/
{
  if( !tp )
    return FALSE;

#ifdef SMS_CROSS_SUITE
  if(tp->mod_no < sms_._modify_number)
  {
    sms_node_get_trigger(tp->math,sms_._super);
    tp->mod_no = sms_._modify_number;
  }
#endif

  if(tp->status == TRIGGER_FREE)   /* Operator has deleted it */
    return FALSE;

  if( sms_status_evaluate( tp->math ) == 0.0 )
    return TRUE;
  else
    return FALSE;
}

int sms_status_process(sms_node *np)
/**************************************************************************
?  Process the node.
|  Send the free jobs to run.
=  BOOLEAN status if there still is something to do.
************************************o*************************************/
{
  sms_node *kids;
  int       kids_modified;         /* Status if kids were modified */

  if( !np ) return FALSE;

#if 0
  if(np->type == NODE_SUITE)
    sms_time_suite_repeat(np);
#endif

  if( np->status == STATUS_QUEUED && 
      ( np->type==NODE_FAMILY || np->type==NODE_TASK ) )
    if( np->complete && ! sms_status_trigger2(np,NODE_COMPLETE) )
    {
      force_complete(np->kids);
      FLAG_SET(np,FLAG_BYRULE);
      sms_status_change(np,STATUS_COMPLETE,0,0);
      spit(0,IOI_MSG,"complete:%s by rule",STR(sms_node_full_name(np)));
    }

  if( np->type == NODE_TASK )
  {
    if( np->status == STATUS_QUEUED || 
      ( np->status == STATUS_ABORTED && np->tryno < sms_variable_tries(np) ) )
    {
      if( FLAG_ISSET(np,FLAG_FORCE_ABORT) )
        return FALSE;

      if( FLAG_ISSET(np,FLAG_KILLED) && np->status == STATUS_ABORTED )
        return FALSE;

      if( sms_time_dependent(np) ) return FALSE;
      if( sms_status_trigger2(np,NODE_TRIGGER) ) return FALSE;  
#if 0
      if( sms_limit_reached(np) ) return FALSE;
#endif

      np->tryno++;                 /* Must be after the send! */
      sms_edit_send(np);           /* May send aliases also   */

      return TRUE;
    }
    else                           /* Nothing else for the TASKs */
      ;
  }
  else
    if( np->status == STATUS_QUEUED    ||
        np->status == STATUS_SUBMITTED ||
        np->status == STATUS_ACTIVE    ||
        np->status == STATUS_ABORTED )
    {
      /* SUITE must not have any of these */
      if( sms_status_trigger2(np,NODE_TRIGGER) ) return FALSE;
      if( sms_time_dependent(np) ) return FALSE;

        do                         /* Loop them at least once */
        {
          kids_modified = FALSE;
          kids          = np->kids;

          while( kids )
          {
            if( ! sms_limit_reached(kids) )
              if( sms_status_process(kids) )
                kids_modified = TRUE;

            kids = kids->next;
          }
        }
        while( kids_modified );

    }

  if( np->type == NODE_SUITE )
    np->modified = FALSE;

  return FALSE;
}

int sms_triggers(sms_node *np)
/**************************************************************************
?  Print out the trigger status.
************************************o*************************************/
{
  while( np )
  {
    if( np->trigger )
    {
      ioi_math_list(stdout,(ioi_node *)(np->trigger->math),0); printf("\n");
        printf("%-30s %d\n",sms_node_full_name(np),
               sms_status_trigger2(np,NODE_TRIGGER));
    }
    sms_triggers(np->kids);
    np = np->next;
  }

  return 0;
}

