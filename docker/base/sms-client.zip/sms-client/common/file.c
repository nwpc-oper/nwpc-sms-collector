/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     FILE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-JUL-1993 / 16-APR-1993 / OP
.VERSION  4.2
.FILE     file.c
.DATE     15-SEP-1994 / 28-FEB-1994 / OP
.VERSION  4.3.2
.FILE     file.c
.LANGUAGE ANSI-C
.DATE     15-SEP-1994 / 28-FEB-1994 / OP
.VERSION  4.3.14
*         Added a check for file size in read
.DATE     10-APR-1997 / 9-APR-1997 / OP
.VERSION  4.3.15
*         Added seek into file read
.DATE     17-OCT-1997 / 17-OCT-1997 / OP
.VERSION  4.3.16
*         Added support to read compressed files.
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     20-JAN-1999 / 30-OCT-1998 / OP
.VERSION  4.4
*         Fetch-command for sms-files
*         RC for read2
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     08-10-2002 / BR
.VERSION  ???
*         Add support for filter in sms_cmd_read
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

#include <sys/types.h>
#include <sys/stat.h>

#define TRICK_FSEEK

#ifdef _STDIO_USES_IOSTREAM
#undef TRICK_FSEEK
#endif

int sms_file_read(char *name, sms_list **lp, int max_lines)
/**************************************************************************
?  Read a file and form a linked list of lines.
|  The lines are added into "lp" which can be of any (sms) type
|  This routine is meant for a small (text) files only
=  BOOLEAN status.
************************************o*************************************/
{
  int       lines = 0;
  char      buff[MAXLEN];
  FILE     *fp;
  static    int levels;            /* Just to be on the safe side */
  char     *newname;

#define USEFASTCODE 1

#if USEFASTCODE
  sms_list *start = NULL;
  sms_list *last  = NULL;
#endif

  if( !name || !*name ) return FALSE;

  if(max_lines == 0) max_lines=99999999;

  if( ! (fp=sms_fopen(name,"r","file-read")) ) return FALSE;

  buff[MAXLEN-1] = '\0';           /* Make sure every line is terminated */

  while( fgets(buff,MAXLEN-1,fp) && lines < max_lines )
  {
#if USEFASTCODE
    sms_list *tp = ls_create(0,(sms_no_newline(buff)));

    if( !start )
      start = last = tp;
    else
    {
      last->next = tp;
      last = tp;

      if( ++lines >= max_lines )
      {
        tp = start->next;
        free(start->name);
        free(start);
        start = tp;
      }
    }
#else
    sms_list_add(lp,sms_node_create(sms_no_newline(buff)));
    lines++;
#endif

  }

#if USEFASTCODE
  ls_join(lp,start);
#endif

  fclose(fp);

  return TRUE;
}

int sms_file_read2(char *name, sms_list **lp, int max_lines, int ispipe,char *filter)
/**************************************************************************
?  Read a file and form a linked list of lines.
|  The lines are added into "lp" which can be of any (sms) type
|  This routine is meant for a small (text) files only
|  This is a speeded up version, and returns last "max_lines" of the
|  file if file is longer than "max_lines"
|  The compress stuff borrowed from ILIB 3.3 (file misc/file.c)
=  SMS_ERROR (SMS_E_OK if everything is ok)
************************************o*************************************/
{
  struct stat st;
  int         size     = 0;
  int         offset   = 0;
  int         seekdone = 0;
  int         lines    = 0;
  char        buff[MAXLEN];
  FILE       *fp;

  unsigned char magic[4];          /* The 'magic!' stamp of the file  */
  char          process[256];      /* To generate the popen command   */
  int           compressed;        /* Is the file compressed?         */
  int           use_popen=FALSE;
  char          filename[MAXLEN];

  sms_list *start = NULL;
  sms_list *last  = NULL;

  if( !name || !*name ) return FALSE;

  if(max_lines == 0) max_lines=99999999;

  strcpy(filename,name);

/* BR: add support for filters */
  if(filter)
  {
	/* Filters are only in filters directory */
	/* sanity check */
	char *p = filter;
	while(*p)
	{
		if(*p == '&' || *p == '|' || *p == ';' || *p == '<' || *p == '>')
			return sms_error(SMS_E_POPEN,"SMS-FILE-READ2: invalid filter %s",STR(filter));

		p++;
	}

	ispipe = 1;
	sprintf(filename,"filters/%s < %s", filter, name);	
  }
/* BR: end */

  if(ispipe)
  {
    use_popen  = TRUE;
    compressed = FALSE;

    if(!(fp=popen(filename,"r")))
      return sms_error(SMS_E_POPEN,"SMS-FILE-READ2: %s",STR(process));
  }
  else
  {
    int reason = SMS_E_OPEN;

    if( ! (fp=fopen(filename,"r")) )
    {
      if( stat(filename, &st) == (-1) )
        reason = SMS_E_NOFILE;

      sprintf(filename,"%s.Z",STR(name));
      fp=fopen(filename,"r");
    }

    if( ! fp )
      return sms_error(reason,"SMS-FILE-READ2: %s",STR(name));

    memset(magic,0,sizeof(magic));
    fread(magic,sizeof(magic),1,fp);
    compressed = (magic[0] == 0x1f && magic[1] == 0x9d);

    if( compressed )               /* Open process for reading */
    {
      fclose(fp);

      spit(0,IOI_DBG,"SMS-FILE-READ2:file %s is compressed",STR(filename));
      sprintf(process,"uncompress -c < %s",STR(filename));
      if(!(fp=popen(process,"r")))
        return sms_error(SMS_E_POPEN,"SMS-FILE-READ2: %s",STR(process));

      memset(magic,0,sizeof(magic));
      fread(magic,sizeof(magic),1,fp);

      compressed = TRUE;
      use_popen  = TRUE;
    }

#ifdef TRICK_FSEEK
    fp->_ptr -= sizeof(magic);
    fp->_cnt += sizeof(magic);
#else
    if(fseek(fp,0L,SEEK_SET)!= 0)    /* No rewind! */
    {
      spit(0,IOI_ERR,"No seek on [%s]\n",(use_popen)?STR(process):STR(filename));
      if(use_popen) pclose(fp);
      else          fclose(fp);
      return sms_error(SMS_E_READ,"SMS-FILE-READ2: no seek for %s",STR(name));
    }
#endif
  }

  if( ! use_popen )
  {
    if( fstat(fileno(fp), &st) == (-1) )
      spit(0,IOI_WAR,"SMS-FILE-READ2:couln't stat file %s",STR(filename));
    else
      size = st.st_size;
  
    if(size>0)
    {
      offset = size - max_lines * GUESSLEN;
      if( offset > 0 )
      {
        if( fseek(fp, offset, SEEK_SET) != 0 )
          spit(0,IOI_WAR,"SMS-FILE-READ2:couln't fseek file %s to %d",STR(filename),offset);
        else
        {
          sprintf(buff,"SEEK in file %s to %d (size is %d)", STR(filename), offset, size);
          seekdone=1;
          ls_add(lp,ls_create(0,buff));
          spit(0,IOI_MSG,"SMS-FILE-READ2:fseek file %s to %d size %d",STR(filename),offset,size);
        }
      }
    }
  }

  buff[MAXLEN-1] = '\0';           /* Make sure every line is terminated */

  while( fgets(buff,MAXLEN-1,fp) )
  {
    sms_list *tp = ls_create(0,(sms_no_newline(buff)));

    if( !start )
      start = last = tp;
    else
    {
      last->next = tp;
      last = tp;

      if( ++lines >= max_lines )
      {
        tp = start->next;
        free(start->name);
        free(start);
        start = tp;
      }
    }
  }

  if( lines >= max_lines )
  {
    int i;
    sprintf(buff,"File %s had %d lines %s; returning last %d lines only",
            STR(filename),lines,
            seekdone? "(after seek)" : "",
            max_lines);
    ls_add(lp,ls_create(0,buff));
    buff[0] = '\0';
    for(i=0;i<6;i++)
      strcat(buff,"<--- cut --->");
    ls_add(lp,ls_create(0,buff));
  }
  ls_join(lp,start);

  if(use_popen) pclose(fp);
  else          fclose(fp);

  return SMS_E_OK;
}

int sms_file_write(char *name, sms_list *lp)
/**************************************************************************
?  Write a file from a linked list of lines.
|  This routine is meant for a small (text) files only
=  BOOLEAN status.
************************************o*************************************/
{
  FILE     *fp;
  time_t    t;

  if( ! (fp=sms_fopen(name,"w","edit-read")) ) return FALSE;

  while(lp)
  {
    fprintf(fp,"%s\n",lp->name?lp->name:"");
    lp = lp->next;
  }

  t = sms_time_t(NULL);

  /* fprintf(fp,"# SMS edit time %s\n",sms_time_c(&t)); */

  fclose(fp);

  return TRUE;
}

char *sms_file_extract(sms_list **gp, sms_node *np)
/**************************************************************************
?  Extract the file from the generic list.
|  The linked list may, and in most cases does, have VARIABLES in the 
|  beginning of the list.
=  The file name
************************************o*************************************/
{
  static char  tmp_name[L_tmpnam];
  char        *fname;
  sms_list    *lp;

  if( np ) sms_variable_generate(np,TRUE,TRUE,NULL,NULL);

  if( sms_._is_server && np )
    fname = sms_variable_get("SMSSCRIPT",np);
  else
    fname = tmpnam(tmp_name);

  lp = *gp;

  while( lp && lp->type == NODE_VARIABLE ) lp = lp->next;

  if( !lp ) return NULL;

  if( sms_file_write(fname,lp) )   /* The file was written */
  {
    lp = *gp;

    if(lp->type != NODE_VARIABLE)  /* Gotto have {} for macro */
    {
      NODE_FREE(*gp,sms_list);
    }
    else
    {
      while( lp->next && lp->next->type == NODE_VARIABLE )
        lp = lp->next;

      NODE_FREE(lp->next,sms_list);
    }
  }

  return fname;
}


#if defined(VMS)

sms_dir *sms_file_dir(char *path, char *pattern) { return NULL; }

#else

#include <sys/stat.h>
#include <dirent.h>

sms_dir *sms_file_dir(char *path, char *pattern, int fullname)
/**************************************************************************
?  Read the directory and generate the listing
************************************o*************************************/
{
  struct dirent *de;
  DIR           *dp;
  struct stat    st;

  sms_dir       *new = NULL;
  sms_dir       *dir = NULL;

  int            ok = TRUE;

  if( (dp=opendir(path)) )
  {
    char name[MAXLEN];
    char *s;

    strcpy(name,path);
    s = name + strlen(path);
    *s++ = '/';

    while( ok && (de=readdir(dp)) != NULL )
    { 
      if( de->d_ino != 0 )
      {
        strcpy(s,de->d_name);

        if( !pattern || strncmp(de->d_name,pattern,strlen(pattern))==0 )
          if( lstat(name,&st) == 0 )
          {
            if( (new = sms_alloc(NODE_DIR)) )
            {
              if(fullname)
              {
                char buff[MAXLEN];
                sprintf(buff,"%s/%s",STR(path),STR(de->d_name));
                new->name = strdup(buff);
              }
              else
                new->name  = strdup(de->d_name);

              new->mode  = st.st_mode;
              new->uid   = st.st_uid;
              new->gid   = st.st_gid;
              new->size  = st.st_size;
              new->atime = st.st_atime;
              new->mtime = st.st_mtime;
              new->ctime = st.st_ctime;

              sms_list_add(&dir,new);
            }
            else
              ok = spit(FALSE,IOI_ERR,"SMS-DIR-LIST:no mem for %s",STR(de->d_name));
          }
          else
            spit(0,IOI_ERR,"SMS-DIR-LIST:couln't stat %s",STR(name));
        else
          ;                        /* Didn't match */
      }
    }
    closedir(dp);
  }
  else
    spit(0,IOI_ERR,"SMS-DIR-LIST:couln't open %s for reading",STR(path));

  return dir;
}
#endif                             /* Other that VMS */

int sms_file_list(FILE *fp, sms_dir *dp)
/**************************************************************************
?  Print the listing
************************************o*************************************/
{
  while(dp)
  {
    fprintf(fp,"%06o %5d %5d %9d %s %s\n",
            dp->mode,dp->uid,dp->gid,dp->size,
            STR(sms_time_c((time_t *)&dp->atime)),
            STR(dp->name));

    dp = dp->next;
  }

  return 0;
}
