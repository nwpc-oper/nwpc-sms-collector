/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CHILD-HEADER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-APR-1992 / 28-AUG-1991 / OP
.VERSION  4.0
.DATE     26-FEB-1993 / 26-FEB-1993 / OP
.FILE     child.h
.VERSION  4.1
.DATE     21-JUL-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     13-FEB-1994 / 13-FEB-1994 / OP
.VERSION  4.2.1
*         Added support for sending messages into SMS log file (smsmsg)
.DATE     04-MAR-1994 / 22-FEB-1994 / OP
.VERSION  4.3
*         Added support for sending meter and label info into SMS
.DATE     20-APR-1995 / 12-DEC-1994 / OP
.VERSION  4.3.4-11
*         Node checkpointing and migration (4.3.4)
*         Re-submission of nodes (4.3.6)
*         Added per node logging (4.3.11)
.DATE     22-APR-1998 / 22-APR-1998 / OP
.VERSION  4.3.18
*         Expire command
.DATE     19-JAN-1999 / 27-NOV-1998 / OP
.VERSION  4.4.0
*         New commands: run, reset, connections, zombies, postings, plug
*         New child command: mail
*         New child command: wait
***************************************************************************
*
*  Command names used by the sms-child programs.
*
************************************o*************************************/

#ifndef SMS_CHILD_H
#define SMS_CHILD_H

static char *child_cmds[] = {
  "smsabort", "smscomplete", "smsevent", "smsinit",
  "smsmsg",   "smsmeter",    "smslabel", "smsmail",
  "smswait",
  "abtt", "endt", "setev",
};

static int sms_child_params[] = {
  0,  0,  1,  0,
  1,  2,  2,  2,
  1,
  0,  0,  1,
};

static int nchild_cmds = sizeof(child_cmds) / sizeof(char *);

#define CMD_SMSABORT     0
#define CMD_SMSCOMPLETE  1
#define CMD_SMSEVENT     2
#define CMD_SMSINIT      3
#define CMD_SMSMSG       4
#define CMD_SMSMETER     5
#define CMD_SMSLABEL     6
#define CMD_SMSMAIL      7
#define CMD_SMSWAIT      8
#define CMD_ABTT         9
#define CMD_ENDT        10
#define CMD_SETEV       11

static char *sms_cmds[] = {
  "users",
  "begin",
  "suspend",
  "resume",
  "cancel",

  "send",
  "force",
  "check",
  "shutdown",
  "restart",

  "terminate",
  "exists",
  "recover",
  "delete",
  "passwd",

  "privileges",
  "scan",
  "sms",
  "alter",
  "halt",

  "file",
  "requeue",
  "dir",
  "manual",
  "suites",

  "order",
  "kill",
  "migrate",
  "restore",
  "resubmit",

  "messages",
  "expire",
  "run",
  "reset",
  "zombies",

  "mail",
  "plug",
  "lock",
  "unlock",

  "jobcheck",
};

#define CMD_USERS       0
#define CMD_BEGIN       1
#define CMD_SUSPEND     2
#define CMD_RESUME      3
#define CMD_CANCEL      4

#define CMD_SEND        5
#define CMD_FORCE       6
#define CMD_CHECK       7
#define CMD_SHUTDOWN    8
#define CMD_RESTART     9

#define CMD_TERMINATE  10
#define CMD_EXISTS     11
#define CMD_RECOVER    12
#define CMD_DELETE     13
#define CMD_PASSWD     14

#define CMD_PRIVILEGES 15
#define CMD_SCAN       16
#define CMD_SMS        17
#define CMD_ALTER      18
#define CMD_HALT       19

#define CMD_FILE       20
#define CMD_REQUEUE    21
#define CMD_DIR        22
#define CMD_MANUAL     23
#define CMD_SUITES     24

#define CMD_ORDER      25
#define CMD_KILL       26
#define CMD_MIGRATE    27
#define CMD_RESTORE    28
#define CMD_RESUBMIT   29

#define CMD_MESSAGE    30
#define CMD_EXPIRE     31
#define CMD_RUN        32
#define CMD_RESET      33
#define CMD_ZOMBIES    34

#define CMD_MAIL       35
#define CMD_PLUG       36
#define CMD_LOCK       37
#define CMD_UNLOCK     38

#define CMD_JOBCHECK   39

#define CMD_

static int sms_privilege[] = {
  0,
  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_PLAY,

  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_OPER | PR_SYSTEM,
  PR_SYSTEM,
  PR_SYSTEM,

  PR_SYSTEM,
  0,
  PR_OPER | PR_SYSTEM,
  PR_USER | PR_OPER,
  PR_ADMIN,

  0 ,
  PR_USER | PR_OPER,
  0 ,
  PR_PLAY,
  PR_SYSTEM,

  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  PR_USER,

  PR_PLAY | PR_SYSTEM,
  PR_USER | PR_OPER,
  PR_PLAY | PR_SYSTEM,
  PR_PLAY | PR_SYSTEM,
  PR_USER | PR_OPER,

  PR_USER | PR_OPER,
  0,
  PR_USER | PR_OPER,
  PR_USER | PR_OPER,
  0,

  PR_USER | PR_OPER,
  PR_PLAY | PR_SYSTEM,

  PR_SYSTEM,
  PR_OPER | PR_SYSTEM,
  0,

  /* 0 | */ PR_USER | PR_PLAY | PR_OPER | PR_SYSTEM | PR_ADMIN,
};

static int sms_params[] = {
  0,  1,  1,  1,  1,
  1,  2,  0,  0,  0,
  0,  1,  0,  2,  8,
  0,  1,  0,  1,  0,
  2,  1,  2,  1,  0,
  2,  0,  0,  0,  1,
  1,  1,  1,  1,  0,
  0,  2,  0,  0,  1,
};

static int nsms_cmds = sizeof(sms_cmds) / sizeof(char *);

#endif   /* SMS_CHILD_H */
