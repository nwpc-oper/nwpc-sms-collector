/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CDP-CMD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-DEC-1992 / 30-OCT-1991 / OP
.VERSION  4.0
.FILE     cdp_cmd.c
.DATE     26-FEB-1993 / 25-FEB-1993 / OP
.VERSION  4.1
.DATE     21-JUL-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     19-AUG-1994 / 21-FEB-1994 / OP
.VERSION  4.3
.DATE     13-OCT-1994 / 19-AUG-1994 / OP
.VERSION  4.3.2
*         Memory manager now optional part
*         Suite registering logic changed
*         + some other minor changes
.LANGUAGE ANSI-C
*         Added support for SMSFILES
.DATE     02-DEC-1994 / 02-DEC-1994 / OP
.VERSION  4.3.3
*         Only nodes needed are updated if NID-reports are used
.DATE     26-SEP-1995 / 08-DEC-1994 / OP
.VERSION  4.3.4-11
*         Node checkpointing and migration (4.3.4)
*         Resubmit (4.3.6)
*         Added per node logging (4.3.11)
.DATE     27-FEB-1998 / 27-FEB-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     23-APR-1998 / 22-APR-1998 / OP
.VERSION  4.3.18
*         expire command added
.DATE     10-JUN-1998 / 10-JUN-1998 / OP
.VERSION  4.3.19
*         expand command added
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     25-JAN-1999 / 10-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Login with nick names
*         Net names for nodes
*         HTML output
*         New commands: run, reset
*         Aliased tasks
*         Primitive talk
*         User and zombie requests
.DATE     11-FEB-1999 / 08-FEB-1999 / OP
.VERSION  4.4.1
*         Locked state
*         Plug modified
.DATE     26-MAR-1999 / 26-MAR--1999 / OP
.VERSION  4.4.2
*         Cancel aliases in bulk
.DATE     17-NOV-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*         XML output started
*
*         CDP commands (most of them)
*         + some XCdp comman wrappers
*
.DATE     28-JUN-2001 / 1-APR-2001 / OP
.VERSION  4.4.5 ABT(c)
*         URL
*         JOBSTATUS
.DATE     08-10-2002 / BR
.VERSION  ???
*         Add support for filter in sms_cmd_read
************************************o*************************************/

#define IOI_MODULE                 /* Want to access the ioi_._argv */

#include "smslib.h"

static char *net_to_full(char *netname)
{
  char *s = netname;

  if(!netname) return 0;

  if(s[0] == '/' && s[1] == '/')
  {
    s += 2;
    while( *s && *s != '/' )
      s++;
  }

  return s;
}

int cdp_check(
    sms_handle *hp,                /* SMS to command                     */
    char       *name,              /* New file name (if not the default) */
    int         mode,              /* One of the check_name[] / smslib.h */
    int         t)                 /* New checkpoint interval (time)     */
/**************************************************************************
?  Checkpoint the SMS or send new parameters.
|  Used by CDP, not by XCDP
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int              rc;             /* Return code */
  char            *argv[4];        /* The SMS client-command   */
  char             c_mode[MAXNAM],c_time[MAXNAM];

  sprintf(c_mode,"%d",mode);
  sprintf(c_time,"%d",t);

  argv[0] = "check";
  argv[1] = name;
  argv[2] = c_mode;
  argv[3] = c_time;

  return sms_client_cmd( hp,4,argv,NULL,0,NULL);
}

#if 0
int cdp_delete(
    sms_handle    *hp,             /* SMS to command                    */
    char          *name,           /* The full name of the node         */
    int            triggers,       /* Mark the triggers to be free 2 go */
    int            time_dep,       /* Remove the time dependency (all)  */
    int            date_dep,       /* Remove the date dependency (all)  */
    int            all,            /* Remove all times/dates            */
    int            permanently,    /* Remove them beyond recovery       */
    sms_list     **lp)
/**************************************************************************
?  Delete the dependencies for the NAME.
|  Used by CDP, not by XCDP
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int              rc;             /* Return code */
  int              options;        /* Well, currently only one */
  char            *argv[2];        /* The SMS client-command   */

  argv[0] = "delete";
  argv[1] = name;

  options = sms_encode(&all,&date_dep,&permanently,&time_dep,&triggers,NULL);

  return sms_client_cmd( hp,2,argv,lp,options,NULL);
}
#endif

int cdp_scan(
    sms_handle    *hp,             /* SMS to command                   */
    char          *name,           /* The full name of the node        */
    int            edit,           /* Flag to request the text also    */
    int            preprocess,     /* Flag to request preprocessin     */
    sms_variable **var,            /* Variables needed to send the job */
    char         **filename)       /* Of the lines, if not NULL        */
/**************************************************************************
?  Scan the NAME for VARiables. With EDIT the lines of the original file
|  will be placed in the FILENAME;
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  If an error occurs the error message is returned in the list *VAR and
|  they are of type NODE_LIST and not NODE_VARIABLE.
************************************o*************************************/
{
  int   rc;                        /* Return code */
  int   options;                   /* Well, currently only one */
  char *argv[2];                   /* The SMS client-command   */

  argv[0] = "scan";
  argv[1] = net_to_full(name);

  options = sms_encode(&edit,&preprocess,NULL);

  NODE_FREE(*var,sms_variable);

  if((rc=sms_client_cmd(hp,2,argv,(sms_list **)var,options,NULL))==SMS_E_OK)
    *filename = edit? sms_file_extract((sms_list **)var,NULL) : NULL;
  else
  {
    sms_list_print(var,stderr);
    NODE_FREE(*var,sms_variable);
  }

  return rc;
}

int cdp_send(
    sms_handle    *hp,             /* SMS to command                   */
    char          *name,           /* The full name of the node        */
    int            alias,          /* Create an alias                  */
    int            run,            /* Run now? or with task if alias   */
    sms_variable **var,            /* Variables needed to send the job */
    char         **filename)       /* Of the lines, if not NULL        */
/**************************************************************************
?  Send the NAME edited with the VARiables. With the FILENAME the original
|  file is not used, but the FILENAME is transmitted instead to be used
|  as the ".sms"-file.
|  If the FILENAME was given it is removed after the call.
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  If an error occurs the error message is returned in the list *VAR and
|  they are of type NODE_LIST and not NODE_VARIABLE.
************************************o*************************************/
{
  int       rc;
  int       options;               /* Well, currently only one */
  char     *argv[2];               /* The SMS client-command   */
  sms_list *gp = NULL;             /* The answer from the SMS  */

  argv[0] = "send";
  argv[1] = net_to_full(name);

  options = sms_encode(&alias,&run,NULL);

  if( *filename ) sms_file_read(*filename,(sms_list **)var,MAXLINES);

  rc = sms_client_cmd(hp,2,argv,&gp,options,(sms_list **)var);

  sms_node_free(*var);
  *var = (sms_variable *)gp;

  if( *filename ) unlink( *filename );

  return rc;
}

int cdp_file(
    sms_handle    *hp,             /* SMS to command                    */
    char          *nodename,       /* The full name of the node         */
    char          *localname,      /* Local filename for SMS in SMSNODE */
    int            maxlines,       /* Max number of lines 2 get         */
    char         **filename)       /* Of the lines, if not NULL         */
/**************************************************************************
?  Ask SMS to send file "localname" and store it in a local (temp) file
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  + filename which is created and must be deleted by the calling routine
|  when it is not needed anymore
************************************o*************************************/
{
  int   rc;                        /* Return code */
  int   options;                   /* Well, currently only one */
  char *argv[3];                   /* The SMS client-command   */

  sms_list *lines = NULL;

  argv[0] = "file";
  argv[1] = net_to_full(nodename);
  argv[2] = localname;

  options = maxlines;              /* We don't really have options */

  if((rc=sms_client_cmd(hp,3,argv,&lines,options,NULL))==SMS_E_OK)
    *filename = sms_file_extract(&lines,NULL);
  else
  {
    sms_list_print(&lines,stderr);
    NODE_FREE(lines,sms_list);
  }

  return rc;
}

int cdp_jobcheck(
    sms_handle    *hp,             /* SMS to command                    */
    char          *nodename,       /* The full name of the node         */
    int            maxlines,       /* Max number of lines 2 get         */
    char         **filename)       /* Of the lines, if not NULL         */
/**************************************************************************
?  Ask SMS to send the output of SMSJOBCHECK and store it in a local (temp) file
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  + filename which is created and must be deleted by the calling routine
|  when it is not needed anymore
************************************o*************************************/
{
  int   rc;                        /* Return code */
  int   options;                   /* Well, currently only one */
  char *argv[3];                   /* The SMS client-command   */

  sms_list *lines = NULL;

  argv[0] = "jobcheck";
  argv[1] = net_to_full(nodename);

  options = maxlines;              /* We don't really have options */

  if((rc=sms_client_cmd(hp,2,argv,&lines,options,NULL))==SMS_E_OK)
    *filename = sms_file_extract(&lines,NULL);
  else
  {
    sms_list_print(&lines,stderr);
    NODE_FREE(lines,sms_list);
  }

  return rc;
}

int cdp_manual(
    sms_handle    *hp,             /* SMS to command            */
    char          *nodename,       /* The full name of the node */
    int            maxlines,       /* Max number of lines 2 get */
    char         **filename)       /* Of the lines, if not NULL */
/**************************************************************************
?  Ask SMS to send manual of the node "nodename" and store it in a local 
| (temp) file
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  + filename which is created and must be deleted by the calling routine
|  when it is not needed anymore
************************************o*************************************/
{
  int   rc;                        /* Return code */
  int   options;                   /* Well, currently only one */
  char *argv[2];                   /* The SMS client-command   */

  sms_list *lines = NULL;

  argv[0] = "manual";
  argv[1] = net_to_full(nodename);

  options = maxlines;              /* We don't really have options */

  if((rc=sms_client_cmd(hp,2,argv,&lines,options,NULL))==SMS_E_OK)
  {
    *filename = sms_file_extract(&lines,NULL);
    ioi_variable_set("smsfilename",*filename?*filename:"");
  }
  else
  {
    sms_list_print(&lines,stderr);
    NODE_FREE(lines,sms_list);
  }

  return rc;
}

int cdp_dir(
    sms_handle    *hp,             /* SMS to command            */
    char          *nodename,       /* The full name of the node */
    char          *pattern,        /* of files to be included   */
    sms_dir      **list)           /* The listing               */
/**************************************************************************
?  Ask SMS to send directory listing of the pattern.
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int   rc;                        /* Return code */
  int   options;                   /* Well, currently only one */
  char *argv[3];                   /* The SMS client-command   */

  /*
   *  This code is NOT active
   */

  NODE_FREE(*list,sms_dir);

  options = 0;

  argv[0] = "dir";
  argv[1] = net_to_full(nodename);
  if( pattern == NULL ) pattern = argv[1] + 1;
  argv[2] = pattern;

  if((rc=sms_client_cmd(hp,3,argv,(sms_list **)list,options,NULL))==SMS_E_OK)
    ;
  else
  {
    sms_list_print(list,stderr);
    NODE_FREE(*list,sms_dir);
  }

  return rc;
}

int cdp_suites(
    sms_handle *hp,                /* SMS to talk to    */
    int         mode,              /* One of SUITES_... */
    sms_list  **list)              /* Input/Output      */
/**************************************************************************
?  Manage suites to be send to the CDP
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int       rc;                    /* Return code */
  char     *argv[1];               /* The SMS client-command   */
  sms_list *lp = NULL;             /* The answer from the SMS  */

  argv[0] = "suites";

  if( mode >= SUITES_NEWIN )
    rc=sms_client_cmd(hp,1,argv,&lp,mode,NULL);
  else
    rc=sms_client_cmd(hp,1,argv,&lp,mode,
        (mode!=SUITES_LIST && mode!=SUITES_MINE)? *list? list:NULL : NULL);

  if( rc==SMS_E_OK )
    ;
  else
  {
    sms_list_print(&lp,stderr);
    NODE_FREE(lp,sms_list);
  }

  if( list )
    *list = lp;

  return rc;
}

int cdp_users(
    sms_handle      *hp,           /* SMS to command */
    int              full,         /* Don't use      */
    sms_connect    **cp)           /* Return users   */
/**************************************************************************
?  Get the users from SMS
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  char        *av[1] = {"users"};
  int          rc;
  sms_connect *con = NULL;

  rc = sms_client_cmd( hp, 1, av, (sms_list **)&con, full, NULL );

  if( cp )
  {
    NODE_FREE(*cp, sms_connect);
    *cp = con;
  }
  else
  {
    if(con && con->type == NODE_CONNECTION)
      sms_list_users(con, full);
    else                           /* Error and 4.3 server */
      ls_print_all(&con,stderr);
      
    NODE_FREE(con, sms_connect);
  }
  return rc;
}

int cdp_zombies(
    sms_handle    *hp,             /* SMS to command             */
    int            cmd,            /* ZOMBIE_xxxx                */
    sms_list      *names,          /* Names if this is a command */  
    sms_zombie   **zp)             /* Return if this is query    */
/**************************************************************************
?  Get the zombies from SMS
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  char     *av[1] = {"zombies"};
  sms_list *lp    = NULL;          /* The answer from the SMS  */
  int       rc;
  int       options = (cmd << 8);  /* Leave space for options  */

  rc = sms_client_cmd( hp,1,av,&lp,options, names? &names:NULL);

  if(zp)
  {
    NODE_FREE(*zp, sms_zombie);
    *zp = (sms_zombie *)lp;

    if(lp && lp->type==NODE_ZOMBIE)
      sms_passwd_zombie_fmt(*zp);
  }
  else
  {
    if(rc==SMS_E_OK && lp && lp->type==NODE_ZOMBIE)
      sms_passwd_zombie_print((sms_zombie*)lp);
    else
      sms_list_print(&lp,stderr);

    NODE_FREE(lp,sms_list);
  }

  return rc;
}

int cdp_mail(
    sms_handle *hp,                /* SMS to command          */
    int         mode,              /* GET, SEND, DEL          */
    int        *number,            /* Line number, (GET, DEL) */
    char       *sendto,            /* Who to send the mail to */
    sms_list  **lines)             /* Input/Output            */
/**************************************************************************
?  Get my mail from SMS
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  char     *av[1] = {"mail"};
  sms_list *lp    = NULL;          /* The answer from the SMS  */
  int       rc;
  int       options = (mode & 0xff) | (*number << 8);

  sms_list *mail = 0;

  if(mode==MAIL_SEND)
  {
    if( !lines || !*lines )
      return sms_error(SMS_E_PROTOCOL,"mail:send to %s nothing?",STR(sendto));

    if( ! (mail=ls_create(0,sendto)) )
      return sms_error(SMS_E_MEMORY,"mail:send to %s",STR(sendto));

    if( lines ) mail->next = *lines;
    rc = sms_client_cmd( hp,1,av,&lp, options, &mail );
    ls_delete(&mail,mail);
    if( lines ) *lines = 0;
  }
  else
    rc = sms_client_cmd( hp,1,av,&lp, options,
                         (lines && *lines)? lines:NULL );

  if(mode==MAIL_GET && lp)
  {
    *number = atoi(lp->name);
    ls_delete(&lp,lp);

#if 0
{
  sms_list *line = lp;

  while(line)
  {
    sms_list *next = line->next;
    char     *s = line->name;


    if( (s=strchr(s, '@')) )
      if( (s=strchr(s, ':')) )
        if(strncmp(s,": SMS",5) == 0)
        {
          s += 5;
          printf("Match is [%s]\n",STR(s));
          ls_delete(&lp,line);
        }

    line = next;
  }
}
#endif

  }

  if(lines && *lines)
  {
    NODE_FREE(*lines, sms_list);
    *lines = lp;
  }
  else
  {
    sms_list_print(&lp,stderr);
    NODE_FREE(lp,sms_list);
  }

  return rc;
}

int cdp_plug(sms_node *into, sms_node *from)
/**************************************************************************
?  Plug node "from" in to "into"
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int   rc;
  char *av[2] = { "plug", 0 };

  sms_handle *hp;

  if( !into || !from ) return SMS_E_NOTFOUND;

  hp = sms_node_find_handle(into);

  av[1] = sms_node_full_name(into);

  return sms_client_cmd_keepgp(hp, 2, av, 0, 0, (sms_list *)from);
}

int cdp_jobstatus(
    sms_handle    *hp,             /* SMS to command          */
    char          *nodename,       /* The full name of the node */
    int            maxlines,       /* Max number of lines 2 get */
    char         **filename)       /* Of the lines, if not NULL */
/**************************************************************************
?  Execute job-status command for the node "nodename" and store it in a
|  local (temp) file
|  Used by both XCDP and CDP (via a wrapper)
=  SMS-ERROR-CODE
|  + filename which is created and must be deleted by the calling routine
|  when it is not needed anymore
************************************o*************************************/
{
  int           rc    = SMS_E_OK;  /* Return code */
  sms_list     *lines = 0;
  sms_node     *np    = 0;
  sms_variable *vp    = 0;
  char          line[MAXLEN];

  if( ! (np=sms_node_net_find(nodename)) )
    sms_error(SMS_E_NOTFOUND,"jobstatus:[%s]",nodename);

  if(np->type != NODE_TASK && np->type != NODE_ALIAS)
    return sms_error(SMS_E_TASK,"jobstatus:[%s]",nodename);

  if( ! (vp=sms_variable_getvar("SMSSTATUSCMD",np)) )
    return sms_error(SMS_E_GLOBALVAR,"jobstatus:no SMSSTATUSCMD for %s",nodename);

  if(sms_edit_string(np,vp->value,line))
  {
    printf("Executing [%s]\n",line);

    if((rc=sms_file_read2(line, &lines, maxlines, 1,NULL))==SMS_E_OK)
    {
      if(sms_._is_xcdp)
      {
        *filename = sms_file_extract(&lines,NULL);
        ioi_variable_set("smsfilename",*filename?*filename:"");
      }
      else
        ls_print_all(&lines,stdout);
    }
    else
      ls_print_all(&lines,stderr);

    NODE_FREE(lines,sms_list);
    return rc;
  }
  else
  {
    spit(0,IOI_ERR,"jobstatus:failed to edit SMSSTATUSCMD for [%s]",nodename);
    return SMS_E_GLOBALVAR;
  }

  return rc;
}

/**************************************************************************
*
*  ROUTINES: (static)
*
*  build_yes()
*  sms_cdp_update(void)
*
*  test()          TEST ONLY (what ever, varies!)
*  info()          netnames
*  find()
*  action()        TEST ONLY
*  suites()
*  sms_register()
*  ping()
*  play()
*  show()
*  playbin()
*  makebin()
*  login()
*  _passwd()
*  privileges()
*  logout()
*  smscmd()        SYSTEM PEOPLE ONLY
*  servers()
*  news()
*  cwn()
*  get()
*  history()
*  users()
*  begin()         netnames
*  resume()        netnames
*  suspend()       netnames
*  cancel()        netnames
*  force()         netnames
*  requeue()       netnames
*  resubmit()      netnames
*  run()
*  dir()
*  file()
* _send()                          // Renemed cos' the VMS protos!
*  mkdirs()
*  check()
*  recover()
* _shutdown()                      // Renemed cos' the VMS protos!
*  halt()
*  restart()
*  terminate()
*  expire()
*  expand()
*  reset()
*  zombies()
*  mail()
*
************************************o*************************************/

static ioi_param *yes;             /* 2 B used 4 loading in to the IOI */
static int        yes_option;      /* The value of the option          */

static void build_yes(void)
/**************************************************************************
?  Build the yes, an option used by many commands.
-USED-BY
|  recover() _shutdown() restart() terminate() halt()
-NOTICE
|  This can only be used as a single (or the last option)
|  The reason is that otherwise the ioi_exe_link_param() would make alter
|  the yes->next field, which would be incorrect.
-CHANGE
|  If needed the text can still be shared, or you might make a cpp-symbol.
************************************o*************************************/
{
  if( !yes ) yes = 
    ioi_exe_param(
      "-yyes",IOI_L_BOOLEAN,ioi_exe_argv(
        "Answer to the confirmation question beforehand. This makes the",
        "scripts much simpler.",
        "",
        "It is higly recommened NOT to use this in interactive use.",
        "",
        "By setting the $cdp_no_confirmation=1 you can preanswer to all",
        "the confirmation questions.",
        NULL
      ),"cdp_no_confirmation",1,&yes_option
    );
}

int sms_cdp_update(sms_handle *hp)
/**************************************************************************
?  Update the internal structure by asking it from the SMS.
=  SMS_ERROR_CODE
************************************o*************************************/
{
  int rc;
  int acn;

  if( sms_._is_xcdp ) return SMS_E_OK;

  if( sms_client_is_ok(hp) != SMS_E_OK )
    return sms_error(SMS_E_NOTIN,"update");

  if( sms_._super )
    if( sms_._super->type != NODE_SUPER )
    {
      NODE_FREE(sms_._super,sms_node);
      sms_._super = NULL;
    }

  if( ! sms_._super )
    sms_._action_number = sms_._modify_number = 0;
  else
    if( ioi_variable_get("NO_UPDATE") ) return SMS_E_OK;

  acn = sms_._action_number;

  if( sms_client_news( hp, acn ) == SMS_E_OK )
  {
    sms_status *st = NULL;

    if( !acn ) acn = NIL;

    if( (rc=sms_client_status(hp,&st,acn)) != SMS_E_OK )
      return rc;

    if( st->node )
    {
      if( st->node->type == NODE_NID )
      {
        sms_nid_update(sms_._super,(sms_nid *)st->node,0,0); /* "Edit" the node-tree  */
#if 0 /* 4.3.3 */
        sms_node_after_receive(sms_._super);       /* Build the variables...*/
#endif
        NODE_FREE(st->node,sms_node);              /* FREE NIDs             */
      }
      else
      {
        NODE_FREE( sms_._super , sms_node );
        sms_._super = st->node;
        st->node = NULL;           /* MOD 25-JAN-1993/OP */
      }
    }
    sms_._action_number = st->action_n;
    sms_._modify_number = st->modify_n;
    sms_._status        = st->status;

    NODE_FREE(st,sms_status);      /* MOD 25-JAN-1993/OP */
  }

  return SMS_E_OK;
}

#include <malloc.h>

static void testit(sms_node *np)
{
  sms_variable *vp;

  if(!np) return;

  if( (vp=ls_find(&np->variable,"SMSPASS")) )
    printf("%s :normal: %s\n",STR(sms_node_full_name(np)),STR(vp->value));
  if( (vp=ls_find(&np->genvars,"SMSPASS")) )
    printf("%s :generated: %s\n",STR(sms_node_full_name(np)),STR(vp->value));

  if(np->passwd)
    printf("%s :field: %s\n",STR(sms_node_full_name(np)),STR(np->passwd));

  for(np=np->kids ; np ; np=np->next)
    testit(np);
}

static int test(int argc, char **argv)
/**************************************************************************
?  Test ... something.
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    sms_node *np;

    if( dummy ) { argc++; argv--; } /* GOT 2 B */

    while( argc-- )
    {
      if( (np=sms_node_net_find(*argv)) )
        testit(np);
      else
        printf("could not find %s\n",STR(*argv));
      argv++;
    }

    return TRUE;
  }
  else
    ioi_exe_add("test:cdp",test,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "netname",IOI_L_STRING,ioi_exe_argv(
            "Network name of an SMS-node.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Test something in the CDP/SMS.",
        "Currently testing migrate password.",
        NULL
       )
    );

  return called = TRUE;
}

static int info(int argc, char **argv)
/**************************************************************************
?  Print the information of the node(s) given
************************************o*************************************/
{
  static int   called;
  static int   variables;
  static char *dummy;

  if( called )
  {
    sms_list *names = NULL;
    sms_node *np = (sms_node *)1;

    if( dummy ) { argc++; argv--; } /* GOT 2 B */

    names = sms_cd_names2(argc,argv,NULL);
    if( !names ) return FALSE;

    while(names && np)
    {
#ifdef USE_NET_NAMES
      if( (np=sms_node_net_find(names->name)) )
        sms_info(np,variables);
#else
      if( (np=sms_node_find_full(names->name)) )
        sms_info(np,variables);
#endif
      else
        printf("%s was not found\n",STR(names->name));

      names = names->next;
      if(names)
        printf("--------------------------------------------------\n");
    }

    return np? TRUE:FALSE;
  }
  else
    ioi_exe_add( "info:cdp",info,
      ioi_exe_link_param(
        ioi_exe_param(
          "-vvariables",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display the variables also. The default is not to display them.",
            "Generated variables are surrounded by [square brackets] and the",
            "node where the variable is defined is also printed.",
            NULL
          ),NULL,1,&variables
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "Node names (relative to $cwn) or full names to be examined",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Print the information of the node(s) requested.",
        "", "NOTICE!", "",
        "Currently under construction,",
        NULL
      )
    );

  return called = TRUE;
}

static int find(int argc, char **argv)
/**************************************************************************
?  Node finder
************************************o*************************************/
{
  static int   called;
  static int   verbose;
  static char *pattern;

  if( called )
  {
    sms_list *names = NULL;
    sms_node *next,*last,*np;

    if( sms_cdp_update(HANDLE) != SMS_E_OK )
      return FALSE;

    names = sms_cd_pattern(pattern,TRUE,NULL);

    if( !names ) return FALSE;

    np=sms_node_find_full(ioi_variable_get("cwn"));
    if(!np) np = sms_._super;

    if( verbose ) sms_list_print(&names,stdout);

    sms_cd_find(pattern,np->nid,sms_._super,&last,&next);

    ioi_variable_set("find_next",sms_node_full_name(next));
    ioi_variable_set("find_last",sms_node_full_name(last));

    return names? TRUE:FALSE;
  }
  else
    ioi_exe_add( "find:cdp",find,
      ioi_exe_link_param(
        ioi_exe_param(
          "-vverbose",IOI_L_BOOLEAN,ioi_exe_argv(
            "Find nodes and list all matching nodes.",
            NULL
          ),NULL,1,&verbose
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "pattern",IOI_L_STRING,ioi_exe_argv(
            "Regular expression of the nodes to find.",
            NULL
          ),NULL,-1,&pattern
        ),
        NULL
      ),
      ioi_exe_argv(
        "Find nodes matching the pattern given.",
        "All nodes in SMS are checked against pattern so the output can be big",
        "$cwn has no effect on this command.",
        "If any of the nodes match the pattern, the variables",
        "  find_next will be set to the next match after $cwn and",
        "  find_last will be set to the last match before $cwn",
        "",
        "$find_next and $find_last are the same if there is only one match.",
        NULL
      )
    );

  return called = TRUE;
}

static int action(int argc, char **argv)
/**************************************************************************
?  Test the action_number.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    printf("Current action number: %d\n",sms_._action_number);
    printf("Current modify number: %d\n",sms_._modify_number);
  }
  else
    ioi_exe_add("actionnumber:cdp",action,NULL,NULL,ioi_exe_argv(
      "Test the action number.",
      TEST_ONLY,
      NULL )
    );

  return called = TRUE;
}

static int suites(int argc, char **argv)
/**************************************************************************
?  Manage suites to be send to the CDP
************************************o*************************************/
{
  static int   called;
  static int   newon;
  static int   newoff;
  static int   delete;
  static int   set;
  static char *dummy;

  if( called )
  {
    sms_list *lp = NULL;
    int       options = 0;
    int       mode = SUITES_LIST;
    int       rc;

    if( dummy ) { argc++; argv--; }

    if( newon ) options++;
    if( newoff ) options++;
    if( delete ) options++;
    if( set ) options++;

    if( options>1 )
      return ioi_out(FALSE,IOI_ERR,"suites:too many options, use only one");

    if( newon || newoff )
      return SMS_NEW_SUITES(newon) == SMS_E_OK;

    if( !options && !dummy )
    {
       if( cdp_suites(HANDLE,SUITES_LIST,&lp) != SMS_E_OK )
         return FALSE;

       if(lp) printf("Suites defined in the SMS %s\n",STR(sms_._logins->name));
       else   printf("No suites defiined in the SMS %s\n",STR(sms_._logins->name));

       ls_fancy(&lp,stdout,LINE_WIDTH);
       NODE_FREE(lp,sms_list);

       if( cdp_suites(HANDLE,SUITES_MINE,&lp) != SMS_E_OK )
         return FALSE;

       if(lp) printf("Suites you are following\n");
       else   printf("You are not follwing any suites :-(\n");

       ls_fancy(&lp,stdout,LINE_WIDTH);
       NODE_FREE(lp,sms_list);

       return TRUE;
    }

    for( ; argc ; argc-- , argv++ )
      ls_add( &lp, ls_create(0,*argv) );

    if( !options ) rc = cdp_suites(HANDLE,SUITES_ADD,   &lp);
    if( set )      rc = cdp_suites(HANDLE,SUITES_SET,   &lp);
    if( delete )   rc = cdp_suites(HANDLE,SUITES_DELETE,&lp);

    sms_._action_number = sms_._modify_number = 0;

    NODE_FREE(lp,sms_list);

    return rc;
  }
  else
    ioi_exe_add("suites:cdp",suites,
      ioi_exe_link_param(
        ioi_exe_param(
          "-nnew",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add new suites into my list when they are created.",
            NULL
          ),NULL,1,&newon
        ),
        ioi_exe_param(
          "-Nnonew",IOI_L_BOOLEAN,ioi_exe_argv(
            "Do not add new suites into my list when they are created.",
            NULL
          ),NULL,1,&newoff
        ),
        ioi_exe_param(
          "-ddelete",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the suites named from the list of suites",
            NULL
          ),NULL,1,&delete
        ),
        ioi_exe_param(
          "-sset",IOI_L_BOOLEAN,ioi_exe_argv(
            "Set the list of suites",
            NULL
          ),NULL,1,&set
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "suite(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the suites to be added by default or",
            "deleted (-d) or set (-s).",
            "If none given suites in sms are listed as well as the ones",
            "currently being followed.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
      "Ask sms for a list of suites",
      "This allowes you to register(CDP) suites that you want to see",
      NULL )
    );

  return called = TRUE;
}

static int sms_register(int argc, char **argv)
/**************************************************************************
?  Register suites into SMS
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    sms_list *lp = NULL;

    if( dummy ) { argc++; argv--; }

    for( ; argc ; argc-- , argv++ )
      ls_add( &lp, ls_create(0,*argv) );

    if( cdp_suites(HANDLE,SUITES_SET,&lp) == SMS_E_OK )
      return TRUE;

    return FALSE;
  }
  else
    ioi_exe_add("register:cdp",sms_register,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "suites-name",IOI_L_STRING,ioi_exe_argv(
            "Suites to register into SMS",
            "If none are given all suites are reported",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Register suites into current SMS",
        "This allowes you to select which suites to follow.",
      NULL )
    );

  return called = TRUE;
}

static int ping(int argc, char **argv)
/**************************************************************************
?  CDP-command ping.
|  Try to figure if a singe host is active.
************************************o*************************************/
{
  static int   called;
  static char *host;

  if( called )
  {
    int rc;

    sms_numbers( ioi_variable_get_int("SMS_PROG") ,
                 ioi_variable_get_int("SMS_VERS") );

    rc = sms_client_ping(host,FALSE,0);

    if(rc) printf("ok\n");
    else   printf("nop\n");

    return rc;
  }
  else
    ioi_exe_add("ping:cdp",ping,NULL,
      ioi_exe_param("host",IOI_L_STRING,ioi_exe_argv(
          "The host name or internet number",
          NULL
        ),NULL,-1,&host
      ),
      ioi_exe_argv(
        "Ping the SMS in the host given",
        "Find out is a single sms located in host alive or not.",
        "","VARIABLES","",
        "SMS_PROG and SMS_VERS control the RPC protocol used",
        NULL
      )
    );

  return called = TRUE;
}

static int play(int argc, char **argv)
/**************************************************************************
?  CDP-command play.
|  A copy of the parameters must be made, since the play command uses
|  IOI to generate the input stream.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   echo;
  static int   local;
  static char  *replace;

  int ok = TRUE;

  if( called )
  {
    if( local || (sms_client_is_ok(HANDLE)==SMS_E_OK) )
      ok = sms_play_definition(dummy,echo,local,replace);
    else
      if( !local )
        ok = ioi_out(FALSE,IOI_ERR,"play:Not connected.");

    return ok;
  }
  else
    ioi_exe_add( "play:cdp",play,
      ioi_exe_link_param(
        ioi_exe_param(
          "-eecho",IOI_L_BOOLEAN,ioi_exe_argv(
            "CDP will echo the lines while reading the definition file(s).",
            "The default is to be absolute quiet except for errors and",
            "commands not understood.",
            NULL
          ),"echo_play",1,&echo
        ),
        ioi_exe_param(
          "-llocal",IOI_L_BOOLEAN,ioi_exe_argv(
            "Generate a local (CDP) copy of the file(s) only. That is, do",
            "not send them to the SMS. The CDP need not to be connected",
            "to a SMS if this option is used.",
            "","NOTICE!","",
            "Only the last file is kept for viewing.",
            "The next play/status will remove the local suite.",
            NULL
          ),NULL,1,&local
        ),
#ifdef SMS_CROSS_SUITE
        ioi_exe_param(
          "-rreplace",IOI_L_STRING,ioi_exe_argv(
            "Replace the node given in the SMS. The node in the SMS is",
            "replaced by the node in the new definition file. This means",
            "that only the contents of the new matching node is replaced",
            "and you can use the original definition file.",
            "",
            "This option overrides the effect of the local option.",
            "",
            "Some SMS's might refuse to accept this option.",
            NULL
          ),NULL,1,&replace
        ),
#endif
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "playfile",IOI_L_PATH,ioi_exe_argv(
            "The name of the file that contain the definitions.",
            "Suite definition must be inside a single file but multiple",
            "suites can be in same file.",
            "",
            "If connected to a SMS the file will be send after reading",
            "and validation, unless the LOCAL-option is used.",
            "",
            "If no file name is given, stdin is read if it is not the",
            "control terminal of the CDP. Eg HERE-document works.",
            "",
            "The stdin can be used to input the suite definition, but",
            "this is still under testing. To terminate the definition",
            "without sending the use illegal definition command.", 
            "To terminate the definition (and send it) use EOF(play) or",
            "end of file character (typically ^D)",
            "","BUGS","",
            "At the moment non-play commands and unknown commands does not",
            "terminate the definition of the suite (errors are reported.)",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define, validate and send the suites to the SMS.",
        "Read the play-files given and define the suites in the files.",
        "If connected, and LOCAL-option is NOT used, the successfull",
        "definition is send to the SMS. The user needs to have privileges",
        "to define suite(s) in the SMS.",
        "", "NOTICE!", "",
        "At the moment the local suite definition is just kept in the CDP",
        "and every new load will destroy the old definition. That really",
        "means that playing multiple files only the last definition",
        "stays in effect.",
        "",
        "You can use the show-command to see the last local definition.",
        NULL
      )
    );

  return called = TRUE;
}

static int show(int argc, char **argv)
/**************************************************************************
?  CDP-command show
************************************o*************************************/
{
  static int   called;
  static int   full;
  static int   kids;
  static char *dummy;
  static int   xml;

  if( called )
  {
    sms_node *np = 0;

    if(dummy) np = sms_node_find_full(dummy);

    if(np)
      sms_play_write_definition(stdout,np,0,FALSE,full, !kids, xml);
    else
      sms_play_show(full, !kids, xml);
  }
  else
    ioi_exe_add( "show:cdp",show,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ffull",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display the comments also",
            NULL
          ),NULL,1,&full
        ),
        ioi_exe_param(
          "-xxml",IOI_L_BOOLEAN,ioi_exe_argv(
            "Write output in XML, this is test version only",
            "Notice this doesn't do a good job, yet, just an idea...",
            NULL
          ),NULL,1,&xml
        ),
        ioi_exe_param(
          "-Kkids",IOI_L_BOOLEAN,ioi_exe_argv(
            "Don't display the kids (default is to produce complete file)",
            NULL
          ),NULL,1,&kids
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node",IOI_L_PATH,ioi_exe_argv(
            "The name of the node (optional)",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Show the current local suite definition(s), if any.",
        "Print out the current local suite definition in text.",
        "",
        "Only the last succesfully locally played file or after the",
        "get-commannd or status-command.",
        "","NOTICE","",
        TEST_ONLY,
        NULL
      )
    );

  return called = TRUE;
}

static int playbin(int argc, char **argv)
/**************************************************************************
?  CDP-command playbin (test only)
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   show;

  int ok = TRUE;

  if( called )
  {
#ifdef IMPOSSIBLE
    if( dummy ) { argc++; argv--; } /* GOT 2 B */

    while( argc-- && ok )
      ok = sms_play_binfile(*argv++,show);
#endif

    ok = sms_play_binfile(dummy);

    return ok;
  }
  else
    ioi_exe_add( "playbin:cdp",playbin,
      ioi_exe_link_param(
        ioi_exe_param(
          "-sshow",IOI_L_BOOLEAN,ioi_exe_argv(
            "Show while reading the bin file.",
            "After reading the binary file (check point file) show",
            "the definition on stdout.",
            NULL
          ),NULL,1,&show
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "playfile",IOI_L_PATH,ioi_exe_argv(
            "The name of the file that contain the binary definitions.",
            "The file must be produced by either CDP or SMS.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Read the binary definition of the suite.",
        "Read the binary play-files or check point files and define the",
        "suites in the files.",
        "","NOTICE!","",
        "The binary commands ables you to examine the checkpoint files",
        "but you should not convert the definition files into binary.",
        "These command MAY be removed from the final product",
        NULL
      )
    );

  return called = TRUE;
}

static int makebin(int argc, char **argv)
/**************************************************************************
?  CDP-command makebin (test only)
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    return sms_play_makebin(dummy);
  }
  else
    ioi_exe_add( "makebin:cdp",makebin,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "binfile",IOI_L_PATH,ioi_exe_argv(
            "The name of the output binary file.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Create a binary file of the current definition.",
        "Binary files are faster to process.",
        "","NOTICE!","",
        "The binary commands ables you to examine the checkpoint files",
        "but you should not convert the definition files into binary.",
        "These command MAY be removed from the final product",
        NULL
      )
    );

  return called = TRUE;
}

static int login(int argc, char **argv)
/**************************************************************************
?  CDP-command login. Try to make connection to the host.
************************************o*************************************/
{
  static int   called;
  static char *host;
  static char  user[MAXNAME];
  static char  pass[MAXPASSLEN];
  static int   no_passwd;
  static int   port;
  static int   p_min=0,p_max=64*1024-1,p_def=0;
  static int   t_out=60;
  static int   t_min=1,t_max=3600*24,t_def=60;

  if( called )
  {
    sms_handle *hp;

    sms_numbers( ioi_variable_get_int("SMS_PROG") ,
                 ioi_variable_get_int("SMS_VERS") );

    if(no_passwd) pass[0]='\0';

#if 0
    if( sms_client_is_ok(HANDLE)==SMS_E_OK )
    {
      ioi_out(FALSE,IOI_WAR,"login:Already logged in %s",STR(sms_._host));
      sms_client_logout(HANDLE);
    }
#endif

    if( ! *user )
    {
      int len;

      printf("Login %s: ",STR(host));
      fgets(user,MAXNAME-1,stdin);

      if( len = strlen(user))
        if( user[len-1]=='\n' )
          user[--len]='\0';

      if( ! *user )
        strncpy(user,cuserid(NULL),sizeof(user));

      user[sizeof(user)-1] = '\0';

      if( ! *user )
        return ioi_out(FALSE,IOI_WAR,"login:User name must be given!");
    }

    if( ! no_passwd )
      if( ! pass[0] )
        strcpy(pass,sms_password("Password:"));

    hp = sms_client_login(host,user,pass,t_out,port,NULL,0);
    sms_client_swap(hp,0);

    return hp? 1:0;
  }
  else
    ioi_exe_add("login:cdp",login,
      ioi_exe_link_param(
        ioi_exe_param(
          "-nnopasswd",IOI_L_BOOLEAN,ioi_exe_argv(
            "Login without password. Typically used in aliases and in scripts.",
            NULL
          ),NULL,1,&no_passwd
        ),
        ioi_exe_param(
          "-pport",IOI_L_INTEGER,ioi_exe_argv(
            "The tcp/ip port number of the server. If it is zero (default)",
            "the portmapper in the HOST is consulted to find it.",
            NULL
          ),"sms_port",1,&port,&p_min,&p_max,&p_def
        ),
        ioi_exe_param(
          "-ttimeout",IOI_L_INTEGER,ioi_exe_argv(
            "Timeout in seconds to be used in the login and in all the SMS-CDP",
            "transmissions.",
            NULL
          ),"sms_timeout",1,&t_out,&t_min,&t_max,&t_def
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "host",IOI_L_STRING,ioi_exe_argv(
            "The host name where the SMS is expected to be running.",
            NULL
          ),"sms_host",-1,&host
        ),
        ioi_exe_param(
          "user",IOI_L_CHARACTER,ioi_exe_argv(
            "The user name in the host to be logged in to.",
            "If not given on command line, stdio is read with a prompt.",
            "A <RETURN> can be given to indicate the current user.",
            NULL
          ),"sms_user",sizeof(user),user
        ),
        ioi_exe_param(
          "pass",IOI_L_CHARACTER,ioi_exe_argv(
            "Password to enter into the host as a operator",
            "If not given on command line the stdio is read while the",
            "echoing is disabled. A <RETURN> indicates to login as a",
            "monitoring user only",
            NULL
          ),NULL,10,pass
        ),
        NULL
      ),
      ioi_exe_argv(
        "Login to the SMS in host given.",
        "Handshake with the SMS running in the HOST.",
        "Since version 4.4 you can use CDP to login to multiple of SMS's",
        "however if currently logged into the same SMS, that connection is",
        "broken (wiht warning message) and loggen out first.",
        "Nick names were introduced in version 4.4 ($HOME/.xcdprc/servers)",
        "","VARIABLES","",
        "SMS_PROG and SMS_VERS control the RPC protocol used",
        "","EXAMPLE","",
        "CDP> alias  host  login -n host myname",
        "CDP> host",
        "myname logged in host [007]",
        NULL
      )
    );

  return called = TRUE;
}

static int swap(int argc, char **argv)
/**************************************************************************
?  CDP-command swap. Swap the active SMS in CDP
************************************o*************************************/
{
  static int   called;
  static char *host;
  static int   listem;;

  if( called )
  {
    sms_handle *hp;

    if(listem || !host)
    {
      if(sms_._logins)
      {
        sms_handle *hp = sms_._logins;

        if(!hp)
          return ioi_out(1,IOI_WAR,"swap:not logged on any SMS");

        ioi_out(0,IOI_MSG,"Currently logged into the following SMS:");

        for( ; hp ; hp=hp->next )
        {
          ioi_printf(0," %-20s %d.%d.%d %s\n",STR(hp->name), 
                     hp->vers,hp->rev,hp->mod,
                     hp->client? "connected" : "disconnected");
        }
      }
      else
        ioi_out(0,IOI_WAR,"Not logged into any SMS at the moment");

      return 1;
    }

    if(!host)
      return ioi_out(0,IOI_ERR,"swap:Parameter host missing");

    hp = ls_find(&sms_._logins,host);
    if( ! hp )
      return ioi_out(0,IOI_ERR,"swap:%s not found",STR(host));
    
    sms_client_swap(hp,0);

    return 1;
  }
  else
    ioi_exe_add("swap:cdp",swap,
      ioi_exe_link_param(
        ioi_exe_param(
          "-llist",IOI_L_BOOLEAN,ioi_exe_argv(
            "List the hosts currently logged in.",
            NULL
          ),NULL,1,&listem
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "host",IOI_L_STRING,ioi_exe_argv(
            "The sms name which we are currently loggen into.",
            NULL
          ),"sms_host",1,&host
        ),
        NULL
      ),
      ioi_exe_argv(
        "Swap the active SMS to another SMS already logged into in CDP.",
        "The current SMS is pushed back into a stack of SMS's and the named",
        "SMS is made to be the active one.",
        "","EXAMPLE","",
        "CDP> swap -l",
        "sms1 oper research",
        "CDP> swap oper",
        NULL
      )
    );

  return called = TRUE;
}

static int _passwd(int argc, char **argv)
/**************************************************************************
?  CDP-passwd command.
************************************o*************************************/
{
  static int   called;
  static char *user;
  static char *comment;
  static int   delete,list;        /* The options */
  static int   uid,gid;
  static int   u_min=0, u_max=99999, u_def;
  static int   g_min=0, g_max=99999, g_def;
  static int   priv,priv_def=PRIV_NONE;

  static char  passwd[MAXPASSLEN];
  static char  newpw1[MAXPASSLEN];
  static char  newpw2[MAXPASSLEN];

  if( called )
  {
    char *av[9];

    int rc;

    if( !passwd[0] )
      strcpy(passwd,sms_password("Old password:"));

    if( !delete && !list )         /* None of the options */
    {
      if( !newpw1[0] )
        strcpy(newpw1,sms_password("New password:"));
      else
        strcpy(newpw2,newpw1);     /* Batch mode */

      if( !newpw2[0] )
        strcpy(newpw2,sms_password("Retype new password:"));
    }

    av[0] = "passwd";
    av[1] = user;
    av[2] = passwd;
    av[3] = newpw1;
    av[4] = newpw2;

    av[5] = strdup(sms_to_char(uid));
    av[6] = strdup(sms_to_char(gid));
    av[7] = strdup(sms_to_char(priv));
    av[8] = comment;

    rc = sms_client_cmd( HANDLE,9,av,NULL,sms_encode(&delete,&list,NULL),NULL);

    IFFREE(av[5]); IFFREE(av[6]); IFFREE(av[7]);

    newpw2[0] = '\0';              /* It's not a parameter! */

    /* if( rc ) sms_error(rc,"passwd"); */

    return ! rc;
  }
  else
  {
    ioi_exe_add("passwd:cdp",_passwd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ddelete",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the user named. Only users with PRIV_ADMIN.",
            NULL
          ),NULL,1,&delete
        ),
        ioi_exe_param(
          "-llist",IOI_L_BOOLEAN,ioi_exe_argv(
            "List the SMS passwords. Only users with PRIV_ADMIN.",
            NULL
          ),NULL,1,&list
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "user",IOI_L_STRING,ioi_exe_argv(
            "The user name in the host to be changed/added.",
            "Only users with PRIV_ADMIN can succesfully use this option.",
            NULL
          ),NULL,1,&user
        ),
        ioi_exe_param(
          "uid",IOI_L_INTEGER,ioi_exe_argv(
            "User id of the new user. Only with PRIV_ADMIN",
            NULL
          ),NULL,1,&uid,&u_min,&u_max,&u_def
        ),
        ioi_exe_param(
          "gid",IOI_L_INTEGER,ioi_exe_argv(
            "Group id of the new user. Only with PRIV_ADMIN",
            NULL
          ),NULL,1,&gid,&g_min,&g_max,&g_def
        ),
        ioi_exe_param(
          "privileges",IOI_L_ENUM,ioi_exe_argv(
            "Privileges of the new user. Only with PRIV_ADMIN",
            NULL
          ),NULL,1,&priv,privilege_name,&priv_def
        ),
        ioi_exe_param(
          "comment",IOI_L_STRING,ioi_exe_argv(
            "A commnet to describe the new user. Only with PRIV_ADMIN",
            NULL
          ),NULL,1,&comment
        ),
        ioi_exe_param(
          "newpasswd",IOI_L_CHARACTER,ioi_exe_argv(
            "The new SMS password for the user. If not given on command",
            "line the stdio is read twice while the echoing is disabled.",
            "","PRIV_ADMIN","",
            " '*'  To disable loggins.",
            " ' '  To enable loggins wihtout passwd.",
            " '-'  To install crypted password start it with minus.",
            NULL
          ),NULL,MAXPASSLEN,newpw1
        ),
        ioi_exe_param(
          "passwd",IOI_L_CHARACTER,ioi_exe_argv(
            "The current SMS-password. If not given on command line the",
            "stdio is read while the echoing is disabled.",
            NULL
          ),NULL,MAXPASSLEN,passwd
        ),
        NULL
      ),
      ioi_exe_argv(
        "Change the users SMS-password.",
        "The passwd changes (or installs) a SMS password, or other infor-",
        "mation of the user (by default your own)",
        "","NOTICE","",
        "Only the user with PRIV_ADMIN can change other users information.",
        "","EXAMPLE","",
        "passwd archie 111 2222 user \"Archie Bunker,x1111\"",
        "Old password: <type YOUR passwd>",
        "New password: <for the user>",
        "Retype new password: <for the user>",
        NULL
      )
    );

    u_def = getuid();
    g_def = getgid();
  }

  return called = TRUE;
}

static int privileges(int argc, char **argv)
/**************************************************************************
?  CDP-privileges command.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1];
    av[0] = "privileges";

    return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
  }
  else
    ioi_exe_add("privileges:cdp",privileges,NULL,NULL,
      ioi_exe_argv(
        "Show the privileges of current SMS connection.",
        "All the privileges and an explanation are listed one per line.",
        NULL
      )
    );

  return called = TRUE;
}

static int logout(int argc, char **argv)
/**************************************************************************
?  CDP-command logout. Remove the connection to the host.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    int rc;
    rc = sms_client_logout(HANDLE);

    if(rc==SMS_E_OK)
    {
      sms_client_swap(sms_._logins,0);
      if(sms_._logins)
        ioi_out(0,IOI_MSG,"logout:current host is %s",STR(sms_._logins->name));
    }

    return ! rc;
  }
  else
    ioi_exe_add("logout:cdp",logout,NULL,NULL,
      ioi_exe_argv(
        "Logout from the SMS.",
        "Terminate the connection to the SMS.",
        "",
        "If not currently logged in to the SMS give an error message.",
        "The current working node is set to be \"/\".",
        "","EXAMPLE","",
        "If the cwn is the function in the cwn(cdp) define a function:",
        "",
        "  define logout {",
        "    /logout",
        "    cwn",
        "  }",
        NULL
      )
    );

  return called = TRUE;
}

static int smscmd(int argc, char **argv)
/**************************************************************************
?  Execute a command in the SMS.
************************************o*************************************/
{
  static int   called;
  static int   statistics;
  static char *dummy;
  static char *argum;

  if( called )
  {
    if( !dummy )
    {
      argv[0] = "sms";
      return ! sms_client_cmd( HANDLE,1,argv,NULL,statistics,NULL );
    }

    if( dummy ) { argc++; argv--; }
    if( argum ) { argc++; argv--; }

    return ! sms_client_smscmd(HANDLE,argc,argv);
  }
  else
    ioi_exe_add("sms:cdp",smscmd,
      ioi_exe_param(
        "-sstatistics",IOI_L_BOOLEAN,ioi_exe_argv(
          "Display the statistics of the SMS if it is collecting them.",
          NULL
        ),NULL,1,&statistics
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "smscmd",IOI_L_STRING,ioi_exe_argv(
            "The remote command to be executed. Special case must be taken",
            "to use any special characters.",
            "If omitted the information of the remote sms will be returned.",
            NULL
          ),NULL,1,&dummy
        ),
        ioi_exe_param(
          "arg(s)",IOI_L_STRING,ioi_exe_argv(
            "Wot the remote command might need.",
            NULL
          ),NULL,1,&argum
        ),
        NULL
      ),
      ioi_exe_argv(
        "Execute direct SMS command, or give statistics/info.",
        "The user needs SYSTEM privileoges to execute remote commands.",
        "","EXAMPLES","",
        "  CDP> sms \\$df . \\\\\\> aapo        # nice?",
        "  CDP> sms '$df . \\> aapo          # same as the above",
        "  CDP> sms                         # just give the info",
        "","NOTICE","",
        "The remote command is silently executed. No output will be returned.",
        "This will probably only be in the test version of the cdp",
        NULL
      )
    );

  return called = TRUE;
}

static int response(void *userdata, char *s)
{
  printf("%s\n",STR(s));
  return 0;
}

static int servers(int argc, char **argv)
/**************************************************************************
?  CDP-command servers. Show all the servers currently running.
!  The timeout is too long (RPC/UDP-broadcast: totally 60 sec)
************************************o*************************************/
{
  static int   called;
  static int   verbose;
  static int   replies,rep_min=0,rep_def=0;
  static char *hostfile;

  if( called )
  {
    sms_map *mp;

    int       rc;

/*
    sms_numbers( ioi_variable_get_int("SMS_PROG") ,
                 ioi_variable_get_int("SMS_VERS") );
*/

    mp = sms_nick_broadcast(replies,verbose,hostfile,response,0);

    if( mp )
      if( !verbose )
      {
        printf("Servers in the list now:\n");
        sms_list_print(&mp,stdout);
      }
      else
        ;
    else
      printf("No one is alive\n");

/*
    if( replies==1 && mp )
      ioi_variable_set("sms_server",mp->name);
*/

    return 1;
  }
  else
    ioi_exe_add("servers:cdp",servers,
      ioi_exe_link_param(
        ioi_exe_param(
          "-hhostfile",IOI_L_PATH,ioi_exe_argv(
            "Use the file also to ping individual host listed in the file.",
            NULL
          ),NULL,1,&hostfile
        ),
        ioi_exe_param(
          "-nnumber",IOI_L_INTEGER,ioi_exe_argv(
            "The maximum number of replies to wait. The zero value means",
            "to wait all of them, until the hardcoded timeout.",
            "",
            "If only one reply is asked (the first server to respond) the",
            "value is stored into IOI-variable $sms_server. This can be",
            "used to automatically login to the server at the startup of",
            "the CDP.",
            NULL
          ),NULL,1,&replies,&rep_min,NULL,&rep_def
        ),
        ioi_exe_param(
          "-vverbose",IOI_L_BOOLEAN,ioi_exe_argv(
            "List the server responds at the time they arrive. The internet",
            "address is also given. Multiple responds are listed.",
            "The default is to display only the names after the command.",
            NULL
          ),NULL,1,&verbose
        ),
        NULL
      ),
      NULL,
      ioi_exe_argv(
        "List the SMS-servers that can be reached with broadcast.",
        "Just print the names of the servers that respond. You do not need",
        "to be logged into the SMS to execute this one.",
        "","NOTICE","",
        "If the server is busy it does NOT respond to the broadcast message.",
        "Currently the servers are asked only twice with 1 & 3 second delays.",
        "","VARIABLES","",
        "SMS_PROG and SMS_VERS control the RPC protocol used",
        "","EXAMPLE","",
        "servers -n1; login $sms_server user \" \"",
        NULL
      )
    );

  return called = TRUE;
}

static int news(int argc, char **argv)
/**************************************************************************
?  Test has anything changed since last status.
************************************o*************************************/
{
  static int   called;
  static int   verbose;

  if( called )
  {
    int rc = sms_client_news( HANDLE,sms_._action_number );

    if( verbose )
      if( rc == SMS_E_OK )
        printf("Yeps! There is changes in the suite(s)\n");
      else
        if( rc == SMS_E_NONEWS )
          printf("Nop! Nothing changed since last status.\n");
        else
          printf("news failed.\n");

    return ! rc;
  }
  else
    ioi_exe_add("news:cdp",news,
      ioi_exe_param(
        "-vverbose",IOI_L_BOOLEAN,ioi_exe_argv(
          "Tell the news in text as a one-liner.",
          NULL
        ),NULL,1,&verbose
      ),
      NULL,
      ioi_exe_argv(
        "Test has anything changed since last status.",
        "The result is stored in the IOI-variable rc and nothing is",
        "displayed unless verbose-option is used.",
        "",
        "This allowes to execute a loop efficently by displaying the",
        "status changes only when something has changed in the SMS.",
        "","EXAMPLE","",
        "CDP> set break on  # to be able to break out from the loop!",
        "CDP> while( 1 ) do",
        ">      news;",
        ">      if( rc ) then",
        ">        $clear",
        ">        status",
        ">      else",
        ">        sleep 100",
        ">      endif",
        ">    endwhile",
        "status changes only when something changes in the SMS...",
        NULL
      )
    );

  return called = TRUE;
}

static int cwn(int argc, char **argv)
/**************************************************************************
?  Change Working Node.
************************************o*************************************/
{
  static int   called;
  static char *newnode;

  if( called )
  {
    sms_node    *np;
    char        *cwn;              /* Change Working Node     */
    char        *to;               /* Want to go there!       */
    int          rc;

    if( sms_cdp_update(HANDLE) != SMS_E_OK )
    {
      ioi_variable_set("cwn","/");
      ioi_variable_set("cwn_type",node_name[NODE_SUPER]);
      ioi_variable_set("cwn_status",status_name[STATUS_UNKNOWN]);
      return FALSE;
    }

    cwn = ioi_variable_get("cwn");

    if( !newnode )                 /* Just print to current one */
    {
      printf("cwn:%s\n",cwn?cwn:"/");
      return TRUE;
    }

    if( ! (to=sms_cd_name2(newnode)) )
      return FALSE;

    if( np=sms_node_find_full(to) )
    {
      ioi_variable_set("cwn",sms_node_full_name(np));
      ioi_variable_set("cwn_type",node_name[np->type]);
      ioi_variable_set("cwn_status",
         np->type? status_name[np->status] : event_name[np->status] );
    }
    else
      return ioi_out(FALSE,IOI_ERR,"cwn:unable to cwn to %s",STR(newnode));

    return TRUE;
  }
  else
    ioi_exe_add("cwn:cdp",cwn,NULL,
      ioi_exe_param(
        "node",IOI_L_STRING,ioi_exe_argv(
          "The name to become the new Working Node.",
          NULL
        ),"cwn",1,&newnode
      ),
      ioi_exe_argv(
        "Change Working Node.",
        "Change the IOI variable \"cwn\".",
        "The node you \"cd\" to must exist in the SMS you are currently",
        "logged in. Upon logout it is returned to point the root \"/\".",
        "",
        "Currently the $cwn is used by the commands:",
        "alter cancel delete force info overview resume send suspend (o)status",
        "",
        "Without parameters the variable $cwn is printed.",
        "","EXAMPLE","",
        "To make the prompt reflect the cwn use function:","",
        "  define cwn {",
        "    if( $# > 0 ) then",
        "      /cwn $1",
        "    endif",
        "    set prompt $cwn\"-CDP\"",
        "  }",
        NULL
      )
    );

  return called = TRUE;
}

static int get(int argc, char **argv)
/**************************************************************************
?  Get back the suite definition.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    int rc;

    sms_._action_number = sms_._modify_number = 0;
    rc = sms_cdp_update(HANDLE);

    if( rc != SMS_E_OK )
      return ioi_out(FALSE,IOI_WAR,"get:Nop!");

    if( sms_._super )
      ioi_out(0,IOI_MSG,"get:Got it!");
    else
      ioi_out(0,IOI_WAR,"get:Nothin' there?");

    return TRUE;
  }
  else
    ioi_exe_add("get:cdp",get,NULL,NULL,
      ioi_exe_argv(
        "Get back the suite definition.",
        "Use show-command to view the suites got back.",
        "",
        "The output can be directed to a file to be used as a play file.",
        NULL
      )
    );

  return called = TRUE;
}

static int history(int argc, char **argv)
/**************************************************************************
?  Get back the last lines of the SMS logfile.
|  Currently the number of lines is 100.
************************************o*************************************/
{
  static int   called;
/*
  static int   lines,lines_min=1,
               lines_max=SMSHISTORYLEN,lines_def=SMSHISTORYLEN;
*/
  if( called )
    return ! sms_client_history( HANDLE,NULL,ioi_variable_get_int("xyz") );
  else
  {
    static char config[80];         /* Just big enough for this one */

    sprintf(config,"SMSHISTORYLEN in config.h and was %d at compilation time",
            SMSHISTORYLEN);

    ioi_exe_add("smshistory:cdp",history,
      NULL,

      ioi_exe_link_param(
/*
        ioi_exe_param(
          "lines",IOI_L_INTEGER,ioi_exe_argv(
            "Max number of lines printed (a'la csh history)",
            NULL
          ),NULL,1,&lines,&lines_min,&lines_max,&lines_def
        ),
*/
        NULL
      ),
      ioi_exe_argv(
        "Get back the last lines of the SMS history.",
        "The lines are simply printed on stdout.","",
        "The maximum number of lines is controlled by",
        config,
        NULL
      )
    );
  }

  return called = TRUE;
}

static int users(int argc, char **argv)
/**************************************************************************
?  Get back the current users in ascii format.
************************************o*************************************/
{
  static int   called;
  static int   full;               /* Get the full listing of users */

  if( called )
  {
    cdp_users( HANDLE, 0, NULL );
    if(full) cdp_users( HANDLE, full, NULL );
    return 0;
  }
  else
    ioi_exe_add("users:cdp",users,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ffull",IOI_L_BOOLEAN,ioi_exe_argv(
            "Get all information possible",
            "The default is to get just one liners",
            NULL
          ),NULL,1,&full
        ),
        NULL
      ),
      NULL,
      ioi_exe_argv(
        "Display the users logged in to the SMS.",
        "All user that are currently loggend in the SMS are printed an user at",
        "a line. Also the privilege, idle time and connection time are listed.",
        "","NOTICE","",
        "The non-user connections are not listed (unless -f option is used)",
        "Those are tasks sending status change information and users like",
        "STATUS (a special user).",
        NULL
      )
    );

  return called = TRUE;
}

static int begin(int argc, char **argv)
/**************************************************************************
?  Begin the suite(s) given.
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    char *av[2] = {"begin"};
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,0,&names);
  }
  else
    ioi_exe_add("begin:cdp",begin,NULL,
      ioi_exe_param(
          "suite(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the suite(s) to be started.",
            "Suite must be defined and waiting to be started, that is",
            "the status must be either unknown or complete.",
            NULL
          ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Begin the suite(s) given.",
        "The suite(s) in the SMS are started. The user needs to have",
        "USER or OPER privileges to start the suite(s).",
#ifdef USE_NET_NAMES
        "The suite names can be netnames (//host/suite)",
#endif
        "The suite must be in state UNKNOWN or COMPLETE.",
        "The name can start with the '/' or be obitted.",
        NULL
       )
    );

  return called = TRUE;
}

static int resume(int argc, char **argv)
/**************************************************************************
?  Resume node(s) given.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   recursively;

  if( called )
  {
    char     *av[2] = {"resume"};
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,sms_encode(&recursively,NULL),&names);
  }
  else
    ioi_exe_add("resume:cdp",resume,
      ioi_exe_param(
        "-rrecursively",IOI_L_BOOLEAN,ioi_exe_argv(
          "Recursively process nodes encountered.",
          "Everything in suites/families are also resumed.",
          NULL
        ),NULL,1,&recursively
      ),
      ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the node(s) to be resumed.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            "Node must be defined and its status must be suspended.",
            NULL
          ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Resume node(s) given.",
        "The nodes that are currently suspended can be brought back to",
        "execution by resuming them.",
        "",
        "The user must have USER or OPER privileges to resume node(s).",
        "","NOTICE","",
        "It is not an error to resume a node that is not suspended. Those",
        "attemps are silently ignored.",
        "","NOTICE","",
        "You can resume a task in a family that is suspended, but since",
        "the family is suspended the task is never send until either the",
        "task is send manually or the family is resumed.",
        NULL
      )
    );

  return called = TRUE;
}

static int suspend(int argc, char **argv)
/**************************************************************************
?  Suspend node(s) given.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   recursively;

  if( called )
  {
    char     *av[2] = {"suspend"};
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,sms_encode(&recursively,NULL),&names);
  }
  else
    ioi_exe_add("suspend:cdp",suspend,
      ioi_exe_param(
        "-rrecursively",IOI_L_BOOLEAN,ioi_exe_argv(
          "Recursively process nodes encountered.",
          "Everything in suites/families are also suspended.",
          NULL
        ),NULL,1,&recursively
      ),
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be suspended.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          "Node must be defined.",
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Suspend node(s) given.",
        "To temporarily stop nodes to be processed by the SMS you can",
        "suspend them. Jobs that are already submitted or active does still",
        "receive state changes and possibe events from the jobs, but no new",
        "jobs will be send until the node is resumed.",
        "",
        "The user must have USER or OPER privileges to suspend node(s).",
        "","NOTICE!","",
        "It is not an error to suspend a node that is already suspended.",
        "Those attemps are silently ignored.",
        NULL
      )
    );

  return called = TRUE;
}

static int cancel(int argc, char **argv)
/**************************************************************************
?  Cancel node(s) given.
|  Currently only suites can be cancelled.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   force;
  static int   alias;

  if( called )
  {
    char     *av[3];
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    av[0] = "cancel";

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    if( yes_option )
      return ! COMMAND(1,av,NULL,sms_encode(&force,&alias,NULL),&names);

    while( names )
    {
      char  buff[MAXNAM];
      int   rc = SMS_E_OK;

      av[1] = names->name;

      sprintf(buff,"cancel%s %s", alias? " aliases in":"" ,STR(names->name));

      if( ! sms_confirm(buff) ) return FALSE;

      rc = sms_client_cmd(HANDLE,2,av,NULL,sms_encode(&force,&alias,NULL),NULL);
      if( rc != SMS_E_OK ) return FALSE;

      names = names->next;
    }

    return TRUE;
  }
  else
    ioi_exe_add("cancel:cdp",cancel,
      ioi_exe_link_param(
#ifdef SMS_CROSS_SUITE
        ioi_exe_param(
          "-fforce",IOI_L_BOOLEAN,ioi_exe_argv(
            "Remove the node(s) even if thay have external dependecies.",
            "The SMS might refuse to follow this if cross suite",
            "dependencies are not allowed in the SMS.",
            NULL
          ),NULL,1,&force
        ),
#endif
        ioi_exe_param(
          "-aalias",IOI_L_BOOLEAN,ioi_exe_argv(
            "Remove complete alias(es) from node(s)",
            NULL
          ),NULL,1,&alias
        ),
        yes,                       /* Must be the last 1 */
        NULL
      ),
      ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the node(s) to be cancelled.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Cancel node(s) given.",
        "The node(s) given are PERMANENTLY removed from the suite definition",
        "and can be placed back only by the play(CDP) command.",
        "",
        "You should not use cancel in repeated suites except on suite level.",
        "",
        "The user must have PLAY privileges to cancel node(s) and ownership.",
        "of the node(s) to be cancelled",
        "",
        "If the user has privileges on the node level (s)he can cancel that",
        "node, even while there might be node below that does not belong to",
        "the user.",
        "",
        "Cancelling aliases with a-option, will only remove the aliases,"
        "not the node(s) given. SMS will recursively scan the tree and",
        "remove the alias(es) which are complete.",
        "","NOTICE!","",
        "Only free nodes that can be cancelled (except if force is used). That",
        "is nodes that are not triggers to other nodes. Family can be",
        "cancelled if the triggers are inside that family.",
        "",
        "Super node can not be cancelled.",
        NULL
       )
    );

  return called = TRUE;
}

static int force(int argc, char **argv)
/**************************************************************************
?  Force node(s) into a given status.
|  Currently only tasks can be forced.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   status;
  static int   status_def = 0;
  static int   quick;
  static int   recursively;

  if( called )
  {
    int       rc    = SMS_E_OK;
    sms_list *names = 0;
    char *av[3];

    av[0] = "force";
    av[1] = status_names[status];

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( quick )
      ls_argv(&names,argc,argv);
    else
      sms_cd_names2(argc,argv,&names);

    if( !names )
      return FALSE;

    return ! COMMAND(2,av,NULL,sms_encode(&recursively,NULL),&names);
  }
  else
    ioi_exe_add("force:cdp",force,
      ioi_exe_link_param(
        ioi_exe_param(
          "-qquick",IOI_L_BOOLEAN,ioi_exe_argv(
            "Force the exact names without the variable $cwn.",
            "Used to speed up the force from loggen(cdp).",
            NULL
          ),NULL,1,&quick
        ),
        ioi_exe_param(
          "-rreqursively",IOI_L_BOOLEAN,ioi_exe_argv(
            "Force node(s) recursively",
            "This way you can force a family.",
            NULL
          ),NULL,1,&recursively
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "status",IOI_L_ENUM,ioi_exe_argv(
            "The status of the node(s) to be forced into.",
            "The values \"set\" and \"clear\" are only valid for the events",
            "and the rest only for tasks.",
            NULL
          ),NULL,-1,&status,status_names,&status_def
        ),
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the node(s) to be forced into status given.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Force node(s) into a given status",
        "The node(s) given are marked to have the status given. No direct",
        "action is taken. Only the derivated actions are taken. That is",
        "to force node to be submitted does not actually submit the job,",
        "SMS only expects to hear the smsinit message from the job (this.",
        "is quite unlike since the SMS does not know the password!",
        "",
        "Only tasks and events can be forced. Suites and families can",
        "be forced only indirectly by forcing the tasks. This is clumsy.",
        "",
        "The user must have USER or OPER privileges to use on force node(s).",
        "","LIMITS","",
        "Althought multiple nodes can be given at the same time, nodes and",
        "events can not be forced with the same command.",
        "","NOTICE","",
        "The tasks have SMS-generated passwords which makes it difficult to",
        "force a task to be submitted and make the job connect",
        "into SMS successfully.",
        "",
        "To force a task to be queued normally means that SMS will submit",
        "the job. However, nodes that have dependencies may not be submitted",
        "if the dependency holds the node. Use the delete command to free the",
        "node if necessary.",
        "",
        "Meters, labels and repeat can not be forced. Use alter(cdp)",
        NULL
      )
    );

  return called = TRUE;
}

static int requeue(int argc, char **argv)
/**************************************************************************
?  Requeue a node.
|  Forward / backward triggers works normally.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   force;

  if( called )
  {
    char     *av[2] = {"requeue"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,sms_encode(&force,NULL),&names);
  }
  else
    ioi_exe_add("requeue:cdp",requeue,
      ioi_exe_param(
        "-fforce",IOI_L_BOOLEAN,ioi_exe_argv(
          "Force the requeing even if there are nodes that are active",
          "or submitted.",
          NULL
        ),NULL,1,&force
      ),
      ioi_exe_param(
        "node",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be requeued.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Requeue a node.",
        "The node(s) is/are requeued to be run normally. All forward",
        "and backward triggers apply. This is possible only for nodes",
        "complete or queued unless force (-f) is used",
        "","NOTICE","",
        "Be carefull with the force if there are jobs actually running.",
        NULL
      )
    );

  return called = TRUE;
}

static int resubmit(int argc, char **argv)
/**************************************************************************
?  Resubmit node(s) reqursively
|  tasks in state "submitted" or "active" (and "aborted" if specified)
|  are forced to be queued again (their events and meters are cleared)
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   aborted, clear;

  if( called )
  {
    char     *av[2] = {"resubmit"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;
 
    return ! COMMAND(1,av,NULL,sms_encode(&aborted,&clear,NULL),&names);
  }
  else
    ioi_exe_add("resubmit:cdp",resubmit,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aaborted",IOI_L_BOOLEAN,ioi_exe_argv(
            "Resubmit aborted tasks also",
            NULL
          ),NULL,1,&aborted
        ),
        ioi_exe_param(
          "-cclear",IOI_L_BOOLEAN,ioi_exe_argv(
            "Clear the meters, events, etc ",
            NULL
          ),NULL,1,&clear
        ),
        NULL
      ),
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be resubmitted.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Resubmit node(s).",
        "The node(s) specified are reqursively scanned and all tasks",
        "with status \"active\" or \"submitted\" (or \"aborted\" if -a option",
        "is used) are forced to be queued again, with their try-number",
        "increased and events cleared and meters initialized.",
        "Labels are initialised and repeat restarted.",
        NULL
      )
    );

  return called = TRUE;
}

static int run(int argc, char **argv)
/**************************************************************************
?  Run a task immediately
|  Ignore trigger, limits, sms status (halted, shutdown), parent
|  status (suspended) etc.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   force,clear;

  if( called )
  {
    char     *av[2] = {"run"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;
 
    return ! COMMAND(1,av,NULL,sms_encode(&force,&clear,NULL),&names);
  }
  else
    ioi_exe_add("run:cdp",run,
      ioi_exe_link_param(
        ioi_exe_param(
          "-fforce",IOI_L_BOOLEAN,ioi_exe_argv(
            "Run even if the task is active or submitted",
            NULL
          ),NULL,1,&force
        ),
        ioi_exe_param(
          "-cclear",IOI_L_BOOLEAN,ioi_exe_argv(
            "Clear the meters, events, etc ",
            NULL
          ),NULL,1,&clear
        ),
        NULL
      ),
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be run.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Run immediately node(s).",
        "Ignore triggers, limits, sms status (halted, shutdown),",
        "parent status (suspended) etc., just run the task now.",
        NULL
      )
    );

  return called = TRUE;
}

static int dir(int argc, char **argv)
/**************************************************************************
?  Show remote directory listing by asking SMS to send it
|  Currently this is for the testing only.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static char *path;               /* File name specified by user */

  if( called )
  {
    sms_list *name = NULL;
    sms_dir  *dir  = NULL;

    sms_handle *hp;
    sms_node   *np;

    if(dummy) { argc++; argv--; }

    if( ! (name=sms_cd_names2(argc,argv,NULL)) )
      return FALSE;

    /* if( path == NULL ) path = name->name + 1; */

#ifdef USE_NET_NAMES
    np = sms_node_net_find(name->name);
    hp = sms_node_find_handle(np);
#else
    np = sms_node_find_full(name->name);
    hp = HANDLE;
#endif

    if( cdp_dir(hp,sms_node_full_name(np),path,&dir) == SMS_E_OK )
    {
      sms_file_list(stdout,dir);
      NODE_FREE(dir,sms_dir);

      return TRUE;
    }

    return FALSE;
  }
  else
    ioi_exe_add("dir:cdp",dir,
      ioi_exe_param(
        "-ppath",IOI_L_STRING,ioi_exe_argv(
          "The path name of a directory to be send.",
          NULL
        ),NULL,1,&path
      ),
      ioi_exe_param(
        "task",IOI_L_STRING,ioi_exe_argv(
          "The name of the task to be get.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Ask the SMS to send a directory listing for the node.",
        "Only one directory can be get at the time",
        NULL
      )
    );

  return called = TRUE;
}

static int file(int argc, char **argv)
/**************************************************************************
?  Get a file named from SMS and generate a local file in $TMPDIR
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static char *fname;              /* File name specified by user */

  static int   file_type,file_def = 0;
  static char *file_names[] = { "script","job","jobout","manual",NULL };
  static char *file_micro[] = 
    { "SMSSCRIPT","SMSJOB","SMSJOBOUT","SMSSCRIPT",NULL };

  if( called )
  {
    sms_list *name = NULL;
    char     *tmp;
    char     *filename = NULL;     /* File name returned by cdp_file() */

    char     *s;                   /* Temp till we get this standardized */
    char      buff[MAXNAME];       /*  - " -  */
    int       rc;

    sms_handle *hp;
    sms_node   *np;

    if(dummy) { argc++; argv--; }

    if( ! (name=sms_cd_names2(argc,argv,NULL)) )
      return FALSE;

#ifdef USE_NET_NAMES
    np = sms_node_net_find(name->name);
    hp = sms_node_find_handle(np);
#else
    np = sms_node_find_full(name->name);
    hp = HANDLE;
#endif

    if( fname == NULL && file_type < 3 )
    {
      tmp=sms_variable_get(file_micro[file_type],np);
      if(!tmp) return FALSE;

      if(file_type==0)             /* SMS will use variable SMSFILES */
        tmp="";
    }
    else
      tmp = fname;

    if( file_type < 3 ) rc = cdp_file(hp,sms_node_full_name(np),tmp,MAXLINES,&filename);
    else                rc = cdp_manual(hp,sms_node_full_name(np),MAXLINES,&filename);

    if( rc == SMS_E_OK )
    {
      printf("local file name is %s\n",filename?filename:"unknown");
      sleep(1);
      if(!filename) return FALSE;

      ioi_variable_set("localfile",filename);
      return TRUE;
    }

    return FALSE;
  }
  else
    ioi_exe_add("file:cdp",file,
      ioi_exe_link_param(
        ioi_exe_param(
          "-nname",IOI_L_STRING,ioi_exe_argv(
            "The name of the file to be send.",
            NULL
          ),NULL,-1,&fname
        ),
        ioi_exe_param(
          "-ttype",IOI_L_ENUM,ioi_exe_argv(
            "Which file to send.",
            NULL
          ),NULL,-1,&file_type,file_names,&file_def
        ),
        NULL
      ),
      ioi_exe_param(
          "task",IOI_L_STRING,ioi_exe_argv(
            "The name of the task to be get.",
#ifdef USE_NET_NAMES
            "The task names can be netnames (//host/suite/family/task)",
#endif
            NULL
          ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Ask the SMS to send the sms-script for the node.",
        "Only one file can be get at the time",
        NULL
      )
    );

  return called = TRUE;
}

static int _send(int argc, char **argv)
/**************************************************************************
?  Send the job!
|  The old SMSEDIT.
|  Currently this is for the testing only.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   edit,alias,run,preprocess;

  if( called )
  {
    sms_variable *vp    = NULL;
    char         *name  = NULL;
    int           rc;
    sms_list     *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    names = sms_cd_names2(argc,argv,NULL);
    if( !names ) return FALSE;

    if((rc=cdp_scan(HANDLE,names->name,edit,preprocess,&vp,&name))
        ==SMS_E_OK)
    {
      if(sms_variable_edit(vp,name)==TRUE)
      {
        rc=cdp_send(HANDLE,names->name,alias,run,&vp,&name);
        sms_list_print(&vp,stderr);
      }
      else
        if(edit) unlink(name);
    }
    else
      sms_list_print(&vp,stderr);

    sms_node_free(vp);

    return ! rc;
  }
  else
    ioi_exe_add("send:cdp",_send,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aalias",IOI_L_BOOLEAN,ioi_exe_argv(
            "Send the job without interfering the current running of the SMS.",
            "That is, the status of the task itself is not changed to be",
            "submitted but a new aliased-task is created. This allows the",
            "status of the task itself to remain as it is.",
            "","NOTICE","",
            "This is a new feature since 4.4.",
            NULL
          ),NULL,1,&alias
        ),
        ioi_exe_param(
          "-rrun",IOI_L_BOOLEAN,ioi_exe_argv(
            "Run the task now. The other alternative is to prepare the aliased",
            "job and run it with the task itself.",
            "Only meaningfull with alias-option.",
            NULL
          ),NULL,1,&run
        ),
        ioi_exe_param(
          "-eedit",IOI_L_BOOLEAN,ioi_exe_argv(
            "Edit the \".sms\" file also.",
            NULL
          ),NULL,1,&edit
        ),
        ioi_exe_param(
          "-ppreprocess",IOI_L_BOOLEAN,ioi_exe_argv(
            "Preprocess the file before sending it.",
            "Default is that the file send will have the %include and",
            "other preprocessing symbols in it.",
            "Turning this option on will send the file whit the file",
            "included and manual and comment lines removed.",
            NULL
          ),NULL,1,&preprocess
        ),
        NULL
      ),
      ioi_exe_param(
          "task(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the task(s) to be send.",
            NULL
          ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Send the task job to be run (spawn it) (== smsedit).",
        "The user must have USER or OPER privileges to send the task(s).",
        "","NOTICE!","",
        "Very limited checking!!!",
        "","NOTICE!","",
        "Will be replaced by the run/rerun commands.",
        NULL
      )
    );

  return called = TRUE;
}

static int mkdirs(int argc, char **argv)
/**************************************************************************
?  Build directories from the definition file
|  Currently this is for the testing only.
************************************o*************************************/
{
  static int    called;
  static int    overwrite,verbose;
  static double abort_rate,a_min=0.0,a_max=1.0,a_def=0.0;
  static int    e_sleep,e_min=0,e_max=500,e_def=10;
  static int    t_sleep,t_min=0,t_max=500,t_def=30;
  static char  *begin_file,*end_file,*home;

  if( called )
  {
    sms_node *np = sms_._super;

    if( np && np->type==NODE_SUPER ) np = np->kids;

    return ( np )?
      sms_node_mkdir( np , home , begin_file , end_file ,
                      t_sleep,e_sleep,overwrite,abort_rate,verbose)
      :
      ioi_out(FALSE,IOI_WAR,"Use get/play -l/status to define the suite!")
      ;
  }
  else
    ioi_exe_add("mkdirs:cdp",mkdirs,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aabort",IOI_L_DOUBLE,ioi_exe_argv(
            "The rate to generate abort into the scripts.",
            "(Test only.)",
            NULL
          ),NULL,1,&abort_rate,&a_min,&a_max,&a_def
        ),
        ioi_exe_param(
          "-bbegin",IOI_L_PATH,ioi_exe_argv(
            "The begin file to be used.",
            NULL
          ),NULL,1,&begin_file
        ),
        ioi_exe_param(
          "-eend",IOI_L_PATH,ioi_exe_argv(
            "The end file to be used.",
            NULL
          ),NULL,1,&end_file
        ),
        ioi_exe_param(
          "-hhome",IOI_L_PATH,ioi_exe_argv(
            "The home to be used for the building",
            "The default is the current directory",
            NULL
          ),NULL,1,&home
        ),
        ioi_exe_param(
          "-ooverwrite",IOI_L_BOOLEAN,ioi_exe_argv(
            "Overwrite the existing files. The default is to only build the",
            "missing files/directories.",
            NULL
          ),NULL,1,&overwrite
        ),
        ioi_exe_param(
          "-vverbose",IOI_L_BOOLEAN,ioi_exe_argv(
            "Print wots goin' on",
            NULL
          ),NULL,1,&verbose
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "eventsleep",IOI_L_INTEGER,ioi_exe_argv(
            "Time to sleep between events in the generated script.",
            NULL
          ),NULL,1,&e_sleep,&e_min,&e_max,&e_def
        ),
        ioi_exe_param(
          "tasksleep",IOI_L_INTEGER,ioi_exe_argv(
            "Time to sleep before task completion in the generated script.",
            NULL
          ),NULL,1,&t_sleep,&t_min,&t_max,&t_def
        ),
        NULL
      ),
      ioi_exe_argv(
        "Create the directories from the internal suite definition.",
        "Use get/play -l/status to get/create them.",
        "By default the directories are created in the current directory.",
        "","NOTICE!","",
        "This should be used in tests only!",
        NULL
      )
    );

  return called = TRUE;
}

static int check(int argc, char **argv)
/**************************************************************************
?  Checkpoint the SMS.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   t,t_min=0,t_def=0;
  static int   mode,mode_def=0;

  if( called )
  {
    argv--; argc++;                /* The SMS-command name */

    return ! cdp_check(HANDLE,dummy,mode,t);
  }
  else
    ioi_exe_add("check:cdp",check,
      ioi_exe_link_param(
        ioi_exe_param(
          "-mmode",IOI_L_ENUM,ioi_exe_argv(
            "The mode how to checkpoint the SMS.",
            "The privilege required is PRIV_OPER.",
            NULL
          ),NULL,1,&mode,check_name,&mode_def
        ),
        ioi_exe_param(
          "-ttime",IOI_L_INTEGER,ioi_exe_argv(
            "Time in seconds for the interval to checkpoint the SMS.",
            "A reasonable value would be something between 60-300 sec.",
            "This only effects if the mode is (on)time.",
            "The privilege required is PRIV_OPER.",
            NULL
          ),NULL,1,&t,&t_min,NULL,&t_def
        ),
        NULL
      ),
      ioi_exe_param(
        "filename",IOI_L_PATH,ioi_exe_argv(
          "The checkpoint file name. The default file name is $SMSCHECK",
          "in the SMS. The file name is in the machine where the SMS is",
          "running.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Checkpoint the SMS.",
        "The SMS is advised to write an extra copy of the checkpoint file. If",
        "the name is given it is used, otherwise the SMSCHECK file is used.",
        "",
        "You can view the checkpoint file by playbin-show commands.",
        "",
        "The user must have OPER or SYSTEM privileges to write a checkpoint",
        "file",
        NULL
      )
    );

  return called = TRUE;
}

static int recover(int argc, char **argv)
/**************************************************************************
?  Recover the SMS from the checkpoint file
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    char *av[2];
    int   ac=1;

    av[0] = "recover";

    if(dummy) av[ac++] = argv[-1];

    if( yes_option || sms_confirm(*av) )
      return ! sms_client_cmd( HANDLE,ac,av,NULL,0,NULL );

    return FALSE;
  }
  else
    ioi_exe_add("recover:cdp",recover,
      yes,
      ioi_exe_param(
        "filename",IOI_L_PATH,ioi_exe_argv(
          "The checkpoint file name. The default file name is $SMSCHECK",
          "in the SMS.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Recover the SMS from the checkpoint file.",
        "The SMS is advised to try to recover from the checkpoint file.",
        "",
        "In order to be able to recover:",
        "  The SMS must be shutdown",
        "  The SMS must be empty, that is no suites defined",
        "  The user must have OPER or SYSTEM privileges.",
        "",
        "In case of success, you need still restart the SMS.",
        NULL
      )
    );

  return called = TRUE;
}

static int _shutdown(int argc, char **argv)
/**************************************************************************
?  Shutdown the SMS.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"shutdown"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
    else
      return FALSE;
  }
  else
    ioi_exe_add("shutdown:cdp",_shutdown,
      yes,
      NULL,
      ioi_exe_argv(
        "Shutdown the SMS.",
        "By shuting the SMS down, the SMS stops submitting new jobs.",
        "The jobs that are already in execution (submitted or active)",
        "may send events and complete.",
        "",
        "It is a good practice to \"drain\" the SMS before takeing the",
        "computer down or terminating the SMS.",
        "","The user needs OPER or SYSTEM privileges.",
        "","EXAMPLE","",
        "To temporarily stop SMS from submitting new jobs use:",
        "",
        "CDP> shutdown",
        "  Are U serious 'bout shutdown? yes",
        "  shutdown:by user@007",
        "#",
        "# And to get the things going again:",
        "#",
        "CDP> restart",
        "CDP> Are U serious 'bout restart? yes",
        "restart:by user@007",
        NULL
      )
    );

  return called = TRUE;
}

static int halt(int argc, char **argv)
/**************************************************************************
?  Halt the SMS.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"halt"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
    else
      return FALSE;
  }
  else
    ioi_exe_add("halt:cdp",halt,
      yes,
      NULL,
      ioi_exe_argv(
        "Halt the SMS.",
        "Before bringing the SMS down, it must be halted first. That is",
        "all the activity between to jobs stops and the SMS stops sending",
        "new jobs.",
        "","The user needs OPER or SYSTEM privileges.",
        "","EXAMPLE","",
        "To change the node, or the version of the SMS in fly do:",
        "",
        "CDP> shutdown",
        "  Are U serious 'bout shutdown? yes",
        "  shutdown:by user@007",
        "#",
        "#  Let the jobs finnish, if necessary.",
        "#",
        "CDP> halt",
        "  Are U serious 'bout halt? yes",
        "  halt:by user@007",
        "CDP> check",
        "checkpoint:written into sms.check by user@007",
        "CDP> terminate",
        "  Are U serious 'bout terminate? yes",
        "  terminate:by user@007",
        "  terminate:breaking up the connection.",
        "#",
        "#  Change the version / change the node and start the SMS",
        "#  Login again!",
        "#",
        "CDP> recover",
        "recover:complete from sms.check by user@007",
        "CDP> restart",
        "CDP> Are U serious 'bout restart? yes",
        "restart:by user@007",
        NULL
      )
    );

  return called = TRUE;
}

static int lockit(int argc, char **argv)
/**************************************************************************
?  Lock the SMS.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"lock"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
    else
      return FALSE;
  }
  else
    ioi_exe_add("lock:cdp",lockit,
      yes,
      NULL,
      ioi_exe_argv(
        "Lock the SMS.",
        "Halt SMS by  obtaining exclusive lock on it",
        "Only one user at the time may have the lock use unlock(CDP)",
        "to release the lock.",
        NULL
      )
    );

  return called = TRUE;
}

static int unlockit(int argc, char **argv)
/**************************************************************************
?  Unlock the SMS.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"unlock"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
    else
      return FALSE;
  }
  else
    ioi_exe_add("unlock:cdp",unlockit,
      yes,
      NULL,
      ioi_exe_argv(
        "Unlock the SMS.",
        "Release the exclusive lock."
        "","NOTICE","",
        "This will release the lock even if you don't own it",
        NULL
      )
    );

  return called = TRUE;
}

static int restart(int argc, char **argv)
/**************************************************************************
?  Restart the SMS.
|  Currently this is for the testing only.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"restart"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      return ! sms_client_cmd( HANDLE,1,av,NULL,0,NULL );
    else
     return FALSE;
  }
  else
    ioi_exe_add("restart:cdp",restart,
      yes,
      NULL,
      ioi_exe_argv(
        "Restart the SMS.",
        "The SMS must be restarted in the beginning of the SMS and after",
        "shutdown to anything happen.",
        "","The user needs OPER or SYSTEM privileges.",
        NULL
      )
    );

  return called = TRUE;
}

static int terminate(int argc, char **argv)
/**************************************************************************
?  Terminate the SMS.
************************************o*************************************/
{
  static int   called;

  if( called )
  {
    char *av[1] = {"terminate"};
    argv--; argc++;                /* The SMS-command name */

    if( yes_option || sms_confirm(*argv) )
      if(sms_client_cmd( HANDLE,1,av,NULL,0,NULL ))
        return FALSE;              /* FAILED! */
      else
      {
        ioi_out(0,IOI_MSG,"terminate:breaking up the connection.");
        return sms_client_terminate(HANDLE,TRUE);
      }
    else return FALSE;
  }
  else
    ioi_exe_add("terminate:cdp",terminate,
      yes,
      NULL,
      ioi_exe_argv(
        "Terminate the SMS.",
        "The SMS will exit. It is good practice to make sure there is a",
        "valid checkpoint file before terminating the SMS.",
        "Upon completion the connection is also broken.",
        "","The user needs SYSTEM privileges.",
        NULL
      )
    );

  return called = TRUE;
}

static int expire(int argc, char **argv)
/**************************************************************************
?  Expire all date/time dependencies on a node
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   recursively;

  if( called )
  {
    char     *av[2] = {"expire"};
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,sms_encode(&recursively,NULL),&names);
  }
  else
    ioi_exe_add("expire:cdp",expire,
      0,
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be expired.",
#ifdef USE_NET_NAMES
          "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          "Node must be defined.",
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Expire all date/time-dependencies on node(s) given.",
        "All date/time-dependencies are marked as used regardless if they",
        "have been expired or are in use (holding). This is useful for task",
        "which have repeated time dependencies but you want to stop running",
        "the task",
        "",
        "The user must have USER or OPER privileges to expire node(s).",
        "","NOTICE!","",
        "It is not an error to expire a node that has no date/time",
        "dependencies defined.",
        "Those attemps are silently ignored.",
        NULL
      )
    );

  return called = TRUE;
}

static int expand(int argc, char **argv)
/**************************************************************************
?  Expand regular epression to form a variable
************************************o*************************************/
{
  static int   called;
  static char *name;
  static char *dummy;

  if( called )
  {
    sms_list *names = 0;           /* Filled by the CD */
    int       len   = 1;
    char     *buff  = 0;
    sms_list *lp;
    int       rc = 1;

    if(dummy) { argc++; argv--; }

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

#ifdef USE_NET_NAMES
#else
#endif

    for(lp=names ; lp ; lp=lp->next)
      len += strlen(lp->name) + 1;
  
    if(len < MAXLEN && (buff=malloc(len)))
    {
      char *s = buff;
      for(lp=names ; lp ; lp=lp->next)
      {
        strcpy(s,lp->name);
        s += strlen(lp->name);
        *s++ = ' ';
      }
      *s = 0;

      /* printf("s is [%s]\n",STR(buff)); */
      rc = ioi_variable_set(name,buff);
      /* printf("rc: %d\n",rc); */
    }

    ls_delall(&names);
    IFFREE(buff);

    return rc;
  }
  else
    ioi_exe_add("expand:cdp",expand,
      0,
      ioi_exe_link_param(
        ioi_exe_param(
          "variable",IOI_L_STRING,ioi_exe_argv(
            "The name of the variable to hold the values of the expansion.",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) or regexp of the name(s) to be expanded.",
            "Node must be defined and known by cdp (check suites).",
            NULL
          ),NULL,-1,&dummy
        ),
        0
      ),
      ioi_exe_argv(
        "Expand the regular expression of node name(s).",
        "A CDP variable is created to hold the names of the expansion.",
        "","Example","",
        "expand n /*/*",
        "loop i ( $n ) do",
        "  alter -v $i dummyvar value",
        "endloop",
        NULL
      )
    );

  return called = TRUE;
}

static int reset(int argc, char **argv)
/**************************************************************************
?  Reset limit
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    char     *av[2] = {"reset"};
    sms_list *names = NULL;        /* Filled by the CD, removed by CLIENT */

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,0,&names);
  }
  else
    ioi_exe_add("reset:cdp",reset,
      0,
      ioi_exe_param(
        "limit(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the limit(s) to be reset.",
#ifdef USE_NET_NAMES
          "The node names can be netnames (//host/suite[....])",
#endif
          "Node must be defined.",
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Reset limit(s) to tasks that are still running",
        "When things are forced on SMS by means of cancel(CDP), migrate(CDP)",
        "run(CDP), force(CDP), play(CDP) etc, tasks may be left into limit even",
        "if they don't actually exist anymore as a job. Rather that clearing them",
        "individually (by alter -N) you can ask SMS to check that if the names in",
        "limit exists and that they are still running.",
        "Unaccounted for entries are removed and the counter set accordingly.",
        "",
        "Giving a node other that limit will scan all the limits in that node.",
        "Thus 'reset /' will reset all limits in SMS.",
        "",
        "The user must have USER or OPER privileges to reset limit(s).",
        "","NOTICE!","",
        "The counting is incorrect if there are names that are migrated and these",
        "tasks are actually still running. (SMS does NOT scan migrated nodes.)",
        NULL
      )
    );

  return called = TRUE;
}

static int zombies(int argc, char **argv)
/**************************************************************************
?  Manage zombies
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   delete, fob, fail, rescue;

  if( called )
  {
    sms_list *names = 0;
    int       rc;
    int       cmd;

#if 0
if(argc > 0)
printf("argv[0] %s\n",STR(argv[0]));
#endif

    if(dummy) { argc++; argv--; }


    cmd = ZOMBIE_GET;
    if(fob)    cmd = ZOMBIE_FOB;
    if(delete) cmd = ZOMBIE_DELETE;
    if(fail)   cmd = ZOMBIE_FAIL;
    if(rescue) cmd = ZOMBIE_RESCUE;

    ls_argv(&names,argc,argv);

    rc = cdp_zombies( HANDLE, cmd, names, NULL );
    NODE_FREE(names,sms_list);

    return rc;
  }
  else
    ioi_exe_add("zombies:cdp",zombies,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ddelete",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the named zombie(es)",
            NULL
          ),NULL,1,&delete
        ),
        ioi_exe_param(
          "-ffob",IOI_L_BOOLEAN,ioi_exe_argv(
            "Fob to the named zombie(es)",
            "The messages from zombie task(s) are accepted so that the",
            "task(s) can eventually terminate, but nothing is done by.",
            "SMS (tasks do not change status)",
            NULL
          ),NULL,1,&fob
        ),
        ioi_exe_param(
          "-rrecover",IOI_L_BOOLEAN,ioi_exe_argv(
            "Recover a task from the zombie.",
            "Move the password from the zombie back to the task.",
            NULL
          ),NULL,1,&rescue
        ),
        ioi_exe_param(
          "-Ffail",IOI_L_BOOLEAN,ioi_exe_argv(
            "Fail to the named zombie(es)",
            "The zombie task(s) are asked to fail and stop talking to SMS(es).",
            "Tasks should exit with status 1.",
            NULL
          ),NULL,1,&fail
        ),
        NULL
      ),
      ioi_exe_param(
        "zombie(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the zombie(s).",
          "If none are given all zombies will be listed.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Control zombies in SMS.",
        "SMS may be configured to remember tasks that were running when",
        "user reruns, requeues, cancels them or by similar action makes",
        "the password held be SMS to be lost. These tasks are called zombies.",
        "Zombies also exist if another SMS has lost interest on a task which",
        "is running, eventually trying to connect to any SMS who is willing",
        "to listen.",
        "",
        "Without arguments this command lists all the zombies in SMS.",
        NULL
      )
    );

  return called = TRUE;
}

static int url(int argc, char **argv)
/**************************************************************************
?  Execute URL command
=  ABT (c) extension / OP
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   delete, fob, fail, rescue;

  if( called )
  {
    sms_list *names = 0;           /* Filled by the CD */
    sms_list *lp;
    int       rc = 1;
    char      line[MAXLEN];


    sms_node *np;
    sms_variable *vp;;

    if(dummy) { argc++; argv--; }

    /* USE_NET_NAMES */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    for(lp=names ; lp ; lp=lp->next)
    {
      if( (np=sms_node_net_find(lp->name)) )
        if( (vp=sms_variable_getvar("SMSURLCMD",np)) )
        {
          if(sms_edit_string(np,vp->value,line))
          {
            printf("Executing [%s]\n",line);
            system(line);
          }
        }
        else
          rc=spit(0,IOI_ERR,"url:no SMSURLCMD defined for %s",lp->name);
      else
        rc=spit(0,IOI_ERR,"url:no node %s",lp->name);
    }

    ls_delall(&names);

    return rc;
  }
  else
    ioi_exe_add("url:cdp",url,
      NULL, /* no options */
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s).",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Execute command to display URL.",
        "Tasks may be given variables SMSURL which will be given to a",
        "command SMSURLCMD to be executed by the CDP",
        "","EXAMPLE","",
        "suite x",
        "  edit SMSURLCMD \"netscape -remote 'openURL(%URLBASE%/%URL%)'\"",
        "  edit URLBASE  file:/home/otto/sms/doc",
        "  family f",
        "    task t1",
        "      edit URL acknowledge.html",
        "    task t2",
        "      edit URL index.html",
        0
      )
    );

  return called = TRUE;
}

static int jobstatus(int argc, char **argv)
/**************************************************************************
?  Execute job-status request
=  ABT (c) extension / OP
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   delete, fob, fail, rescue;

  if( called )
  {
    sms_list *names = 0;           /* Filled by the CD */
    sms_list *lp;
    int       rc = 1;
    char     *filename = 0;

    if(dummy) { argc++; argv--; }

    /* USE_NET_NAMES */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    for(lp=names ; lp ; lp=lp->next)
      cdp_jobstatus(HANDLE,lp->name,MAXLINES, &filename);

    ls_delall(&names);

    return rc;
  }
  else
    ioi_exe_add("jobstatus:cdp",jobstatus,
      NULL, /* no options */
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s).",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Execute command to display job status.",
        "Tasks may be given variables SMSSTATUSCMD which will be executed",
        "by the CDP to display job status. Obiviously the command depends",
        "on the queing system being used.",
        "","EXAMPLE","",
        "  edit SMSSTATUSCMD 'rsh %SCHOST% qstat -f %SMSRID%.%SCHOST%'",
        "  edit SMSSTATUSCMD 'ps --sid %SMSRID% -f'",
        "  (make sure smsinit sends the session id)",
        "  (eg smsinit $(getsid))",
        0
      )
    );

  return called = TRUE;
}

static int mail(int argc, char **argv)
/**************************************************************************
?  Manage mail
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   delete;
  static char *user;
  static int   clear;

#if 0
  mail
  mail -d
  mail -C
  mail user text
#endif

  if( called )
  {
    sms_handle *hp = HANDLE;

    sms_list *lp = 0;
    int       rc;
    int       cmd;
    int       number;
    int       lastline = 0;

    cmd = MAIL_GET;
    if(delete) cmd = MAIL_DEL;
    if(dummy)  cmd = MAIL_SEND;
    if(clear)  cmd = MAIL_DELMOT;

    if( hp ) lastline = hp->lastline;
    number = lastline;

    if(cmd==MAIL_SEND)
    {
      char line[MAXLEN];
      int  goon = 1;
      while( goon )
      {
        printf("mail> ");
        if( fgets(line,MAXLEN-1,stdin) )
        {
          sms_no_newline(line);
          if(line[0] == '.' && line[1] == '\0')
            goon = 0;
          else
            ls_add(&lp,ls_create(0,line));
        }
        else
          goon = 0;
      }
      if( !lp )
      {
        ioi_printf(IOI_WAR,"mail: nothing send\n");
        return 1;
      }
    }

    rc = cdp_mail(HANDLE, cmd, &number, dummy, &lp);

    if( lp )
    {
      if(cmd==MAIL_GET && lp)
        hp->lastline = number;

      sms_list_print(&lp,stderr);
    }
    NODE_FREE(lp,sms_list);

    return rc;
  }
  else
    ioi_exe_add("mail:cdp",mail,
      ioi_exe_link_param(
        ioi_exe_param(
          "-CclearMOT",IOI_L_BOOLEAN,ioi_exe_argv(
            "Clear the Message Of Today in SMS",
            "Only users with PRIV_ADMIN can use this option.",
            NULL
          ),NULL,1,&clear
        ),
        ioi_exe_param(
          "-ddelete",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the read mail in SMS",
            NULL
          ),NULL,1,&delete
        ),
#if 0
        ioi_exe_param(
          "-ssend",IOI_L_STRING,ioi_exe_argv(
            "Send mail to the user",
            NULL
          ),NULL,1,&user
        ),
#endif
        NULL
      ),
      ioi_exe_param(
        "text",IOI_L_STRING,ioi_exe_argv(
          "The text to be send.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Control your mail in SMS.",
        "SMS may hold mail for you, this command allows you the manage it.",
        "",
        "Without arguments this command lists all your mail in SMS.",
        "User names are those listed with command users(CDP) or the first",
        "part of that, SMS and \"*\". SMS will create new MOT and send the",
        "mail to everyone currently logged in. \"*\" will send to everyone.",
        NULL
      )
    );

  return called = TRUE;
}

int cdp_exit(int code)
/**************************************************************************
?  Terminate the CDP.
|  If "logged" in to the SMS then logout.
|  Called by the IOI.
************************************o*************************************/
{
  while( sms_._logins )            /* Log out of all SMSes */
  {
    if( sms_client_is_ok(HANDLE)==SMS_E_OK )
      sms_client_logout(HANDLE);
    else
      sms_client_remove(HANDLE,SMS_E_OK);
  }

  printf("Goodbye %s\n",STR(cuserid(NULL)));

  ioi_close();
  exit(code);

  return 0;
}

int cdp_init(int *argc, char **argv, int xcdp)
/**************************************************************************
?  Initialize the CDP module
************************************o*************************************/
{
 /*
  *  The options should be processed before ioi_open
  */

  signal(SIGPIPE,SIG_IGN);

  ls_open();
  ioi_open(*argc,argv,"CDPRC");
  ioi_try_name("IOIRC");

  ioi_variable_set("prompt","CDP");
  ioi_variable_set("cwn","/");
  ioi_variable_set("ioi_title","ECMWF Command and Display Program");

  ioi_user_exit(cdp_exit);

  sms_._is_server = FALSE;
  sms_._is_xcdp = xcdp;

  sms_numbers(
    (getenv("SMS_PROG"))? atoi(getenv("SMS_PROG")) : SMS_PROG ,
    (getenv("SMS_VERS"))? atoi(getenv("SMS_VERS")) : SMS_VERS
  );

  build_yes();

  test      (0,NULL);
  info      (0,NULL);
  find      (0,NULL);

  ping      (0,NULL);

  play      (0,NULL);              /* Let's load the commands into IOI */
  show      (0,NULL);
  playbin   (0,NULL);
  makebin   (0,NULL);
  login     (0,NULL);
  swap      (0,NULL);
 _passwd    (0,NULL);
  logout    (0,NULL);
  smscmd    (0,NULL);
  servers   (0,NULL);
  news      (0,NULL);
  history   (0,NULL);
  users     (0,NULL);
  begin     (0,NULL);
  action    (0,NULL);
  suspend   (0,NULL);
  resume    (0,NULL);
  cancel    (0,NULL);
  force     (0,NULL);
  requeue   (0,NULL);
  resubmit  (0,NULL);
  run       (0,0);
  dir       (0,NULL);
  file      (0,NULL);
 _send      (0,NULL);              /* Renemed cos' the VMS protos! */
  mkdirs    (0,NULL);
  check     (0,NULL);
  recover   (0,NULL);
 _shutdown  (0,NULL);              /* Renemed cos' the VMS protos! */
  halt      (0,NULL);
  lockit    (0,NULL);
  unlockit  (0,NULL);
  restart   (0,NULL);
  terminate (0,NULL);
  expire    (0,0);
  expand    (0,0);
  reset     (0,0);
  zombies   (0,0);
  mail      (0,0);
  url       (0,0);
  jobstatus (0,0);

  get       (0,NULL);
  cwn       (0,NULL);
  suites    (0,NULL);
  sms_register (0,NULL);

  privileges(0,NULL);

  cdp_status       (0,NULL);       /* From the file cstatus.c  */
  sms_delete_cmd   (0,NULL);       /* From the file delete.c   */
  sms_alter_cmd    (0,NULL);       /* From the file alter.c    */
  cdp_why          (0,NULL);       /* From the file why.c      */
  cdp_overview_cmd (0,NULL);       /* From the file overview.c */
  cdp_loggen_cmd   (0,NULL);       /* From the file loggen.c   */
  cdp_order_cmd    (0,NULL);       /* From the file order.c    */
  cdp_kill_cmd     (0,NULL);       /* From the file kill.c     */
  cdp_jobcheck_cmd (0,NULL);       /* From the file kill.c     */
  cdp_migrate_cmd  (0,NULL);       /* From the file migrate.c  */
  cdp_restore_cmd  (0,NULL);       /* From the file migrate.c  */
  cdp_migrate_plug (0,NULL);       /* From the file migrate.c  */
  cdp_log_cmd      (0,NULL);       /* From the file log.c      */
  cdp_html_cmd     (0,NULL);       /* From the file html.c     */
  sms_play_load();
  sms_malloc(0,NULL);

  return 0;
}

int cdp_command(sms_handle *hp, int argc, char **argv, sms_list **lp)
/**************************************************************************
?  Execute and parse a command.
|  Made for the XCDP.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_handle *tmp = 0;
  int  rc;
  int  i;

  if(argc >= ioi_._asize) return
    ioi_out(SMS_E_MEMORY,IOI_ERR,"CDP-COMMAND:Too many arguments %d",argc);

  ioi_._argc = argc;

  for( i=0 ; i<argc ; i++ )        /* No need to release since the IOI */
    ioi_._argv[i] = argv[i];       /* only uses these, not frees them  */

  ioi_._argv[argc]=NULL;

  sms_._client_error = SMS_E_OK;

  sms_client_copy(lp);             /* Command the CLINET to save messages */

  sms_._super         = hp->super;
  sms_._action_number = hp->action_number;
  sms_._modify_number = hp->modify_number;
  sms_._xdr_version   = hp->rev*1000+hp->mod;
  hp->super = 0;
  if(sms_._super)
    sms_._super->parent = 0;

  tmp          = sms_._logins ;    /* Oh boy, wot can I say? */
  sms_._logins = hp;

#if 0
  printf("cdp_command: for %s is::",STR(hp->name));
  ioi_misc_arg("",argc,argv);
  printf("\n");
#endif

  rc = ioi_exe_substitute(NULL,0,NULL);
  sms_client_copy(NULL);           /* Stop saving the messages */

  sms_._logins = tmp;

  hp->super = sms_._super;
  hp->action_number = sms_._action_number;
  hp->modify_number = sms_._modify_number;
  sms_._super = 0;
  sms_._action_number = sms_._modify_number = 0;

  if( rc )
    return SMS_E_PROTOCOL;

  return sms_._client_error;
}
