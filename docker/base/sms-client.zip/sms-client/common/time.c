/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     TIME
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     14-DEC-1992 / 10-SEP-1991 / OP
.VERSION  4.0
.FILE     time.c
*
.DATE     26-FEB-1993 / 26-FEB-1993 / OP
.VERSION  4.1
.DATE     27-APR-1993 / 22-APR-1993 / OP
.VERSION  4.2
.DATE     20-MAR-1995 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-5
*         Fixed a bug in sms_time_complete() to force a family to be
*         complete if all the tasks in it are complete because they
*         do not run today.
*         Added support for autocancel/automigration
.DATE     20-SEP-1995 / 20-SEP-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     16-JAN-1996 / 16-JAN-1996 / OP
.VERSION  4.3.13
*         Added today time dependency
.DATE     08-APR-1997 / 08-APR-1997 / OP
.VERSION  4.3.14
*         Year is now 4 digits
.DATE     11-MAR-1998 / 11-MAR-1998 / OP
.VERSION  4.3.17
*         Bug fix for nodes that are complete by default
.DATE     22-APR-1998 / 22-APR-1998 / OP
.VERSION  4.3.18
*         Expire time/date-dependencies
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     15-JAN-1999 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
*         mktime everywhere
.DATE     07-MAR-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
*
*  Time and date calculating routines:
*
************************************o*************************************/

#include "smslib.h"

static time_t    suite_time;       /* The time for the current suite */
static int       suite_clock;      /* The type of the clock          */
static time_t    suite_morning;    /* The time in sec at 00:00 today */
static int       suite_midnight;
static struct tm suite_tm;         /* and it broken into pieces      */
static time_t    current_time;     /* No need to call time all the time */

time_t sms_time_t(time_t *t)
/**************************************************************************
?  This routine can be modified to run differently on SMS and CDP sides
|  to allow total gain of SMS using gain on super node level.
=  Return the time since 1.1.1970 in seconds in GMT.
************************************o*************************************/
{
  return current_time = time(t);
}

time_t sms_time_current(time_t *t)
/**************************************************************************
?  Return last time, to avoid some system calls
=  Return the time since 1.1.1970 in seconds in GMT.
************************************o*************************************/
{
  if( t ) *t = current_time;
  return current_time;
}

struct tm *sms_time_tm(time_t *t)
/**************************************************************************
?  Brake the time pointed by [t] into fields.
************************************o*************************************/
{
  return gmtime(t);
}

char *sms_time_c(time_t *t)
/**************************************************************************
?  Return the time in ascii without the newline
************************************o*************************************/
{
  return sms_no_newline(ctime(t));
}

time_t sms_time_gmt(struct tm *tm)
/**************************************************************************
?  Return the time in seconds (GMT or UTC) from the broken down time
=  -1 if errors
************************************o*************************************/
{
  return mktime(tm);

#if 0
  return timegm(tm);
#endif
}

#if defined(mips) && ! ((defined(sgi) || defined(__sgi)))
#  define MKTIME_MISSING
#  include "mktime.c"
#endif

char *sms_time_gmt2s(time_t t)
/**************************************************************************
?  Convert the time_t value into ascii text in GMT timezone
=  The string in static area (overwritten at next call)
* NA
************************************o*************************************/
{
  return asctime(gmtime(&t));
}

sms_time_s2gmt(char *s)
/**************************************************************************
?  Convert the string into time_t
=  GMT seconds
|  unix time "starts" at 00:00:00 1.1.1970
|  -1 indicates an error
************************************o*************************************/
{
  return 0;
}


void sms_time_load(sms_node *np)
/**************************************************************************
?  Just load the current values to the statics used by the other routines
************************************o*************************************/
{
  sms_node *suite = np;

  struct tm *tm;

  while( suite->parent && suite->type != NODE_SUITE ) suite = suite->parent;

  suite_clock   = suite->clock;
  suite_time    = suite->stime;
  tm            = gmtime( &suite_time );

  memcpy(&suite_tm,tm,sizeof(suite_tm));

  suite_morning = suite_time - (tm->tm_sec+tm->tm_min*60+tm->tm_hour*3600);

  return;
}

int sms_time_suite(
    sms_node *np,                  /* To get the gain and clock type */
    int       init,                /* Is this a begin command?       */
    nid_func  func,                /* To update XCdp                 */
    void     *userdata)
/**************************************************************************
?  Calculate the current time and day to process the suite given.
|  The time (in seconds) differs from the systems (GMT time) by the
|  amount stored in np->gain.
|  Also the np->clock field determines the action on the midnight,
|  which is derived from the time in seconds.
*
*  The suite hold's its current time in the field .stime (sec in GMT)
*
*  The date/day dependencies are processed only when the day changes
*  or with the begin command.
*
=  TRUE if the midnight changed, FALSE otherwise.
************************************o*************************************/
{
  struct tm     last_tm;           /* Needed for the CLOCK_HYBRID    */
  int           midnight;          /* If a midnight was passed       */
  sms_variable *v;                 /* Used to add into list */
  struct tm    *tm;

  if( !np ) return FALSE;          /* Well it really didn't change! */

  if( np->type != NODE_SUITE )
  {
    fprintf(stderr,"ERROR: sms_time_suite for %s\n",STR(sms_node_full_name(np)));
    return FALSE;
  }

/*
 *  ->btime needed for the hybrid clock
 */

  if(init || np->status == STATUS_UNKNOWN )  /* Calculate the date! */
  {                                          /* Keep it in seconds  */
    np->btime  = sms_time_t(NULL);

    if( np->clock == CLOCK_HYBRID )
    {
      np->btime += np->gain;
    }

    np->btime  = (np->btime / 86400)*86400;
/*
    tm         = sms_time_tm( &np->btime );
    np->btime -= (tm->tm_sec+tm->tm_min*60+tm->tm_hour*3600);
*/
  }

  tm = sms_time_tm( &np->btime );
  memcpy(&last_tm,tm,sizeof(last_tm));

  np->stime = suite_time = sms_time_t(NULL) + np->gain;
  tm = sms_time_tm( &suite_time );
  memcpy(&suite_tm,tm,sizeof(suite_tm));

  midnight = ( suite_tm.tm_yday > last_tm.tm_yday ||
               suite_tm.tm_year > last_tm.tm_year );

  suite_morning = suite_time - (tm->tm_sec+tm->tm_min*60+tm->tm_hour*3600);
  suite_clock   = np->clock;

  if( np->clock == CLOCK_HYBRID )
  {
    if( FALSE )                    /* These "run" with the system clock */
    {
      suite_tm.tm_sec   = last_tm.tm_sec;   /* seconds (0 - 59)         */
      suite_tm.tm_min   = last_tm.tm_min;   /* minutes (0 - 59)         */
      suite_tm.tm_hour  = last_tm.tm_hour;  /* hours (0 - 23)           */
    }

    suite_tm.tm_mday  = last_tm.tm_mday;    /* day of month (1 - 31)    */
    suite_tm.tm_mon   = last_tm.tm_mon;     /* month of year (0 - 11)   */
    suite_tm.tm_year  = last_tm.tm_year;    /* year - 1900              */
    suite_tm.tm_wday  = last_tm.tm_wday;    /* day of week (Sunday = 0) */
    suite_tm.tm_yday  = last_tm.tm_yday;    /* day of year (0 - 365)    */

    midnight = FALSE;              /* The date doesn't change in HYBRID */
  }
  else                             /* CLOCK_REAL */
    np->btime = suite_time;

  /* Generate the time dependent variables for the suite */

#define GEN sms_variable_time(np,func,userdata,
  GEN "DATE"   , "%02d.%02d.%04d", suite_tm.tm_mday, suite_tm.tm_mon+1, suite_tm.tm_year+1900);
  GEN "DAY"    , "%s"            , day_name[suite_tm.tm_wday]      );
  GEN "DD"     , "%02d"          , suite_tm.tm_mday                );
  GEN "DOW"    , "%d"            , suite_tm.tm_wday                );
  GEN "DOY"    , "%d"            , suite_tm.tm_yday+1              );
  GEN "MM"     , "%02d"          , suite_tm.tm_mon+1               );
  GEN "MONTH"  , "%s"            , month_name[suite_tm.tm_mon]     );
  GEN "YYYY"   , "%04d"          , suite_tm.tm_year + 1900         );

  GEN "SMSDATE" , "%04d%02d%02d", suite_tm.tm_year + 1900, suite_tm.tm_mon+1 , suite_tm.tm_mday);
  GEN "SMSTIME" , "%02d:%02d"   , suite_tm.tm_hour,suite_tm.tm_min);
  GEN "SMSCLOCK", "%s:%s:%d:%d",
      day_name[suite_tm.tm_wday], month_name[suite_tm.tm_mon] ,
      suite_tm.tm_wday, suite_tm.tm_yday+1 );

#undef GEN

/*
  spit(0,IOI_DBG,"Time for %s is %02d:%02d:%02d in GMT %d",np->name,
       suite_tm.tm_hour,suite_tm.tm_min,suite_tm.tm_sec,suite_time);
*/

  if( midnight )
    spit(0,IOI_LOG,"midnight:suite %s past midnight",STR(np->name));

  return suite_midnight = midnight;
}

void sms_time_clock_vars(int gain)
/**************************************************************************
?  Generate a few variables for CDP only
|  Called from play-defintion when clock is defined
************************************o*************************************/
{
  struct tm *tm;
  time_t     t;
  int        days_in_month = 0;

  sms_time_t(&t);
  t += gain;

  tm = sms_time_tm(&t);

  while( ! days_in_month || tm->tm_mday != 1 )
  {
    days_in_month = tm->tm_mday;
    t += 86400;
    tm = sms_time_tm(&t);
  }

  ioi_variable_set_int("days_in_month",days_in_month);
}

int sms_time_free(sms_time *tp)
/**************************************************************************
?  Check if the node does have HOLDING time-deps that have actually EXPIRED.
|  Since only one of them can be expired at any given time, return when the
|  first one is found (not necessarily the oldes one).
|
|  This is only called for QUEUED nodes.
=  BOOLEAN status, TRUE if the time was released, FALSE otherwise.
@  suite_time
************************************o*************************************/
{
  sms_time *orig = tp;

  while(tp)
    if(tp->status == TIME_EXPIRED) /* Only one at the time! */
      return FALSE;
    else
      tp = tp->next;

  tp = orig;
     
  while(tp)
  {
    if( tp->status == TIME_HOLDING )
      if( tp->nexttime <= suite_time )
      {
        tp->act_no = ++sms_._action_number;
        tp->status = TIME_EXPIRED;
        return TRUE;               /* Yeps suite must change! */
      }

    tp = tp->next;
  }

  return FALSE;
}

int sms_time_date_free(sms_date *dp)
/**************************************************************************
?  Check if the node does have HOLDING date-deps that have actually EXPIRED.
|  Count all EXPIRED date-deps and mark.
|  This is called for nodes that are not:
|    - unknown
|    - complete
|  This is called only at the time midnight changes.
=  BOOLEAN status, TRUE if any of the date-dep was released, FALSE otherwise.
************************************o*************************************/
{
  int count = 0;                   /* Of newly EXPIRED dates */

  while( dp )
  {
    if( dp->status == TIME_HOLDING )
    {
      sms_time_date_calc( dp );
      if( dp->status == TIME_EXPIRED )
        count++;
    }
    dp = dp->next;
  }

  return count? TRUE : FALSE;      /* Could just return the count! */
}

int sms_time_suite_complete(sms_node *np)
/**************************************************************************
|  Check if suite must be held as complete past some time
=  BOOLEAN status
************************************o*************************************/
{
  if(!np->time) return 0;

  sms_time_suite(np,0,0,0);

  if(np->time->nexttime < suite_time)
    return 0;

  return 1;
}

/* NOT USED??? */
#if 0
int sms_time_suite_repeat(sms_node *np)
{
  if(np->time && np->status == STATUS_COMPLETE)
  {
    sms_time_suite(np,0,0,0);

    if( np->time->nexttime < suite_time )
    {
      sms_repeat_node(np);
    }
  }

  return 0;
}
#endif

sms_date *sms_time_date_holding(sms_date *dp)
/**************************************************************************
?  Check if any of the date is holding the QUEUED node.
|  This works for both the SMS-TIME and SMS-DATE
=  Return the holding date-pointer if any.
|  If any of the time/date-dependencies has expired a NULL is returned
|  otherwise the next one (if any) to expire is returned.
*OLD
*  TRUE if none of the date-deps is EXPIRED,
*  FALSE if node is free to go by date-deps
************************************o*************************************/
{
  sms_date *next = NULL;           /* Next holding date to come */

  for( ; dp ; dp=dp->next )
    switch( dp->status )
    {
      case TIME_EXPIRED:           /* It's free to go by the time */
        return NULL;
        /* break; */

      case TIME_HOLDING:
        if( !next || (next->nextdate > dp->nextdate))
          next = dp;
        break;
    }
 
  return next;
}

static void parent_check(sms_node *np)
/**************************************************************************
?  Check the status of the node after kids have (possible) changed
************************************o*************************************/
{
  int max_kid, old;

  if(!np) return;

  if( ! IS_RUNNING && np->type==NODE_SUPER )
    return;

  max_kid = sms_status_max(np->kids);
  old     = np->status;

  if(old == max_kid)
    return;

  if(np->status == STATUS_SUSPENDED)
    np->savedstat = max_kid;
  else
    np->status = max_kid;

  SUITE_CHANGED(np);

  if(np->type == NODE_SUPER)
    return;

  parent_check(np->parent);
}

int sms_time_complete(sms_node *np)
/**************************************************************************
?  Mark the node to be complete in hybrid-clock date-dependencies that
|  doesn't match today.
************************************o*************************************/
{
  sms_node *kids;

  np->status = STATUS_COMPLETE;

  for( kids=np->kids; kids ; kids=kids->next )
    sms_time_complete(kids);

  parent_check(np->parent);

  return 0;
}

int sms_time_autocm(sms_node *np, int type)
/**************************************************************************
?  Check if node can be cancelled.
=  Boolean status if the cancel on a node has expired.
************************************o*************************************/
{
  sms_time *cp;

  if( np->status != STATUS_COMPLETE || np->autocm==NULL ) return FALSE;
  if( np->autocm->type != type ) return FALSE;

  cp=np->autocm;

  if( cp->status == TIME_UNUSED )  /* Node just became complete */
  {
    int offset = cp->hour[0]*3600 + cp->minute[0]*60;

    if( !cp->relative )
      offset=cp->hour[0]*24*3600;  /* Operations */

    cp->nexttime = sms_time_t(NULL) + offset;

    cp->status = TIME_HOLDING;

    if( offset == 0 )              /* Cancel it NOW */
    {
      cp->act_no = ++sms_._action_number;
      cp->status = TIME_EXPIRED;
      /* sms_cancel(np,TRUE,FALSE,FALSE); */   /* Or next time they are checked */
    }
  }

  if( cp->status == TIME_HOLDING )
    if( current_time > cp->nexttime )
    {
      cp->act_no = ++sms_._action_number;
      cp->status = TIME_EXPIRED;
    }

  if( cp->status == TIME_EXPIRED )
    return TRUE;

  return FALSE;
}

void sms_time_autocm_string(sms_node *np, char *str)
/**************************************************************************
?  Print the auto[cancel/migrate] status
|  This can be of interest only if the autocm->status == HOLDING
************************************o*************************************/
{
  sms_time *cp=np->autocm;
  int sec;

  if( np->status != STATUS_COMPLETE || !cp ) return;

  sms_time_load(np);

  if( cp->status == TIME_HOLDING )
  {
    sec = cp->nexttime - current_time;
    if(sec > 0)
    {
      int d,h,m,s;

      d =  sec / 86400;
      h = (sec % 86400) / 3600;
      m = (sec %  3600) / 60;
      s =  sec %    60;

      if(d>0)
        sprintf(str," (expires in %d days and %02d:%02d:%02d)",d,h,m,s);
      else
        sprintf(str," (expires in %02d:%02d:%02d)",h,m,s);
    }
    else
      sprintf(str," should have expired");
  }
}

void sms_time_autocm_init(sms_node *np)
/**************************************************************************
?  Initialize the autocancel/automigration structures
|  This is done after sms_time_mark() so nodes that are complete by default
|  can be subject to cancellation.
************************************o*************************************/
{
  sms_time *cp;

  cp = np->autocm;
  while( cp )                    /* Calculate the next time! */
  {
    cp->act_no    = ++sms_._action_number;
    cp->status    = TIME_UNUSED;
    cp->nexttime  = 0;
    cp            = cp->next;
  }

  if( sms_time_autocm(np, np->autocm? np->autocm->type : 0) )
    return;

  np = np->kids;
  while( np )                    /* Loop the kids also */
  {
    sms_node *next = np->next;   /* np might disapper in cancel_init() */
    sms_time_autocm_init( np );
    np = next;
  }
}

int sms_time_mark(sms_node *np)
/**************************************************************************
?  Mark the time stamps in the nodes and calculate the next times for
|  the nodes.
|  Used by the BEGIN-command and if the family has a repeated-time.
|  Also, by the REQUEUE-command.
|  Also, later on, by the RERUN-command.
************************************o*************************************/
{
  sms_date *dp;
  sms_time *tp;
  sms_time *lp;
  int       complete = FALSE;

  if( dp = np->date )              /* If none matches, it's complete */
    complete = TRUE;

  while( dp )                      /* Calculate the next day */
  {
    dp->act_no = ++sms_._action_number;
    dp->status = TIME_UNUSED;
    sms_time_date_calc(dp);        /* Derive from the suite-time */

    if( dp->status == TIME_EXPIRED )
      complete = FALSE;            /* Any match ---> run them */

    dp = dp->next;
  }

  if( suite_clock == CLOCK_HYBRID && complete )
    sms_time_complete(np);
  else
  {
    tp = np->time;
    while( tp )                    /* Calculate the next time! */
    {
      tp->act_no = ++sms_._action_number;
      tp->status = TIME_UNUSED;
      sms_time_calc(tp);           /* Derive from the suite-time */
      tp = tp->next;
    }

    if(np->type==NODE_TASK || np->type==NODE_FAMILY)
      np->stime = suite_time;
    lp = np->late;
    if( lp )
      np->late->status = 0;

    np = np->kids;
    while( np )                    /* Loop the kids also */
    {
      sms_time_mark(np);
      np = np->next;
    }
  }

  return 0;
}

void sms_time_waiting(sms_node *np)
/**************************************************************************
?  Check the time and date dependencies. (SMS ONLY)
|  Should be called once in a minute, or at least, not so often than the
|  node processing.
|
|  Nodes that has expiried are marked
|  suite is marked to be changed.
|
|  Only one time can be EXPIRED at the same time.
************************************o*************************************/
{
  sms_node *orig = np;

  if( !np ) return;

  if( orig->type == NODE_SUITE ) suite_midnight = FALSE;

  while( np )
  {
    if( np->type == NODE_SUITE )
      if(np->status != STATUS_UNKNOWN && np->status != STATUS_COMPLETE)
        sms_time_suite(np,FALSE,NULL,NULL);
        /* This might change at the midnight! */

    if(suite_midnight)             /* PROCESS the date-deps */
      if(np->status != STATUS_COMPLETE && np->status != STATUS_UNKNOWN)
        if(sms_time_date_free(np->date))
          SUITE_CHANGED(np);

    if(np->status == STATUS_QUEUED)
      if( !sms_time_date_holding(np->date) )
        if(sms_time_free(np->time))  /* PROCESS the time-deps */
          SUITE_CHANGED(np);

    if( !sms_time_dependent(np) )
      sms_time_waiting(np->kids);

    np = np->next;
  }

  if( orig->type == NODE_SUITE ) suite_midnight = FALSE;
}

void sms_time_requeue(sms_node *np)
/**************************************************************************
?  Requeue the node if there are still times holding or date has expired.
************************************o*************************************/
{
  sms_node *orig = np;

  sms_status_change(np,STATUS_QUEUED,FALSE,FALSE);

  if( np->type == NODE_TASK )
  {
    sms_status_default(np);
    return;
  }

  sms_time_load(np);               /* Will loop back to the suite */

  np = np->kids;
  while( np )                      /* Reset the kids, not myself */
  {
    sms_status_validate(np);       /* Reset to unknown   */
    sms_status_default(np);

    sms_time_mark(np);             /* Reset the times??? */
    np = np->next;
  }

  sms_time_waiting(orig);          /* Check them! */
}

void sms_time_used(sms_node *np)
/**************************************************************************
?  Mark the time dependency to be used if any expired can be found.
|  and calculate the next one, if needed.
|
|  This is called at the completion of a node.
|  Coming here the node is marked to be complete.
=  void, nothing interesting @ all
************************************o*************************************/
{
  int       old;                   /* Time to be searched in expired dates */
  sms_node *suite;
  sms_time *tp = np->time;
  sms_date *dp = np->date;

  if( !dp && !tp ) return;         /* There is no time/date-deps! */

  sms_time_load(np);               /* FIX! */

/*
 *  The logic is:
 *
 *    If there are time dependencies one of them have to have EXPIRED.
 *    (otherwise it's force complete on and we'll force one to be EXPIRED)
 *    Mark it and calculate the next one.
 *
 *    If all the time dependencies are used the node completes.
 *    and in that case mark the used date dependency.
 */

  while( tp )
  {
    if( tp->status == TIME_EXPIRED )
    {
      sms_time_calc(tp);
      break;
    }
    tp = tp->next;
  }

  if( !tp )
  {
    sms_time *oldest = NULL;

    spit(0,IOI_WAR,"time-used:%s none found",STR(sms_node_full_name(np)));
    for( tp = np->time; tp ; tp=tp->next )
      if( tp->status == TIME_HOLDING )
        if( !oldest || tp->nexttime < oldest->nexttime )
          oldest = tp;

    if( oldest )
    {
      oldest->act_no = ++sms_._action_number;
      oldest->status = TIME_EXPIRED;
      spit(0,IOI_WAR,"time-used:%s marking oldest as expired",
           STR(sms_node_full_name(np)));
      sms_time_used(np);
    }

    return;
  }

  tp = np->time;

  while( tp )
    if( tp->status == TIME_HOLDING )
    {
      sms_time_requeue(np);
      return;
    }
    else
      tp = tp->next;

/*
 *  Find out the oldest date dep and remove all of that date.
 *  This part depends of the clock type.
 */

  suite = np;
  while( suite->parent && suite->type != NODE_SUITE ) suite = suite->parent;

  switch( suite->clock )
  {
    case CLOCK_HYBRID:
      while( dp )
      {
        if( dp->status == TIME_EXPIRED )
          dp->status = TIME_USED;
        dp = dp->next;
      }                            /* The node stays complete */
      break;
    case CLOCK_REAL:
/*
 *  It is possible that the task/family has started before midnight
 *  and new HOLDING dates has EXPIRED. We only remove the old dates.
 *
 *  The old dates has all expired at the same time, seconds in GMT.
 */
      old = INT_MAX;

      while( dp )                  /* Find the oldest expired date */
      {
        old = MIN(old,dp->nextdate);
        dp = dp->next;
      }

      dp = np->date;

      while( dp )                  /* All the old expired are used */
      {
        if( dp->status == TIME_EXPIRED && dp->nextdate == old )
          dp->status = TIME_USED;
        dp = dp->next;
      }

      dp = np->date;

      while( dp )                  /* Requeued if any date has expired */
        if( dp->status == TIME_EXPIRED )
        {
          sms_time_requeue(np);
          return;
        }
        else
          dp = dp->next;
      break;                       /* Otherwise the node stays complete */
  }

  return;
}

int sms_time_dependent(sms_node *np)
/**************************************************************************
?  Is the node dependent of the time/date?
*
*  This shuld be called for the QUEUED nodes only.
*  For non-QUEUED this always return 0.
*
*  NOTICE!  Triggers can still hold the node.
*
*  This checks has any of them expired.
*
=  STATUS AS:
|    0: Free to go
|    1: Time still holds
|    2: Date still holds
|  ===> FALSE free to go otherwise (C-true) is still holding.
************************************o*************************************/
{
  if(np->status != STATUS_QUEUED)  /* Nothing is holding this succer! */
    return 0;

/*
 *  Node is free to go (date wise) if:
 *
 *    There is no date dependencies
 *    There are but any of them has EXPIRED
 *    There are only USED dates
 */

  if(sms_time_date_holding(np->date)) return 2;

/*
 *  Node is free to go (time wise) if:
 *
 *    There is no time dependencies
 *    There are but any of them has EXPIRED
 *    There are only USED times
 */

  if(sms_time_date_holding((sms_date *)np->time)) return 1;

  return 0;                        /* It's free to GO! */
}

sms_list *sms_time_why(sms_node *np)
/**************************************************************************
?  If the node is still hold by the time/date tell it in text.
|  The logic is the same as above in sms_time_dependent().
************************************o*************************************/
{
  sms_time  *tp;
  sms_date  *dp;
  sms_list  *lp = NULL;
  struct tm *tm;
  char       line[MAXLEN];

  if( np->status != STATUS_QUEUED ) return NULL;

  if( (dp=sms_time_date_holding(np->date)) )
  {
    tm = sms_time_tm( &dp->nextdate );
    sprintf(line,"%02d.%02d.%04d",tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
    sms_list_add(&lp,sms_node_create(line));
  }

  if( (tp=(sms_time *)sms_time_date_holding((sms_date *)np->time)) )
  {
    tm = sms_time_tm( &tp->nexttime );
    sprintf(line,"%02d:%02d",tm->tm_hour,tm->tm_min);
    sms_list_add(&lp,sms_node_create(line));
  }

  return lp;
}

static int match_range(sms_time *tp, time_t t)
/**************************************************************************
?  Check if time "t" is in range
************************************o*************************************/
{
  struct tm *tm;

  tm = sms_time_tm(&t);

  if(tp->weekdays)
    if( ! ((1<<tm->tm_wday) & tp->weekdays) )
      return 0;

  if(tp->monthdays)
    if( ! ((1<<(tm->tm_mday-1)) & tp->monthdays) )
      return 0;

  if(tp->months)
    if( ! ((1<<tm->tm_mon) & tp->months) )
      return 0;

  return 1;
}

int sms_time_calc(sms_time *tp)
/**************************************************************************
?  Calculate the next time for the node.
|
|  The formula for the next time for the multiple times.
|
|          now - start + (inc - 1)
|  (int )[ ----------------------- ] * inc + start
|                     inc
|
|  If the time is not today, the first tomorrows time is calculated.
************************************o*************************************/
{
  int i;
  int t[3];                        /* In seconds GMT */
  int next;                        

  for( i=0 ; i<3 ; i++ )
    t[i] = tp->hour[i]*3600 + tp->minute[i]*60;

  t[0] += suite_morning;           /* Start */
  t[1] += suite_morning;           /* End   */

  if(tp->status != TIME_HOLDING)
    tp->act_no = ++sms_._action_number;

  switch( tp->status )
  {
    case TIME_UNUSED:              /* At the begin command or at */
                                   /* rerun of the family        */
      if( tp->relative )
      {
        t[0] += suite_time - suite_morning;
        t[1] += suite_time - suite_morning;
      }

      if(tp->repeat)               /* Multiple times */
        if( t[0] > suite_time || t[1] < suite_time )
          next = t[0];
        else
          next = ( (suite_time - t[0] + (t[2]-1)) / t[2]) * t[2] + t[0];
      else                         /* A single time */
        next = t[0];

      if( ! tp->today )
        if( next < suite_time )
          next += 3600*24;

      tp->lasttime = t[1] + ((t[1] < suite_time)? 3600*24 : 0);
      /* The paranthesis    ^    must be here!!!             ^   */

      if( tp->iscron )             /* Find next day */
      {
        int safety = 365*10;
        while( safety && next < suite_time )
        {
          safety--;
          next += 3600*24;
        }

        safety = 365*10;
        while( ! match_range(tp,next) && safety )
        {
          safety--;
          next += 3600*24;
        }

        if( tp->lasttime < next )
          tp->lasttime += ( (next - t[1])/(24*3600) ) * 24*3600;

      }

      tp->nexttime = next;


      tp->status   = TIME_HOLDING;
      break;

    case TIME_HOLDING:             /* We really shouldn't be here! */
      break;

    case TIME_EXPIRED:
      if( tp->repeat )             /* The suite morning might have changed! */
      {
        tp->nexttime += t[2];      /* We'll advance at leas once */
        while( tp->nexttime < suite_time && tp->nexttime < tp->lasttime )
          tp->nexttime += t[2];

        tp->status = (tp->nexttime > tp->lasttime)? TIME_USED:TIME_HOLDING;
      }
      else
        tp->status = TIME_USED;

      if( tp->status == TIME_USED && tp->iscron )
      {
        tp->status = TIME_UNUSED;  /* Find out next day */
        sms_time_calc(tp);
      }

    case TIME_USED:                /* Only begin can change this one */
      break;
  }

  return 0;
}

int sms_time_date_calc(sms_date *dp)
/**************************************************************************
?  Compute the status of the date dependent.
|
|  If the date/day matches todays date/day the node is "free"==TIME_EXPIRED
|  otherwise it is TIME_HOLDING.
|
|  Only called by the BEGIN-command (or autorepeat) or at midnight if the
|  clock is REAL.
************************************o*************************************/
{
  int today =
    (dp->weekdays)
    ?
      ( (1<<(suite_tm.tm_wday)) & dp->weekdays )
    :
      (( dp->year  == NIL || dp->year  == suite_tm.tm_year  ) &&
       ( dp->month == NIL || dp->month == suite_tm.tm_mon+1 ) &&
       ( dp->day   == NIL || dp->day   == suite_tm.tm_mday  ))
    ;

  int repeated = ( dp->year == NIL || dp->month == NIL || dp->day == NIL );

  dp->act_no = ++sms_._action_number;  /* Let's FIS this 1 later on */

  switch( dp->status )
  {
    case TIME_UNUSED:              /* At the begin command      */
    case TIME_HOLDING:             /* At midnight in real clock */
      dp->status = today? TIME_EXPIRED : TIME_HOLDING;
      dp->nextdate = suite_time;   /* Last processed */
      break;

    case TIME_EXPIRED:
      if( repeated )
        dp->status = today? TIME_EXPIRED : TIME_HOLDING;
      else
        dp->status = TIME_USED;
      break;

    case TIME_USED:                /* Only begin can change this one */
      break;
  }

  return 0;
}

void sms_time_out(void)
/**************************************************************************
?  Timeout users.
|  This doesn't do anything unless activated from "config.h"
************************************o*************************************/
{
  sms_connect *cp = sms_._connect;
  time_t now;

  if( SMS_TIMEOUT == 0 ) return;

  sms_time_t(&now);

  while( cp )
    if(now - cp->idle > SMS_TIMEOUT)
    {
      sms_connect *next = cp->next;

      spit(0,IOI_WAR,"timeout:user %s timed out",STR(cp->name));
      ls_remove(&sms_._connect,cp);
      sms_node_free(cp);

      cp = next;
    }
    else
      cp = cp->next;

}

void sms_time_expire(sms_node *np)
/**************************************************************************
?  Mark all time/date-dependencies as used
|  Usefull for repeated time dependents
************************************o*************************************/
{
  sms_time *tp = np->time;
  sms_date *dp = np->date;

  char *name = sms_node_full_name(np);

  int expired, holding;

  if( np->status == STATUS_UNKNOWN )
    return;

  for( expired=holding=0 ; tp ; tp=tp->next )
  {
    if( tp->status == TIME_EXPIRED ) expired++;
    if( tp->status == TIME_HOLDING ) holding++;

    tp->status = TIME_USED;
  }

  if(expired)
    spit(0,IOI_MSG,"expire:%s %d times was expired",STR(name),expired);
  if(holding)
    spit(0,IOI_MSG,"expire:%s %d times was holding",STR(name),holding);

  if(expired || holding)
    SUITE_CHANGED(np);

  for( expired=holding=0 ; dp ; dp=dp->next )
  {
    if( dp->status == TIME_EXPIRED ) expired++;
    if( dp->status == TIME_HOLDING ) holding++;

    dp->status = TIME_USED;
  }

  if(expired)
    spit(0,IOI_MSG,"expire:%s %d dates was expired",STR(name),expired);
  if(holding)
    spit(0,IOI_MSG,"expire:%s %d dates was holding",STR(name),holding);

  if(expired || holding)
    SUITE_CHANGED(np);
}
