/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMS-CMD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-OCT-1992 / 09-AUG-1991 / OP
.FILE     sms_cmd.c
.VERSION  4.0
*
.DATE     25-FEB-1993 / 25-FEB-1993 / OP
.VERSION  4.1
.DATE     26-JUL-1993 / 15-APR-1993 / OP
.VERSION  4.2
*         Added file and directory commands
*         Modified scan/send
*         Added a fix for send -> dependently
.DATE     13-FEB-1994 / 13-FEB-1994 / OP
.VERSION  4.2.1
*         Added support for sending messages into SMS log file (smsmsg)
.DATE     08-DEC-1994 / 22-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-4
*         Added support for sending meter and label info into SMS
*         New commands for extended protocol
*         Bug fix to get the directory ok
*         Suite registering logic changed
.DATE     26-SEP-1995 / 01-SEP-1994 / OP
.VERSION  4.3.4-12
*         Node checkpointing and migration  (4.3.4)
*         Bug fix in sms_cmd_file: for null filename (4.3.5)
*         Resubmit (4.3.6)
*         Bug fix in sms_cmd_send: for generated variables (4.3.7)
*         Suites CMD to process star (all), but no regexp
*         Added per node logging (4.3.11)
*         XDR privilege handling revisited (4.3.12)
.DATE     21-OCT-1997 /  17-OCT-1997 / OP
.VERSION  4.3.16
*         Added alternate path for output
*         Meter query
.DATE     09-MAR-1998 / 09-MAR-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     22-APR-1998 / 22-APR-1998 / OP
.VERSION  4.3.18
*         expire command and endt
.DATE     05-JUN-1998 / 05-JUN-1998 / OP
.VERSION  4.3.19
*         SMS version in the sms command
*         Options for migrate
.DATE     22-JUL-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
*         Logging for scan
*         Statistics of querying
.DATE     17-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
*         Bug fix for delete command
.DATE     28-JAN-1998 / 17-AUG-1998 / OP
.VERSION  4.4
*         Bug fix for delete (check type)
*         Net names for nodes
*         Zombie passwords
*         New commands: run, reset, users, zombies, mail
*         Old child commands, task mail & wait
*         Migrate with cancel and plug
.DATE     09-FEB-1999 / 08-FEB-1999 / OP
.VERSION  4.4.1
*         Locked state
*         Plug modified
.DATE     26-MAR-1999 / 26-MAR--1999 / OP
.VERSION  4.4.2
*         Cancel aliases in bulk
.DATE     08-10-2002 / BR
.VERSION  ???
*         Add support for filter in sms_cmd_read(2)
************************************o*************************************/

/* #define IOI_MODULE */

#include "smslib.h"

static char *command_name;         /* The actual command been executed */

static int options;                /* No need put this into _cmd_call! */

#include "child.h"
#undef SMS_CHILD_H

int sms_cmd_typeok(char *cmd, sms_node *np, ...)
/**************************************************************************
?  Check the node type
=  TRUE carry on
|  FALSE error
************************************o*************************************/
{
  va_list ap;
  int     type = 0;
  int     rc   = 0;

  va_start(ap, np);

  while( (type=va_arg(ap, int)) != 0 )
    if(np->type == type)
      rc = 1;

  va_end(ap);

  if(!rc)
    sms_error(SMS_E_TYPE,"%s: %s is %s",STR(cmd),STR(sms_node_full_name(np)),
              node_name[np->type]);

  return rc;
}

int sms_cmd_log_user(sms_node *np)
/**************************************************************************
?  Log the users action into SMSLOG without telling it to the user.
************************************o*************************************/
{
  sms_._answer = FALSE;

  spit(0,IOI_MSG,"%s:%s by %s",
       STR(command_name),
       STR(sms_node_full_name(np)),
       STR(SMS_USER));

  sms_._answer = TRUE;

  return 0;
}

int sms_cmd_suites(sms_list *args)
/**************************************************************************
?  Send a linked list of the all suites currently in the SMS
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node        *np;
  sms_list        *lp;
  int              mode  = options;

  /* sms_decode(options,&mode,NULL); */
  /* Mode is a single parameter      */

#if 0
printf("SUITES: option %d, %s\n",mode,suites_name[mode]);
ls_fancy(&args,stdout,80);
#endif

  switch( mode )
  {
    case SUITES_ADD:
      for( ; args ; args = args->next )
      {
        if( strcmp(args->name,"*") == 0 )
        {
          sms_node *suites;

          for( suites = sms_._super->kids; suites ; suites=suites->next )
          {
            ls_delname( &sms_._current_con->suites , suites->name);
            ls_add( &sms_._current_con->suites, ls_create(0,suites->name) );
          }
        }
        else
        {
          ls_delname( &sms_._current_con->suites , args->name);
          ls_add( &sms_._current_con->suites, ls_create(0,args->name) );
        }
      }
      break;

    case SUITES_DELETE:
      if( !args || strcmp(args->name,"*")==0 )
        ls_delall( &sms_._current_con->suites );
      else
      {
        /* Delete from an empty list, copy all and then delete */
        if( ! sms_._current_con->suites )
          ls_copy( &sms_._current_con->suites, sms_._super->kids );

        for( ; args ; args = args->next )
          ls_delname( &sms_._current_con->suites, args->name );
      }
      break;

    case SUITES_SET:
      NODE_FREE(sms_._current_con->suites,sms_list);
      for( ; args ; args = args->next )
      {
        if( strcmp(args->name,"*")==0 )
        {
          sms_node *suites;

          for( suites = sms_._super->kids; suites ; suites=suites->next )
          {
            ls_delname( &sms_._current_con->suites , suites->name);
            ls_add( &sms_._current_con->suites, ls_create(0,suites->name) );
          }
        }
        else
        {
          ls_delname( &sms_._current_con->suites , args->name);
          ls_add_d( &sms_._current_con->suites, ls_create(0,args->name) );
        }
      }
      break;

    case SUITES_LIST:
      np = sms_._super->kids;
      for( np=sms_._super->kids; np ; np=np->next )
        ls_add( &sms_._reply, ls_create(0,np->name) );
      break;

    case SUITES_MINE:
      if( sms_._current_con->suites )
        for( lp=sms_._current_con->suites ; lp ; lp=lp->next )
          ls_add( &sms_._reply, ls_create(0,lp->name) );
      else
        ;
        /* ls_add( &sms_._reply, ls_create(0,"(all the suites)") ); */
      break;

    case SUITES_NEWIN:
    case SUITES_NEWOUT:
      sms_._current_con->newsuites = (mode==SUITES_NEWIN);
      break;
  }

  return SMS_E_OK;
}

int sms_cmd_order(sms_list *args)
/**************************************************************************
?  Reorganize the suites/families/tasks
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;
  int       how = options;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"order:%s",STR(args->name));

  if( how==ORDER_TOP || how==ORDER_BOTTOM ||
      how==ORDER_UP  || how==ORDER_DOWN )
  {
    if( np->type==NODE_SUPER )
      return sms_error(SMS_E_ORDER,"order:%s",STR(sms_node_full_name(np)));

    if( np->parent->type == NODE_SUPER &&
        ! (PRIVILEGE(PR_ADMIN) || PRIVILEGE(PR_OPER)) )
      return sms_error(SMS_E_PRIVILEGE,"order:can't order suites");

    if( ! sms_status_privilege( np->parent ) )
      return sms_error(SMS_E_NOTOWNER,"order:%s [%s]",
                       STR(sms_node_full_name(np->parent)),order_name[how]);
  }
  else
  {
    if( np->type==NODE_SUPER &&
        ! (PRIVILEGE(PR_ADMIN) || PRIVILEGE(PR_OPER)) )
      return sms_error(SMS_E_PRIVILEGE,"order:can't order suites");

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"order:%s",STR(args->name));
  }

  LOGGING(np);
  args = args->next;

  return sms_order(np,how,args);
}

int sms_cmd_kill(sms_list *args)
/**************************************************************************
?  Kill tasks
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"kill:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"kill:%s",STR(args->name));

    LOGGING(np);
    if( (rc=sms_kill(np,options,TRUE)) != SMS_E_OK )
      return rc;

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_jobcheck(sms_list *args)
/**************************************************************************
?  Check tasks
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;

  sms_node_free(sms_._reply);
  sms_._reply = 0;

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"jobcheck:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"jobcheck:%s",STR(args->name));

    LOGGING(np);
    if( (rc=sms_jobcheck(np)) != SMS_E_OK )
      return rc;

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_migrate(sms_list *args)
/**************************************************************************
?  Migrate a node into a checkpoint file
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"migrate:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"migrate:%s",STR(args->name));

    /* No options at the moment */
    LOGGING(np);
    if( (rc=sms_migrate(np,NULL,options)) != SMS_E_OK )
      return rc;

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_restore(sms_list *args)
/**************************************************************************
?  Restore a node from a checkpoint file
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"restore:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"restore:%s",STR(args->name));

    LOGGING(np);
    if( (rc=sms_restore(np,NULL,options)) != SMS_E_OK )
      return rc;

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_plug(sms_list *args)
/**************************************************************************
?  Restore a node completely from the wire (CDP sends it)
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"plug:%s",STR(args->name));

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"plug:%s",STR(args->name));

  LOGGING(np);
  if( (rc=sms_restore_plug(np,args->next)) != SMS_E_OK )
    return rc;

  args->next = 0;   /* We nicked it, XDR should not free this */

  return SMS_E_OK;
}

int sms_cmd_message(sms_list *args)
/**************************************************************************
?  Get the message from a node (no privileges, this is read only, except
|  for the setting of the message)
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc;
  sms_node *np;
  int       clear, summary, first, last;

  sms_decode(options,&clear,&summary,&first,&last,NULL);

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"node-message:%s",STR(args->name));

  if( ! sms_cmd_typeok("message",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
    return SMS_E_TYPE;

  if( args->next )
  {
    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"node-message:%s",STR(args->name));

    sms_log_add(np,args->next->name);
    spit(0,IOI_MSG,"message:%s by %s [%s]",
       STR(sms_node_full_name(np)), STR(SMS_USER), STR(args->next->name));
  }
  else if( summary )
     sms_log_summary(np);
  else if( clear )
     sms_log_clear(np,first,last);
  else
    sms_log_message(np);

  return SMS_E_OK;
}

int sms_cmd_alter(sms_list *args)
/**************************************************************************
?  Alter the properties of a single node
|  If remove, the XDR in RPC will handle the memory, otherwise it's copied
|  and XDR is "fooled" by steeling the contents of the first argument.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;
  int       r_opt=options & 0x01;  /* The first bit, see alter.c */
  sms_list *tmp = NULL;
 
  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"alter:%s",STR(args->name));

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"alter:%s",STR(args->name));

  args = args->next;

  if(args && ! r_opt)
  {
    if( ! (tmp=sms_alloc(args->type)) )
      return sms_error(SMS_E_MEMORY,"alter");

    memcpy(tmp,args,sms_sizes[args->type]); /* Steel the structure from */
    memset(args,0,sms_sizes[args->type]);   /* from the RPC */
  }
  else
    tmp = args;

  LOGGING(np);
  return sms_alter(np,options,tmp);
}

int sms_cmd_begin(sms_list *args)
/**************************************************************************
?  Begin the suite.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;

  while( args )
  {
    if( ! (np = (args->name[0]=='/')?
                sms_node_find_full(args->name)        :
                (sms_node *)ls_find(&sms_._super->kids,args->name)
          ) )
      return
        sms_error(SMS_E_NOTFOUND,"begin:%s",STR(args->name));

    if( np->type != NODE_SUITE )
      return sms_error(SMS_E_SUITE,"begin:%s == %s",
                  STR(sms_node_full_name(np)),node_name[np->type]);

    if( np->status == STATUS_UNKNOWN || np->status == STATUS_COMPLETE )
      if( ! sms_status_privilege( np ) )
        return sms_error(SMS_E_NOTOWNER,"begin:%s",STR(args->name));
      else
        ;
    else
      return sms_error(SMS_E_BEGINST,"begin:suite %s is %s",
                  STR(args->name),status_name[np->status]);

    LOGGING(np);
    sms_node_begin(np,TRUE);

    if( IS_SHUTDOWN ) spit(0,IOI_WAR,"begin:SMS is shutdown");
    if( IS_HALTED   ) spit(0,IOI_WAR,"begin:SMS is halted");

    if( np->status == STATUS_SUSPENDED )
      spit(0,IOI_WAR,"begin:%s is suspended",STR(args->name));

    args = args->next;
  }
  return SMS_E_OK;
}

int sms_cmd_cancel(sms_list *args)
/**************************************************************************
?  Cancel the parts of the suite definition.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;
  int       brute_force = FALSE;   /* Default & only way if ! CROSS-SUITE */
  int       aliases     = FALSE;

  sms_decode(options,&brute_force,&aliases,NULL);

#ifndef SMS_CROSS_SUITE
  if(brute_force)
    return sms_error(SMS_E_CONFIG,"cancel:force option");
#endif

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"cancel:%s",STR(args->name));

#if 0 /* in sms_cancel */
    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"cancel:%s",STR(args->name));

    if( np->type == NODE_SUPER )
      return sms_error(SMS_E_PRIVILEGE,"cancel:can't remove super-node");
#endif

    sms_cancel(np,brute_force,aliases,FALSE);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_check(sms_list *args)
/**************************************************************************
?  Write a checkpoint file.
=  SMS-RETURN-CODE
~  sms_node_check()
************************************o*************************************/
{
  char *name;
  int   mode=0,t=0;

  name = args?args->name : NULL;

  if( args )
  {
    args = args->next;
    if( args )
    {
      mode = atoi(args->name);
      args = args->next;
      if( args )
        t = atoi(args->name);
    }
  }

  if( name &&  ! *name ) name = NULL;

  if( !name && (mode || t) )
  {
    if(PRIVILEGE(PRIV_OPER))
    {
      if(mode) sms_._check_mode = mode;
      if(t>1)  sms_._check_time = t;
      sms_._check_last = 0;       /* Make sure it's done next time in main */

      spit(0,IOI_MSG,"check:method %s interval %d sec by %s",
        check_name[sms_._check_mode],sms_._check_time,STR(SMS_USER));

      return SMS_E_OK;
    }
    return sms_error(SMS_E_PRIVILEGE,"check:mofify");
  }

  if( !name )
  {
    sms_._xdr_privs = XDR_SERVER;  /* No need to turn it back */

    sms_node_check();

    if( ! (name=sms_variable_get("SMSCHECK",NULL)) )
      return sms_error(SMS_E_GLOBALVAR,"checkpoint:%s","SMSCHECK");
  }
  else
    if( !sms_node_write(sms_._super,name) )
      return sms_error(SMS_E_WRITE,"checkpoint:%s",STR(name));

  return
    spit(SMS_E_OK,IOI_LOG,"checkpoint:written into %s by %s",STR(name),STR(SMS_USER));
}

int sms_cmd_child(int cmd, int old, sms_list *args)
/**************************************************************************
?  Execute the job-command.
|  (abtt, endt, setev, smsinit, smsmsg, smsmeter or smslabel)
|  (smsabort, smscomplete, smsevent, smsinit, smsmsg, smsmeter or smslabel)
=  SMS-RETURN-CODE
************************************o*************************************/
{
#undef SMS_CHILD_H

  sms_node  *np;
  sms_event *ep;
  sms_meter *mp;
  sms_label *lp;

  char       name[MAXNAM];         /* Full name of the task */
  char      *s;                    /* Remove the '@' from the connection */

  strcpy(name,sms_._current_con->name);

  if( s=strchr(name,'@') )
    *s = '\0';
  else
    return sms_error(SMS_E_CHILDNAME,"child:%s",STR(name));

  if( sms_cmd_islocked("empty") || IS_HALTED ) return SMS_E_HALTED;

  if( IS_DYING ) return SMS_E_TERMINATE;

  if( ! (np=sms_node_find_full(name)) )
    return sms_error(SMS_E_NOTFOUND,"%s:%s",STR(child_cmds[cmd]),STR(name));

  if( (cmd==CMD_SMSEVENT || cmd==CMD_SMSMETER || cmd==CMD_SMSLABEL) &&
      strcmp(args->name,"-q") == 0 )
  {
#ifdef SMS_STATISTICS
    smss_._tasks_queries++;
#endif

    if( ! args->next )
      return sms_error(SMS_E_PROTOCOL,"%s:%s for %s",
                       STR(child_cmds[cmd]), STR(args->name), STR(name));

    return sms_query(np,cmd,args->next);
  }

  if( old==CMD_ENDT || old==CMD_ABTT || old==CMD_SETEV )
    spit(0,IOI_WAR,"translate: %s to %s",STR(child_cmds[old]),STR(child_cmds[cmd]));

#ifdef SMS_STATISTICS
  switch( cmd )
  {
    case CMD_SMSABORT:    smss_._tasks_aborted++;    break;
    case CMD_SMSCOMPLETE: smss_._tasks_completed++;  break;
    case CMD_SMSEVENT:    smss_._events_set++;       break;
    case CMD_SMSINIT:     smss_._tasks_init++;       break;
    case CMD_SMSMSG :     smss_._tasks_msgs++;       break;
    case CMD_SMSMETER:    smss_._tasks_meters++;     break;
    case CMD_SMSLABEL:    smss_._tasks_labels++;     break;
    case CMD_SMSMAIL:     smss_._tasks_mails++;      break;
    case CMD_SMSWAIT:     smss_._tasks_waits++;      break;
  }
#endif

  switch( cmd )
  {
    case CMD_SMSABORT:    
      if(np->status == STATUS_ACTIVE && np->tryno < sms_variable_tries(np))
        spit(0,IOI_WAR,"abort:%s ---> try number %d",
             STR(sms_node_full_name(np)),np->tryno);

      if(sms_status_change(np,STATUS_ABORTED,FALSE,FALSE)) return SMS_E_OK;

      break;

    case CMD_SMSCOMPLETE:
      if( args && args->name )
        if( strcmp(args->name,sms_cmds[CMD_EXPIRE]) == 0 )
          sms_time_expire(np);

      if(sms_status_change(np,STATUS_COMPLETE,FALSE,FALSE)) return SMS_E_OK;
      break;

    case CMD_SMSINIT:
      if( args )
        if( sms_is_number(args->name) )
          np->rid = atoi(args->name);
          sms_variable_generate(np,FALSE,FALSE,NULL,NULL);

      if(sms_status_change(np,STATUS_ACTIVE,FALSE,FALSE)) return SMS_E_OK;
      break;

    case CMD_SMSMSG:
      spit(SMS_E_OK,IOI_MSG,"%s:message form task",STR(name));
      for( ; args ; args = args->next )
        spit(SMS_E_OK,IOI_MSG,"::%s",STR(args->name));
      return SMS_E_OK;
      /* break; */


    case CMD_SMSEVENT:
      if( (ep=ls_find(&np->event,args->name)) )
        if(sms_status_change((sms_node *)ep,EVENT_SET,FALSE,FALSE))
          return SMS_E_OK;
        else
          ;
      else
        return sms_error(SMS_E_NOTFOUND,"event:%s for %s",STR(args->name),STR(name));
      break;

    case CMD_SMSMETER:
      if( ! args->next )
        return sms_error(SMS_E_PROTOCOL,"meter:%s for %s",STR(args->name),STR(name));

      if( mp = ls_find(&np->meter,args->name) )
        if(sms_status_change_meter(mp,atoi(args->next->name)))
          return SMS_E_OK;
        else
          return SMS_E_METER;    /* Stop looping (range error) */
      else
        return sms_error(SMS_E_NOTFOUND,"meter:%s for %s",STR(args->name),STR(name));

      /*NOTREACHED*/
      break;

    case CMD_SMSLABEL:
      if( ! args->next )
        return sms_error(SMS_E_PROTOCOL,"label:%s for %s",STR(args->name),STR(name));

      if( lp = ls_find(&np->label,args->name) )
        if(sms_status_change_label(lp,args->next->name))
          return SMS_E_OK;
        else
          return SMS_E_LABEL;    /* Stop looping */
      else
        return sms_error(SMS_E_NOTFOUND,"label:%s for %s",STR(args->name),STR(name));

      /*NOTREACHED*/
      break;

    case CMD_SMSMAIL:
      return sms_mail(MAIL_SEND, 0, args);
      /*NOTREACHED*/
      break;

    case CMD_SMSWAIT:
      return sms_status_trigger_wait(np, (sms_trigger *)args) ?
             SMS_E_WAIT : SMS_E_OK;
      /*NOTREACHED*/
      break;
  }

  return sms_error(SMS_E_STATUS,child_cmds[cmd]);
}

int sms_cmd_delete(sms_list *args)
/**************************************************************************
?  Delete triggers/time-deps/date-deps.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"delete:%s",STR(args->name));

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"delete:%s",STR(args->name));

  if( ! sms_cmd_typeok("delete",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,0))
    return sms_error(SMS_E_RFORCE,"delete:%s",STR(args->name));

  LOGGING(np);
  sms_delete(np,options);

  return SMS_E_OK;
}

int sms_cmd_exists(sms_list *args)
/**************************************************************************
?  Check if the node(s) named exists.
|  The names MUST be a full name.
|  The "real" name is returned for each one found.
|  eg "/s/f/t/../ff/tt" ===> "/s/ff/tt".
=  SMS-RETURN-CODE
|  SMS_E_OK if all does exist, ERROR otherwise. The last line contains the 
|  name of the one which couldn't be found. The rest are not examined.
************************************o*************************************/
{
  sms_node *np;

  while( args )
  {
    if( !(np=sms_node_find_full(args->name)) )
    {
      sms_output("%s:%s",STR(args->name),error_name[SMS_E_NOTFOUND]);
      return SMS_E_NOTFOUND;
    }
    sms_output(sms_node_full_name(np));
    args = args->next;
  }

  return SMS_E_OK;                 /* Yeps all of the nodes exists */
}

int sms_cmd_file(sms_list *args)
/**************************************************************************
?  Get a text file
************************************o*************************************/
{
  sms_node *np;
  int       rc = SMS_E_FILE;
  sms_list *gp = 0;
  char     *filename;
  char      path[MAXLEN];
  int       ispipe = 0;

/* BR: Change for running filters */
   char     *filter = 0;
   char     *p = args->next->name;
   while(*p)
   {
      if(*p == '|')
      {
         *p     = 0;
         filter = p+1;
         break;
      }
      p++;
   }
/* BR: End change */


  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"file:%s",STR(args->name));

  args = args->next;

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"file:%s",STR(args->name));

  if( np->type != NODE_TASK && np->type != NODE_ALIAS )
    return sms_error(SMS_E_TASK,"file:%s",STR(sms_node_full_name(np)));

  /*
   *   Check filename against node-name (do it later!)
   *   the strcmp is for 4.2 XCdp
   */

  if( strlen(args->name)==0 ||
      strcmp(args->name,sms_variable_get("SMSSCRIPT",np))==0 )
    filename = SMSSCRIPT(np,&ispipe);
  else
    filename = args->name;

  if( filename )
  {
    if( *filename == '/' )
      strcpy(path,filename);
    else
    {
      char *home = sms_variable_get("SMSHOME",np);
      if(!home) home=".";

      sprintf(path,"%s%s/%s",STR(home),STR(sms_node_full_name(np->parent)),STR(filename));
    }

    sms_variable_generate(np,FALSE,FALSE,NULL,NULL);

    if( strcmp(path,sms_variable_get("SMSJOBOUT",np))==0 )
    {                              /* For output try SMSHOME firts */
      char *smsout, *smshome;
      char path2[MAXLEN];

      smsout  = sms_variable_get("SMSOUT",np);
      smshome = sms_variable_get("SMSHOME",np);

      if( smsout && smshome && strcmp(smsout,smshome) != 0 )
      {
        sprintf(path2,"%s%s.%d", STR(smshome), STR(sms_node_full_name(np)), np->tryno);

        rc = sms_file_read2(path2,&gp,MAXLINES,ispipe,filter);
      }

      if(rc == SMS_E_OK)
      {
        sms_node_free(sms_._reply);    /* No message is send, only the file   */
                                       /* Return the variables back to CDP    */
        sms_._reply=gp;                /* Freed next time sms_._answer needed */
      }
      else
      {
        ls_delall(&gp);
        gp = 0;
      }
    }

    if( rc != SMS_E_OK )
    if( (rc=sms_file_read2(path,&gp,MAXLINES,ispipe,filter)) == SMS_E_OK )
    {
      sms_node_free(sms_._reply);    /* No message is send, only the file   */
                                     /* Return the variables back to CDP    */
      sms_._reply=gp;                /* Freed next time sms_._answer needed */
    }

  }

  return rc;
}

int sms_cmd_manual(sms_list *args)
/**************************************************************************
?  Get a manual page
************************************o*************************************/
{
  sms_node *np;
  int       rc;
  sms_list *gp = NULL;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"manual:%s",STR(args->name));
  /* This guarantees that node is super/suite/family/task/alias/event... */

  args = args->next;

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"manual:%s",STR(args->name));

  if( rc=sms_edit_manual(np,&gp) )
  {
    sms_node_free(sms_._reply);    /* No message is send, only the file   */
                                   /* Return the variables back to CDP    */
    sms_._reply=gp;                /* Freed next time sms_._answer needed */

    if(!gp) return SMS_E_MANUAL;
  }

  return rc? SMS_E_OK : SMS_E_MANUAL;
}

int sms_cmd_dir(sms_list *args)
/**************************************************************************
?  Get the directory listing of the path specified
|  Input: node-name file-name
************************************o*************************************/
{
  sms_node *np;
  int       rc;
  sms_list *gp = NULL;
  char      path[MAXLEN];
  char     *pattern = NULL;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"dir:%s",STR(args->name));

  args = args->next;

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"dir:%s",STR(args->name));

  if( ! sms_cmd_typeok("dir",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
    return sms_error(SMS_E_DIR,"dir:%s is wrong type",STR(sms_node_full_name(np)));

  /*
   *   Check filename against node-name (do it later!)
   */

  if( *(args->name) == '/' )
    strcpy(path,args->name);
  else
    sprintf(path,"%s/%s",STR(sms_variable_get("SMSHOME",np)),STR(args->name));

  if(np->type==NODE_TASK || np->type==NODE_ALIAS)
  {
    char *s = path + strlen(path) - 1;
    while( s>path && *s != '/' )
      *s-- = '\0';
    /* pattern = sms_variable_get("TASK",np); */
    pattern = np->name;
  }

  if( (gp=(sms_list *)sms_file_dir(path,pattern,0)) != NULL )
  {
    sms_node_free(sms_._reply);
                                   /* Return the variables back to CDP    */
    sms_._reply=gp;                /* Freed next time sms_._answer needed */
  }

  return (gp!=NULL)? SMS_E_OK : SMS_E_DIR;
}

static int force_loop(sms_node *np, int status, int event)
/**************************************************************************
?  Force the node(s) into the status given recursively
=  SMS-RETURN-CODE
************************************o*************************************/
{
  if(!np) return SMS_E_OK;

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"force:%s",STR(sms_node_full_name(np)));

  LOGGING(np);

  if(np->type==NODE_EVENT)
    if(sms_status_change(np,status,TRUE,FALSE)) 
      return SMS_E_OK;
    else return
      sms_error(SMS_E_STATUS,"force(recursively):%s",STR(sms_node_full_name(np)));

  if(np->type==NODE_TASK || np->type==NODE_ALIAS)
  {
    sms_event *ep;

    if(event)
      for( ep=np->event ; ep ; ep=ep->next )
        if( ! sms_status_change((sms_node *)ep,status,TRUE,FALSE))
          return SMS_E_STATUS;
        else
          ;
    else
      if( ! sms_status_change(np,status,TRUE,FALSE))
        return
        sms_error(SMS_E_STATUS,"force(recursively):%s",STR(sms_node_full_name(np)));
  }
  else
    for( np=np->kids ; np ; np=np->next )
      if( force_loop(np,status,event) != SMS_E_OK )
        return SMS_E_STATUS;

  return SMS_E_OK;
}

int sms_cmd_force(sms_list *args)
/**************************************************************************
?  Force the node(s) into the status given.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;
  int       status;
  int       is_event = NIL;        /* Status name given is for the events */
  int       recursively;

  sms_decode(options,&recursively,NULL);

  if( args )
  {
    if( (status = ioi_user_cmdf(args->name,status_names,NULL,STATUS_NAMES_MAX))
        ==NIL )
      return sms_error(SMS_E_PROTOCOL,"force:status = %d",status);

    args = args->next;
  }

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"force:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"force:%s",STR(args->name));

    if( recursively )              /* Type mixing allowed */
    {
      int rc;

      if( ! sms_cmd_typeok("force",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
        return sms_error(SMS_E_RFORCE,"force(recursively):%s",STR(args->name));

      if( is_event == NIL )        /* Don't know it yet */
        if( (is_event = (status >= STATUS_USABLE)) )
          status -= STATUS_USABLE;

      rc=force_loop(np,status,is_event);
      if( rc != SMS_E_OK ) return rc;

      LOGGING(np);
      spit( 0,IOI_MSG,"force(recursively):%s to %s by %s",STR(args->name),
            is_event? event_name[status] : status_name[status],
            STR(SMS_USER) );
    }
    else
    {
      if( ! sms_cmd_typeok("force",np,NODE_TASK,NODE_ALIAS,NODE_EVENT,0))
        return sms_error(SMS_E_FORCETYPE,"force:%s is %s",
                    STR(args->name),node_name[np->type]);

      if( is_event == NIL )            /* Don't know it yet */
        if( (is_event = (np->type == NODE_EVENT)) )
          if( status >= STATUS_USABLE ) 
            status -= STATUS_USABLE;   /* Must be for the event */
          else
            return sms_error(SMS_E_EVENT,"force:clear or set");

      if( is_event && (np->type==NODE_TASK || np->type==NODE_ALIAS) )
        return sms_error(SMS_E_EVENT,"force:%s:%s != event",
          event_name[status],STR(args->name));

      if( ! is_event && np->type == NODE_EVENT ) 
        return sms_error(SMS_E_TASK,"force:%s:%s != %s",
          status_name[status],STR(args->name),node_name[np->type]);

      LOGGING(np);
      if( ! sms_status_change(np,status,TRUE,FALSE))    /* SHOULD BE OK! */
        return sms_error(SMS_E_STATUS,"force:%s",STR(args->name));

      /* sms_._answer = FALSE; */
      spit( 0,IOI_MSG,"force:%s to %s by %s",STR(args->name),
            (np->type==NODE_EVENT) ? event_name[status] : status_name[status],
            STR(SMS_USER) );
      /* sms_._answer = TRUE; */
    }

    if( ! IS_RUNNING && np->status == STATUS_QUEUED )
      if( ! sms_time_dependent(np) )
        if( ! sms_status_trigger2(np,NODE_TRIGGER) )
          spit(0,IOI_WAR,"force:SMS is not running [%s]",
               status_name[ sms_._status + STATUS_USABLE - 1 ]);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_passwd(sms_list *args)
/**************************************************************************
?  Change/add real user passwd.
|  In secure mode the SMS-user and the CDP-user must match.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_passwd *sp;
  int         rc;
  int         my_self = FALSE;
  int         delete,list;
  char *user,*passwd,*newpw1,*newpw2,*comment;
  int   uid,gid,rights;

  sms_decode(options,&delete,&list,NULL);

  user    = args->name; args = args->next;
  passwd  = args->name; args = args->next;
  newpw1  = args->name; args = args->next;
  newpw2  = args->name; args = args->next;

  if( !delete && !list )
    if(strcmp(newpw1,newpw2))
      return 
      spit(SMS_E_PERMISSION,IOI_ERR,"passwd:mismatch password unchanged");

  uid     = atoi(args->name); args = args->next;
  gid     = atoi(args->name); args = args->next;
  rights  = atoi(args->name); args = args->next;

  rights = (1<<rights);

  comment = args->name; args = args->next;

  if( ! *user  )
  {
    my_self = TRUE;
    user = strdup(sms_passwd_user(SMS_USER));
  }

 /*
  *  First check the password of the user issuing the command.
  */
  if(
      !sms_._passwd ||
      (
        sms_passwd_ok(sms_._current_con->name,passwd)

#ifdef SMS_IN_SECURE_MODE
        &&
        ( 
          PRIVILEGE(PR_ADMIN) ||
          (
            strcmp(user,sms_passwd_user(NULL)) == 0
            && sms_._current_con->uid == uid &&
            && sms_._current_con->gid == gid 
          )
        )
#endif
      )
    )
  {
    if( list )
      if( PRIVILEGE(PR_ADMIN) ) 
      {
        sms_passwd_list(FALSE);
        return SMS_E_OK;
      }
      else
        return sms_error(SMS_E_PERMISSION,"passwd-list");

    if( delete )
      if( PRIVILEGE(PR_ADMIN) ) 
        return sms_passwd_delete(user);
      else
        return sms_error(SMS_E_PERMISSION,"passwd-delete");

    sp = ls_find(&sms_._passwd,user);

    if( !sms_._passwd || (PRIVILEGE(PR_ADMIN) && !my_self) )
    {
      if( sp )
        if(rights != PR_NONE) rights |= sp->rights;

      rc = sms_passwd_add(user,uid,gid,rights,newpw1,comment)?
           SMS_E_OK : SMS_E_WRITE;
   
    }
    else
      if( sp )
        rc = sms_passwd_add(
               sp->name,sp->uid,sp->gid,sp->rights,newpw1,sp->comment
             )? SMS_E_OK : SMS_E_WRITE;
      else
        rc = SMS_E_PERMISSION;

    if( my_self ) IFFREE(user);
    return rc;
  }

  if( my_self ) IFFREE(user);

  return sms_error(SMS_E_PRIVILEGE,"passwd");
}

int sms_cmd_privileges()
/**************************************************************************
?  Show the privileges of the current connection.
=  SMS_E_OK;
************************************o*************************************/
{
  sms_passwd_privileges();

  return SMS_E_OK;
}

int sms_cmd_auto_recover(void)
/**************************************************************************
?  Automatically recover from the checkpoint file.
|  May be called once in the beginning of the sms (no users present)
=  SMS-RETURN-CODE
************************************o*************************************/
{
  char *name;
  char  temp[MAXLEN];
  int   rc;

  if( ! (name=sms_variable_get("SMSCHECK",NULL)) )
    return sms_error(SMS_E_GLOBALVAR,"recover:%s","SMSCHECK");

  strcpy(temp,name);
  name = temp;

  sms_._xdr_version = SMS_REVISION * 1000 + SMS_MODIFICATION;
  rc = sms_node_read(name,NULL);

  sms_._super->status = STATUS_HALTED;

  if( !rc )
    return sms_error(SMS_E_READ,"recover:%s",STR(name));
  else
    spit(0,IOI_LOG,"autorecover:complete from %s by %s",STR(name),STR(SMS_USER));

  return 0;
}

int sms_cmd_recover(sms_list *args)
/**************************************************************************
?  Recover from the checkpoint file.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  char *name;
  char  temp[MAXLEN];
  int   rc;
  int   client_xdr_vers = sms_._xdr_version;

  name = args?args->name : NULL;

  if( ! IS_HALTED )
    return sms_error(SMS_E_NOTHALTED,"recover");

  if( sms_._super->kids )
     return sms_error(SMS_E_NOTEMPTY,"recover");

  if( !name )
  {
    if( ! (name=sms_variable_get("SMSCHECK",NULL)) )
      return sms_error(SMS_E_GLOBALVAR,"recover:%s","SMSCHECK");

    strcpy(temp,name);
    name = temp;
  }

  sms_._xdr_version = SMS_REVISION * 1000 + SMS_MODIFICATION;
  sms_._xdr_privs   = XDR_SERVER;

  rc = sms_node_read(name,NULL);
  sms_._xdr_version = client_xdr_vers;

  if( !rc )
    return sms_error(SMS_E_READ,"recover:%s",STR(name));

  sms_._super->status = STATUS_HALTED;

  sms_connect_recover();

  return
    spit(SMS_E_OK,IOI_LOG,"recover:complete from %s by %s",STR(name),STR(SMS_USER));
}

int sms_cmd_requeue(sms_list *args)
/**************************************************************************
?  Requeue a node.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;
  int       force;

  sms_decode(options,&force,NULL);

  while( args )
  {
    int status;

    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"requeue:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"requeue:%s",STR(args->name));

    if( ! sms_cmd_typeok("requeue",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      return SMS_E_REQUETYPE;

    status = (np->status==STATUS_SUSPENDED)? np->savedstat : np->status;
    
    if( status == STATUS_SUBMITTED ||
        status == STATUS_ACTIVE    || 
        status == STATUS_ABORTED    )
      if( force )
        spit(0,IOI_WAR,"requeue:%s from %s %s",STR(args->name),STR(status_name[status]),
             (np->status==STATUS_SUSPENDED)? "while suspended" : "");
      else
        return sms_error(SMS_E_FREQUE,"requeue:%s",STR(args->name));

    LOGGING(np);
    sms_node_requeue(np,FALSE);
    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_resubmit(sms_list *args)
/**************************************************************************
?  Resubmit node(s)
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;
  int       aborted,clear;

  sms_decode(options,&aborted,&clear,NULL);

  while( args )
  {
    int status;

    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"resubmit:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"resubmit:%s",STR(args->name));

    if( ! sms_cmd_typeok("resubmit",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      return SMS_E_RESUBMIT;

    LOGGING(np);
    sms_node_resubmit(np,aborted,clear);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_run(sms_list *args)
/**************************************************************************
?  Run node(s)
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node *np;
  int       force,clear;

  sms_decode(options,&force,&clear,NULL);

  while( args )
  {
    int status;

    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"run:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"run:%s",STR(args->name));

    if( ! sms_cmd_typeok("run",np,NODE_TASK,NODE_ALIAS,0))
      return SMS_E_TASK;

    LOGGING(np);
    sms_node_run(np,force,clear);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_restart(void)
/**************************************************************************
?  Restart the SMS.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np = sms_._super->kids;

  if( IS_RUNNING )
    return sms_error(SMS_E_NOTDOWN,"restart? %s",STR(SMS_USER));

  while( np )
  {
    np->modified = TRUE;          /* Force SMS to check the suites */
    np = np->next;
  }

  sms_._status = SMS_RUNNING;
  sms_._super->status = sms_status_max(sms_._super->kids);
  sms_._super->act_no = ++sms_._action_number;

  LOGGING(sms_._super);
  return spit(SMS_E_OK,IOI_MSG,"restart:by %s",STR(SMS_USER));
}

int sms_cmd_resume(sms_list *args)
/**************************************************************************
?  Resume the node(s) given.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;
  int       recursively;

  sms_decode(options,&recursively,NULL);

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"resume:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"resume:%s",STR(args->name));

    if( ! sms_cmd_typeok("resume",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      return SMS_E_TYPE;

    LOGGING(np);

    if( ! sms_status_change(np,STATUS_RESUME,FALSE,recursively) )
      return sms_error(SMS_E_STATUS,"resume:%s",STR(args->name));

    if( IS_SHUTDOWN ) spit(0,IOI_WAR,"resume:SMS is shutdown");
    if( IS_HALTED   ) spit(0,IOI_WAR,"resume:SMS is halted");

    sms_cmd_log_user(np);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_scan(sms_list *args)
/**************************************************************************
?  Scan the SMS-file for the variables.
|  Return the file itself if option edit is TRUE
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node     *np;
  sms_variable *var = NULL;
  int           rc;
  int           edit;
  int           preprocess;

  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"scan:%s",STR(args->name));

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"scan:%s",STR(np->name));

  if( np->type != NODE_TASK )
    return sms_error(SMS_E_TASK,"scan:%s",STR(sms_node_full_name(np)));

  sms_decode(options,&edit,&preprocess,NULL);

  np->tryno++;
  LOGGING(np);
  if( rc = sms_edit_scan(np,&var,edit,preprocess) )
  {
    sms_node_free(sms_._reply);
                                   /* Return the variables back to CDP    */
    sms_._reply=(sms_list *)var;   /* Freed next time sms_._answer needed */
  }
  np->tryno--;

  return rc? SMS_E_OK : SMS_E_SEND;
}

int sms_cmd_send(sms_list *args)
/**************************************************************************
?  SEND the task edited with the variables given by the CDP.
=  SMS-RETURN-CODE
@  options
************************************o*************************************/
{
  sms_node     *np;
  sms_variable *var=NULL;
  int           rc = SMS_E_OK;
  int           edit;
  int           alias;
  int           run;

  sms_list     *lp;
  char         *filename;
  int           ispipe = 0;


  if( ! (np=sms_node_find_full(args->name)) )
    return sms_error(SMS_E_NOTFOUND,"send:%s",STR(args->name));

  args = args->next;

  sms_decode(options,&alias,&run,NULL);

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"send:%s",STR(np->name));

  if( np->type != NODE_TASK )
    return sms_error(SMS_E_TASK,"send:%s",STR(sms_node_full_name(np)));

  var = (sms_variable *)args;

  filename = SMSSCRIPT(np,&ispipe);

  edit = (sms_file_extract((sms_list **)&var,np) != NULL);

  for( lp=(sms_list *)var ; lp ; lp=lp->next )
    if(lp->type != NODE_VARIABLE)
      return sms_error(SMS_E_WRITE,"send:%s",STR(sms_node_full_name(np)));

  if( !alias && 
      (
        np->status == STATUS_UNKNOWN    ||
        np->status == STATUS_SUBMITTED  ||
        np->status == STATUS_ACTIVE     ||
        (
          np->status == STATUS_SUSPENDED &&
          (
            np->savedstat == STATUS_UNKNOWN   ||
            np->savedstat == STATUS_SUBMITTED ||
            np->savedstat == STATUS_ACTIVE
          )
        )
      )
    )
  {
    sms_variable_generate(np,FALSE,FALSE,NULL,NULL);
    return sms_error(SMS_E_STATUS,"send:%s",STR(sms_node_full_name(np)));
  }

  /* if(!independently) */
    LOGGING(np);

  np->tryno++;
  if( !(rc=sms_edit_cmd(np,var,edit,alias,run)) )
    sms_error(SMS_E_SEND,"send:%s",STR(np->name));
  else
  {
    if( alias ) np->tryno--;
    rc=SMS_E_OK;
  }

  sms_variable_generate(np,FALSE,FALSE,NULL,NULL);

  return
    spit(rc,IOI_MSG,"%s%s%s:%s by %s",
      STR(command_name),
      alias?"(alias)":"",
      run?"(run)":"",
      STR(sms_node_full_name(np)),
      STR(SMS_USER));
}

int sms_cmd_shutdown()
/**************************************************************************
?  Shutdown the SMS.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np = sms_._super->kids;

  if( IS_SHUTDOWN )
    return sms_error(SMS_E_SHUTDOWN,"shutdown? %s",STR(SMS_USER));

  while( np )
  {
    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"shutdown:%s",STR(np->name));

    np = np->next;
  }

  sms_._status = SMS_SHUTDOWN;
  sms_._super->status = STATUS_SHUTDOWN;
  sms_._super->act_no = ++sms_._action_number;

  LOGGING(sms_._super);
  return spit(SMS_E_OK,IOI_MSG,"shutdown:by %s",STR(SMS_USER));
}

int sms_cmd_halt(void)
/**************************************************************************
?  Halt the SMS.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np = sms_._super->kids;

  if( IS_HALTED )
    return sms_error(SMS_E_HALTED,"halt? %s",STR(SMS_USER));

  while( np )
  {
    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"halt:%s",STR(np->name));

    np = np->next;
  }

  sms_._status = SMS_HALTED;
  sms_._super->status = STATUS_HALTED;
  sms_._super->act_no = ++sms_._action_number;

  LOGGING(sms_._super);
  return spit(SMS_E_OK,IOI_MSG,"halt:by %s",STR(SMS_USER));
}

int sms_cmd_lockit(void)
/**************************************************************************
?  Halt SMS by gaining exclusive lock on it
|  Only one user at the time may have the lock
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np = sms_._super;

  if( FLAG_ISSET(np,FLAG_LOCKED))
    return sms_error(SMS_E_LOCKED,"lock? %s",STR(SMS_USER));

  while( np )
  {
    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"lock:%s",STR(np->name));

    np = np->next;
  }

  FLAG_SET(sms_._super, FLAG_LOCKED);
  sms_._super->act_no = ++sms_._action_number;
  sms_._lockedby = sms_._current_con->handle;

  LOGGING(sms_._super);
  return spit(SMS_E_OK,IOI_MSG,"lock:by %s",STR(SMS_USER));
}

int sms_cmd_unlockit(void)
/**************************************************************************
?  Release sms from it's lock
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np = sms_._super;

  if( FLAG_ISSET(np,FLAG_LOCKED))
  {
    FLAG_CLEAR(sms_._super, FLAG_LOCKED);
    sms_._super->act_no = ++sms_._action_number;
    sms_._lockedby = 0;

    LOGGING(sms_._super);
    return spit(SMS_E_OK,IOI_MSG,"unlock:by %s",STR(SMS_USER));
  }

  return SMS_E_OK;
}

int sms_cmd_sms(void)
/**************************************************************************
?  This is the routine called by rpc-cmd command.
=  SMS_E_OK
************************************o*************************************/
{
  sms_connect *c;
  int          statistics;
  int          i;
  char         locked[MAXLEN];

  locked[0]=0;
  if( FLAG_ISSET(sms_._super,FLAG_LOCKED) )
  {
    sms_connect *cp;

    for( cp=sms_._connect ; cp ; cp=cp->next )
     if( sms_._lockedby == cp->handle )
       break;

    if(!cp)
      sprintf(locked," locked by user # %d (disappeared!)",sms_._lockedby);
    else
      sprintf(locked," locked by %s%s",STR(cp->name),
              cp->handle == sms_._lockedby ? " that you" : "");
  }

  sms_decode(options,&statistics,NULL);

  sms_output("SMSNODE             %s",STR(sms_._host));
  sms_output("Up since            %s",STR(sms_time_c(&sms_._start_up)));

  sms_output("SMS [RPCNUM]        %d/%d  tcp=%d  udp=%d",
      sms_._prog,sms_._vers,sms_._tcp_port,sms_._udp_port);

  sms_output("SMS version         %d.%d.%d",
             SMS_VERSION,SMS_REVISION,SMS_MODIFICATION);
  sms_output("SMSHOME             %s",STR(sms_variable_get("SMSHOME",NULL)));
  sms_output("CWD                 %s",STR(ioi_variable_get("cwd")));
  sms_output("Status              %s%s",sms_._status?
             status_name[sms_._super->status] : "running", STR(locked) );

  if(sms_._passwd)
    sms_output("Security            %s mode","secure");
  else if(sms_._whitelist || sms_._blacklist)
    sms_output("Security            %s mode","user listing");
  else
    sms_output("Security            %s mode","open");
    
  for( i=0 , c=sms_._connect ; c ; c=c->next )
    if( c->name[0] != '/' )
      i++;
  sms_output("User connections    %d",i);

  for( i=0 , c=sms_._connect ; c ; c=c->next )
    if( c->name[0] == '/' )
      i++;
  sms_output("Task connections    %d",i);
  i = sms_passwd_zombies();
  sms_output("Zombie tasks        %d",i);

  sms_output("Suites              %d",ls_len(&sms_._super->kids));

  sms_output("checkpointing       %s [%s]",
      STR(check_name[sms_._check_mode]),
      STR(sms_variable_get("SMSCHECK",NULL)));

  sms_output("check-interval      %dsec",sms_._check_time);
  sms_output("last done           %s", sms_._check_last?
      sms_time_c(&sms_._check_last):"never");

  sms_output("history             %d/%d lines",sms_._hist_len,sms_._hist_max);
  sms_output("time update         %d sec",sms_._interval);
  sms_output("micro/edit          [%c]",SMSMICRO(sms_._super));

  if(statistics)
  {
#ifdef SMS_STATISTICS
    int all = smss_._rpc_calls;
    int nll = smss_._null_proc_calls;
    
    sms_output("RPC-CALLS:");
    sms_output("  normal            %-8d %5.1f %%",all-nll,
        (100*(all-nll))/(double)all);
    sms_output("  null-proc         %-8d %5.1f %%",nll    ,
        (100*nll)/(double)all);
    sms_output("  total             %d",all);

    sms_output("USERS:");
    sms_output("  logins            %d",smss_._user_logins);
    sms_output("  privileged logins %d",smss_._priv_logins);
    sms_output("  denied            %d",smss_._users_denied);
    sms_output("  anonymous         %d",smss_._anonymous_logins);
    sms_output("TASKS:");
    sms_output("  send              %d",smss_._tasks_send);
    sms_output("  resend            %d",smss_._tasks_resend);
    sms_output("  logins            %d",smss_._task_logins);
    sms_output("  zombies           %d",smss_._tasks_zombie);
    sms_output("  denied            %d",smss_._tasks_denied);
    sms_output("MESSAGES DELIVERED:");
    sms_output("  init              %d",smss_._tasks_init);
    sms_output("  msgs              %d",smss_._tasks_msgs);
    sms_output("  completed         %d",smss_._tasks_completed);
    sms_output("  aborted           %d",smss_._tasks_aborted);
    sms_output("  meters            %d",smss_._tasks_meters);
    sms_output("  labels            %d",smss_._tasks_labels);
    sms_output("  mails             %d",smss_._tasks_mails);
    sms_output("  waits             %d",smss_._tasks_waits);
    sms_output("  queries           %d",smss_._tasks_queries);
    sms_output("  events            %d",smss_._events_set);
    sms_output("  total             %d",
      smss_._tasks_init      + smss_._tasks_msgs    +
      smss_._tasks_completed + smss_._tasks_aborted +
      smss_._tasks_meters    + smss_._tasks_labels  +
      smss_._tasks_mails     + smss_._tasks_waits   +
      smss_._tasks_queries   + smss_._events_set
      );
    sms_output("SUITES:");
    sms_output("  restarts          %d",smss_._auto_begin);
    sms_output("  runs              %d",smss_._suite_complete);

#ifdef SMS_TIMER
    sms_output("TIMES USED:");
    sms_output("  users             %-12d (ticks)",smss_._user_clocks);
    sms_output("  tasks             %-12d (ticks)",smss_._task_clocks);
#endif /* SMS_TIMER */

#else
    sms_output("SMS in %s is not running statistics",STR(sms_._host));
#endif /* SMS_STATISTICS */
  }

  return SMS_E_OK;
}

int sms_cmd_terminate(void)
/**************************************************************************
?  Stop the SMS.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  if( ! IS_HALTED )
    return sms_error(SMS_E_NOTHALTED,"terminate? %s",STR(SMS_USER));

  sms_._status = SMS_DYING;

  LOGGING(sms_._super);
  return spit(SMS_E_OK,IOI_MSG,"terminate:by %s",STR(SMS_USER));
}

int sms_cmd_suspend(sms_list *args)
/**************************************************************************
?  Suspend the node(s) given.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;
  int       recursively;

  sms_decode(options,&recursively,NULL);

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"suspend:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"suspend:%s",STR(args->name));

    if( ! sms_cmd_typeok("suspend",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      return SMS_E_TYPE;

    LOGGING(np);

    if( np->status == STATUS_SUSPENDED )
      spit(0,IOI_WAR,"suspend:%s already suspended",STR(args->name));

    if( ! sms_status_change(np,STATUS_SUSPENDED,FALSE,recursively) )
      return sms_error(SMS_E_STATUS,"suspend:%s",STR(args->name));

    sms_cmd_log_user(np);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_expire(sms_list *args)
/**************************************************************************
?  Expire the node(s) given.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;
  int       recursively;

  sms_decode(options,&recursively,NULL);

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"expire:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"expire:%s",STR(args->name));

    if(!sms_cmd_typeok("expire",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,0))
      return SMS_E_TYPE;

    LOGGING(np);

    sms_time_expire(np);

    sms_cmd_log_user(np);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_reset(sms_list *args)
/**************************************************************************
?  Reset the limits(s) given.
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *np;

  while( args )
  {
    if( ! (np=sms_node_find_full(args->name)) )
      return sms_error(SMS_E_NOTFOUND,"reset:%s",STR(args->name));

    if( ! sms_status_privilege( np ) )
      return sms_error(SMS_E_NOTOWNER,"reset:%s",STR(args->name));

    if(!sms_cmd_typeok("reset",np,NODE_LIMIT,0))
      return SMS_E_TYPE;

    LOGGING(np);

    sms_limit_reset(np);

    args = args->next;
  }

  return SMS_E_OK;
}

int sms_cmd_users(void)
/**************************************************************************
?  Display the users
=  SMS_E_OK
************************************o*************************************/
{
  if(options)
#ifdef SMS_MULTI_PROCESS
    sms_system_process_list();
#else
    ;
#endif
  else
    sms_._staticlist = (sms_list *)sms_._connect;

  return SMS_E_OK;
}

int sms_cmd_zombies(sms_list *args)
/**************************************************************************
?  List/process zombies
=  SMS_E_OK
************************************o*************************************/
{
  int cmd = (options >> 8);

  if( ! cmd==ZOMBIE_GET )
    if( !(PRIVILEGE(PR_ADMIN) || PRIVILEGE(PR_OPER)) )
      return sms_error(SMS_E_PRIVILEGE,"zombies:cmd %s",STR(zombie_cmds[cmd]));

  return sms_passwd_zombie_cmd(cmd,args);
}

int sms_cmd_mail(sms_list *args)
/**************************************************************************
?  Process SMS-mail
=  SMS_E_OK
************************************o*************************************/
{
  int mode   = options & 0xff;
  int number = (options >> 8);

  return sms_mail(mode, number, args);
}

int sms_cmd_number(char *command_name, int *old)
/**************************************************************************
?  Decypher sms command name. Only by SMS
=  Child command number or (-1) if none
************************************o*************************************/
{
  int cmd;

  if( (cmd=ioi_user_cmdf(command_name,child_cmds,NULL,nchild_cmds)) == (-1) )
    return cmd;

  if( old ) *old = cmd;

  if( cmd==CMD_ENDT || cmd==CMD_ABTT || cmd==CMD_SETEV )
  {
    sms_connect *cp = sms_._current_con;

    if( cp && (VERSION_NUMBER(cp->vers,cp->rev,cp->mod) <= 43021) )
    {
      if( cmd==CMD_ABTT  ) cmd=CMD_SMSABORT;
      if( cmd==CMD_ENDT  ) cmd=CMD_SMSCOMPLETE;
      if( cmd==CMD_SETEV ) cmd=CMD_SMSEVENT;
    }
  }

  return cmd;
}

int sms_cmd_islocked(char *cmd)
/**************************************************************************
?  Is SMS locked
************************************o*************************************/
{
  if( strcmp(cmd,sms_cmds[CMD_UNLOCK]) == 0 )
    return FALSE;

  if( FLAG_ISSET(sms_._super,FLAG_LOCKED) )
    if( sms_._current_con->handle == sms_._lockedby )
      return FALSE;
    else
      return TRUE;

  return FALSE;
}

int sms_cmd(
    int       cdp_options,         /* Bit packed, if needed  */
    sms_list *cmd)                 /* Can really be anything */
/**************************************************************************
?  This is the routine called by rpc-cmd command.
=  SMS-RETURN-CODE
************************************o*************************************/
{
#undef SMS_CHILD_H

  int   rc;
  int   old;
  int   ntokes = ls_len(&cmd);     /* Currently ignored */

  if( !cmd || !cmd->name )
    return sms_error(SMS_E_PROTOCOL,"execute:no command");

#if 0
  printf("SMS-COMMAND:");
  ls_fancy(&cmd,stdout,100);
#endif

  command_name = cmd->name;

  if( *command_name == '/' )       /* CDP escape character */
    command_name++;

  options = cdp_options;

  if( (rc=sms_cmd_number(command_name, &old)) != (-1) )
    return sms_cmd_child(rc,old,cmd->next);

  if( (rc=ioi_user_cmdf(command_name,sms_cmds,NULL,nsms_cmds)) == (-1) )
    return sms_error(SMS_E_PROTOCOL,"execute:unknown command %s",STR(command_name));

  if( rc==CMD_PASSWD || rc==CMD_SUITES || rc==CMD_FILE ||
      rc==CMD_DIR    || rc==CMD_MANUAL || rc==CMD_MAIL ||
      rc==CMD_USERS  ||
      ( ! sms_cmd_islocked(command_name) && PRIVILEGE(sms_privilege[rc]) )
    )
  {
    switch( rc )
    {
      case CMD_USERS:      rc=sms_cmd_users();              break;
      case CMD_BEGIN:      rc=sms_cmd_begin(cmd->next);     break;
      case CMD_SUSPEND:    rc=sms_cmd_suspend(cmd->next);   break;
      case CMD_RESUME:     rc=sms_cmd_resume(cmd->next);    break;
      case CMD_CANCEL:     rc=sms_cmd_cancel(cmd->next);    break;

      case CMD_SEND:       rc=sms_cmd_send(cmd->next);      break;
      case CMD_FORCE:      rc=sms_cmd_force(cmd->next);     break;

      case CMD_CHECK:      rc=sms_cmd_check(cmd->next);     break;
      case CMD_RECOVER:    rc=sms_cmd_recover(cmd->next);   break;
      case CMD_SHUTDOWN:   rc=sms_cmd_shutdown();           break;
      case CMD_RESTART:    rc=sms_cmd_restart();            break;
      case CMD_TERMINATE:  rc=sms_cmd_terminate();          break;

      case CMD_EXISTS:     rc=sms_cmd_exists(cmd->next);    break;
      case CMD_DELETE:     rc=sms_cmd_delete(cmd->next);    break;

      case CMD_PASSWD:     rc=sms_cmd_passwd(cmd->next);    break;
      case CMD_PRIVILEGES: rc=sms_cmd_privileges();         break;

      case CMD_SCAN:       rc=sms_cmd_scan(cmd->next);      break;
      case CMD_SMS:        rc=sms_cmd_sms();                break;
      case CMD_ALTER:      rc=sms_cmd_alter(cmd->next);     break;
      case CMD_HALT:       rc=sms_cmd_halt();               break;

      case CMD_FILE:       rc=sms_cmd_file(cmd->next);      break;
      case CMD_REQUEUE:    rc=sms_cmd_requeue(cmd->next);   break;
      case CMD_DIR:        rc=sms_cmd_dir(cmd->next);       break;
      case CMD_MANUAL:     rc=sms_cmd_manual(cmd->next);    break;

      case CMD_SUITES:     rc=sms_cmd_suites(cmd->next);    break;
      case CMD_ORDER:      rc=sms_cmd_order(cmd->next);     break;
      case CMD_KILL:       rc=sms_cmd_kill(cmd->next);      break;
      case CMD_MIGRATE:    rc=sms_cmd_migrate(cmd->next);   break;
      case CMD_RESTORE:    rc=sms_cmd_restore(cmd->next);   break;

      case CMD_RESUBMIT:   rc=sms_cmd_resubmit(cmd->next);  break;

      case CMD_MESSAGE:    rc=sms_cmd_message(cmd->next);   break;
      case CMD_EXPIRE:     rc=sms_cmd_expire(cmd->next);    break;
      case CMD_RUN:        rc=sms_cmd_run(cmd->next);       break;
      case CMD_RESET:      rc=sms_cmd_reset(cmd->next);     break;
      case CMD_ZOMBIES:    rc=sms_cmd_zombies(cmd->next);   break;

      case CMD_MAIL:       rc=sms_cmd_mail(cmd->next);      break;
      case CMD_PLUG:       rc=sms_cmd_plug(cmd->next);      break;
      case CMD_LOCK:       rc=sms_cmd_lockit();             break;
      case CMD_UNLOCK:     rc=sms_cmd_unlockit();           break;

      case CMD_JOBCHECK:    rc=sms_cmd_jobcheck(cmd->next);      break;
    }

    if(rc && rc!=SMS_E_NONEWS)   /* Log the user in case of errors */
    {
      sms_._answer = FALSE;
      spit(0,IOI_ERR,"%s:user was %s",STR(cmd->name),STR(SMS_USER));
    }
  }
  else
    if(sms_cmd_islocked(command_name))
      return sms_error(SMS_E_LOCKED,"%s:user %s",STR(cmd->name),STR(SMS_USER));
    else
      return sms_error(SMS_E_PRIVILEGE,"%s:user %s",STR(cmd->name),STR(SMS_USER));

  sms_._node = NULL;
  return rc;
}
