/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     REPEAT
.SECTION  L
.AUTHOR   Otto Pesonen
.LANGUAGE ANSI-C
.DATE     22-SEP-1995 / 27-FEB-1994 / OP
.VERSION  4.3.0-7
.FILE     repeat.c
*
.DATE     08-APR-1997 / 08-APR-1997 / OP
.VERSION  4.3.14
*         Year is now 4 digits
.DATE     23-APR-1998 / 23-APR-1998 / OP
.VERSION  4.3.18
*         Repeat fixes and alter
.DATE     05-JUN-1998 / 04-JUN-1998 / OP
.VERSION  4.3.19
*         Date repeat
*         julian_to_date() and date_to_julian() borrowed from mars,
*         thanx to Baudouin Raoult
.DATE     14-JUL-1998 / 14-JUL-1998 / OP
.VERSION  4.3.20
*         Bug fix for repeat alter (variable was wrong)
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     16-DEC-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
.DATE     28-JUN-2001 / 28-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         Enumerated repeat
************************************o*************************************/

#include "smslib.h"

static void make_var(sms_node *np, char *fmt, void *anything,
                     nid_func func, void* userdata)
/**************************************************************************
?  Create the repeat variable
************************************o*************************************/
{
  char buff[MAXNAM];
  sms_variable *vp;

  sprintf(buff,fmt,anything);

  sms_variable_update(np, np->repeat->name, buff, func, userdata);
}

long sms_repeat_julian_to_date(long jdate)
{
	long x,y,d,m,e;
	long day,month,year;

	x = 4 * jdate - 6884477;
	y = (x / 146097) * 100;
	e = x % 146097;
	d = e / 4;

	x = 4 * d + 3;
	y = (x / 1461) + y;
	e = x % 1461;
	d = e / 4 + 1;

	x = 5 * d - 3;
	m = x / 153 + 1;
	e = x % 153;
	d = e / 5 + 1;

	if( m < 11 )
		month = m + 2;
	else
		month = m - 10;


	day = d;
	year = y + m / 11;

	return year * 10000 + month * 100 + day;
}

long sms_repeat_date_to_julian(long ddate)
{
	long  m1,y1,a,b,c,d,j1;

	long month,day,year;

	year = ddate / 10000;
	ddate %= 10000;
	month  = ddate / 100;
	ddate %= 100;
	day = ddate;

	if (month > 2)
	{
		m1 = month - 3;
		y1 = year;
	}
	else
	{
		m1 = month + 9;
		y1 = year - 1;
	}
	a = 146097*(y1/100)/4;
	d = y1 % 100;
	b = 1461*d/4;
	c = (153*m1+2)/5+day+1721119;
	j1 = a+b+c;

	return(j1);
}

int sms_repeat_str2date(char *s)
/**************************************************************************
?  Check and convert YYYYMMDD date to integer
=  0 if an error is detected
************************************o*************************************/
{
  long julian;
  int  date = atoi(s);

  julian = sms_repeat_date_to_julian(date);
  if( sms_repeat_julian_to_date(julian) != date )
    return 0;

  return date;
}

void sms_repeat_init(sms_node *np)
/**************************************************************************
?  Initialize the repeat structure at the beginning of the suite or
|  when a node is requeued.
************************************o*************************************/
{
  sms_repeat *rp;
  sms_node   *kid;

  if( !np ) return;

  rp = np->repeat;

  if(rp)
  {
    rp->act_no = ++sms_._action_number;

    switch(rp->mode)
    {
      case REPEAT_DAY:               /* This is done by sms_time_suite() */
      case REPEAT_MONTH:
      case REPEAT_YEAR:
        break;

      case REPEAT_INTEGER:
      case REPEAT_DATE:
        rp->status = rp->start;
        make_var(np,"%d",(void*)(rp->status),NULL,NULL);
        break;

      case REPEAT_ENUMERATED:
        rp->status = 0;
        if( rp->str && rp->str->name )
          rp->status = atoi( rp->str->name );
        else
          spit(0,IOI_DBG,"repeat-init: no str? %s",STR(sms_node_full_name(np)));
        make_var(np,"%d",(void*)(rp->status),NULL,NULL);
        break;

      case REPEAT_STRING:
        make_var(np,"%s",rp->str? STR(rp->str->name) : "",NULL,NULL);
        rp->status = 0;
        break;

      case REPEAT_FILE:              /* Currently NA */
        rp->status = 0;
        break;
    }
  }

  for( kid=np->kids ; kid ; kid=kid->next )
    sms_repeat_init(kid);
}

void sms_repeat_variable(sms_node *np, nid_func func, void *userdata)
/**************************************************************************
?  Update generated variable of the node given
************************************o*************************************/
{
  sms_repeat *rp;
  sms_list   *lp;

  if( !np ) return;

  rp = np->repeat;
  if( !rp ) return;

  switch(rp->mode)
  {
    case REPEAT_DAY:               /* This is done by sms_time_suite() */
    case REPEAT_MONTH:
    case REPEAT_YEAR:
      break;

    case REPEAT_INTEGER:
    case REPEAT_DATE:
    case REPEAT_ENUMERATED:
      make_var(np,"%d",(void*)(rp->status),func,userdata);
      break;

    case REPEAT_STRING:
      lp = ls_item(&rp->str,rp->status);
      if( !lp )
        lp = ls_last(&rp->str);
      make_var(np,"%s",lp?STR(lp->name) : "" ,func,userdata);
      break;

    case REPEAT_FILE:              /* Currently NA */
      break;
  }
}

int sms_repeat_node(sms_node *np)
/**************************************************************************
?  Repeat the a node after it has completed
|  Called by the SMS only
=  Boolean status (does succeed, until file access is implemented)
************************************o*************************************/
{
  sms_repeat *rp = np->repeat;
  sms_list   *lp;
  char        current[MAXLEN];

  int         mode;
  int         do_repeat = FALSE;

  time_t     t;                    /* Used for DAY/MONTH/YEAR repeat */
  time_t     btime;                /* Used for DAY/MONTH/YEAR repeat */
  int        offset;               /* Used for DAY/MONTH/YEAR repeat */
  struct tm *tm;                   /* Used for MONTH/YEAR repeat     */

  long       julian;

  if( !rp ) return TRUE;

  mode = rp->mode;

  if( mode==REPEAT_DAY || mode==REPEAT_MONTH || mode==REPEAT_YEAR )
  {
    if( np->type != NODE_SUITE )
      return sms_error(SMS_E_REPEAT,"autorepeat:%s",STR(sms_node_full_name(np)));

    if( sms_time_suite_complete(np) )
      return 1;

    sms_time_t(&t);
    btime = t+np->gain;
    btime = (btime/86400)*86400; /* We only need the date */
  }

  switch( rp->mode )
  {
    case REPEAT_DAY:               /* SUITE only */
      if(np->clock==CLOCK_HYBRID)
      {
        offset = (rp->step * 86400);
        np->gain  += offset - (btime - np->btime);
        np->btime += offset;
      }
      do_repeat = (rp->end)? (rp->end >= np->btime) : TRUE;
      break;

    case REPEAT_MONTH:             /* SUITE only */
      if(np->clock==CLOCK_HYBRID)
      {
        tm = sms_time_tm(&np->btime);

        tm->tm_mon += rp->step;
        if( tm->tm_mon > 11 )
        {
          tm->tm_mon -= 12;
          tm->tm_year++;
        }
        if( tm->tm_mon < 0 )
        {
          if( tm->tm_year == 0 )
            return sms_error(SMS_E_REPEAT,"autorepeat:%s month underflow",
                             STR(sms_node_full_name(np)));
          else
          {
            tm->tm_mon += 12;
            tm->tm_year--;
          }
        }
        t = sms_time_gmt(tm);
        offset = t - np->btime;

        np->gain  += offset - (btime - np->btime);
        np->btime += offset;
      }
      do_repeat = (rp->end)? (rp->end >= np->btime) : TRUE;
      break;

    case REPEAT_YEAR:              /* SUITE only */
      if(np->clock==CLOCK_HYBRID)
      {
        tm = sms_time_tm(&np->btime);

        tm->tm_year += rp->step;

        if( tm->tm_year <= 0 )
          return sms_error(SMS_E_REPEAT,"autorepeat:%s year underflow",
                           STR(sms_node_full_name(np)));

        t = sms_time_gmt(tm);
        offset = t - np->btime;

        np->gain  += offset - (btime - np->btime);
        np->btime += offset;
      }
      do_repeat = (rp->end)? (rp->end >= np->btime) : TRUE;
      break;

    case REPEAT_INTEGER:
      rp->status += rp->step;
      do_repeat   = (rp->step>0)? (rp->status <= rp->end) : (rp->status >= rp->end);
      break;

    case REPEAT_ENUMERATED:
      sprintf(current,"%d",rp->status);
      lp = ls_find(&rp->str, current);
      do_repeat   = (lp && lp->next);
      if(do_repeat)
      {
        lp = lp->next;
        rp->status = atoi(lp->name? lp->name : "0");
      }
      break;

    case REPEAT_STRING:
      rp->status += 1;
      do_repeat   = (rp->status < ls_len(&rp->str));
      break;

    case REPEAT_FILE:              /* Currently NA */
      do_repeat   = FALSE;
      break;

    case REPEAT_DATE:
      julian = sms_repeat_date_to_julian(rp->status + rp->step);
      rp->status = sms_repeat_julian_to_date(julian);
      do_repeat = (rp->step>0)? (rp->status <= rp->end) :
                               (rp->status >= rp->end) ;
      break;
  }

  if( do_repeat )
  {
    sms_repeat_variable(np,NULL,NULL);
    SUITE_CHANGED((sms_node *)rp);
    if( mode==REPEAT_DAY || mode==REPEAT_MONTH || mode==REPEAT_YEAR )
    {
      spit(0,IOI_MSG,"autorepeat date:%s started",STR(sms_node_full_name(np)));
      /*
       * For suite we must call sms_node_begin() which permanently
       * alters the gain of the suite and generates the variabels
       */
      sms_node_begin(np,FALSE);
    }
    else
    {
      sms_node_requeue(np,TRUE);
      if(np->type==NODE_SUITE)
        spit(0,IOI_MSG,"autorepeat variable:%s started",STR(sms_node_full_name(np)));
    }
  }

  return 0;
}

int sms_repeat_alter(sms_repeat *rp, char *str)
/**************************************************************************
?  Alter repeat for string and integer (X)CDP command
|  Called by sms_alter()
************************************o*************************************/
{
  char     *fn = sms_node_full_name(rp);
  sms_list *lp;
  int       i;

  if(rp->type != NODE_REPEAT)
    return spit(SMS_E_NOTFOUND,IOI_ERR,"alter:%s has no repeat",STR(fn));

  switch(rp->mode)
  {
    case REPEAT_DAY:
    case REPEAT_MONTH:
    case REPEAT_YEAR:
      return spit(SMS_E_IMPLEMENT,IOI_ERR,"alter:%s try alter gain",STR(fn));
      /* break; */

    case REPEAT_INTEGER:
      if( !sms_is_signed_number(str) ) return 
        spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %s is not a number",STR(fn),STR(str));

      i = atoi(str);

      if(rp->step > 0)
        if(i<rp->start || i>rp->end || ((i - rp->start) % rp->step ) != 0)
          return spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %d is not within the loop",STR(fn),i);
        else
          ;
      else
        if(i<rp->end || i>rp->start || ((i - rp->start) % rp->step ) != 0)
          return spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %d is not within the loop",STR(fn),i);

      spit(0,IOI_MSG,"alter:%s repeat to %d",STR(fn),i);
      rp->status = i;
      SUITE_CHANGED( (sms_node*)rp );
      break;

    case REPEAT_ENUMERATED:
    case REPEAT_STRING:
      i = ls_index(&rp->str,str);

      if( i == (-1) )
        if( sms_is_number(str) )
        {
          i = atoi(str);
          if( i<0 || i>=ls_len(&rp->str))
            return spit(SMS_E_REPEATR,IOI_ERR,
                        "alter:%s index (%d) is too big",STR(fn),i);
        }
        else
          return spit(SMS_E_REPEATR,IOI_ERR,
                      "alter:%s token %s not found",STR(fn),STR(str));

      lp = ls_item(&rp->str,i);

      if(rp->mode == REPEAT_ENUMERATED)
        i = atoi(lp?lp->name:"0");

      spit(0,IOI_MSG,"alter:%s repeat to %d %s %s",STR(fn),i,
           rp->mode==REPEAT_ENUMERATED? "enumerated":"string",
           lp?STR(lp->name):"");
      rp->status = i;

      SUITE_CHANGED( (sms_node*)rp );
      break;

    case REPEAT_FILE:
      return SMS_E_IMPLEMENT;
      /* break; */

    case REPEAT_DATE:
      if( (i=sms_repeat_str2date(str)) == 0 ) return 
        spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %s is not valid date",STR(fn),STR(str));

      if(rp->step > 0)
        if(i<rp->start || i>rp->end || 
          ((sms_repeat_date_to_julian(i) - sms_repeat_date_to_julian(rp->start)) % rp->step ) != 0)
          return spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %d is not within the date loop",STR(fn),i);
        else
          ;
      else
        if(i<rp->end || i>rp->start ||
          ((sms_repeat_date_to_julian(i) - sms_repeat_date_to_julian(rp->start)) % rp->step ) != 0)
          return spit(SMS_E_REPEATR,IOI_ERR,"alter:%s value %d is not within the date loop",STR(fn),i);

      spit(0,IOI_MSG,"alter:%s repeat to %d",STR(fn),i);
      rp->status = i;
      SUITE_CHANGED( (sms_node*)rp );
      break;
  }

  sms_repeat_variable(rp->parent,NULL,NULL);

  return SMS_E_OK;
}

void sms_repeat_info(sms_repeat *r)
/**************************************************************************
?  Print the repeat structure into CDP info message (stdout)
************************************o*************************************/
{
  sms_list  *lp;
  struct tm *tm;

  if( r==NULL ) return;

  lp = r->str;
  tm = sms_time_tm( (time_t *)&r->end );

  printf("repeat %s ",repeat_name[r->mode]);

  switch( r->mode )
  {
     case REPEAT_DAY:
     case REPEAT_MONTH:
     case REPEAT_YEAR:
       if( r->end )
         printf("%d %d.%d.%d",r->step,tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
       else
         printf("%d",r->step);
       break;

    case REPEAT_INTEGER:
    case REPEAT_DATE:
      printf("variable %s from %d to %d step %d currently %d ",
              STR(r->name),r->start,r->end,r->step,r->status);
      break;

    case REPEAT_FILE:
      printf("file name [%s] line number %d",STR(r->name),r->status);
      break;

    default:
      printf("%s from [",STR(r->name));

      for( ; lp ; lp=lp->next)
        printf("\"%s\"%s",STR(lp->name), lp->next?" ":"");
      lp = ls_item(&r->str,r->status);

      printf("] now \"%s\" [no %d]",
             lp?STR(lp->name):"<not defined>", r->status);
      break;
  }
  printf("\n");
}

void sms_repeat_show(sms_repeat *r, FILE *fp)
/**************************************************************************
?  Print the repeat structure into CDP for a play-file
|  One single line is produced if "r" is not NLLL
|  Currently N/A (play uses sms_repeat_string)
************************************o*************************************/
{
  sms_list  *lp;
  struct tm *tm;

  if( r==NULL ) return;

  lp = r->str;
  tm = sms_time_tm( (time_t *)&r->end );

  fprintf(fp,"repeat %s ",repeat_name[r->mode]);
  switch( r->mode )
  {
     case REPEAT_DAY:
     case REPEAT_MONTH:
     case REPEAT_YEAR:
       if( r->end ) 
         fprintf(fp,"%d %d.%d.%d",r->step,tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
       else
         fprintf(fp,"%d",r->step);
       break;

    case REPEAT_INTEGER:
      fprintf(fp,"%s %d %d %d",STR(r->name),r->start,r->end,r->step);
      break;

    case REPEAT_FILE:
      fprintf(fp,"%s",STR(r->name));
      break;

    default:
      fprintf(fp,"%s ",STR(r->name));
      for( ; lp ; lp=lp->next)
        fprintf(fp," \"%s\"",STR(lp->name));
      break;
  }
  fprintf(fp," # status %d\n",r->status);
}

char *sms_repeat_string(sms_node *np, int who)
/**************************************************************************
?  Print a description of a repeat structure into a string
|  One single line is produced if "r" is not NLLL
|  Used by XCdp if who==1 or show(play) if who==0
************************************o*************************************/
{
  static char  str[MAXNAM];
  char        *s;
  sms_repeat  *r = np->repeat;

  sms_list  *lp;
  struct tm *tm;

  str[0] = '\0';

  if( r==NULL ) return str;

  lp = r->str;
  tm = sms_time_tm( (time_t *)&r->end );

  sprintf(str,"%s ",repeat_name[r->mode]);

  s = str + strlen(str);

  switch( r->mode )
  {
     case REPEAT_DAY:
     case REPEAT_MONTH:
     case REPEAT_YEAR:
       if( who )
         if( r->end ) 
           sprintf(s,"by %d %s until %d.%d.%d",
                   r->step,repeat_name[r->mode],
                   tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
         else
           sprintf(s,"by %d %s",r->step,repeat_name[r->mode]);
       else
         if( r->end ) 
           sprintf(s,"%d %d.%d.%d",r->step,
                   tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
         else
           sprintf(s,"%d",r->step);
         break;

    case REPEAT_INTEGER:
    case REPEAT_DATE:
      if(who)
        sprintf(s,"%s from %d to %d by %d",STR(r->name),r->start,r->end,r->step);
      else
        sprintf(s,"%s %d %d %d",STR(r->name),r->start,r->end,r->step);
      break;

    case REPEAT_FILE:
      sprintf(s,"%s",STR(r->name));
      break;

    default:
      sprintf(s,"%s ",STR(r->name));
      for( ; lp ; lp=lp->next)
      {
        s = str + strlen(str);
        sprintf(s," \"%s\"",STR(lp->name));
      }
      break;
  }
  s = str + strlen(str);

  if( who )                        /* XCdp */
  {
    if( r->type==REPEAT_INTEGER || r->type==REPEAT_FILE )
      sprintf(s,"( current repeat counter is %d)",r->status);
  }
  else
    sprintf(s," # status %d",r->status);

  return str;
}
