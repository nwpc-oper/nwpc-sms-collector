/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     PASSWD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     14-APR-1992 / 21-JUN-1991 / OP
.VERSION  4.0
.FILE     passwd.c
*
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.VERSION  4.3
.DATE     09-MAR-1998 / 27-FEB-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     25-JUN-1998 / 24-JUN-1998 / OP
.VERSION  4.3.20
*         White and black list handling changed
.LANGUAGE ANSI-C
.DATE     09-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     15-DEC-1998 / 12-OCT-1998 / OP
.VERSION  4.4
*         Zombie passwords and zombie commands
.DATE     04-FEB-2000 / 04-FEB-2000
.VERSION  4.4.3
*         Zombie timeouts increased
*
*  Zombies are running tasks without valid password. There are three types of
*  zombies:
*
*  SMS created for tasks which timeout while delivering smscomplete message, but
*  are accepted by SMS (the return code is lost, RPC design flaw)
*
*  User created, tasks which are rerun, cancel, requeued etc while they are
*  running.
*
*  Network zombies. These are tasks send by SMS but of which SMS has no knowledge
*  how they appear. There is three reasons why they might happen:
*
*  1) SMS crashed (or was terminated and restarted) and the checkpoint file was
*     out of date.
*
*  2) Task was repeatedly re-run by user, the earlied copies will not be remembered
*     by SMS. There will only be one zombie with the same name.
*
*  3) Task send by another SMS and which can not talk back to the original SMS.
*
*
*  From active -> complete when task sends this, the zombie time need not
*  be too long (a couple of minutes perhaps) But form active -> queued by
*  user, the possible zombie time might be long (up to a couple of hours)
*
*  This file contains routines to handle password checking and manipulation
* 
*  About the passwords:
*  --------------------
*
*    The tasks send by the SMS will have GENERATED PASSWORD that is not
*    stored into the any file (except the job file). It only exist in the
*    SMS-memory. If the SMS fails and a new one is started, it must be
*    told (by operator) to accept the messages from the unknown jobs.
*
*    The GENERATED PASSWORDs are stored into the CHECKPOINT file. So if the
*    SMS fails and is RESTARTed from a valid CHECKPOINT file, the SMS gets
*    to know about the tasks.
*
*    The user passwords are kept in a file. When ever an user logs into
*    the SMS or changes the "level" of privileges while already in the
*    file is consulted.
*
*    The format of the file is binary XDR.
*
************************************o*************************************/

#include "smslib.h"

extern char *crypt(const char *key, const char *salt);

/* Include <crypt.h> when it is available on all systems! */

static sms_zombie *zombies;

#ifndef ZOMBIE_TIMEOUT
#define ZOMBIE_TIMEOUT 3600
#endif

#ifndef ZOMBIE_SMSTIME
#define ZOMBIE_SMSTIME   300
#define ZOMBIE_USERTIME  900
#define ZOMBIE_NETTIME  3600
#endif

int sms_passwd_zombies(void)       /* For SMS */
{
  return ls_len(&zombies);
}

static char fmthdr[100];
static char fmtzom[100];

void sms_passwd_zombie_fmt(sms_zombie *zp)
{
  int name   = strlen("task name");
  int host   = strlen("host");
  int sender = strlen("sender");

  for( ; zp ; zp=zp->next )
  if( zp->type == NODE_ZOMBIE )
  {
    name   = MAX(strlen(zp->name),name); /* Ok we call strlen twice, BFD */
    host   = MAX(strlen(zp->host),host);
    sender = MAX(strlen(zp->sender),sender);
  }

  sprintf(fmthdr,"%%-%ds %%4s %%5s %%4s %%-%ds %%-%ds %%3s %%4s %%6s %%3s",name,host,sender);
  sprintf(fmtzom,"%%-%ds %%4s %%5d %%4d %%-%ds %%-%ds %%3s %%4s %%6s %%3d",name,host,sender);
}

void sms_passwd_zombie_str(sms_zombie *zp, char *buff, time_t t)
{
  if( ! zp )
    /* sprintf(buff,"%-25s %4s %5s %4s %10s %10s %3s %4s %6s %3s", */
    sprintf(buff,fmthdr,
            "task name",
            "why",
            "secs",
            "call",
            "host",
            "sender",
            "fob",
            "fail",
            "rescue",
            "NO:");
  else
    /* sprintf(buff,"%-25s %4s %5d %4d %10s %10s %3s %4s %6s %3d", */
    sprintf(buff,fmtzom,
            zp->name,
            zombie_whyname[zp->why],
            zp->t - t,
            zp->count,
            zp->host,
            zp->sender,
            zp->fob     ? "yes":"no",
            zp->fail    ? "yes":"no",
            zp->recover ? "yes":"no",
            zp->tryno);
}

void sms_passwd_zombie_print(sms_zombie *zp)
{
  char buff[MAXLEN];
  time_t t = sms_time_t(0);

  sms_passwd_zombie_fmt(zp);

  if(zp)
  {
    sms_passwd_zombie_str(0, buff, t);
    printf(" %s\n",STR(buff));
  }

  for( ; zp ; zp=zp->next )
  {
    sms_passwd_zombie_str(zp, buff, t);
    printf(" %s\n",STR(buff));
  }
}

static void timeit(sms_zombie *zp)
{
  int t;

  if(!zp) return;

  if(zp->why==ZOMBIE_SMS)  t = ZOMBIE_SMSTIME;
  if(zp->why==ZOMBIE_USER) t = ZOMBIE_USERTIME;
  if(zp->why==ZOMBIE_NET)  t = ZOMBIE_NETTIME;

  zp->t      = sms_time_t(0) + t;
}

static sms_zombie *create(int why, char *name, char *passwd, char *host, char *sender, int tryno)
{
  sms_zombie *zp = sms_alloc(NODE_ZOMBIE);

  if(!host)   host   = "unknown";
  if(!sender) sender = "unknown";

  if(zp)
  {
    zp->passwd = strdup(passwd);
    zp->name   = strdup(name);
    zp->host   = strdup(host);
    zp->sender = strdup(sender);

    zp->why     = why;
    zp->fob     = FALSE;
    zp->fail    = FALSE;
    zp->recover = FALSE;
    zp->tryno   = tryno;

    if(!zp->passwd || !zp->name || !zp->host || !zp->sender)
    {
      IFFREE(zp->passwd);
      IFFREE(zp->name);
      IFFREE(zp->host);
      IFFREE(zp->sender);
      IFFREE(zp);
    }
  }

  timeit(zp);

  return zp;
}

static int zombie_fob(char *name)
/**************************************************************************
?  Allow SMS to fob to a named zombie (created from network)
************************************o*************************************/
{
  sms_zombie *zp;

  if( (zp=ls_find(&zombies, name)) )
  {
    zp->fob = TRUE;
    return spit(SMS_E_OK,IOI_MSG,"zombie:fob to %s",STR(name));
  }

  return sms_error(SMS_E_NOTFOUND,"zombie:fob %s",STR(name));
}

static int zombie_fail(char *name)
/**************************************************************************
?  Allow SMS to ask zombie task to a fail (created from network)
************************************o*************************************/
{
  sms_zombie *zp;

  if( (zp=ls_find(&zombies, name)) )
  {
    zp->fail = TRUE;
    return spit(SMS_E_OK,IOI_MSG,"zombie:fail %s",STR(name));
  }

  return sms_error(SMS_E_NOTFOUND,"zombie:fail %s",STR(name));
}

static int zombie_delete(char *name)
/**************************************************************************
?  Delete named zombie from SMS
************************************o*************************************/
{
  sms_zombie *zp;

  if( (zp=ls_find(&zombies, name)) )
  {
    ls_remove(&zombies,zp);
    NODE_FREE(zp,sms_zombie);
    return spit(SMS_E_OK,IOI_MSG,"zombie:deleted %s",STR(name));
  }

  return sms_error(SMS_E_NOTFOUND,"zombie:delete %s",STR(name));
}

static int zombie_recover(char *name)
/**************************************************************************
?  Move the password back to the task and remove the zombie
************************************o*************************************/
{
  sms_zombie *zp;
  sms_node   *np;

  if( (zp=ls_find(&zombies, name)) )
  {
    if( ! (np=sms_node_find_full(zp->name)) )
      return sms_error(SMS_E_NOTFOUND,"zombie:recover %s",STR(name));

    if( np->type != NODE_TASK && np->type != NODE_ALIAS )
      return sms_error(SMS_E_TASK,"zombie:recover %s",STR(name));

    zp->recover = TRUE;

    spit(0,IOI_MSG,"zombie:recover %s next time it communicates",STR(name));
    return SMS_E_OK;
  }

  return sms_error(SMS_E_NOTFOUND,"zombie:recover %s",STR(name));
}

static void recover(char *name)
/**************************************************************************
?  Recover the task if so instructed
************************************o*************************************/
{
  sms_zombie *zp;
  sms_node   *np;

  if( (zp=ls_find(&zombies, name)) && zp->recover )
  {
    if( ! (np=sms_node_find_full(zp->name)) )
      return;

    if( np->type != NODE_TASK && np->type != NODE_ALIAS )
      return;

    if( np->passwd )
    {
      spit(0,IOI_WAR,"zombie:recover %s had a password (deleted)",STR(name));
      IFFREE(np->passwd);
    }

    if( strcmp(zp->sender,"SMS")== 0 )
      np->passwd = strdup(zp->passwd);
    else
      np->passwd = strdup(sms_passwd_crypt(zp->passwd));

    if(np->status != STATUS_ACTIVE && np->status != STATUS_SUBMITTED)
    {
      sms_status_change(np,STATUS_ACTIVE,TRUE,FALSE);
      /* sms_limit_running(sms_node *np); ??? */
      spit(0,IOI_MSG,"zombie:recover forced status for %s",STR(name));
    }

    np->tryno = zp->tryno;
    sms_variable_generate(np,FALSE,FALSE,NULL,NULL);
    SUITE_CHANGED(np);

    ls_remove(&zombies,zp);
    NODE_FREE(zp,sms_zombie);

    spit(0,IOI_MSG,"zombie:recover %s is ok now",STR(name));
  }
}

int sms_passwd_zombie_cmd(int cmd, sms_list *lp)
/**************************************************************************
?  Execute zombie command
************************************o*************************************/
{
  int rc = SMS_E_OK;

  if( cmd != ZOMBIE_GET )
  {
    while( lp && rc==SMS_E_OK )
    {
      switch( cmd )
      {
        case ZOMBIE_FOB:    rc = zombie_fob(lp->name); break;
        case ZOMBIE_DELETE: rc = zombie_delete(lp->name); break;
        case ZOMBIE_FAIL:   rc = zombie_fail(lp->name); break;
        case ZOMBIE_RESCUE: rc = zombie_recover(lp->name); break;

        default: break;
      }

      lp = lp->next;
    }
  }
  else
    sms_._staticlist = (sms_list *)zombies;

  return rc;
}

void sms_passwd_zombie(sms_node *np)
/**************************************************************************
?  Add an entry to the zombie list when caused by SMS itself
|  Password is being hijacked (no need to delete it by the caller)
************************************o*************************************/
{
  int         why;
  sms_zombie *zp;
  char       *fullname;

  if(ZOMBIE_TIMEOUT <= 0) return;
  if(!np) return;

  if( np->type != NODE_TASK && np->type != NODE_ALIAS )
  {
    for( np=np->kids ; np ; np=np->next )
      sms_passwd_zombie(np);
    return;
  }

  if(!np->passwd) return;

  fullname = sms_node_full_name(np);

  if( sms_._current_con )
  {
    /* printf("zombie because %s",sms_._current_con->name); */
    if( sms_._current_con->name[0] == '/' )
    {
      /* printf(" ... it's a task\n"); */
      why = ZOMBIE_SMS;
    }
    else
    {
      /* printf(" ... it's a user\n"); */
      why = ZOMBIE_USER;
    }
  }
  else
  {
#if 0
    printf("zombie because SMS\n");  /* Shouldn't really be here */
#endif
    why = ZOMBIE_USER;
  }

  if( (zp=ls_find(&zombies,fullname)) )
  {
    ls_remove(&zombies,zp);
    NODE_FREE(zp,sms_zombie);
  }

  zp = create(why, fullname, np->passwd, "SMS", "SMS", np->tryno);

  ls_add(&zombies,zp);

  IFFREE(np->passwd);
}

void sms_passwd_process(time_t t)
/**************************************************************************
?  Process zombies (remove too old entries)
************************************o*************************************/
{
  sms_zombie *zp, *next;

  for( zp=zombies ; zp ; )
  {
    next = zp->next;
    if( zp->t < t )
    {
      ls_remove(&zombies,zp);      /* Ok we could keep the last, ... */
      NODE_FREE(zp,sms_zombie);
    }

    zp = next;
  }
}

int sms_passwd_is_zombie(sms_login *who, int  *fail)
/**************************************************************************
?  Check if the task-user's passwd is zombie
=  BOOLEAN status.
|  TRUE -> answer ok to the task!
************************************o*************************************/
{
  char        salt[3];
  sms_zombie *zp;

  char *taskname = who->name;
  char *passwd   = who->passwd;
  char *host     = sms_._machine;
  char *sender   = who->sender;
  int   tryno    = who->tryno;

  if( tryno == 0 ) tryno = 1;      /* An educated guess */

  if( ! (zp=ls_find(&zombies,taskname)) ) /* Network zombie */
  {
    zp = create(ZOMBIE_NET, taskname, passwd, host, sender, tryno );

    if(zp)
    {
      ls_add(&zombies,zp);

      spit(0,IOI_WAR,"zombie:created new network zombie %s from %s sender %s",
           STR(taskname), host?host:"unknown", sender?sender:"unknown");
    }
    return FALSE;
  }
    
  zp->count++;

  timeit(zp);

  *fail = zp->fail;

  if( zp->fail || zp->fob )
    return TRUE;

  if( zp->why==ZOMBIE_SMS && zp->count <=3 && who->lines &&
      sms_cmd_number(who->lines->name,0)== /*CMD_SMSCOMPLETE*/ 1 )
  {
    strncpy(salt,zp->passwd,2);      /* Get the salt */
    salt[2] = '\0';

    if( strcmp(crypt(passwd,salt),zp->passwd) == 0 )
      return TRUE;
  }

  return FALSE;
}

int sms_passwd_read(char *name)
/**************************************************************************
?  Read the password file.
|  We are using XDR to make sure it will come back on any machine.
!  It's a binary file!
=  BOOLEAN status.
************************************o*************************************/
{
  FILE              *fp;
  XDR                x;
  enum xdr_op        x_op = XDR_DECODE;
  int                rc   = FALSE;
  static sms_passwd *pp;

  if( !name )
    if( !(name=sms_variable_get("SMSPASSWD",NULL)) )
      return spit(FALSE,IOI_ERR,"SMS-PASSWD-READ:no name");
   
  if( ! (fp=fopen(name,"r")) )
    return spit(FALSE,IOI_ERR,"SMS-PASSWD-READ:File r-open error => %s",STR(name));

  xdrstdio_create(&x,fp,x_op);

  pp = NULL;

  NODE_FREE(sms_._passwd,sms_passwd);

  if(rc=sms_xdr_pointer(&x,(sms_list **)&pp))
  {
    sms_._passwd = pp;
    pp = 0;
  }
  else
    spit(0,IOI_ERR,"SMS-PASSWD-READ:read error in the file %s",STR(name));

  if( pp ) sms_node_free(pp);      /* Only in errors */

  xdr_destroy(&x);
  fclose(fp);

  return rc;
}

int sms_passwd_write(char *name)
/**************************************************************************
?  Write the node into the file named.
|  We are using XDR to make sure it will come back on any machine.
=  BOOLEAN status.
!  It's a binary file!
-NOTICE  Only used by the SMS.
************************************o*************************************/
{
  FILE        *fp;
  XDR          x;
  enum xdr_op  x_op = XDR_ENCODE;
  int          rc;

  if( !name )
    if( !(name=sms_variable_get("SMSPASSWD",NULL)) )
      return spit(FALSE,IOI_ERR,"SMS-PASSWD-WRITE:no name");
   
  if( ! (fp=sms_fopen(name,"w","SMS-PASSWD-WRITE")) ) return FALSE;

  xdrstdio_create(&x,fp,x_op);

  if(rc=sms_xdr_pointer(&x,(sms_list **)&sms_._passwd))
    spit(TRUE,IOI_DBG,"SMS-PASSWD-WRITE:Write complete into %s",STR(name));
  else
    spit(FALSE,IOI_ERR,"SMS-PASSWD-WRITE:Write failed for %s",STR(name));

  xdr_destroy(&x);
  fclose(fp);
  return rc;
}

char *sms_passwd_user(char *user)
/**************************************************************************
?  Return the user name without the number
=  User name in static area.
************************************o*************************************/
{
  static char name[MAXNAM];
  char       *s = name;

  if( !user )
   user = sms_._current_con->name;

  while( *user && *user != '@' )
    *s++ = *user++;
  *s = '\0';

  return name;
}

sms_passwd_ok(char *user, char *passwd)
/**************************************************************************
?  Check if the users passwd is ok
=  BOOLEAN status.
************************************o*************************************/
{
  sms_passwd *sp;
  char        name[MAXNAM];
  char       *s = name;

  if( !sms_._passwd )
    return TRUE;

  if( !(sp = ls_find(&sms_._passwd,sms_passwd_user(user) )) )
    return FALSE;

  if( sp->passwd[0] == '\0' ) return TRUE;
  if( sp->passwd[0] == '*'  ) return FALSE;

  strncpy(name,sp->passwd,2);      /* Get the salt */
  name[2] = '\0';

  return ! strcmp(crypt(passwd,name),sp->passwd);
}

int sms_passwd_task_ok(sms_login *who)
/**************************************************************************
?  Check if the task-users passwd is ok
=  BOOLEAN status.
************************************o*************************************/
{
  sms_node     *np;
  char          salt[3];
  sms_variable *pw;                /* If a variable is found */

  if( !(np=sms_node_find_full(who->name)) )
    if( TRUE )                     /* Cancelled nodes */
      return FALSE;

  if( (pw=ls_find(&np->variable,"SMSPASS")) != NULL )
    if( strcmp(who->passwd,pw->value) == 0 || strcmp("FREE",pw->value) == 0 )
      return TRUE;

  recover(who->name);

  if( !np->passwd )
    return FALSE;                  /* Never send! */

  strncpy(salt,np->passwd,2);      /* Get the salt */
  salt[2] = '\0';

  return ! strcmp(crypt(who->passwd,salt),np->passwd);
}

char *sms_passwd_crypt(char *passwd)
/**************************************************************************
?  Crypt the passwd.
=  Crypted password in static area.
************************************o*************************************/
{
  char   salt[3];
  int    i;

  for( i=0 ; i<2 ; i++ )
  {
    salt[i] = 64.0 * sms_drand48() + '.';
    if(salt[i] > '9') salt[i] += 7;
    if(salt[i] > 'Z') salt[i] += 6;
  }
  salt[2] = '\0';

  return crypt(passwd,salt);
}

sms_variable *sms_passwd_generate(sms_node *np)
/**************************************************************************
?  Generate the password for the tasks.
|  Used by the sms_edit_send
=  sms_variable * ( "SMSPASS","the-true-passwd" )
************************************o*************************************/
{
  sms_variable *vp = NULL;
  char          pw[9];
  int           i;

  for( i=0 ; i<8 ; i++ )           /* generate a random password */
  {
    pw[i]=64.0*sms_drand48()+'.';  /* Just crack this one! */
    if(pw[i] > '9') pw[i] += 7;
    if(pw[i] > 'Z') pw[i] += 6;
  }
  pw[8] = '\0';

  vp = sms_variable_create("SMSPASS",pw);

  sms_list_add(&np->variable,vp);  /* So the edit will find it! */

  IFFREE(np->passwd);              /* SMS only keeps the crypted one! */
  np->passwd=strdup(sms_passwd_crypt(pw));

  return vp;
}

int sms_passwd_legal(char *passwd)
/**************************************************************************
?  Check if the password candidate is legal.
=  BOOLEAN status.
************************************o*************************************/
{
  if( PRIVILEGE(PR_ADMIN) )
  {
    if( *passwd == '*'  ) return TRUE;
    if( *passwd == '\0' ) return TRUE;
  }

  return (strlen(passwd) >= 5);
}

int sms_passwd_add(
    char   *user,
    int     uid,
    int     gid,
    int     rights,
    char   *passwd,
    char   *comment)
/**************************************************************************
?  Add a user into the database
************************************o*************************************/
{
  sms_passwd *pw;

  if( !(pw=sms_alloc(NODE_PASSWD)) )
    return spit(FALSE,IOI_ERR,"SMS-PASSWD-ADD:No mem");

  pw->type    = NODE_PASSWD;
  pw->name    = strdup(user);
  pw->uid     = uid;
  pw->gid     = gid;
  pw->rights  = rights;

  if( passwd[0] == '*' ) pw->passwd =  strdup("*");
  else
  if( passwd[0] == ' ' ) pw->passwd =  strdup("");
  else
  pw->passwd  = strdup( passwd[0]=='-'?&passwd[1]:sms_passwd_crypt(passwd));

  pw->change  = sms_time_t(NULL);
  pw->comment = comment?strdup(comment):NULL;

  sms_list_add(&sms_._passwd,pw);

  if( sms_passwd_write(NULL) )
    return spit(TRUE,IOI_MSG,"passwd:changed for %s by %s,",STR(pw->name),STR(SMS_USER));

  return FALSE;
}

int sms_passwd_delete(char *user)
/**************************************************************************
?  Delete a user from the database.
=  SMS-ERROR-CODE
************************************o*************************************/
{
  sms_passwd *pw;

  if( pw = ls_find(&sms_._passwd,user) )
  {
    sms_list_delete(&sms_._passwd,pw);

    if( sms_passwd_write(NULL) ) return
       spit(SMS_E_OK,IOI_MSG,"passwd:user %s deleted by %s",STR(user),STR(SMS_USER));

    return SMS_E_WRITE;
  }

  return SMS_E_NOTFOUND;
}

int sms_passwd_list(int std)       /* If TRUE print on stdout */
/**************************************************************************
?  Print the passwd file
************************************o*************************************/
{
  sms_passwd *sp = sms_._passwd;
  int         i;
  int         rights;              /* Current rights / what is left    */
  int         first;               /* To print the comma between privs */
  char        str[MAXLEN];

  while( sp )
  {
    sprintf(str,"%s:%s:%d:%d:%s:%s:",
      STR(sp->name),STR(sp->passwd),sp->uid,sp->gid,STR(sp->comment),
      STR(sms_time_c(&sp->change))
    );

    first = TRUE;

    for( rights = sp->rights , i=0 ; rights ; i++,rights >>= 1 )
      if( rights & 0x1 )
      {
        if(!first) strcat(str,",");
        strcat(str,privilege_name[i]);
        first = FALSE;
      }

    if( first ) strcat(str,privilege_name[0]);

    strcat(str,":");
    if( std ) printf("%s\n",STR(str));
    else      sms_output("%s",STR(str));
    sp = sp->next;
  }

  return 0;
}

void sms_passwd_privileges(void)
/**************************************************************************
?  Print the privileges of the user.
************************************o*************************************/
{
  int rights = sms_._current_con->passok;
  int i;

  if( sms_._passwd )
  {
    sms_output("%d 0x%x",rights,rights);

    if( !rights )
      sms_output("none");
    else
      for( i=0 ; i<PRIV_MAX ; i++ )
        if( (1<<i) & rights )
          sms_output("%-9s user can %s",STR(privilege_name[i]),STR(privilege_do[i]));
  }
  else
  {
    sms_output("%d 0x%x", rights?PR_ALL:PR_NONE, rights?PR_ALL:PR_NONE);

    if( rights )
      sms_output("user can do anything.");
    else
      sms_output("user can only monitor.");
  }
}

int sms_passwd_list_read(char *name)
/**************************************************************************
?  Read listed users (black and white listd)
=  Boolean success
************************************o*************************************/
{
  FILE     *fp;
  sms_list *lp;
  char      buff[MAXLEN];
  char      user[MAXLEN];
  int       version = 0;
  int       newformat;

  if( !name )
    if( !(name=sms_variable_get("SMSLISTS",NULL)) )
      return spit(0,IOI_ERR,"SMS-PASSWD-LIST-READ:no name");

  if( ! (fp=sms_fopen(name,"r","SMS-PASSWD-READ-LIST")) )
    return 0;

  buff[MAXLEN-1] = '\0';           /* Make sure every line is terminated */

  NODE_FREE(sms_._whitelist,sms_list);
  NODE_FREE(sms_._blacklist,sms_list);

  while( fgets(buff,MAXLEN-1,fp) )
  {
    sms_no_newline(buff);

    if(buff[0] != '#')
    {
      if(!version)
      {
        int release, major, minor;

        if(sscanf(buff,"%d.%d.%d",&release,&major,&minor)==3)
        {
          version = VERSION_NUMBER(release,major,minor);
          if(version < 43017)
          {
            fclose(fp);
            return spit(0,IOI_ERR,"SMS-PASSWD-LIST-READ:wrong version %d",version);
          }
          newformat = (version >= 43020);
        }
      }
      else
        if(sscanf(buff,"%s",user) == 1)
          if(user[0] != '-')
            ls_add(&sms_._whitelist,ls_create(0,user));
          else
            if(user[1])
              ls_add(&sms_._blacklist,ls_create(0,user+1));
    }
  }

  fclose(fp);

  if(newformat)
  if(!sms_._whitelist && sms_._blacklist)
  {
    spit(0,IOI_ERR,"SMS-PASSWD-LIST-READ:Only blacklisted users, refusing");
    spit(0,IOI_ERR,"SMS-PASSWD-LIST-READ:Running in an open mode");
    ls_delall(&sms_._blacklist);
  }

  if(!version)
    return spit(0,IOI_ERR,"SMS-PASSWD-LIST-READ:no version number");

  return 1;
}

int sms_passwd_list_write(char *name)
/**************************************************************************
?  Print the privileges of the user.
=  Boolean success
************************************o*************************************/
{
  FILE     *fp;
  sms_list *lp;

  if( !name )
    if( !(name=sms_variable_get("SMSLISTS",NULL)) )
      return spit(0,IOI_ERR,"SMS-PASSWD-LIST-WRITE:no name");

  if( ! (fp=sms_fopen(name,"w","SMS-PASSWD-LIST-WRITE")) )
    return 0;

  fprintf(fp,"%d.%d.%d\n",SMS_VERSION,SMS_REVISION,SMS_MODIFICATION);

  for( lp=sms_._whitelist ; lp ; lp=lp->next )
    fprintf(fp,"%s\n", STR(lp->name));
  
  for( lp=sms_._blacklist ; lp ; lp=lp->next )
    fprintf(fp,"-%s\n", STR(lp->name));
  
  fclose(fp);

  return 1;
}

int sms_webaccess_read(char *name)
/**************************************************************************
?  Read webaccess settings
=  Boolean success
************************************o*************************************/
{
  FILE     *fp;
  sms_list *lp;
  char      buff[MAXLEN];
  char      host[MAXLEN];
  int       version = 0;
  int       newformat;

  if( !name )
    if( !(name=sms_variable_get("SMSWEBACCESS",NULL)) )
      return spit(0,IOI_ERR,"SMS-WEBACCESS-READ:no name");

  if( ! (fp=sms_fopen(name,"r","SMS-WEBACCESS-LIST")) )
    return 0;

  buff[MAXLEN-1] = '\0';           /* Make sure every line is terminated */

  NODE_FREE(sms_._web_hosts,sms_list);

  while( fgets(buff,MAXLEN-1,fp) )
  {
    sms_no_newline(buff);

    if(buff[0] != '#')
    {
      if(!sms_._web_uid)
      {
		   sscanf(buff,"%d %d",&sms_._web_uid,&sms_._web_gid);
		   spit(0,IOI_MSG,"webaccess: uid/gid %d/%d",
			sms_._web_uid,sms_._web_gid);
      }
	  else if(!sms_._web_certif_port)
	  {
		sscanf(buff,"%s %d",host,&sms_._web_certif_port);
		IFFREE(sms_._web_certif_host);
		sms_._web_certif_host = strdup(host);
		   spit(0,IOI_MSG,"webaccess: certicate server %s:%d",
			sms_._web_certif_host,sms_._web_certif_port);
	  }
      else
        if(sscanf(buff,"%s",host) == 1)
		{
            ls_add(&sms_._web_hosts,ls_create(0,host));
			spit(0,IOI_MSG,"webaccess: host %s",host);
		}
    }
  }

  fclose(fp);

  sms_._web_callable = (sms_._web_uid != 0) && (sms_._web_gid != 0);

  return 1;
}

int sms_check_webaccess(char *who,char *password)
{
	struct sockaddr_in s_in;
	struct hostent     *him;
	int s;
	int status;
	int tries = 0;
	int flg;

#ifdef __alpha
	unsigned int  addr;
    unsigned int  none = (unsigned int)~0;
#elif defined(fujitsu)
	u_int addr;
    u_int none = (u_int)~0;
#elif defined(__64BIT__)
	unsigned long addr;
	uint32_t none = (uint32_t)-1;
#else
	unsigned long addr;
    unsigned long none = (unsigned long)-1;
#endif

	bzero(&s_in,sizeof(s_in));

	s_in.sin_port        = htons(sms_._web_certif_port);
	s_in.sin_family      = AF_INET;
	addr                 = inet_addr(sms_._web_certif_host);
	s_in.sin_addr.s_addr = addr;

	if(addr == none) 
	{
		if ((him = gethostbyname(sms_._web_certif_host)) == 0)
		{
			spit(0,IOI_ERR,"unknown host : %s",sms_._web_certif_host);
			return 0;
		}
	}

	s_in.sin_family = him->h_addrtype;
	bcopy(him->h_addr_list[0],&s_in.sin_addr,him->h_length);

	s = socket(AF_INET, SOCK_STREAM, 0);
	if (s < 0)
	{
		spit(0,IOI_ERR,"cannot create socket %s",strerror(errno));
		return 0;
	}

	if(connect(s,(struct sockaddr*)&s_in,sizeof(s_in)) < 0)
	{
		spit(0,IOI_ERR,"cannot connect socket %s",strerror(errno));
		return 0;
	}


	close(s);


	return 1;
}
