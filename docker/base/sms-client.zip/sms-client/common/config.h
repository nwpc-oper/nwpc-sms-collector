/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMSLIB-CONFIGURATION
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-JUL-1992 / 06-DEC-1991 / OP
.VERSION  4.0
.FILE     config.h
*
.DATE     23-APR-1993 / 23-APR-1993 / OP
.VERSION  4.2
.DATE     16-JAN-1996 / 18-FEB-1994 / OP
.VERSION  4.3.0-13
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Autorestore added
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.17
*         Password white and black lists added
.DATE     20-APR-1998 / 21-APR-1998 / OP
.VERSION  4.3.18
*         YP-caching
.DATE     06-MAY-1998 / 15-JUN-1998 / OP
.VERSION  4.3.19
*         Checkpoint file has a stamp in the end of the file also
*         Server timeout
.DATE     18-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
.LANGUAGE ANSI-C
.DATE     13-OCT-1998 / 17-AUG-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Cleaning up of old versions
*         Zombie passwords
.DATE     22-MAR-1999 / 22-MAR--1999 / OP
.VERSION  4.4.2
*         SMSMICRO an edit variable now
*
*  NOTICE  This file is included smslib.h AND sms.x!
*          That means there can only be definitions here, NO varaibles or
*          typedefs
************************************o*************************************/

#ifndef SMS_CONFIG_H
#define SMS_CONFIG_H

#define VERSION4_4

/**************************************************************************
*  To configurate the SMS system mark the following symbols to be either
*  defined or undefined.
************************************o*************************************/

  /************************************************************************
  *  Gather information of the RPC-activity and logins and failures
  *  Can be requested by the "sms -s" command.
  ************************************************************************/

#define SMS_STATISTICS

  /************************************************************************
  *  Gather timing information of user/task execution in ticks.
  *  The tick is OS dependent, normally the HZ but eg in CRAY 1/10^6 sec
  *  Can only be used if the SMS_STATISTICS is active
  ************************************************************************/

#define SMS_TIMER

  /************************************************************************
  *  In secure mode the remote and local user must match completely.
  *  Passwords must be used
  ************************************************************************/

#undef  SMS_IN_SECURE_MODE

  /************************************************************************
  *  Impossible is never possible to happen. Must be undef
  ************************************************************************/

#undef  IMPOSSIBLE

  /************************************************************************
  *  Constantly crypt the password-handle on both ends
  *  The timeout causes the client to logout
  *  CNA
  ************************************************************************/

#undef  SMS_PW_CRYPTING

  /************************************************************************
  *  Crypt all the traffic
  *  Currently not applicable (in external SMS installations)
  ************************************************************************/

#undef  SMS_CRYPTING

  /************************************************************************
  *  Allow cross-suite dependencies
  *  Allow the command external
  *  Allow the option -f in cancel (brute Force)
  *  Allow the option -r in play (replace (internally cancel -f))
  ************************************************************************/

#define SMS_CROSS_SUITE

  /************************************************************************
  *  Allow only a dedicated user to be the first one to login to the SMS
  *  after the start-up. The user must also logout before anybody else is
  *  allowed to login.
  *  CNA
  ************************************************************************/

#undef  SMS_STARTUP_USER

  /************************************************************************
  *  Limit the commands awailabe for the SMS-variable SMSCMD to the ones 
  *  listed in configuration file.
  *  CNA
  ************************************************************************/

#undef  SMS_CMD_LIMIT

  /************************************************************************
  *  A list of hosts tried if no one responded to the broadcast request.
  *  CNA
  ************************************************************************/

#undef  SMS_BROADCAST_LIST

  /************************************************************************
  *  Strip the password from the status repors to the normal users
  ************************************************************************/

#define SMS_STRIP_PASSWD

  /************************************************************************
  *  Guess wot?
  ************************************************************************/

#undef SMS_DEBUG_XDR

  /************************************************************************
  *  If defined remove the automount directory prefix
  *  Needed 4 the qsub (RQS) and XCdp to locate the scripts & jobs
  *  Must be defined to be a string to be removed from the path names
  ************************************************************************/

#define SMS_AUTOMOUNT "/tmp_mnt"

  /************************************************************************
  *  If defined, this controls the number of second SMS waits in "select"
  *  system call. Reasonable values is 2-10 (seconds)
  *  SMS checks the time dependencies every minute + SMS_CYCLE_TIME seconds
  *  Increasing this over 30 seconds is not practical
  *  0 is used to achieve the old (rapid) behaviour
  *  Negative value will give you headacke
  ************************************************************************/

#define SMS_CYCLE_TIME 5

  /************************************************************************
  *  Defines the timeout in seconds for any connection
  *  0 (zero) means that there is no timeouts
  ************************************************************************/

#define SMS_TIMEOUT 24*3600

  /************************************************************************
  *  Defines the interval to check autocancel
  *  0 (zero) means that there is no timeouts
  *  CNA
  ************************************************************************/

#define SMSAUTOCANCEL 3600

  /************************************************************************
  *  Allow SMS to queue the system commands executed
  *  At the moment there is no limit on the number of child-processes
  *  This allowes commands like "qsub %SMSJOB%" to be executed without
  *  the need to wait for them
  ************************************************************************/

#define SMS_MULTI_PROCESS

#if defined(VMS) || defined(FUJITSU)
#  undef SMS_MULTI_PROCESS
#endif

  /************************************************************************
  *  Use the setenv at submission time
  *  If used you pay a small space penalty (look at "BUG" in setenv.c)
  ************************************************************************/

#undef SMS_SETENV

  /************************************************************************
  *  Allowes to kill the whole family/suite
  *  This is up to the installation
  ************************************************************************/

#define SMS_RECURSIVE_KILL

  /************************************************************************
  *  Use own memory allocator
  *  Turning this on will slow things down, but not radically
  *  But you will not loose any memory (except through fragmentation)
  ************************************************************************/

#undef SMS_MALLOC

  /************************************************************************
  *  Use own memory allocator (can not be on if SMS_MALLOC is not on)
  *  Enables you to check the mallocs performance
  *  This will definetely slow you down (see more in malloc.c)
  ************************************************************************/

#if defined(SMS_MALLOC)
#undef SMS_MALLOC_CHECK
#endif

  /************************************************************************
  *  Size of the TCP buffers
  *  0 (zero) will use normal values (4000 bytes or so)
  *  512*1024 seemed to work ok on SGI
  ************************************************************************/

#define SMS_TCPSIZE 64000

  /************************************************************************
  *  Size of the buffers for checkpoint writing
  *  0 (zero) use default (pagesize)
  ************************************************************************/

#define SMS_CHECKBUFFER 1024*512

  /************************************************************************
  *  Yellow page usage
  *  Cache them?
  ************************************************************************/

#define CACHE_YP

#if defined(CACHE_YP)
#  define SMS_GETPWUID sms_getpwuid
#  define SMS_ENDPWENT sms_endpwent
#else
#  define SMS_GETPWUID getpwuid
#  define SMS_ENDPWENT endpwent
#endif

  /************************************************************************
  *  Server timeout processing
  *  Select max one (alarm or jump) but not both (none is ok)
  ************************************************************************/

#undef SMS_USE_ALARM
#define SMS_USE_JUMP

  /************************************************************************
  *  Server timeout
  *  0 means server never times out (may block forever)
  ************************************************************************/

#define SMS_SERVER_TIMEOUT 120

#if !defined(SMS_USE_ALARM) && !defined(SMS_USE_JUMP)
#  undef SMS_SERVER_TIMEOUT
#  define SMS_SERVER_TIMEOUT 0
#endif

  /************************************************************************
  *  Keep zombie passwords in case task tries to communicate after
  *  complete/abort or user re-running/requeueing the task
  *  0 == do not keep zombies
  ************************************************************************/

#define ZOMBIE_TIMEOUT 3600

  /************************************************************************
  *  Check point configuration:
  *
  *  Mode must be one of: CHECK_NONE CHECK_NEVER CHECK_ON_TIME CHECK_ALWAYS   
  *  The checkpoint filenames can be gonfigured using environment variables
  ************************************************************************/

#define SMSCHECK          "sms.check"
#define SMSCHECKOLD       "sms.check.b"
#define SMSCHECKINTERVAL  120      /* Used in time based checkpointing */

#define SMSAUTORECOVER

#define SMSCHECKMODE      CHECK_ON_TIME

#ifndef SMSCHECKMODE
#define SMSCHECKMODE      CHECK_NONE
#endif

/**************************************************************************
*                 CONFIGURATE THE DEFAULTS FOR THE SMS
************************************o*************************************/

#if defined(ultrix) || defined(__sgi) || defined(__mips) || defined(FUJITSU)
#  define _clnt_broadcast clnt_broadcast
#endif

#define SMSSOCKET        3141

#define SMSPASS        "super-idiot"
#define SMSPASSWD      "sms.passwd"
#define SMSLISTS       "sms.lists"
#define SMSWEBACCESS   "sms.webaccess"
#define SMSLOG         "sms.log"
#define SMSNODE         sms_._host
#define SMSSERVERS     "/usr/local/lib/xcdp/servers"

#define SMSINTERVAL        60      /* Seconds to check the time     */
#define SMSHISTORYLEN     100      /* Lenght of the log file in mem */
#define SMSNODEHISTORY    100      /* Lenght of the node log in mem */
#define SMSDEFTRIES         2      /* If job aborts                 */
#define SMSMAXHOSTLINES   100      /* In the servers file           */

#define SMSMKDIRPROT     0775      /* rwxrwxr-x                     */

#define SMSMICRO(np)   (*sms_variable_get("SMSMICRO",np))
#define SMSMICRODEF      "%"

#if defined(unix) || defined(__unix)
#  define SMSCMD         "%SMSJOB% 1> %SMSJOBOUT% 2>&1 &"
#  define SMSHOME        "."
#else /* VAX/VMS */
#  define SMSCMD         "submit %SMSJOB%/LOG=job.log"
#  define SMSHOME "SYS$SCRATCH"
#endif

#endif /* SMS_CONFIG_H */

#ifdef IMPOSSIBLE                  /* Just examples */
#  define SMSCMD         "/bin/sh %SMSJOB% 1>/dev/null 2>&1 &"
#  define SMSCMD         "qsub < %SMSJOB% 1>/dev/null 2>&1 &"
#  define SMSCMD         "qsub -x %SMSJOB% &"
#endif
