/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CLIENT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     20-AUG-1992 / 12-AUG-1991 / OP
.VERSION  4.0
.DATE     22-JUL-1993 / 23-APR-1993 / OP
.VERSION  4.2
.DATE     22-JUL-1993 / 23-APR-1993 / OP
*         Fixed clnt_sperror bug which caused VAX to bang (null pointer)
.DATE     07-MAR-1994 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     05-APR-1995 / 01-SEP-1994 / OP
.VERSION  4.3.2-5
*         Added fast login for the tasks
.DATE     06-OCT-1995 / 06-OCT-1995 / OP
.VERSION  4.3.12
*         Mod to make sure XCDP and CDP agree of the structure
.DATE     24-FEB-1998 / 17-FEB-1998 / OP
.VERSION  4.3.16
*         mod for solaris broadcast
.DATE     24-FEB-1998 / 17-FEB-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     20-APR-1998 / 20-APR-1998 / OP
.VERSION  4.3.18
*         TCP buffer size
.DATE     10-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.FILE     client.c
.DATE     25-DEC-1998 / 17-AUG-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Login with nick names
*         Net names for nodes
.DATE     22-APR-1999 / 22-APR-1999 / OP
.VERSION  4.4.2
*         Stop broadcast from XCdp
*         Fixed clnt_sperror bug which caused SUN/HP to bang (null pointer)
*         (Had creeped in again ;-)
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  This file hides the RPC from the SMS-CLIENTs.
*
*  login creates the client-handles
*  logout deletes the client-handles
*
*  any client call may disconnect (invalidate) the client handle but
*  they do not remove the handle (they may alter it)
*
*  terminate deletes the client part of the handles
*
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

#include <sys/socket.h>

#if defined(mips) || defined(__uxppx__) || defined(AIX)
#include <netinet/in.h>
#endif

#if defined(AIX)
#include <arpa/inet.h>
#endif


#if defined(__uxppx__)
#  include <rpc/clnt_soc.h>
#endif
                                   /* FOR THE BROADCAST STUFF          */
static sms_list   **servers;       /* Names of the servers responding  */
static int          s_wanted;      /* Number of servers asked          */
static int          s_verbose;     /* Print the internet address?      */

static void        *callbackdata;
static int        (*callback)(void *, char *);

static sms_list   **copy_out;      /* PATH flag for sms_client_copy    */

#define IS_OK(hp,name) if( !hp || !hp->handle ) return \
  ioi_out(SMS_E_NOTIN,IOI_WAR,"SMS-CLIENT:Not logged on (%s).",STR(name));

static void (* old_int)();         /* The status of the signals before */
static void (* old_quit)();        /* entering into this RPC calls     */
static void (* old_stop)();        /* Restored before leaving.         */
static void (* old_cont)();

static int   catch_sig;

static void catch(int sig)
/**************************************************************************
?  Ignore (or postpone) some of the signals while executing client calls
|  Remember the last signal (if any) to be delivered after the signals
|  has been restored.
************************************o*************************************/
{
  catch_sig = sig;

  signal(sig,catch);
}

static void load_signals(void)
/**************************************************************************
?  Load the signal that should be ignored during the RPC-calls.
************************************o*************************************/
{
  catch_sig = 0;

  old_int  = signal(SIGINT ,catch);
  old_quit = signal(SIGQUIT,catch);
 
#ifdef SIGCONT
  old_stop = signal(SIGTSTP,catch);
  old_cont = signal(SIGCONT,catch);
#endif
}

static void restore_signals(void)
/**************************************************************************
?  Restore the signals alfter the RPC-call has been executed.
|  And (possible) deliver the last stored signal to the process.
************************************o*************************************/
{
  signal(SIGINT ,old_int);
  signal(SIGQUIT,old_quit);
 
#ifdef SIGCONT
  signal(SIGTSTP,old_stop);
  signal(SIGCONT,old_cont);
#endif

  if(catch_sig)                    /* Deliver the (last) signal recorded */
    kill(getpid(),catch_sig);
}

void sms_client_swap(sms_handle *hp, char *name)
/**************************************************************************
?  Swap the handle for CDP (XCdp has it's own swapping routine)
|  If something left after play (playbin etc) free it.
|  If old has been updated copy it back handle.
|  If handle is given, make that the "current" SMS
|  else if name is given, find that and if found make that the "current" SMS
|  else update the "current" SMS 
************************************o*************************************/
{
  sms_handle *old = sms_._logins;
  int n;

  if(sms_._super && sms_._super->type != NODE_SUPER)
    NODE_FREE(sms_._super,sms_node);

  if(old)
  {
    old->super         = sms_._super;
    old->action_number = sms_._action_number;
    old->modify_number = sms_._modify_number;

    sms_._super = 0;
    sms_._action_number = sms_._modify_number = 0;
  }

  old = 0;

  if(name)
  {
    hp=ls_find(&sms_._logins,name);
    if( !hp ) return;
  }

  if(hp)
  {
    n=ls_index_key(&sms_._logins, hp);
    if(n==NIL) return;

    ls_roll(&sms_._logins,n);

    old = sms_._logins;

    sms_._super = old->super;
    sms_._action_number = old->action_number;
    sms_._modify_number = old->modify_number;
    sms_._xdr_version   = old->rev*1000+old->mod;

    if(sms_._super)
      sms_._super->parent = 0;

    old->super = 0;

    ioi_variable_set("host",hp->name);
    ioi_variable_set("cwn","/");

    return;
  }
}

int sms_client_init(int *argc, char **argv)
/**************************************************************************
?  4 the XCdp
************************************o*************************************/
{
  if( !ioi_._work )
  {
    ioi_open(*argc,argv,"CDPRC");
    ioi_try_name("IOIRC");
  }

  return 0;
}

int sms_client_is_ok(sms_handle *hp)
/**************************************************************************
?  Status is the client side in order.
=  SMS-ERROR-CODE
|  SMS_E_OK (0) if we are "connected" to the SMS and we still hold a valid
|  handle number. SMS_E_NOTIN otherwise.
************************************o*************************************/
{
  if( !hp || !hp->handle || !hp->client )
    return SMS_E_NOTIN;

  /* Update the globals */

  /*
  sms_._action_number = hp->action_number;
  sms_._modify_number = hp->modify_number;
  sms_._xdr_version   = hp->rev*1000+hp->mod;
  */

  return SMS_E_OK;
}

void sms_client_copy(sms_list **lp)
/**************************************************************************
?  Make sure the sms_client_command copy the output for the XCDP.
************************************o*************************************/
{
  copy_out = lp;

  if(lp)
    NODE_FREE(*lp,sms_list);
}

static void copy(sms_list *lp)
/**************************************************************************
?  Copy the list for the XCDP.
************************************o*************************************/
{
  if( copy_out )
    while(lp)
    {
      sms_list_add(copy_out,sms_node_create(lp->name));
      lp = lp->next;
    }
}

int sms_client_error(char *host, CLIENT *client)
/**************************************************************************
?  Get the RPC-client error and store it.
=  BOOLEAN status was it really an error.
|  TRUE   serious trouble.
|  FALSE  ok, just timed out.
************************************o*************************************/
{
  struct rpc_err err;

  CLNT_GETERR(client,&err);

  sms_._client_msg=clnt_sperror(client,host?host:"unknown");
  printf("%s\n",STR(sms_._client_msg));

  sms_._client_error = err.re_status;

  if( err.re_status == RPC_SUCCESS || err.re_status == RPC_TIMEDOUT )
    return FALSE;

  return TRUE;
}

int sms_client_terminate(sms_handle *hp, int rc)
/**************************************************************************
?  Make sure that next call is handshake or broadcast.
|  Destroy the contents of the handle but not the handle
|  Destroy the kids and the client
|  Only valid fields after the call are the name and next
|  (and possible the user_data)
-NOTICE For internal use in client.c only.
=  rc
************************************o*************************************/
{
  ioi_variable_set("host","");

  if( sms_client_is_ok(hp)==SMS_E_OK )
  {
    auth_destroy( hp->client->cl_auth );
    clnt_destroy( hp->client );
  }

  if( ! sms_._is_xcdp )
    NODE_FREE(hp->super, sms_node);

  hp->client = NULL;
  hp->handle = 0;
  hp->action_number = hp->modify_number = 0;

  sms_._action_number = 0;         /* Make sure NEWS works! */

  ioi_variable_set("cwn","/");

  return rc;
}

int sms_client_remove(sms_handle *hp, int rc)
/**************************************************************************
?  Terminate a client connection and remove the handle from the (X)CDP
|  Handle can not be used after this call
-NOTICE For internal use in client.c only.
=  rc
************************************o*************************************/
{
  ls_remove(&sms_._logins,hp);

  sms_._action_number = 0;         /* Make sure NEWS works! */
  sms_._modify_number = 0;
  sms_._node = 0;

  sms_client_terminate(hp,rc);
  IFFREE(hp->name);
  free(hp);
  return rc;
}

AUTH *sms_client_auth_unix(int handle)
/**************************************************************************
?  Create a unix style authentication and use the groups fields to hold
|  the SMS given handle.
************************************o*************************************/
{
  char machname[MAX_MACHINE_NAME + 1];

  if (gethostname(machname, MAX_MACHINE_NAME) == -1)
  {
    ioi_out(0,IOI_WAR,"SMS-CLIENT-AUTH-UNIX:gethostname failed");
    strcpy(machname,"unknown");
  }
  machname[MAX_MACHINE_NAME] = 0;

  if( handle )
#if defined(_SYSTYPE_SVR4) || defined(__uxppx__) || defined(AIX)
    return (authunix_create(machname,geteuid(),getegid(),1,(gid_t *)&handle));
#else
    return (authunix_create(machname,geteuid(),getegid(),1,&handle));
#endif
  else
    return (authunix_create(machname,geteuid(),getegid(),0,NULL));
}

int sms_client_ping(char *host, int quiet, int number)
/**************************************************************************
?  Check if the SMS is alive in the host given.
************************************o*************************************/
{
  enum clnt_stat ans;

  int         prognum;             /* SMS program number                 */
  char       *netname;             /* Network name (can be same as host) */

  if( ! host || ! *host )
    return FALSE;

  prognum = sms_._prog;
  netname = host;

  if( ! sms_._is_server )
  {
    sms_nick_servers(0);
    prognum = sms_nick_number(host);
    netname = sms_nick_name(host);
  }

  prognum = number? number : prognum;

  if(ans=callrpc(netname,prognum,sms_._vers,NULLPROC,xdr_void,0,xdr_void,0))
  {
    if( ! quiet )
    {
      clnt_perrno(ans);
      printf("\n");
    }
    return FALSE;
  }

  return TRUE;
}

static void auto_logout(char *host)
/**************************************************************************
?  Logout the user if login is done on the same node again.
************************************o*************************************/
{
  sms_handle *hp;

  if( (hp=ls_find(&sms_._logins,host)) )
  {
    ioi_out(0,IOI_WAR,"SMS-CLIENT-LOGIN:Was already logged in %s",STR(host));
    ioi_out(0,IOI_WAR,"SMS-CLIENT-LOGIN:logging out");

    sms_client_logout(hp);
  }
}

sms_handle *sms_client_login(
    char      *host,               /* Host name or number is ascii */
    char      *user,               /* User name NOT a number       */
    char      *passwd,             /* The real password, or NULL    */
    int        t_out,              /* In second, 0==def (25 sec)     */
    int        port,               /* If known, zero->call portmapper */
    sms_list **lp,                 /* Only 4 the task 2 speed thing up */
    int       *code)               /* Return code for task              */
/**************************************************************************
?  Login to the SMS.
|  Host name must be a valid name where the SMS is currently running.
|  If the user is NULL or empty the current user (process owner) is used.
|  If the passwd is NULL or empty a monitoring connection is attempted.
|  If the t_out is 0 the normal timeout is used (25 sec).
|  If a "lp" is a valid list, an express login is executed
|  (login, the command in "lp" and logout all are executed simultaenously)
=  SMS-ERROR-CODE (+diagnostic.)
***
***-NOTICE  CONTROL-D action during input may cause the routine to reopen
***|  the stdin. ( move this to passwd )
***
************************************o*************************************/
{
  extern char *cuserid();

  CLIENT     *client;
  sms_handle *rc = 0;
  int         prognum;             /* SMS program number                 */
  char       *netname;             /* Network name (can be same as host) */

  struct timeval timeout;
  sms_login      slogin;

  static struct sockaddr_in  addr;
  struct hostent            *hp;
  int sock = RPC_ANYSOCK;          /* We don't care to remember it */

  if(!host)
  {
    ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:Host not supplied.");
    if(code) *code = SMS_E_HOST;
    return 0;
  }

  auto_logout(host);

  sms_nick_servers(0);
  prognum = sms_nick_number(host);
  netname = sms_nick_name(host);

  if( (hp=gethostbyname(netname)) )
  {
    bcopy(hp->h_addr,&addr.sin_addr,hp->h_length);
    addr.sin_port   = htons(port);
    addr.sin_family = AF_INET;

#if defined(SMS_TCPSIZE)
    client = clnttcp_create(&addr,prognum,sms_._vers,&sock,
                            SMS_TCPSIZE,SMS_TCPSIZE);
#else
    client = clnttcp_create(&addr,prognum,sms_._vers,&sock,0,0);
#endif
  }
  else
  {
    ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:host %s unknown",STR(host));
    if(code) *code = SMS_E_RPC;
    return 0;
  }

  if( !client )
    client = clnt_create(host,prognum,sms_._vers,"tcp");

  if( ! client )
  {
    sms_._client_error = rpc_createerr.cf_stat;
    sms_._client_msg=clnt_spcreateerror(host);
    ioi_out(0,IOI_ERR,"RPC:%s",STR(sms_._client_msg));
    ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:Client creation failed for host %s.",STR(host));
    if(code) *code = SMS_E_RPC;
    return 0;
  }

  timeout.tv_usec = 0;
  timeout.tv_sec  = t_out;
  if( t_out > 0 ) clnt_control(client,CLSET_TIMEOUT,(char *)&timeout);

  slogin.type = NODE_LOGIN;

  if( !user || !*user )
    user = cuserid(NULL);

  slogin.name = strdup( user );
  slogin.passwd = (passwd && *passwd)? strdup(passwd) : NULL;
  slogin.uid = getuid();
  slogin.gid = getgid();
  slogin.sender = 0;

  slogin.vers = SMS_VERSION;
  slogin.rev  = SMS_REVISION;
  slogin.mod  = SMS_MODIFICATION;

  slogin.lines = lp? *lp : NULL;

  if(lp)
  {
    slogin.sender = strdup(getenv("SMSNODE"));
    slogin.tryno  = getenv("SMSTRYNO")? atoi(getenv("SMSTRYNO")) : 0;
    slogin.lines = *lp;
  }
  else
    slogin.lines = NULL;

  client->cl_auth = sms_client_auth_unix(0);

  rc = sms_login_1(&slogin,client);

  IFFREE(slogin.name);
  IFFREE(slogin.passwd);
  IFFREE(slogin.sender);

  if( ! rc )
  {
    sms_client_error(host,client);
    auth_destroy(client->cl_auth);
    clnt_destroy(client);
    ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:Login failed (RPC)");
    if(code) *code = SMS_E_RPC;
    return 0;
  }

  if( rc->handle )
  {
    if( lp )                       /* Express login for a task */
    {
      sms_list *l = rc->lines;

      while( l )
      {
        if( rc->code == SMS_E_OK )
          printf("SMS-> %s\n",STR(l->name));
        else if( rc->code == SMS_E_QUERY )
          printf("%s\n",STR(l->name));
        else
          fprintf(stderr,"SMS-> %s\n",STR(l->name));
        l = l->next;
      }

      if(SMS_VERSION*10000 + rc->rev*1000 + rc->mod < 43002)
      {
        ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:express login not available");
        ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:you probably have a mix-up");

        auth_destroy( client->cl_auth );
        client->cl_auth = sms_client_auth_unix(rc->handle);
        sms_client_logout(rc);
        if(code) *code = SMS_E_VERSION;
        return 0;
      }

      rc->client = client;         /* For terminate */
      sms_client_terminate(rc, SMS_E_OK);

      if(code) *code = rc->code;
      return 0;
    }
    else
    {
      sms_handle *handle;

      auth_destroy( client->cl_auth );
      client->cl_auth = sms_client_auth_unix(rc->handle);

      ioi_out(0,IOI_MSG,"SMS-CLIENT-LOGIN:%s logged into %s%s [%d]",
              STR(user),STR(host),(passwd && *passwd)?" with password":"" ,
              rc->handle);

      if( (passwd && *passwd) && rc->rights == 0 )
        ioi_out(0,IOI_MSG,"SMS-CLIENT-LOGIN:%s in %s is restricted user",
              STR(user),STR(host));

      handle = sms_alloc(NODE_HANDLE);
      memcpy(handle,rc,sizeof(sms_handle));

      handle->name = strdup(host);
      handle->client = client;

      ioi_variable_set("host",host);

      if(code) *code = SMS_E_OK;
      ls_add(&sms_._logins,handle);
      return handle;
    }
  }

  auth_destroy( client->cl_auth );
  clnt_destroy(client);

  ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGIN:Permission denied.");
  if(code) *code = SMS_E_PERMISSION;
  return 0;
}

int sms_client_logout(sms_handle *hp)
/**************************************************************************
?  Logout the client from the SMS. Permanently remove the SMS-client link.
|  After this the user can only call the sms_client_login to get the handle
|  or sms_client_servers to find out where the servers, if any, are running.
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int *rc;

  if(!hp)
    return ioi_out(SMS_E_NOTIN,IOI_WAR,"SMS-CLIENT-LOGOUT:Not logged on.");

  if(hp->client)
  {
    if( ! (rc=sms_logout_1(NULL,hp->client)) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-LOGOUT:Logout failed (RPC)");

      if(sms_client_error(hp->name,hp->client))
        return sms_client_terminate(hp,SMS_E_RPC);

      return SMS_E_TIMEOUT;
    }
    else
      ioi_out(0,IOI_MSG,"SMS-CLIENT-LOGOUT:logout from %s",STR(hp->name));
  }
  else
    ioi_out(0,IOI_WAR,"SMS-CLIENT-LOGOUT:removing broken handle (%s)",STR(hp->name));

  sms_client_terminate(hp,0);
  sms_client_remove(hp,SMS_E_OK);

  return SMS_E_OK;
}

int sms_client_news(sms_handle *hp, int last)
/**************************************************************************
?  Has there been any changes since we last heard about SMS?
=  SMS-ERROR-CODE (handle is not valid anymore)
|  SMS_E_OK there is news. (==FALSE)
|  SMS_E_NONEWS indicates that there is no news but the SMS is alive.
************************************o*************************************/
{
  int *rc;

  IS_OK(hp,"SMS-CLIENT-NEWS");

  sms_._xdr_version   = hp->rev*1000+hp->mod;
  if( ! (rc = sms_news_1( &last,hp->client )) )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-NEWS:No news today!. (RPC)");

      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  return *rc;
}

int sms_client_status(sms_handle *hp, sms_status **st, int all)
/**************************************************************************
?  Receive the status information from the SMS.
|  all:
|    0           just the header
|  positive      == action_number: get the NID's
|  negative      == get the whole lot
=  SMS-ERROR-CODE
************************************o*************************************/
{
  sms_status *rc;

  IS_OK(hp,"SMS-CLIENT-STATUS");

  if( all <= 0 )                   /* Make sure XCDP and CDP agree */
  {
    hp->modify_number = 0;
    hp->action_number = 0;
  }

  if( st )                         /* Let's delete the old stuff   */
    if( rc = *st )                 /* Let's take a copy 4 the free */
      NODE_FREE(rc->node,sms_node);

  if( !st )
    NODE_FREE( hp->super,sms_node );
 
  load_signals();
  sms_._xdr_version   = hp->rev*1000+hp->mod;
  rc = sms_status_1( &all,hp->client );
  restore_signals();

  if( ! rc )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-STATUS:No status. (RPC)");

      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  if(rc->node)
    if(rc->node->type != NODE_NID)
    {
      sms_node *np = rc->node;

      if(np) np->parent = 0;
      sms_node_after_receive(np);

#if 0
      if(np->type == NODE_SUPER)
      {
        IFFREE(np->name);
        np->name = strdup(hp->name);
      }
#endif

      sms_nid_count(hp,np,rc->action_n);
    }
    else
      sms_nid_version(hp);

  if( st )
    if( ! *st )
      if( ! (*st = sms_alloc(NODE_STATUS)) )
      {
        sms_node_free(rc->node);
        return ioi_out(SMS_E_MEMORY,IOI_ERR,"SMS-CLIENT-STATUS:No mem.");
      }

  /* ^^^ FIX the mem error ^^^ */

  if( st && *st )                  /* Did we save rc in to the users area */
  {
    (*st)->node     = rc->node;
    (*st)->action_n = rc->action_n;
    (*st)->modify_n = rc->modify_n;
    (*st)->status   = rc->status;
  }
  else
  {
    sms_node_free(hp->super);
    hp->super         = rc->node;
    hp->action_number = rc->action_n;
    hp->modify_number = rc->modify_n;
  }

  memset(rc,0,sizeof(sms_status));

  return SMS_E_OK;
}

int sms_client_history(sms_handle *hp, sms_list **lp, int last)
/**************************************************************************
?  Receive the X-number of last lines of the logfile.
=  SMS-ERROR-CODE
************************************o*************************************/
{
  sms_list *rc;

  IS_OK(hp,"SMS-CLIENT-HISTORY");

  if( lp )                         /* Let's get rid of the old stuff */
    NODE_FREE( *lp,sms_list );

  sms_._xdr_version   = hp->rev*1000+hp->mod;
  if( ! (rc = sms_history_1( &last,hp->client )) )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-HISTORY:No more history!. (RPC)");

      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  if( lp )
    if( *lp = sms_alloc(NODE_LIST) )
    {
      (*lp)->type = NODE_LIST;
      (*lp)->name = rc->name;
      (*lp)->next = rc->next;
      memset(rc,0,sizeof(sms_list));
    }
    else
      return ioi_out(SMS_E_MEMORY,IOI_ERR,"SMS-CLIENT-HISTORY:No mem.");
  else
  {
    sms_list *orig = rc;

    while( rc )
    {
      printf("%s\n",STR(rc->name));
      rc = rc->next;
    }

    xdr_free(sms_xdr_list,(char *)orig);   /* The XDR will free the memory */
  }

  return SMS_E_OK;
}

int sms_client_play(sms_handle *hp, sms_node *np)
/**************************************************************************
?  Send the definition to the SMS.
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int *rc;

  IS_OK(hp,"SMS-CLIENT-PLAY");

  sms_._xdr_version   = hp->rev*1000+hp->mod;
  if( ! (rc = sms_play_1( np,hp->client )) )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-PLAY:Definition failed (RPC)");

      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  return *rc;
}

static int delete_gp = TRUE;

int sms_client_cmd(
    sms_handle *hp,                /* SMS to talk to                */
    int         argc,              /* Text command in argv, if > 0  */
    char      **argv,              /* The text command if argc > 0  */
    sms_list  **lp,                /* The answer for the command    */
    int         options,           /* Bit packed options (boolean)  */
    sms_list  **gp)                /* Command in list, if not NULL  */
/**************************************************************************
?  Execute sms command.
|  This is not a user callable routine!
|  The SMS assumes that the command is parsed and that the syntax is correct.
|
|  If the lp is a valid pointer the answer will be returned to the caller, who
|  need to take care of releasing the memory or by calling next time with
|  the same pointer. In the beginning the list is freed.
|
|  If the command has generic parameters the argc-argv array (if argc>0)
|  is added in front of the list and the memory is released after the call.
|
|  The variables pointed by the *gp are freed by this routine.
|
-NOTICE  If the command is already formed in the gp (and argc==0) the 
|  name of the first generic item must be used to carry the command name.
=  The SMS-ERROR-CODE
************************************o*************************************/
{
  sms_reply   *rc;
  sms_reply    command;
  sms_list    *cmd;

  IS_OK(hp,"SMS-CLIENT-CMD");

  if( lp )                         /* Remove the previous answer */
    NODE_FREE( *lp,sms_list );

  if( argc < 1 && ! gp )
    return ioi_out(SMS_E_PROTOCOL,IOI_ERR,"SMS-CLIENT-CMD:Serious trouble!");

  cmd = NULL;

  if( gp )
  {
    while( argc )
      if( ! sms_list_add_text(gp,argv[--argc]) )
        return ioi_out(SMS_E_MEMORY,IOI_ERR,"SMS-CLIENT-CMD:No mem.");
  }
  else                             /* Build the list form the argv */
  {
    sms_list *temp;

    cmd = (sms_list *)ioi_token_build(argc,argv);
    for( temp=cmd ; temp ; temp=temp->next ) temp->type = NODE_LIST;
  }

  command.type = NODE_REPLY;

  command.code = options;
  command.lines = cmd?cmd:*gp;

#ifdef DEBUG_TRAFFIC
  {
    sms_list *g = (sms_list *)command.lines;

    while(g)
    {
      printf("CMD: %-10s %s\n",STR(node_name[g->type]),STR(g->name));
      g = g->next;
    }
  }
#endif

  sms_._xdr_version   = hp->rev*1000+hp->mod;
  rc = sms_cmd_1(&command,hp->client);

  NODE_FREE( cmd,sms_list );

  if( delete_gp )
  if( gp )                         /* Remove the arguments */
    NODE_FREE( *gp,sms_list );

  if( ! rc )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-CMD:Execution failed (RPC)");
 
      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  copy((sms_list *)rc->lines);     /* For the XCdp */
  sms_._client_error = rc->code;   /* XCDP */

  if( lp )                         /* Let's steel it from the XDR */
  {
    *lp = rc->lines;
    rc->lines=NULL;
  }
  else
  {
    sms_list_print(&rc->lines,stdout);

    xdr_free(sms_xdr_reply,(char *)rc);
  }

  return sms_._client_error ;
}

int sms_client_cmd_keepgp(
    sms_handle *hp,                /* SMS to talk to                */
    int         argc,              /* Text command in argv, if > 0  */
    char      **argv,              /* The text command if argc > 0  */
    sms_list  **lp,                /* The answer for the command    */
    int         options,           /* Bit packed options (boolean)  */
    sms_list   *gp)                /* Command in list, if not NULL  */
/**************************************************************************
?  Execute sms command but don't delete gp (otherwise == sms_client_cmd)
=  The SMS-ERROR-CODE
@  sms_client_cmd()
************************************o*************************************/
{
  sms_list *base = 0;
  int rc;

  ls_argv(&base, argc, argv);
  ls_join(&base, gp);

  delete_gp = FALSE;
  rc = sms_client_cmd(hp, 0, 0, lp, options, &base);
  delete_gp = TRUE;

  while( argc-- )
    ls_delete(&base, base);

  return rc;
}

int sms_client_cmd_any(
    int         argc,              /* Text command in argv, if > 0  */
    char      **argv,              /* The text command if argc > 0  */
    sms_list  **lp,                /* The answer from the command   */
    int         options,           /* Bit packed options (boolean)  */
    sms_list  **gp)                /* Net names as a param for cmd  */
/**************************************************************************
?  Execute a command in any SMS.
|  Like sms_client_cmd, but swap between SMS's
|  argc, argv has the command and gp points to a list of netnames
|  argc >= 1
-NOTICE  The argv must have at least one more element than argc
=  The SMS-ERROR-CODE
************************************o*************************************/
{
  sms_list   *argp;
  int         rc = SMS_E_OK;

  if( lp )                         /* Remove the previous answer */
    NODE_FREE( *lp,sms_list );

  if( argc < 1 || !gp ) return sms_._client_error =
    ioi_out(SMS_E_PROTOCOL,IOI_ERR,"SMS-CLIENT-CMD-ANY:Serious trouble!");

  argp = *gp;

  while( argp && (rc==SMS_E_OK || rc==SMS_E_TIMEOUT) )
  {
    sms_node   *np = sms_node_net_find( argp->name );
    sms_handle *hp = sms_node_find_handle( np );
    sms_list   *mes = 0;

    if(hp)
    {
      argv[argc] = sms_node_full_name(np);
      sms_client_cmd( hp, argc+1, argv, lp? &mes : 0, options, 0 );

      if(lp)
        ls_join(lp,mes);
    }
    else
    {
      sms_._client_error = 
        sms_error(SMS_E_NOTFOUND,"SMS-CLIENT-CMD-ANY:%s:for node %s",
                  STR(argv[0]),STR(argp->name));
      if( gp ) NODE_FREE( *gp , sms_list );
      return sms_._client_error;
    }

    argp = argp->next;
  }

  if( gp ) NODE_FREE( *gp , sms_list );

  return rc;
}

int sms_client_smscmd(sms_handle *hp, int argc, char **argv)
/**************************************************************************
?  Execute sms command.
=  The SMS-ERROR-CODE
************************************o*************************************/
{
  int  *rc;
  char  line[MAXLEN];
  char *cmd = line;

  IS_OK(hp,"SMS-CLIENT-CMD-OLD");

  strcpy(cmd,*argv++); argc--;

  while( argc-- )                  /* Let's build the command to be executed */
    strcat(cmd," ") , strcat(cmd,*argv++);
  strcat(cmd,"\n");

  sms_._xdr_version   = hp->rev*1000+hp->mod;
  if( ! (rc=sms_cmd_old_1(&cmd,hp->client)) )
  {
    if( sms_client_error(hp->name,hp->client) )
    {
      ioi_out(0,IOI_ERR,"SMS-CLIENT-CMD:Execution failed (RPC)");

      return sms_client_terminate(hp,SMS_E_RPC);
    }
    return SMS_E_TIMEOUT;
  }

  return *rc;
}

static int client_collect(
    caddr_t             result,    /* Well, we asked for void!    */
    struct sockaddr_in *server)    /* Servers name/internet style */
/**************************************************************************
?  Called by the sms_client_broadcast().
=  TRUE if the number of host requested has already responded.
!  The way sms_client_broadcast uses UDP does lead multiple responces of a
|  single servers.
************************************o*************************************/
{
  struct hostent *hp;              /* We want the character name */
  sms_list       *lp;
  char            message[MAXLEN];
  int             rc = TRUE;

  hp = gethostbyaddr( (char *)&server->sin_addr,sizeof(server->sin_addr),
                       server->sin_family);
  if( hp )
  {
    if(sms_._is_xcdp)
      sprintf(message,"alive: %s IP:%s",STR(hp->h_name),STR(inet_ntoa(server->sin_addr)));
    else
      sprintf(message,"alive: %-20s (%s)",STR(hp->h_name),STR(inet_ntoa(server->sin_addr)));

    if( s_verbose )
      printf("%s\n",STR(message));

    if( ls_find( servers,hp->h_name ) )
      if( s_verbose )
      {
        sprintf(message,"alive: Another reply from the %s\n",STR(hp->h_name));
        if( callback ) rc = callback(callbackdata,message);
      }
      else
        ;
    else
      if( lp = sms_alloc(NODE_LIST) )
      {
        if( callback ) rc = callback(callbackdata,message);

        lp->type = NODE_LIST;
        lp->name = strdup(hp->h_name);

        ls_add(servers,lp);
        return ( --s_wanted == 0 );
      }
      else
        return ioi_out(FALSE,IOI_ERR,"SMS-CLIENT-COLLECT:No mem.");

    if( !rc )
      return 1;                    /* Stop collecting */
  }

  return FALSE;                    /* Can't really go on anymore! */
}

static void ping_servers(char *name, int verbose)
/**************************************************************************
?  Use callrpc with NULLPROC to check if the SMS(s) in named host(s) is/are
|  alive. The file is typically taken from an environment variable and
|  should contain hostname per line.
************************************o*************************************/
{
  char  buff[MAXNAME];
  FILE *fp;
  int   lines = 1;                 /* In the servers file */

  if(!(fp=sms_fopen(name,"r","SMS-CLIENT-PING-SERVERS")))
    return;

  while( fgets(buff,MAXNAME-1,fp) && lines < SMSMAXHOSTLINES )
    if(sms_client_ping(sms_no_newline(buff),verbose,0))
    {
      sms_list *lp;

      if( lp = sms_alloc(NODE_LIST) )
      {
        lp->name = strdup(buff);   /* No NL anymore */
        sms_list_add(servers,lp);
      }
      else
        ioi_out(FALSE,IOI_ERR,"SMS-CLIENT-PING-SERVERS:No mem.");

      lines++;
    }

  fclose(fp);
}

#ifdef SET_BACKOFF

static int tv_sec;

static void first(struct timeval *tv)
{
  tv_sec = 2;

  tv->tv_usec = 0;
  tv->tv_sec  = tv_sec;
}

static int next(struct timeval *tv)
{
  tv->tv_usec = 0;
  tv->tv_sec  = tv_sec++;

  if(tv_sec < 4) return TRUE;

  return FALSE;
}

#endif

int sms_client_servers(
    sms_list **ls,
    int        maxnum, int verbose,
    char       *pingfile,
    int (*func)(void *, char *),
    void *userdata)
/**************************************************************************
?  Broadcast to find the servers.
|  In many cases it's clever to just wait for one answer.
=  The SMS-ERROR-CODE
=  SMS_E_OK if the operation was ok. The actual number of servers can be
|  calculated from the list, there are no duplicates in the list.
|  SMS_E_RPC if the broadcast was terminated abnormally (there might still
|  be some entries in the list.)
-CALLED
|  sms_list *lp = NULL;
|  sms_client_servers(&lp,1,FALSE,NULL);   //  Be quiet!  //
|  ... use them, if any ...
|  sms_node_free(lp);
************************************o*************************************/
{
  int rc;

  servers   = ls;
  s_wanted  = maxnum;
  s_verbose = verbose;

  callback     = func;
  callbackdata = userdata;

#ifdef SET_BACKOFF
  clnt_setbroadcastbackoff( first , next );
#define  _clnt_broadcast clnt_broadcast
#endif

#if defined(__sun) || defined(__alpha) || defined(linux) || defined(AIX)
#  define  _clnt_broadcast clnt_broadcast
#endif

#ifdef hpux
  rc = RPC_SUCCESS;
#else
  rc = _clnt_broadcast(            /* The SMS version of it */
                       sms_._prog,sms_._vers,NULLPROC,
                      xdr_void,NULL,xdr_void,NULL,client_collect);
#endif

  if( rc != RPC_SUCCESS && rc != RPC_TIMEDOUT )
  {
    ioi_out(0,IOI_WAR,"SMS-CLIENT-SERVERS:No broadcast-networks available.");
    
    if(!pingfile)
      return SMS_E_RPC;
  }

  if(pingfile)
    ping_servers(pingfile,verbose);

  return SMS_E_OK;
}
