/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     WHY
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     19-MAR-1992 / 28-NOV-1991 / OP
.VERSION  4.0
.FILE     why.c
*
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     02-OCT-1998 / 02-OCT-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
*
*  Why the node is not running
*
************************************o*************************************/

#include "smslib.h"

int cdp_why(int argc, char **argv)
/**************************************************************************
?  Why the nodes given are not running?
|  Currently do it locally.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   all;

  if( called )
  {
    sms_list *names;
    sms_node *np = (sms_node *)1;

    if( dummy ) { argc++; argv--; }

    names = sms_cd_names2(argc,argv,NULL);

    while( names && np )
    {
      sms_list *reason;

#ifdef USE_NET_NAMES
      np = sms_node_net_find(names->name);
#else
      np = sms_node_find_full(names->name);
#endif

      printf("%s:",STR(names->name));

      if((reason=sms_status_why(np)))
      {
        printf("\n");
        sms_list_print(&reason,stdout);
        printf("\n");
        NODE_FREE(reason,sms_list);
      }
      else
        if(np)
          printf("is %s\n",STR(status_name[np->status]));
        else
          printf("was not found?\n");

        names = names->next;
    }

    return 1;
  }
  else
    ioi_exe_add("why:cdp",cdp_why,
      ioi_exe_param(
        "-aall",IOI_L_BOOLEAN,ioi_exe_argv(
          "Give status of the kids also.",
          NULL
        ),NULL,1,&all
      ),
      ioi_exe_param(
        "node",IOI_L_STRING,ioi_exe_argv(
          "The node to examine. The default node to examine is the $cwn.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Why the node is not running?",
        "This command answers to the question from the local copy.",
        "Use get(cdp), play(cdp) -l or playbin(cdp) to \"load\" the",
        "local copy.",
        NULL
      )
    );

  return called = TRUE;
}
