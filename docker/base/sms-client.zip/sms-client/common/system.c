/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SYSTEM
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-JUL-1992 / 30-AUG-1991 / OP
.VERSION  4.0
.FILE     system.c
*
.DATE     16-SEP-1993 / 30-AUG-1991 / OP
.VERSION  4.2.1
.DATE     19-AUG-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.1-6
.DATE     27-APR-1995 / 19-AUG-1994 / OP
*         Setenv usage discontinued (config.h)
.VERSION  4.3.13
.DATE     28-OCT-1996 / 28-OCT-1996 / OP
*         Bug fix: Kill without SMSKILL
.VERSION  4.3.16
.DATE     17-OCT-1997 / 17-OCT-1997 / OP
*         stray child are now debug level messages (maybe from popen)
*         use SVR4 signals instead of BSD
.LANGUAGE ANSI-C
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     16-NOV-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
.DATE     05-JUL-2000 / 07-JUN-2000 / OP
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     18-MAY-2001 / 1-MAR-2001 / OP
.VERSION  4.4.5 ABT(c)
*         waitpid calling
.DATE     06-JAN-2003 BR
*         Add system_jobcheck
*
*  Operating system dependent routines.
*
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

#include <sys/stat.h>

#ifdef VMS
#  include <processes.h>
#  ifndef SIGCHLD
#    define SIGCHLD 18
#  endif
#else
#  include <sys/wait.h>
#endif

#ifdef SMS_SETENV
#  include "setenv.c"
#endif

#ifdef CRAY
#  define SYSTEM sms_system_kid
#  define fork vfork
#else
#  define SYSTEM system
#endif

#ifdef SMS_MULTI_PROCESS

#ifndef O_WRONLY
#include <fcntl.h>
#endif

/*=========================================================================
*  The following code is used if SMS is to have multi-threaded execution
*
*  All this stuff is for SMS only
************************************o*************************************/

struct sms_process {
  int                 type;
  char               *name;
  struct sms_process *next;
  char               *cmd;
  int                 pid;
};
typedef struct sms_process sms_process;

static sms_process *processes;
static int          mask;

void sms_system_process_list(void)
/**************************************************************************
?  Print a list of processes pending into output
************************************o*************************************/
{
  sms_process *pp = processes;

  if(pp) sms_output("Processes pendind to finnish");

  for( ; pp ; pp=pp->next )
    if( pp->name )
      sms_output("%5d %s",pp->pid,STR(pp->name));
    else
      sms_output("%5d [%s]",pp->pid,STR(pp->cmd));
}

void sms_process_child(void)
/**************************************************************************
?  Unblock SIGCHLD. This will call the signal-handler if there is any
|  such signals pending.
|  Once the signals are processed, block them until we come in here again
************************************o*************************************/
{
#ifdef SVR4
  sigset_t set;

  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_UNBLOCK, &set, 0);

  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_BLOCK, &set, 0);
#else
  sigsetmask(mask);
  sigblock(1<<(SIGCHLD-1));
#endif
}

static void died(char *name)
/**************************************************************************
?  Process the death of the process. This is most unwanted and iplies
|  that the shell died abnormally.
************************************o*************************************/
{
  sms_node *np;

  if(!name) return;

  if( (np=sms_node_find_full(name)) != NULL )
  {
    FLAG_SET(np,FLAG_CMD_FAILED);
    sms_status_change(np,STATUS_ABORTED,FALSE,FALSE);
    IFFREE(np->passwd);
  }
}

static void catch_child(int sig)
/**************************************************************************
?  Catch the death of the child process
|  If the death is not normal the status of the node (if found) is set
|  to be aborted and a flag is raised
************************************o*************************************/
{
  int          status;
  int          pid;
  sms_process *pp;

#if 0 /* Replaced by Baudouin's request to while ... */
  if( (pid=waitpid(-1,&status,WNOHANG)) != NIL )
#endif

#if 1
  while( (pid=waitpid(-1,&status,WNOHANG)) != NIL && pid != 0 )
#else
  if( (pid=wait(&status)) != NIL )
#endif
  {
    for( pp=processes; pp ; pp=pp->next )
      if( pp->pid == pid )
        break;

    if( pp )                       /* Found my process */
    {
      if( WIFSTOPPED(status) )
        spit(0,IOI_WAR,"SMS-PROCESS-CHILD:PID %d STOPPED??? [%s]",pid,STR(pp->name));
      else                           /* Process terminated */
      {
        if( WIFSIGNALED(status) )
        {
          spit(0,IOI_ERR,"SMS-PROCESS-CHILD:PID %d died of signal %d [%s]",
                 pid,WTERMSIG(status),STR(pp->cmd));
          died(pp->name);
        }
        else                         /* Must be exit! */
          if(WEXITSTATUS(status))
          {
            spit(0,IOI_ERR,"PID %d exited with status %d [%s]",
                   pid,WEXITSTATUS(status),STR(pp->cmd));
            died(pp->name);
          }
          else
            spit(0,IOI_DBG,"PID %d exited [%s]",pid,STR(pp->cmd));

        ls_remove(&processes,pp);
        IFFREE(pp->name);
        free(pp->cmd);
        free(pp);
      }
    }
    else
      spit(0,IOI_DBG,"SMS-PROCESS-CHILD:stray PID %d (ignored)",pid);
  }

  signal(sig,catch_child);         /* On some systems re-load is needed */
}

static int sys(char *name, char *cmdname)
/**************************************************************************
?  Execute the command (cmdname) and return, DO NOT WAIT for the termination
|  of the children.
|  The stdin, stdout and stderr are closed (or redirected to /dev/null)
=  PID in case of succes or 0 in case of errors.
************************************o*************************************/
{
  sms_process *pp;
  int          pid;
  int          f;

  if((pid = fork()) == 0)          /* The child */
  {
    close(2);
    if( (f=open("/dev/null",O_WRONLY)) != 2 )
      close(f);

    close(1);
    if( (f=open("/dev/null",O_WRONLY)) != 1 )
      close(f);

    close(0);
    if( (f=open("/dev/null",O_RDONLY)) != 0 )
      close(f);

    execl("/bin/sh", "sh", "-c", cmdname, NULL);
    /*
     *  Mayby the file protection failed (no executable bit set)
     *  or the shell couldn't be found. Look at man execve(2).
     */
    _exit(127);
  }

  if (pid == -1)
  {
    spit(0,IOI_ERR,"SMS-PROCESS-SYS:,FORK error for %s",STR(cmdname));
    return 1;
  }

  if( (pp=malloc(sizeof(sms_process))) )
  {
    pp->name = name? strdup(name) : NULL;
    pp->cmd  = strdup(cmdname);
    pp->pid  = pid;
    pp->next = NULL;
    ls_add(&processes,pp);
  }

  return 0;
}

void sms_system_block(void)
/**************************************************************************
?  Catch the death of the child process
************************************o*************************************/
{
  sigset_t set;

  static int been_here;

  if( been_here ) return;

  signal(SIGCHLD,catch_child);
#ifdef SVR4
  sms_process_child();
#else
  mask = sigblock(1<<(SIGCHLD-1));
#endif

  been_here = TRUE;
}
/*=======================================================================*/
#endif

#ifdef VMS
static char *to_vax(char *s)
/**************************************************************************
?  Convert a filename to VMS-format
=  The result in the static buffer
-NOTICE  Not as robust and good as the shell$to_vms() but since I don't
|        know the parameters for that routine we'll use this.
************************************o*************************************/
{
  static char  buff[MAXLEN];       /* */
  char        *t;                  /* Pointer to the buff */
  int          add_dot = FALSE;

  if(!s) return NULL;

  t = buff;

  if( *s=='/' ) s++;               /* Must B */

  while( isalnum(*s) || *s=='$' || *s=='_' )
    *t++ = *s++;                   /* Build the disk */
  *t++ = ':';

  *t++ = '[';                      /* Start the directory part */

  if( *s != '/' )
  {
    spit(0,IOI_ERR,"to-vax:bad name");
    return 0;
  }

  s++;

  while( strchr(s,'/') )           /* Add directories */
  {
    if( add_dot ) *t++ = '.';

    while( *s && *s != '/' )
      *t++ = *s++;

    if( *s=='/' ) *s++;

    add_dot = TRUE;
  }

  *t++ = ']';

  while( *s ) *t++ = *s++;         /* The file name part */

  *t = '\0';

  return buff;
}
#endif

static int is_in_rt;

void sms_system_start_kid(void)
/**************************************************************************
?  Start the child process to execute the commands given to the _kid()
************************************o*************************************/
{
  spit(0,IOI_MSG,"sms:running in the real-time mode");
  is_in_rt = TRUE;
}

int sms_system_kid(char *cmd)
/**************************************************************************
= 0, 'till we'll get it back
************************************o*************************************/
{

  if(is_in_rt)
  {
    int rc;
#ifdef CRAY
    rc = ISHELL(cmd);

    spit(0,IOI_DBG,"ISHELL:%s = %d",STR(cmd),rc);
#else
    rc = system(cmd);
#endif

    return rc;
  }
  else
    return system(cmd);
}

int sms_system(sms_node *np, char *cmd)
/**************************************************************************
?  Execute a system command.
=  0 == OK.
************************************o*************************************/
{
  int rc  = 1;                     /* Not a zero          */
  int try = 1;                     /* Currently hardcoded */

#ifdef VMS
  printf("SYSTEM:%d\n",SYSTEM(cmd) );
  rc=0;
#else

  for( rc=1 ; try && rc ; try-- )
  {
    rc=
#ifdef SMS_MULTI_PROCESS
       sys( np? sms_node_full_name(np) : NULL ,cmd);
#else
       SYSTEM(cmd);
#endif

    if( rc )
      sleep(1);                    /* Mayby 2 many processes */
  }

  if( rc )
  {
    sms_error(SMS_E_UNIX,"system:%s",STR(cmd));
    sms_perror("system");
  }
#endif

  return rc;
}

int sms_system_execute(char *cmd)
/**************************************************************************
?  Execute a system command, but don't wait for it
|  A command is executed in separate xterm if:
|    $DISPLAY exists
|    $TERM exist and == 'xterm'
|  otherwise the command is executed on background
| 4.3
|  Not executed on background, this is an error
************************************o*************************************/
{
  extern char *getenv();
  char newcmd[MAXLEN];
  char *term = getenv("TERM");

  if( getenv("DISPLAY") && term && strcmp(term,"xterm")==0 )
    sprintf(newcmd,"xterm -T SMS-SHELL -e %s &",STR(cmd));
  else
    sprintf(newcmd,"%s",STR(cmd));

  system(newcmd);

  return 0;
}

int sms_system_submit(sms_node *np, char *name)
/**************************************************************************
?  Submit the job (file) NAME to be executed.
|
|  The variables found in the SMSCMD inside a pair of '%'-chars are
|  been replaced by the SMS-variables. They all must be found.
|
|  Environment:
|    SMSNAME   the full name of the task eg /suite/fam1/fam2/task
|    SMSNODE   the host name of the sender
|    SMSPASS   the password to give to the SMS
|
=  Boolean status, was the job actually send.
************************************o*************************************/
{
  char      line[MAXLEN];          /* To be executed after building it */
  char     *s;                     /* 2 loop the line                  */
  char     *cmd  = NULL;           /* Command to send this node        */
  char     *c;                     /* 2 loop the cmd (a format string) */
  char     *t;                     /* 2 loop the host & name           */

  char      micro = SMSMICRO(np);

  if( chmod(name,0755) != 0 )
  {
    sms_error(SMS_E_UNIX,"chmod:%s",STR(name));
    sms_perror("chmod");
    return FALSE;
  }

  if( ! (sms_edit_variable(np, "SMSCMD", line)) )
    return spit(FALSE,IOI_ERR,"submit:bad cmd %s for %s",STR(cmd),STR(name));

#if 0
  for( s=line , c=cmd ; *c ; c++ ) /* Build the command */
    if( *c == micro )
      if( *++c == micro )          /* Substitute by a single micro */
        *s++ = *c;
      else                         /* Find the name and replace */
      {
        char *v;
        char *var_name = c;        /* Mark the variable name */
 
        for( ; *c && *c != micro ; c++ ) ;

        if( *c != micro )
          return spit(FALSE,IOI_ERR,"submit:bad SMSCMD %s for %s",STR(cmd),STR(name));

        *c = '\0';                 /* Temp only! */
        var_name=strdup(var_name);
        *c = micro;                /* Put it back */
         
        if( ! (v=sms_variable_get(var_name,np)) )
          spit(FALSE,IOI_ERR,"submit:variable %s in cmd [%s] for %s missing",
               STR(var_name),STR(cmd),STR(name));
#ifdef VMS
        else
        {
          if(strcmp("SMSJOB",var_name) == 0 ||
             strcmp("SMSJOBOUT",var_name) == 0 
            )
            v=to_vax(v);
        }
#endif

        free(var_name);
        if( !v ) return FALSE;

        strcpy(s,v);
        s += strlen(v);
      }
    else
      *s++ = *c;

  *s = '\0';
#endif

  {   
    static char  *env[] = { "SMSNAME", "SMSNODE", "SMSPASS", NULL };
    char        **loop;
    char         *var;

    for( loop=env ; *loop ; loop++ )
    {
      if( (var=sms_variable_get(*loop,np)) )
      {
#ifdef SMS_SETENV
        if( setenv(*loop,var,1) )
          return spit(FALSE,IOI_ERR,"submit:setenv %s for %s",STR(*loop),STR(name));
#endif
      }
      else
        return spit(FALSE,IOI_ERR,"submit:no %s for %s",STR(*loop),STR(name));
    }
  }

  spit(0,IOI_DBG,"SUBMIT:[%s]",STR(line));

  return ! sms_system(np,line);

#ifdef IMPOSSIBLE
  return TRUE;                     /* We'll claim success every time! */
#endif
}

int sms_system_kill(sms_node *np)
/**************************************************************************
?  Execute kill command for the node
|
|  The variables found in the SMSKILL inside a pair of '%'-chars are
|  been replaced by the SMS-variables. They all must be found.
|
=  Boolean status, was the job actually killed.
************************************o*************************************/
{
  char      line[MAXLEN];          /* To be executed after building it */
  char     *s;                     /* 2 loop the line                  */
  char     *cmd  = NULL;           /* Command to send this node        */
  char     *c;                     /* 2 loop the cmd (a format string) */
  char     *t;                     /* 2 loop the host & name           */

  char      micro = SMSMICRO(np);
  char     *name  = sms_node_full_name(np);

  if( ! (sms_edit_variable(np, "SMSKILL", line)) )
    return spit(FALSE,IOI_ERR,"kill:bad killcmd for %s",STR(name));

#if 0
  for( s=line , c=cmd ; *c ; c++ ) /* Build the command */
    if( *c == micro )
      if( *++c == micro )          /* Substitute by a single micro */
        *s++ = *c;
      else                         /* Find the name and replace */
      {
        char *v;
        char *var_name = c;        /* Mark the variable name */
 
        for( ; *c && *c != micro ; c++ ) ;

        if( *c != micro )
          return spit(FALSE,IOI_ERR,"kill:bad SMSKILL %s for %s",STR(cmd),STR(name));

        *c = '\0';                 /* Temp only! */
        var_name=strdup(var_name);
        *c = micro;                /* Put it back */
         
        if( ! (v=sms_variable_get(var_name,np)) )
          spit(FALSE,IOI_ERR,"kill:variable %s in cmd [%s] for %s missing",
               STR(var_name),STR(cmd),STR(name));

        free(var_name);
        if( !v ) return FALSE;

        strcpy(s,v);
        s += strlen(v);
      }
    else
      *s++ = *c;

  *s = '\0';
#endif

  spit(0,IOI_DBG,"KILL:[%s]",STR(line));

  return sms_system(NULL,line);
}


