/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     HTML
.SECTION  L
.FILE     html.c
.LANGUAGE ANSI-C
.AUTHOR   Otto Pesonen
.DATE     03-NOV-1998 / 09-OCT-1998 / OP
.VERSION  4.4
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     28-JUN-2001 / 08-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         depth for html output for Meteo-France
*
*  Html test for 4.4.5
*
*  Notice that </td> and </tr> are not really needed, we just add them
*  to give some structure (and use them to check that code is ok!)
*
************************************o*************************************/

#include "smslib.h"

static FILE *fp;
static int lineno;
static int statusmask;
static int openkids;
static int maxdepth;
static int decorate;
static int userdepth;

static int countnext(void *anything, int depth) /* For events, meter, label, repeat only */
{
  sms_node *np = anything;
  int n = 0;

  if(np && depth > maxdepth)
    maxdepth = depth;

  for( np = anything; np ; np=np->next )
  {
    np->user_int = lineno++;
    n++;
  }
  return n;
}

static void count(sms_node *np, int depth)
{
  int n = 0;
  sms_node *kids;

  if(!np) return;

/* 445 */
  if( ! ((1<<(np->status)) & statusmask) || depth > userdepth )
    return;

  if(depth > maxdepth)
    maxdepth = depth;

  /* 445 depth++; */

  np->user_int=lineno;

  if(openkids)
  {
    n += countnext(np->repeat,depth+1);
    n += countnext(np->event,depth+1);
    n += countnext(np->meter,depth+1);
    n += countnext(np->label,depth+1);
  }

  if( sms_node_table[np->type].has_kids )
    if( depth < userdepth )
    for( kids=np->kids ; kids ; kids=kids->next )
    {
      count(kids,depth+1);
      n++;
    }

  if(!n) lineno++;
}

static void header(sms_node *np)
{
  sms_handle *hp;

  hp = sms_node_find_handle(np);

  fprintf(fp,"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\"\n");
  fprintf(fp,"  \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n");
  fprintf(fp,"<html>\n");
  fprintf(fp,"<head>\n");
  fprintf(fp,"  <meta http-equiv=\"refresh\" content=\"600\">\n");
  fprintf(fp,"  <title>Status tree of %s in %s</title>\n",STR(sms_node_full_name(np)),hp?STR(hp->name):"no-host");
  fprintf(fp,"  <link rel=\"stylesheet\" type=\"text/css\" href=\"file:/home/ma/map/http/sms.css\">\n");
  fprintf(fp,"</head>\n");
  fprintf(fp,"<body>\n");
  fprintf(fp,"  <table border=2 cellpadding=2>\n");
  fprintf(fp,"    <tr>\n");
}

static void trailer(sms_node *np)
{
  fprintf(fp,"  </table>\n");
  fprintf(fp,"</body>\n");
  fprintf(fp,"</html>\n");
}

static int lastnext(int n, void *anything) /* For events, meter, label, repeat only */
{
  sms_node *np;

  if( ! (np=anything) )
    return n;

  np = ls_last(&np);

  return np->user_int;
}

static int last(sms_node *np, int depth)
{
  sms_node *kids;

  int n = np->user_int;

  if( sms_node_table[np->type].is_node )
    if(openkids)
    {
      n = lastnext(n,np->repeat);
      n = lastnext(n,np->event);
      n = lastnext(n,np->meter);
      n = lastnext(n,np->label);
    }
    else
      ;
  else
    return lastnext(n,np);

  for( kids=0 , np=np->kids ; np ; np = np->next )
    if( (1<<(np->status)) & statusmask )
      kids = np;

/* 445 */
  if( depth >= userdepth ) return n;

  if( !kids ) return n;

  /* np = ls_last(&np->kids); */

  return last(kids,depth+1);
}

static void parent(void *anything, int depth)
{
  sms_node *np = anything;
  int span;

  if(depth && lineno == np->parent->user_int + 1)
    parent(np->parent,depth-1);

  span = last(np,depth) - lineno + 1;

  if(span>0)
    fprintf(fp,"      <td rowspan=%d></td>\n",span);
}

static void img(char *name)
{
  fprintf(fp,"<img src=\"../gifs/%s.gif\" alt=\"[%s]\">",STR(name),STR(name));
}

static void decorations(sms_node *np)
{
  if(np->status==STATUS_HALTED)   img("halted");
  if(np->status==STATUS_SHUTDOWN) img("shutdown");

  if(np->tryno > 1) img("rerun");
  if(FLAG_ISSET(np,FLAG_MESSAGE)) img("message");
  if(FLAG_ISSET(np,FLAG_LATE)) img("late");
  if(FLAG_ISSET(np,FLAG_MIGRATED)) img("migrated");
  if(sms_time_dependent(np)) img("clock");
}

static void ref(sms_node *np)
{
  char *out = sms_variable_get("SMSJOBOUT",np);

  if(out)
    fprintf(fp,"<a href=\"%s\">",STR(out));
}

static int table(void *anything, int depth)
{
  sms_node *np = anything;
  sms_node *kids;
  int       n = 0;

  if(!np) return n;

/* 445 */
  if( depth > userdepth ) return n;

  if( sms_node_table[np->type].is_node )
    if( ! ((1<<(np->status)) & statusmask) ) return n;

  if(depth && np->user_int == np->parent->user_int + 1)
    parent(np->parent,depth-1);

  if( sms_node_table[np->type].is_node )
  {
    fprintf(fp,"      <td class=\"%s\">",STR(status_name[np->status]));

    if(np->type==NODE_TASK && np->tryno>0) ref(np);

    if(decorate) decorations(np);
    fprintf(fp,"%s",STR(np->name));

    if(np->type==NODE_TASK && np->tryno>0) fprintf(fp,"</a>");

    fprintf(fp,"</td>\n");
  }
  else
  {
    sms_meter  *mp = anything;
    sms_label  *lp = anything;
    sms_repeat *rp = anything;
    int span = maxdepth - depth + 1;

    fprintf(fp,"      <td ");
    if(np->type != NODE_EVENT && span > 1)
      fprintf(fp,"colspan=%d ",span);

    switch(np->type)
    {
      case NODE_EVENT:
          fprintf(fp,"class=\"%s\">:%s</td>\n",STR(event_name[np->status]),STR(np->name));
        break;

      case NODE_METER:
        fprintf(fp,"class=\"meter\">:%s [%d]</td>\n",STR(mp->name),mp->status);
        break;

      case NODE_LABEL:
        fprintf(fp,"class=\"label\">:%s [%s]</td>\n",STR(lp->name),STR(lp->value));
        break;

      case NODE_REPEAT:
        fprintf(fp,"class=\"repeat\">:%s [%d]</td>\n",STR(rp->name),rp->status);
        break;

      default:
        fprintf(fp,"></td>\n");
    }
  }

  if( openkids && sms_node_table[np->type].is_node )
  {
    sms_event *ep;
    sms_meter *mp;
    sms_label *lp;

    n += table(np->repeat,depth+1);    /* Only one */

    for( ep = np->event ; ep ; ep = ep->next )
      n += table(ep,depth+1);

    for( mp = np->meter ; mp ; mp = mp->next )
      n += table(mp,depth+1);

    for( lp = np->label ; lp ; lp = lp->next )
      n += table(lp,depth+1);
  }

  if( sms_node_table[np->type].has_kids )
    /* 445 */
    if(np->kids && depth < userdepth )
    {
      int i = 0;
      for( kids=np->kids ; kids ; kids=kids->next )
      {
        if( ((1<<(kids->status)) & statusmask) )
        {
          if(i)
            fprintf(fp,"    <tr>\n");
          n += table(kids,depth+1);
          i++;
        }
      }
    }

  if(n == 0)
  {
    fprintf(fp,"    </tr>\n");
    lineno++;
    n++;
  }

  return n;
}

int sms_html_write(sms_node *np, FILE *ffp)
{
  maxdepth = 0;
  lineno = 0;
  count(np,0);

  /* fprintf(stderr,"LINENO: %d\n",lineno); */

  fp = ffp;
  header(np);
  lineno = 0;
  table(np,0);
  trailer(np);

  /* fprintf(stderr,"LINENO: %d\n",lineno); */

  return 0;
}

static void write_link(sms_node *np, int horizontal, char *base, char *target)
{
  fprintf(fp,"      <base target=\"%s\">\n",STR(target));

  for( ; np ; np=np->next )
  {
    fprintf(fp,"      <td class=\"%s\">", STR(status_name[np->status]));
    fprintf(fp,"<a href=\"%s/%s.html\">%s</a>\n",
            STR(base), STR(np->name), STR(np->name));

    if( horizontal && np->next )
    {
      fprintf(fp,"    </tr>\n");
      fprintf(fp,"    <tr>\n");
    }
  }
  fprintf(fp,"    </tr>\n");
}

void sms_html_links(sms_node *np, FILE *ffp, int title, int horizontal)
{
  char *base = ioi_variable_get("htmlbase");
  char *target = ioi_variable_get("htmltarget");

  if(!base) base = "od";
  if(!target) target = "level1";

  fp = ffp;
  header(np);

  if(title)
  {
    fprintf(fp,"      <th>%s</th>\n",STR(np->name));
    if( horizontal )
    {
      fprintf(fp,"    </tr>\n");
      if( np->kids )
        fprintf(fp,"    <tr>\n");
    }
  }

  write_link(np->kids, horizontal, base, target);
  trailer(np);
}

int cdp_html_cmd(int argc, char **argv)
/**************************************************************************
?  Produce html out of the tree
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static char  masks[10];
  static int   links;
  static int   horizontal;
  static int   title;
  static int   depth_min=0, depth_max=MAXINT, depth_def=0;

  if( called )
  {
    sms_list *names = 0;
    sms_node *np = (sms_node *)1;

    statusmask = sms_status_mask(0xffffffff, masks);

/* 445 */
    if(userdepth==0) userdepth=MAXINT;

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    for( names=sms_cd_names2(argc,argv,0) ; np && names ; names=names->next )
    {
#ifdef USE_NET_NAMES
      if( (np=sms_node_net_find(names->name)) )
#else
      if( (np=sms_node_find_full(names->name)) )
#endif
      {
        if(links)
          sms_html_links( np, stdout, title, horizontal );
        else
          sms_html_write( np, stdout );
      }
      else
        ioi_printf(IOI_ERR,"HTML:%s not found?",STR(names->name));
    }

    return 0;
  }
  else
    ioi_exe_add("html:cdp",cdp_html_cmd,
      ioi_exe_link_param(
/* 445 */
        ioi_exe_param(
          "-Ddepth",IOI_L_INTEGER,ioi_exe_argv(
            "Depth of processing, by default or value 0 means all",
            NULL
          ),NULL,1,&userdepth,&depth_min,&depth_max,&depth_def
        ),

        ioi_exe_param(
          "-ddecorate",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add decorative symbols (not with -l option.)",
            NULL
          ),NULL,1,&decorate
        ),
        ioi_exe_param(
          "-llinks",IOI_L_BOOLEAN,ioi_exe_argv(
            "Write a table of links on the top level instead.",
            "(-d, and -k options are ignored.)",
            NULL
          ),NULL,1,&links
        ),
        ioi_exe_param(
          "-kkids",IOI_L_BOOLEAN,ioi_exe_argv(
            "Open tasks, eg show meters, events... in the output.",
            "(not with -l option.)",
            NULL
          ),NULL,1,&openkids
        ),
        ioi_exe_param(
          "-ttitle",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add the title into a table of links. (with -l option.)",
            NULL
          ),NULL,1,&title
        ),
        ioi_exe_param(
         "-hhorizontal",IOI_L_BOOLEAN,ioi_exe_argv(
            "Make the table (of links) horizontal. (with -l option.)",
            NULL
          ),NULL,1,&horizontal
        ),
        ioi_exe_param(
          "-sstatusmask",IOI_L_CHARACTER,ioi_exe_argv(
            "Mask given status from the display. The characters given are",
            "the same as in the curses mode. Use status -h to get curses help.",
            "By default all the modes are displayed.",
            NULL
          ),NULL,10,masks
        ),
        NULL
      ),
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be written into file.",
#ifdef USE_NET_NAMES
          "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          "The $cwn is used for names that does not begin with '/'.",
          "To output the current node use '.' as the name.",
          NULL
        ),"cwn",-1,&dummy
      ),
      ioi_exe_argv(
        "Write a html page out of a node.",
        "","NOTICE","","This is in test version of CDP only.",
        "use variables htmlbase and htmltarget to control the output.",
        NULL
      )
    );

  return called = TRUE;
}

