/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     ALTER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-AUG-1992 / 27-NOV-1991 / OP
.FILE     alter.c
.VERSION  4.0
.DATE     27-FEB-1993 / 25-FEB-1993 / OP
.VERSION  4.1
.DATE     16-APR-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     05-SEP-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-2
.DATE     25-SEP-1995 / 25-SEP-1995 / OP
.VERSION  4.3.10
*         Added flag on/off
.DATE     24-MAR-1998 / 22-MAR-1998 / OP
.VERSION  4.3.18
*         Alter meter and label for XCdp
.DATE     05-JUN-1998 / 04-JUN-1998 / OP
.VERSION  4.3.19
*         Alter repeat
.DATE     31-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20-21
*         Complete trigger
.DATE     19-JAN-1999 / 10-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Variables have NIDs
*         Net names for nodes
*         Limit (pseudo queues)
.DATE     22-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
*         Inlimit has own type
*         Events do not have numbers anymore (only a name)
.DATE     04-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     18-JUN-2001 / 18-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         Enumerated repeat
.DATE     26-NOV-2002 / MS
.VERSION  4.4.6
*         alter -V fullnodename:variable definition
*
*  Things that can be altered:
*
*  Since the 4.3 some of these are not functional anymore
*
*  @-marked should be used with care (not fully functional/debugged)
*
*  alter -a  node  status script   // add(replace) action-script
*  alter -ar node  status          // remove action-script
*  alter -c  node  clocktype       // specify new clock type
*@ alter -d  node  DATE            // start waiting DATE
*@ alter -dr node  [DATE]          // remove the date dependency
*@ alter -D  node  days            // define new day-mask
*@ alter -Dr node                  // remove the day-mask
*  alter -e  node  event [name]    // add(modify) an event
*  alter -er node  eventname       // remove the event
*  alter -f  node  flagname        // clear flag
*  alter -F  node  flagname        // set flag
*  alter -g  node  gain ...        // Alter the gain (suite only)
*  alter -l  node  text            // alter label to be text
*  alter -m  node  value           // alter meter value
*  alter -o  node  user uid gid    // add a new user
*  alter -or node  user            // remove the user
*@ alter -t  node  TIME            // start waiting TIME
*@ alter -tr node  [TIME]          // remove the time dependency
*  atler -T  node  triggermath     // replace the trigger math
*  atler -Tr node                  // remove the trigger math
*  alter -v  node  variable def    // define a (new) variable
*  alter -vr node  variable        // remove the variable
*  alter -s  node  status          // define the default status
*  alter -x  node  "text"          // add text into comments
*  alter -xr node                  // remove all comments
*  alter -R  node  variable value  // status of the repeat
*  alter -C  node  triggermath     // replace the complete math
*  alter -Cr node                  // remove the complete math
*  alter -L  node  count           // limit count
*  alter -M  node  maxval          // limit maxvalue
*  alter -N  node  name            // limit remove name
*  alter -V  node:variable def     // define a (new) variable
*  alter -Vr node:variable        // remove the variable
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

extern sms_list *sms_list_find();

#define A_ACTION         0         /* sms_action     */
#define A_CLOCK          1         /* sms_list(INT)  */
#define A_DATE           2         /* sms_date       */
#define A_DAY            3         /* sms_date       */
#define A_EVENT          4         /* sms_event      */
#define A_GAIN           5         /* sms_list(INT)  */
#define A_OWNER          6         /* sms_user       */
#define A_TIME           7         /* sms_time       */
#define A_TRIGGER        8         /* sms_trigger    */
#define A_VARIABLE       9         /* sms_variable   */
#define A_STATUS        10         /* sms_list(INT)  */
#define A_TEXT          11         /* sms_list       */
#define A_METER         12         /* sms_list(INT)  */
#define A_LABEL         13         /* sms_list       */
#define A_FLAG_ON       14         /* sms_list(INT)  */
#define A_FLAG_OFF      15         /* sms_list(INT)  */
#define A_REPEAT        16         /* sms_list(INT)  */ 
#define A_COMPLETE      17         /* sms_trigger    */

#define A_LIMITVALUE    18         /* sms_list(INT)  */
#define A_LIMITMAX      19         /* sms_list(INT)  */
#define A_LIMITNAME     20         /* sms_list       */

#define A_VARIABLE2     21         /* sms_variable   */

#define MAX_OPTIONS     22

static struct a_par {
  char *name;                      /* Format: '-','letter',"explanation" */
  int   with_r;                    /* Can this be used with r-option?    */
  int   min_param;                 /* Minimum number of parameters       */
  int   min_with_r;                /* same with the r-option             */
} opts[] = {
  { "-aaction"     , TRUE  , 2 , 1 },
  { "-cclocktype"  , FALSE , 1 , 0 },
  { "-ddate"       , TRUE  , 1 , 0 },
  { "-Dday"        , TRUE  , 1 , 0 },
  { "-eevent"      , TRUE  , 1 , 1 },
  { "-ggain"       , TRUE  , 1 , 0 },
  { "-oowner"      , TRUE  , 3 , 1 },
  { "-ttime"       , TRUE  , 1 , 0 },
  { "-Ttrigger"    , TRUE  , 2 , 0 },
  { "-vvariable"   , TRUE  , 2 , 1 },
  { "-sstatus"     , FALSE , 1 , 0 },
  { "-xtext"       , TRUE  , 1 , 0 },
  { "-mmeter"      , FALSE , 1 , 0 },
  { "-llabel"      , FALSE , 1 , 0 },
  { "-fflag_on"    , FALSE , 1 , 0 },
  { "-Fflag_off"   , FALSE , 1 , 0 },
  { "-Rrepeat"     , FALSE , 1 , 0 },
  { "-Ccomplete"   , FALSE , 2 , 0 },

  { "-Llimit"      , TRUE  , 1 , 0 },
  { "-Mmaxvalue"   , FALSE , 1 , 0 },
  { "-Nnamedlim"   , FALSE , 1 , 0 },

  { "-Vvariable"   , TRUE  , 1 , 0 },
};

#define OPTION(x) opts[x].name

#define GEN (sms_list *)

static char *itoa(int n)
/**************************************************************************
?  Convert an integer to ascii
|  used for sms_node_create()
=  String in the static area
************************************o*************************************/
{
  static char s[20];

  sprintf(s,"%d",n);

  return s;
}

/**************************************************************************
*  ROUTINES for XCdp
*
*  cdp_alter_meter(sms_handle *hp, sms_meter *mp, int value)
*  cdp_alter_label(sms_handle *hp, sms_label *lp, char *value)
*  cdp_alter_repeat(sms_handle *hp, sms_repeat *rp, int value)
*
************************************o*************************************/

#if 0
int cdp_alter_meter(sms_handle *hp, sms_meter *mp, int value)
{
  sms_list *gen = 0;

  char *av[3];

  av[0] = "alter";
  av[1] = sms_node_full_name(mp);
  av[2] = itoa(value);

  return sms_client_cmd( hp, 3, av, NULL, (1<<(A_METER+1)), NULL );
}

int cdp_alter_label(sms_handle *hp, sms_label *lp, char *value)
{
  sms_list *gen = 0;

  char *av[3];

  av[0] = "alter";
  av[1] = sms_node_full_name(lp);
  av[2] = value;

  return sms_client_cmd( hp, 3, av, NULL, (1<<(A_LABEL+1)), NULL );
}

int cdp_alter_repeat(sms_handle *hp, sms_repeat *rp, int value)
{
  sms_list *gen = 0;

  char *av[3];

  av[0] = "alter";
  av[1] = sms_node_full_name(rp);
  av[2] = itoa(value);

  return sms_client_cmd( hp, 3, av, NULL, (1<<(A_REPEAT+1)), NULL );
}
#endif

static int alter_limit(sms_limit *np, int option, int r_opt, sms_list *lp)
{
  int rc = SMS_E_OK;
  int i;

  if(r_opt)
  {
    sms_node *parent = np->parent;

    if( ls_remove(&parent->limit,np) )
    {
      spit(0,IOI_MSG,"alter:remove:%s",STR(sms_node_full_name(np)));
      sms_node_free(np);
      SUITE_MODIFIED(parent);
    }
    else
      rc = SMS_E_NOTFOUND;

    return rc;
  }

  if( (option==A_LIMITVALUE || option==A_LIMITMAX) && !sms_is_number(lp->name) )
  {
    spit(0,IOI_ERR,"alter:limit expecting a non negative number,got %s",STR(lp->name));
    return SMS_E_PROTOCOL;
  }
  i = atoi(lp->name);

  switch(option)
  {
    case A_LIMITVALUE:
      np->status = atoi(lp->name);
      SUITE_CHANGED((sms_node*)np);
      spit(0,IOI_MSG,"alter:%s to %d",STR(&(opts[option].name[2])), np->status);
       break;

    case A_LIMITMAX:
      np->limit = atoi(lp->name);
      SUITE_CHANGED((sms_node*)np);
      spit(0,IOI_MSG,"alter:%s to %d",STR(&(opts[option].name[2])), np->limit);
        break;

    case A_LIMITNAME:
      for( ; lp ; lp=lp->next )
        if( ls_delname(&np->tasks,lp->name) )
          spit(0,IOI_MSG,"alter:limitname removed %s",STR(lp->name));
        else
          spit(0,IOI_ERR,"alter:limitname %s not found",STR(lp->name));

      np->status = ls_len(&np->tasks);
      spit(0,IOI_ERR,"alter:count is now %d",np->status);
      SUITE_CHANGED((sms_node*)np);
      break;
  }

  return rc;
}

int sms_alter(
    sms_node  *np,                 /* Privileges are already checked */
    int        options,            /* Packed by the CDP              */
    sms_list  *arg)                /* If needed                      */
/**************************************************************************
?  The SMS part of the alter
|  The protocol says that there must be at least an empty arg
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int      r_opt = options & 0x01; /* Remove the "thing"  */
  int      del   = TRUE;           /* Delete the argument */
  int      option;                 /* Wot 2 do?           */
  int      rc    = SMS_E_OK;       /* The return code     */
  int      i;
  char    *fn    = sms_node_full_name(np);
  char     msg[MAXNAM];

  for( options >>= 1 , option=0 ; options ; options >>= 1, option++ )
    if( options & 0x01 ) break;

#define NA spit(0,IOI_WAR,"alter:option -%c[%s] not implemented yet",\
          opts[option].name[1], STR(&(opts[option].name[2])))

  sprintf(msg,"alter:%s [%s%s]",STR(fn),STR(&(opts[option].name[2])),r_opt?"/remove":"");

  if( option == A_CLOCK  || option == A_GAIN )
    if(np->type != NODE_SUITE)
      rc = sms_error(SMS_E_SUITE,"%s node is %s",STR(msg),STR(node_name[np->type]));

  if( option == A_CLOCK || option == A_GAIN       || option == A_STATUS || 
      option == A_METER
       || option == A_FLAG_ON || option == A_FLAG_OFF
     )
  {
    i = atoi(arg->name);
    if( ! sms_is_number( (option==A_GAIN && arg->name[0]=='-' ||
                          option==A_METER && arg->name[0]=='-' )?
                          &arg->name[1] : arg->name) )
      rc = sms_error(SMS_E_PROTOCOL,"%s expecting integer [%s]",STR(msg),STR(arg->name));
  }

#if 1

  if(option==A_EVENT)
    if(!sms_cmd_typeok("alter",np,NODE_TASK,NODE_ALIAS,0))
      rc = SMS_E_TYPE;

  if(option==A_TRIGGER || option==A_COMPLETE || option==A_TIME)
    if(!sms_cmd_typeok("alter",np,NODE_FAMILY,NODE_TASK,0))
      rc = SMS_E_TYPE;

  if(option==A_ACTION || option==A_OWNER || option==A_STATUS ||
     option==A_TEXT)
    if(!sms_cmd_typeok("alter",np,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      rc = SMS_E_TYPE;

  if(option==A_VARIABLE || option==A_FLAG_ON || option==A_FLAG_OFF)
    if(!sms_cmd_typeok("alter",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
      rc = SMS_E_TYPE;

#endif

  if( rc == SMS_E_OK )
  switch( option )
  {
    case A_ACTION:
    { 
      sms_action *ap = np->action;

      if( r_opt )
      {
        int when;

        if((when=ioi_user_cmdf(arg->name,status_name,NULL,STATUS_USABLE))==NIL)
          rc = sms_error(SMS_E_PROTOCOL,"%s status name %s",STR(msg),STR(arg->name));

        while( ap )
        {
          if( ap->when == when ) break;
          ap=ap->next;
        }
        if( ap )
          sms_list_delete(&np->action,ap);
        else
          spit(0,IOI_WAR,"%s action %s not found",STR(msg),STR(status_name[when]));
      }
      else
      {
        sms_action *new = (sms_action *)arg;

        while(ap)
        {
          if( ap->when == new->when ) break;
          ap = ap->next;
        }
        if( ap )
          sms_list_delete(&np->action,ap);

        sms_list_add(&np->action,arg);
        del = FALSE;
      }
    }
      break;

    case A_CLOCK:
      if( i>=0 && i<CLOCK_MAX )
      {
        np->clock = i;
        SUITE_CHANGED(np);
      }
      else
        rc = sms_error(SMS_E_PROTOCOL,"%s illegal clock %d",STR(msg),i);
      break;

    case A_DATE:
      NA;
      break;

    case A_DAY:
      NA;
      break;

    case A_EVENT:
      if(r_opt) 
        sms_list_delete_name(&np->event,arg->name);
      else
      {
         sms_list_add(&np->event,arg);
         ((sms_event *)arg)->parent = np;
      }
      SUITE_MODIFIED(np);
      del = r_opt;
      break;

    case A_GAIN:
      if(r_opt) i = 0;
      np->gain = i;

      if( np->status==STATUS_QUEUED || np->status==STATUS_SUBMITTED ||
          np->status==STATUS_ACTIVE || np->status==STATUS_ABORTED )
        spit(0,IOI_WAR,"alter:/%s gain of running node modified",STR(np->name));

      sms_time_suite(np,TRUE,NULL,NULL);     /* Let's fake the begin */
      SUITE_MODIFIED(np);
      break;

    case A_OWNER:
      if(r_opt) sms_list_delete_name(&np->user,arg->name);
      else      sms_list_add(&np->user,arg);
      SUITE_MODIFIED(np);
      del = r_opt;
      break;

    case A_TIME:
      {
        sms_time *tp = (sms_time *)sms_time_date_holding((sms_date*)np->time);
        sms_time *new = (sms_time *)arg;

        if(r_opt)                  /* Remove the dependency */
        {
          if(new->type==NODE_TIME) /* Remove a specific time */
          {
            for( tp = np->time ; tp ; tp = tp->next )
              if( memcmp(&(new->hour[0]),&(tp->hour[0]),sizeof(int)*(3+3+1+1))
                  == 0 )                 /* see the sms.x for the struct */
                break;

            if( tp )
            {
              sms_list_delete(&np->time,tp);
              SUITE_MODIFIED(np);
            }
            else
              spit(0,IOI_ERR,"alter:time:remove:the specified was not found");
          }
          else                     /* Mark the holding to be expired */
            if(tp)
            {
              tp->status = TIME_EXPIRED;
              SUITE_CHANGED(np);
            }
            else spit(0,IOI_WAR,"alter:time:remove:no holding time deps");
        }
        else                       /* Alter -t node TIME */
        {
          if( !tp )
            rc = sms_error(SMS_E_NOTFOUND,"%s:no time holding",STR(msg));
          else
          {
            sms_time_load(np);     /* Update the locals in TIME */
            sms_time_calc(new);
            sms_list_delete(&np->time,tp);
            sms_list_add(&np->time,new);
            del = FALSE;
            SUITE_CHANGED(np);     /* Overall it doesn't change! */
          }
        }
      }
      break;

    case A_TRIGGER:
    case A_COMPLETE:
      if(r_opt)
      {
        if(option==NODE_TRIGGER)  NODE_FREE(np->trigger,sms_trigger);
        if(option==NODE_COMPLETE) NODE_FREE(np->complete,sms_trigger);
        SUITE_MODIFIED(np);
      }
      else
        if(sms_node_get_trigger((sms_tree*)arg,np)) /* We'll delete the old one! */
        {
          sms_trigger *tp;

          if(option == A_TRIGGER) 
          {
            tp           = np->trigger;
            np->trigger  = (sms_trigger *)arg;
            arg          = (sms_list    *)tp;
          }
          else
          {
            tp           = np->complete;
            np->complete = (sms_trigger *)arg;
            arg          = (sms_list    *)tp;
          }
          SUITE_MODIFIED(np);
        }
        else
          rc = sms_error(SMS_E_NOTFOUND,"%s math problem",STR(msg));
      break;

    case A_VARIABLE:
      /* Since 4.4 we have to be a bit more suttle */

      if(r_opt)
      {
        if(ls_find(&np->variable,arg->name))
        {
          sms_list_delete_name(&np->variable,arg->name);
          SUITE_MODIFIED(np);
        }
        del = TRUE;
      }
      else
      {
        sms_variable *vp;
        sms_variable *ap = (sms_variable *)arg;

        vp = ls_find(&np->variable,ap->name);

        if( vp )                   /* Update use NIDs! */
        {
          char *tmp = vp->value;   /* Swap value */
          vp->value = ap->value;   /* arg can be freed */
          ap->value = tmp;
          SUITE_CHANGED((sms_node *)vp);
          SUITE_CHANGED((sms_node *)vp->parent);
        }
        else
        {
          sms_list_add(&np->variable,ap);
          ap->parent = np;
          SUITE_MODIFIED(np);
          del = FALSE;
        }

      }
      break;

    case A_STATUS:
      if( i>=0 && i<STATUS_USABLE )
      {
        np->defstatus = i;
        SUITE_CHANGED(np);
      }
      else
        rc = sms_error(SMS_E_PROTOCOL,"%s illegal status %d",STR(msg),i);
      break;

    case A_TEXT:
      if(r_opt) sms_list_delete_all(&np->text);
      else      sms_list_add(&np->text,arg);
      del = r_opt;
      SUITE_MODIFIED(np);
      break;

    case A_METER:
      if( np->type != NODE_METER )
        rc=sms_error(SMS_E_STATUS,"alter:%s not meter",STR(sms_node_full_name(np)));
      else
        if( ! sms_status_change(np,i,TRUE,FALSE))
          rc=sms_error(SMS_E_STATUS,"alter:%s",STR(sms_node_full_name(np)));
        else
          SUITE_CHANGED(np);
      break;

    case A_LABEL:
      if( np->type != NODE_LABEL )
        rc=sms_error(SMS_E_STATUS,"alter:%s not label",STR(sms_node_full_name(np)));
      else
        if( ! sms_status_change_label((sms_label*)np,arg->name))
          rc=sms_error(SMS_E_STATUS,"alter:%s",STR(sms_node_full_name(np)));
        else
          SUITE_CHANGED(np);
      break;

    case A_FLAG_ON:
      if( i == FLAG_MAX )
      {
        int f;
        for( f=0 ; f<FLAG_MAX ; f++)
          FLAG_SET(np,f);
        SUITE_CHANGED(np);
        spit(0,IOI_WAR,"alter:%s all flags on",STR(fn));
      }
      else
        if( ! FLAG_ISSET(np,i) )
        {
          FLAG_SET(np,i);
          SUITE_CHANGED(np);
        }
      break;

    case A_FLAG_OFF:
      if( i == FLAG_MAX )
      {
        np->flags = 0;
        SUITE_CHANGED(np);
        spit(0,IOI_WAR,"alter:%s all flags off",STR(fn));
      }
      else
        if( FLAG_ISSET(np,i) )
        {
          FLAG_CLEAR(np,i);
          SUITE_CHANGED(np);
        }
      break;

    case A_REPEAT:
      rc = sms_repeat_alter((sms_repeat*)np,arg->name);
      break;

    case A_LIMITVALUE:
    case A_LIMITMAX:
    case A_LIMITNAME:
      if( np->type != NODE_LIMIT )
        rc = sms_error(SMS_E_STATUS,"alter:%s not limit",STR(sms_node_full_name(np)));
      else
        rc = alter_limit((sms_limit*)np, option, r_opt, arg);
      break;

    default:
      rc = sms_error(SMS_E_PROTOCOL,"alter:donno the option %d",option);
  }

  if( rc != SMS_E_OK ) del = TRUE;

  if( del && ! r_opt )             /* If remove the sms_cmd.c handles this */
    NODE_FREE(arg,sms_list);

  return
    ( rc != SMS_E_OK )?
    rc 
    :
    spit(SMS_E_OK,IOI_MSG,"alter:%s [%s%s] by %s",
         STR(fn) , STR(&(opts[option].name[2])) , r_opt?"/remove":"" , STR(SMS_USER));
}

int sms_alter_cmd(int argc, char **argv)
/**************************************************************************
?  Alter the node in SMS
************************************o*************************************/
{
  static int flag_lens[FLAG_MAX + 1];
  static char *f_str[ (FLAG_MAX+2+1)/4 + 1];

  static int   called;
  static char *name;
  static char *dummy;

  static int   remove_o;           /* To remove the definition */

  static int   options[MAX_OPTIONS];

  int i;

  if( !called )
  {
    char *s;
    int  i,j;

    ioi_user_fmcl(flag_alter_name,flag_lens,FLAG_MAX+1);

    for( j=0,i=0 ; i <= FLAG_MAX ; i++ )
    {
      if( ! (i%4) )
      {
        j = i/4;
        s = f_str[j] = malloc(MAXNAM);
      }
      sprintf(s,"%s ;   ",STR(flag_alter_name[i]));
      s += strlen(s);
    }
  }

  if( called )
  {
    sms_list *gen = NULL;
    char     *av[2];
    int       option;
    int       rc;
    char     *tmp;

    sms_node   *np;
    sms_handle *hp;
    char       *newname;
    char       *mark = NULL;
    char       *tmpstr;
    char       colon = ':';
    char       namealloc = FALSE;

    if( dummy ) { argc++; argv--; }

    for( rc=0,i=0 ; i<MAX_OPTIONS ; i++ )
    {
      if(options[i])               /* Count used options */
      { rc++; option=i; }          /* And remember the used option */
    }

    if(rc != 1)
      return ioi_out(0,IOI_ERR,"alter:must use one and only one option");

    if( remove_o && ! opts[option].with_r )
      return
        ioi_out(0,IOI_ERR,"alter:option -%c [%s] cannot be used with -r",
                opts[option].name[1], STR(&(opts[option].name[2])));

    if( argc < (remove_o?opts[option].min_with_r:opts[option].min_param) )
      return
        ioi_out(0,IOI_ERR,"alter:too few params for option -%c [%s]",
                opts[option].name[1],STR(&(opts[option].name[2])));

    /* If using -V option then need to convert parameters into
       equivalent -v option parameters */
    if (option == A_VARIABLE2)
    {
      argc++;
      argv--;

      /* At this stage name points to argv[0]. Need to make a copy of the
         string contained within argv[0] to save the nodename as argv[0]
         is about to be reduced to the variable name only */
      name = strdup(argv[0]);
      namealloc = TRUE;

      /* Convert argv[0] to be the variable name only */
      mark = strrchr((char *)argv[0], (int)colon);
      /* Need to check for NULL pointer */
      if (mark == NULL)
      {
        printf("argv[0]=%s\n", argv[0]);
        if (namealloc)
        {
          IFFREE(name);
        }
        return
          ioi_out(0,IOI_ERR,"alter:no character %c found in argument %s\nsyntax: alter -V fullnodename:variable definition",
                colon, STR(argv[0]));
      }

      tmpstr = strdup(++mark);
      (void) strcpy((char *)argv[0], tmpstr);
      IFFREE(tmpstr);

      /* Convert name to be the node name only */
      mark = NULL;
      mark = strrchr(name, (int)colon);
      /* Need to check for NULL pointer */
      if (mark == NULL)
      {
        if (namealloc)
        {
          IFFREE(name);
        }
        return
          ioi_out(0,IOI_ERR,"alter:no character %c found in argument %s\nsyntax: alter -V fullnodename:variable definition",
                colon, STR(name));
      }
      *mark = '\0';

      /* Reset option and options array to configuration for -v option */
      option = A_VARIABLE;
      options[A_VARIABLE2] = 0;
      options[A_VARIABLE] = 1;
         
    }

    if( argc==0 || (remove_o && !(option==A_DATE || option==A_TIME)) )
      gen = GEN sms_node_create(argc?argv[0]:"");
    else switch( option )
    {
      case A_ACTION:
        gen = GEN sms_play_create_action(2,argv[0]);
        break;

      case A_CLOCK:
        if((rc=ioi_user_cmdf(*argv,clock_name,NULL,CLOCK_MAX))==NIL)
          return ioi_out(0,IOI_ERR,"alter:Illegal clock name %s",STR(*argv));
        gen = GEN sms_node_create(itoa(rc));
        break;

      case A_DATE:
        gen = GEN sms_play_create_date(argv[0]);
        break;

      case A_DAY:
        gen = GEN sms_play_create_day(argc,argv);
        break;

      case A_EVENT:
        gen = GEN sms_play_create_event( argv[0] );
        break;

      case A_GAIN:
        if( sms_play_gain(argc,argv,&rc)==0 )
          return ioi_out(0,IOI_ERR,"alter:Illegal gain");
        gen = GEN sms_node_create(itoa(rc));
        break;

      case A_OWNER:
        {
          int uid = atoi(argv[1]);
          int gid = atoi(argv[2]);

          if( sms_is_number(argv[1]) && sms_is_number(argv[2]) )
            gen = GEN sms_play_user( argv[0] , uid , gid );
          else
            return
              ioi_out(0,IOI_ERR,"alter:Illegal uid/gid %s %s",STR(argv[1]),STR(argv[2]));
        }
        break;

      case A_TIME:
        gen = GEN sms_play_create_time( argv[0] ,
                    argc>=3 ? argv[1]:NULL , argc>=3 ? argv[2]:NULL , 0 );
        break;

      case A_TRIGGER:
        gen = GEN sms_play_create_trigger(argc,argv,NODE_TRIGGER);
        break;

      case A_COMPLETE:
        gen = GEN sms_play_create_trigger(argc,argv,NODE_COMPLETE);
        break;

      case A_VARIABLE:
        gen = GEN sms_play_variable(argv[0],argv[1]);
        break;

      case A_STATUS:
        if((rc=ioi_user_cmdf(*argv,status_name,NULL,STATUS_MAX))==NIL)
          return ioi_out(0,IOI_ERR,"alter:Illegal status name %s",STR(*argv));
        gen = GEN sms_node_create(itoa(rc));
        break;

      case A_TEXT:
        gen = GEN sms_play_create_text(argc,argv);
        break;

      case A_METER:
        tmp = *argv;
        rc  = atoi(*argv);
        if(tmp && sms_is_number( (*tmp=='-')? tmp+1 : tmp ) )
          gen = GEN sms_node_create(itoa(rc));
        else
          return ioi_out(0,IOI_ERR,"alter:meter must be a number [%s]",STR(*argv));
        break;

      case A_LABEL:
        {
          char buff[MAXLEN];

          sms_play_label_argv2string(argc,argv,buff,MAXLEN);
          gen = GEN sms_node_create(buff);
        }
        break;

      case A_FLAG_ON:
      case A_FLAG_OFF:
        if((rc=ioi_user_cmdf(*argv,flag_alter_name,flag_lens,FLAG_MAX+1))==NIL)
          return ioi_out(0,IOI_ERR,"alter:Illegal flag name %s",STR(*argv));
        gen = GEN sms_node_create(itoa(rc));
        break;

      case A_REPEAT:
        gen = GEN sms_node_create(*argv);
        break;

      case A_LIMITVALUE:
      case A_LIMITMAX:
        if(sms_is_number(*argv))
          gen = ls_create(0,*argv);
        else
          return ioi_out(0,IOI_ERR,"alter:limitvalue must be a number [%s]",STR(*argv));
        break;

      case A_LIMITNAME:
        ls_argv(&gen, argc, argv);
        break;
    }
 
    if( !gen )
      return ioi_out(0,IOI_ERR,"alter:no action taken");

    /* Expand the node name */

    if( ! (newname=sms_cd_name2(name)) )
      return FALSE;

    np = sms_node_net_find( newname );
    hp = sms_node_find_handle(np);

    if( !hp ) return 0;

    av[0]="alter";                         /* Get the original name    */
    av[1] = sms_node_full_name(np);

    rc = sms_client_cmd( hp, 2, av, NULL, (1<<(option+1))|remove_o, &gen );

    NODE_FREE(gen,sms_list);

    if (namealloc)
    {
      IFFREE(name);
    }

    return ! rc;
  }
  else
  {
    static char  r_effect[MAXNAM];
    char        *s;

    strcpy(r_effect,"Effects the options:");
    s = r_effect;
    while( *s ) s++;

    for( i=0 ; i<MAX_OPTIONS ; i++ )
      if( opts[i].with_r )
      {
        *s++ = ' ';
        *s++ = '-';
        *s++ = opts[i].name[1];
      }

    ioi_exe_add("alter:cdp",sms_alter_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
            "-rremove",IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter by removing. This is a bit risky in repeated suites.",
            r_effect,
            NULL
          ),NULL,1,&remove_o
        ),
        ioi_exe_param(
          OPTION(A_ACTION),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the action script submitted by SMS at given status.",
            "syntax:    status script",
            "      : -r status",
            NULL
          ),NULL,1,&options[A_ACTION]
        ),
        ioi_exe_param(
          OPTION(A_CLOCK),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the clock type of the SUITE, must be complete or unknown",
            "syntax:    clocktype",
            NULL
          ),NULL,1,&options[A_CLOCK]
        ),
        ioi_exe_param(
          OPTION(A_DATE),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the date dependency of the node.",
            "syntax:    DATE",
            "syntax: -r [DATE]            // specify which date is removed",
            NULL
          ),NULL,1,&options[A_DATE]
        ),
        ioi_exe_param(
          OPTION(A_DAY),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the day dependency of the node.",
            "syntax:    weekdays",
            "syntax: -r",
            NULL
          ),NULL,1,&options[A_DAY]
        ),
        ioi_exe_param(
          OPTION(A_EVENT),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the events in the TASK.",
            "syntax:    event [name]",
            "syntax: -r eventname",
            NULL
          ),NULL,1,&options[A_EVENT]
        ),
        ioi_exe_param(
          OPTION(A_FLAG_ON),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the flag by turning it on",
            "syntax:    flagname",
            "flagname is one of:",
            f_str[0], f_str[1], f_str[2], f_str[3],
            NULL
          ),NULL,1,&options[A_FLAG_ON]
        ),
        ioi_exe_param(
          OPTION(A_FLAG_OFF),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the flag by turning it off",
            "syntax:    flagname",
            "flagname is one of:",
            f_str[0], f_str[1], f_str[2], f_str[3],
            NULL
          ),NULL,1,&options[A_FLAG_OFF]
        ),
        ioi_exe_param(
          OPTION(A_GAIN),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the gain of the clock in the SUITE.",
            "syntax:    gains (see the clock(cdp))",
            "syntax: -r",
            NULL
          ),NULL,1,&options[A_GAIN]
        ),
        ioi_exe_param(
          OPTION(A_OWNER),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the owners of the node.",
            "syntax:    user uid gid      // add a new user",
            "syntax: -r user",
            NULL
          ),NULL,1,&options[A_OWNER]
        ),
        ioi_exe_param(
          OPTION(A_TIME),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the time dependency of the node.",
            "syntax:    TIME [END INC]",
            "syntax: -r [TIME]            // specify which time is removed",
            NULL
          ),NULL,1,&options[A_TIME]
        ),
        ioi_exe_param(
          OPTION(A_TRIGGER),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the trigger mathematics of the node.",
            "syntax:    triggermath       // replace the trigger math",
            "syntax: -r",
            NULL
          ),NULL,1,&options[A_TRIGGER]
        ),
        ioi_exe_param(
          OPTION(A_VARIABLE),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the variable in the node.",
            "syntax:    variable definition",
            "syntax: -r variable",
            NULL
          ),NULL,1,&options[A_VARIABLE]
        ),
        ioi_exe_param(
          OPTION(A_STATUS),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the default status of the node.",
            "syntax:    status",
            NULL
          ),NULL,1,&options[A_STATUS]
        ),
        ioi_exe_param(
          OPTION(A_TEXT),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the comment text of the node.",
            "syntax:    \'text'",
            "syntax: -r                   // remove all comments",
            NULL
          ),NULL,1,&options[A_TEXT]
        ),
        ioi_exe_param(
          OPTION(A_METER),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the meter value",
            "syntax:    metername integer",
            "syntax: -r metername ",
            NULL
          ),NULL,1,&options[A_METER]
        ),
        ioi_exe_param(
          OPTION(A_LABEL),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the label value",
            "syntax:    labelname text",
            "syntax: -r labelname",
            NULL
          ),NULL,1,&options[A_LABEL]
        ),
        ioi_exe_param(
          OPTION(A_REPEAT),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the repeat value",
            "syntax:    alter -R node:REPEATVARNAME [integer/string]",
            "For integer repeat the value must be withing the limits",
            "For string repeat the value is either integer index or a string",
            "from the lists of possible values",
            "For enumerated repeat the value is either integer index or a integer value",
            "from the lists of possible values",
            NULL
          ),NULL,1,&options[A_REPEAT]
        ),
        ioi_exe_param(
          OPTION(A_COMPLETE),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the complete tag mathematics of the node.",
            "syntax:    triggermath       // replace the complete tag math",
            "syntax: -r",
            NULL
          ),NULL,1,&options[A_COMPLETE]
        ),
        ioi_exe_param(
          OPTION(A_LIMITVALUE),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the limit tag value (eg after cancel).",
            "syntax:    limitname newvalue     // between zero and max",
            "syntax: -r limitname",
            NULL
          ),NULL,1,&options[A_LIMITVALUE]
        ),
        ioi_exe_param(
          OPTION(A_LIMITMAX),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the limit tag max value (more or less jobs to run).",
            "syntax:    limitname newmaxvalue  // greater or equal to zero",
            NULL
          ),NULL,1,&options[A_LIMITMAX]
        ),
        ioi_exe_param(
          OPTION(A_LIMITNAME),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the limit tag names, remove the named from the list",
            "syntax:    limitname name [...]   // count is reduced also",
            NULL
          ),NULL,1,&options[A_LIMITNAME]
        ),
        ioi_exe_param(
          OPTION(A_VARIABLE2),IOI_L_BOOLEAN,ioi_exe_argv(
            "Alter the variable in the node.",
            "syntax:    fullnodename:variable definition",
            "syntax: -r fullnodename:variable",
            NULL
          ),NULL,1,&options[A_VARIABLE2]
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node",IOI_L_STRING,ioi_exe_argv(
            "The name of the node to be altered according the options.",
            "The $cwn is used for names which do not begin with '/'.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),"cwn",-1,&name
        ),
        ioi_exe_param(
          "param(s)",IOI_L_STRING,ioi_exe_argv(
            "Varies according to the other options used.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Alter the node according to the options given.",
        "The syntax for different parameters is the same as in the play(cdp).",
        "","EXAMPLE","",
        "alter -v /x/y/z SMSCMD \"qsub -x %SMSJOB%\"",
        "alter -V /x/y/z:SMSCMD \"qsub -x %SMSJOB%\"",
        "alter -m /x/y/z:step 10",
        "alter -l /x/y/x:filename xyz",
        "","Syntax is not nice, but not likely to improve in near future",
        NULL
      )
    );
  }

  return called = TRUE;
}

