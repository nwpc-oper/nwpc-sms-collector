/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     ALIAS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-DEC-1998 / 28-NOV-1998 / OP
.VERSION  4.4
.FILE     status.c
.LANGUAGE ANSI-C
*         Aliased tasks
*         Cloned nodes
************************************o*************************************/

/*
Cloned nodes. Like alias but copy the whole tree.

What exactly is cloned?

After clone:

  - Status is suspended

  - Triggers? External? Cross-Suite? (User command)

  - Clock is removed for suite.
*/

/*
The idea of aliasing is that there can be multiple copies of same task
running simultaenously.

Since alias(es) are created only under special circumstanses we can afford
SMS clients (XCdp or CDP) to inquire the whole tree again. That is we
create new nodes (as if play -r)

Aliases cannot be created in the definition file.

The need to run an alias may arise at any time, that is at any status of the
task itselft.

  - The task itself will not reflect the status of the alias(es),

  - The alias will not prevent the suite/family (eg with repeat) from
    completing. (Suite can complete, alias is kept independently at its
    own status)

  - The name of the alias is "alias#" where "#" is a number of aliases
    created form this task.

  - Some generated variables are a bit differet.
    User supplied variables SMSSCRIPT, SMSJOBOUT, SMSJOB and SMSNAME are
    ignored and generated variables override them.
    However, variables like TASK are kept from user edit.

This is important for the choise of the output directory, since if the suite
is allowed to complete the output might be viped off. Also some tasks use the
name %TASK% to trigger their behaviour.

  [s] [f] [tx]
          [ty] TASK=ty, SMSNAME=/s/f/ty, SMSJOB=.../s/f/ty.1
          [tz]

--->

  [s] [f] [tx]
          [ty]               ; TASK=ty, SMSNAME=/s/f/ty,    SMSJOB=.../s/f/ty.1
               [A1,active]   ; TASK=ty, SMSNAME=/s/f/ty/A1, SMSJOB=.../s/f/A1.1
               [A2,submitted]; TASK=ty, SMSNAME=/s/f/ty/A2, SMSJOB=.../s/f/A2.1
          [tz]

Aliases are created by running edit(CDP) or edit(XCdp) with the alias
option. Aliases can be created, but triggered the first time task itself
is run.

How to locate analias?

  -> sms_node_full_name() (No major change, if TASK...kids)
  -> sms_node_find()      (No need to change, if alias status is not propagated)
  -> sms_node_net_name()  (No need to change)
  -> sms_node_find_full() (check for alias, if TASK...kids)

When to delete an alias?

  Immediately it completes? Bad, we need to look at the output
  At suite begin? Only if they are complete.
  How about repeated nodes? Same as begin?
  On user command. We need this anyway, so let's implement it.

  On user command, or autocancel set at smsedit

How to view these aliases?

  In CDP only available if task itself is visible 
  XCdp has more elaborate visibility computation and thus these can be
  switched on separately.

What can be done with the aliases?

  Cancel it
  Run use the same alias number and input file.
  Kill it (SMSKILL)
  Force works ok.

Summa summarum:

  Alias has input edited and variables prepared. The input will still be
  edited with the prepared variables. Input file may have include statements
  in it.
  May be triggered with the task itself.
  Visible only if the task itself is visible.
  Does not prevent suite from completing.

  Status processing is not affected (except that the status of the parent
  of alias(es) does not reflect the status of the aliases)

*/

#include "smslib.h"

static void remove_gen(sms_variable **vars, char *name)
{
  sms_variable *vp;

  if(!vars) return;

  vp = ls_find(vars, name);
  if(vp)
  {
    ls_remove(vars, vp);
    NODE_FREE(vp, sms_variable);
  }
}

sms_node *sms_alias_create(sms_node *np, sms_variable *vars)
/**************************************************************************
?  Create a copy of the node "np" by copying  events, meters, labels,
|  and variables (the list given).
|  Don't copy times, dates, days, triggers, complete, repeat, limits nor inlimit
|
|  mkdir
|  Rename the .usr-file task/alias.sms
|  SMSSCRIPT -> task/alias.sms
|
=  Node
|  Name is running alias number
************************************o*************************************/
{
  sms_node     *ap = 0;

  sms_meter    *mp;
  sms_label    *lp;
  sms_event    *ep;
  sms_variable *vp;

  char buff[MAXLEN];
  /* int  number = 0; */
  int  ispipe;

  char *base  = 0;
  char *fname = SMSSCRIPT(np,&ispipe);

  sms_list     *lines = 0;

  if(!np || np->type != NODE_TASK)
    return 0;

  sprintf(buff,"alias%d",np->alias++);

  ap = sms_play_node(buff, NODE_ALIAS);

  for( ep=np->event ; ep ; ep=ep->next )
    ls_add(&ap->event, sms_play_create_event(ep->name));

  for( mp=np->meter ; mp ; mp=mp->next )
    ls_add(&ap->meter, sms_play_create_meter(mp->name, mp->min, mp->max, mp->color));

  for( lp=np->label ; lp ; lp=lp->next )
  {
    sms_label *tmp = sms_play_create_label(lp->name,0,NULL);

    tmp->def   = strdup(lp->def);
    tmp->value = strdup(lp->def);

    ls_add(&ap->label, tmp);
  }

  for( vp=vars ; vp ; vp=vp->next )
    ls_add(&ap->variable, sms_play_variable(vp->name, vp->value));

  ls_add(&np->kids,ap);
  ap->parent = np;
  sms_node_after_receive(ap);

  /* SCRIPT and SMSNAME are special cases */

  sms_status_default(ap);
  sms_variable_generate(ap, FALSE, FALSE, NULL, NULL);

  remove_gen(&ap->variable,"SMSSCRIPT");
  remove_gen(&ap->variable,"SMSJOBOUT");
  remove_gen(&ap->variable,"SMSJOB");
  remove_gen(&ap->variable,"SMSNAME");
  remove_gen(&ap->variable,"SMSTRYNO");

  /* Make the dir */

  base = sms_variable_get("SMSHOME",ap);
  if( !base ) base=".";
  sms_edit_mkdir_reverse(base,ap);

  /* Copy the file */

  sms_file_read2(fname, &lines, 0, ispipe,NULL); /* Check rc? */
  vp=ls_find(&ap->genvars,"SMSSCRIPT");
  sms_file_write(vp->value, lines);
  NODE_FREE(lines,sms_list);

  SUITE_MODIFIED(ap);

  return ap;
}

