/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     LIMIT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     23-JUL-1998 / 22-JUL-1998 / OP
.VERSION  4.3.21
.LANGUAGE ANSI-C
.FILE     limit.c
.DATE     28-JAN-1998 / 30-OCT-1998 / OP
.VERSION  4.4
.DATE     19-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
*         Inlimit has own type
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*         Limit number of jobs running
*         Limit (pseudo queues) (deleted at 4.4.2)
* 
************************************o*************************************/

#include "smslib.h"

#define FN(np) sms_node_full_name(np)

double sms_limit_evaluate(sms_tree *node)
/**************************************************************************
?  Calculate the value of the expression.
|  Copied from the IOI/MATH.C (with modifications)
|  The value of a limit is taken to be true if (status < limit)
|  Only && supported
************************************o*************************************/
{
#ifdef CRAY
  void (* sig)() = signal(SIGFPE,SIG_IGN);
#endif

  double left, right, rc=0.0;

  if( !node ) return 1.0;          /* If the root is empty! */

  if( node->mtype == M_NAME )
    if( node->math )
    {
      if( node->math->type == NODE_LIMIT )
      {
        sms_limit *lp = (sms_limit *)node->math;

        return (double) (lp->status < lp->limit);
      }

      return (double) node->math->status ;
    }
    else                           /* External unknown node */
      return (double) 1.0;

  left  = sms_limit_evaluate(node->left);
  right = sms_limit_evaluate(node->right);

  switch( node->mtype )
  {
    case M_AND  : rc = (left && right); break;
    default:      rc = 1.0; break; /* Stupid user! */
  }

  return rc;
}

void sms_limit_update(sms_node *np)
/**************************************************************************
?  Make sure the limits are pointed by inlimit
************************************o*************************************/
{
  sms_inlimit *ip = 0;

#ifdef SMS_CROSS_SUITE
  for(ip=np->inlimit ; ip ; ip=ip->next )
    if(ip->mod_no < sms_._modify_number)
    {
      sms_node_get_limit(ip, np);
      ip->mod_no = sms_._modify_number;
    }
#endif
}

int sms_limit_isholding(sms_node *np)
/**************************************************************************
?  Calculate if limit is holding a node.
=  BOOLEAN status.
|  TRUE  == DEPENDENT,
|  FALSE == FREE to go (might also be freed by the operator)
************************************o*************************************/
{
  sms_inlimit *ip = 0;
  sms_limit   *lp = 0;

  if( !np ) return 0;

  sms_limit_update(np);

  for( ip=np->inlimit ; ip ; ip=ip->next )
  {
    int usage = ip->usage;

    if( usage <= 0 ) usage = 1;

    /* Can not be freed like trigger, at the moment */

    lp=ip->limit;

    if( lp )
      if( lp->status + usage > lp->limit )
        return 1;                  /* Does not fit */
  }

  return 0;
}

void sms_limit_mark(sms_limit *lp, int usage, char *fullname)
/**************************************************************************
?  Update the status for all the counters
************************************o*************************************/
{
  if( !lp ) return;

  if( usage>0 || ls_find(&lp->tasks,fullname) )
  {
    lp->status += usage;

    /* printf("sms_limit_mark: %s %s %s %d\n", STR(lp->name), STR(fullname),
              (usage>0)? "adding":"subtracting", usage ); */
  }

  if( usage >= 0 )
  {
    if( !ls_find(&lp->tasks,fullname) )
      ls_add(&lp->tasks,ls_create(0,fullname));
    else
      lp->status -= usage;       /* Was added while it already was there? */
  }
  else
    ls_delname(&lp->tasks,fullname);

  SUITE_CHANGED((sms_node *)lp);
}

int sms_limit_count(sms_node *np)
/**************************************************************************
?  Called originally with NODE_SUPER
************************************o*************************************/
{
  sms_node *tmp;

  int count = 0;

  for( tmp=np->kids ; tmp ; tmp=tmp->next )
    if(tmp->type == NODE_TASK)
    {
      int status = tmp->status;
      if(status == STATUS_SUSPENDED) status = tmp->savedstat;

      if( status == STATUS_ACTIVE || status == STATUS_SUBMITTED )
        count++;
    }
    else
      count += sms_limit_count(tmp);

  return np->count = count;
}

int sms_limit_reached(sms_node *np)
/**************************************************************************
?  Check if a limit has been reached
=  Boolean value, TRUE == we are on or over the limit
************************************o*************************************/
{
  while( np )
  {
    if( sms_limit_isholding(np) )
    {
      FLAG_SET(np,FLAG_QUEUELIMIT);
      return 1;
    }

    FLAG_CLEAR(np,FLAG_QUEUELIMIT);

    if( np->type == NODE_SUPER )
      return 0;

    np = np->parent;
  }

  return 0;
}

void sms_limit_running(sms_node *np)
/**************************************************************************
?  Update the active count when a job is started (submitted)
************************************o*************************************/
{
  char *fn = sms_node_full_name(np);

  while( np )
  {
    sms_inlimit *ip;

    sms_limit_update(np);

    for( ip=np->inlimit ; ip ; ip=ip->next )
    {
      int usage = ip->usage;

      if( usage <= 0 ) usage = 1;

      sms_limit_mark(ip->limit, usage, fn);
    }

    np->count++;
    if( np->type == NODE_SUPER )
      return;

    np = np->parent;
  }
}

void sms_limit_remove(sms_node *np)
/**************************************************************************
?  Update the active count when a job finishes or if forced
************************************o*************************************/
{
  char *fn = sms_node_full_name(np);

  while( np )
  {
    sms_inlimit *ip;

    sms_limit_update(np);

    for(ip=np->inlimit ; ip ; ip=ip->next)
    {
      int usage = ip->usage;

      if( usage <= 0 ) usage = 1;

      sms_limit_mark(ip->limit, -usage, fn);
    }

    np->count++;
    if( np->type == NODE_SUPER )
      return;

    np = np->parent;
  }
}

void sms_limit_init(sms_node *np)
/**************************************************************************
?  Init limit(s) at begin
************************************o*************************************/
{
  sms_limit *lp;

  if( !np ) return;

  for( lp=np->limit; lp ; lp=lp->next )
  {
    lp->status = lp->base;
    SUITE_CHANGED((sms_node *)lp);
  }

  for( np=np->kids ; np ; np=np->next )
    sms_limit_init(np);
}

static void limit_reset(sms_limit *lp)
/**************************************************************************
?  Check the limit for non-existing task and remove them and reset the
|  counter.
|  Only on user command (user should be ware of migrated nodes!)
************************************o*************************************/
{
  sms_list *t;
  int       count = 0;             /* How many nodes were removed? */
  int       old_status = lp->status;

  if( !lp ) return;

  lp->status = lp->base;

  for( t=lp->tasks ; t ; )
  {
    sms_list *next = t->next;
    sms_node *np;

    int  remove = 0;

    if( ! (np=sms_node_find_full(t->name)) )
      remove = spit(1,IOI_WAR,"limit:removed %s (not found)",STR(t->name));
    else
    {
      int status = np->status;
      if(status == STATUS_SUSPENDED) status = np->savedstat;

      if( status != STATUS_SUBMITTED && status != STATUS_ACTIVE )
        remove = spit(1,IOI_WAR,"limit:removed %s (status is %s)",
                      STR(t->name), STR(status_name[status]));
    }

    if(remove)
      ls_delete(&lp->tasks, t);
    else
    {                              /* We have node so let's find the usage */
      while(np)
      {
        sms_inlimit *ip;

        for(ip=np->inlimit ; ip ; ip=ip->next)
          if(ip->limit == lp)
          {
            int usage = ip->usage;

            if( usage <= 0 ) usage = 1;

            lp->status += usage;
            np = 0;
          }

        if(np) np = np->parent;
      }
    }

    count += remove;

    t = next;
  }

  if(count || old_status != lp->status)
  {  
    SUITE_CHANGED((sms_node *)lp);
    spit(0,IOI_MSG,"limit:reset %s by %s",STR(sms_node_full_name(lp)),STR(SMS_USER));
  }
  else
    spit(0,IOI_DBG,"limit:reset %s by %s everything is ok",
         STR(sms_node_full_name(lp)),STR(SMS_USER));
}

void sms_limit_reset(sms_node *np)
/**************************************************************************
?  Reset the limits recursively
|  Only on user command (user should be ware of migrated nodes!)
************************************o*************************************/
{
  sms_limit *lp;

  if(!np) return;

  if(np->type == NODE_LIMIT)
    limit_reset((sms_limit*)np);
  else
  {
    for( lp=np->limit ; lp ; lp=lp->next )
      limit_reset(lp);
 
    for( np=np->kids ; np ; np=np->next )
      sms_limit_reset(np);
  }
}

void sms_limit_info(sms_node *np)
/**************************************************************************
?  Print the info of a limit
************************************o*************************************/
{
  sms_limit *lp;

  for(lp=np->limit ; lp ; lp=lp->next)
  {
    sms_list *t;

    printf("  limit %s [running %d max %d] \n",STR(lp->name), lp->status, lp->limit);
    for( t=lp->tasks ; t ; t=t->next )
    {
      sms_node *tp = sms_node_find_full(t->name);

      printf("       %s [%s]\n",STR(t->name), tp? STR(status_name[tp->status]) : "external");
    }
  }
}
