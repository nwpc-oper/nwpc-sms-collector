/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     KILL
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     25-AUG-1994 / 03-MAR-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-1
.FILE     kill.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     11-JAN-1999 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
*         Aliased tasks
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  sms_kill(sms_node *np)
*  cdp_kill_cmd(int argc, char **argv)
*
*  The logics in killing is that the status of the task is not changed.
*  Only a flag is set to indicate a successfull attempt of the kill.
*  SMS has no means to verify that a kill has succeeded. It is up to the
*  user to take the next action (requeue/force aborted/force complete)
*
*  Killing a whole family is possible if enabled from the config.h file.
*  Only active task are killed (strickly spealing tasks with a valid RID)
************************************o*************************************/

#include "smslib.h"

static int count;

int sms_kill(
    sms_node *np,                  /* Privileges are already checked */
    int       rerun, 
    int       firsttime)
/**************************************************************************
?  The SMS part of the kill
=  SMS-RETURN-CODE
************************************o*************************************/
{
  if(firsttime) count = 0;

#ifndef SMS_RECURSIVE_KILL
  if( np->type != NODE_TASK )
    return sms_error(SMS_E_TASK,"kill:%s",STR(sms_node_full_name(np)));
#else
 if( ! sms_cmd_typeok("kill",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
    return SMS_E_TYPE;
#endif

  if( np->type==NODE_TASK || np->type==NODE_ALIAS )
    if( np->rid != 0 )
      if( sms_system_kill(np) == 0 )
      {
        FLAG_SET(np,FLAG_KILLED);
        SUITE_CHANGED(np);
        count++;
      }
      else
        return SMS_E_UNIX;
    else                         /* Do nothing yet */
      ;
  else                           /* Family/Suite */
  {
    sms_node *kids;
    int       rc;

    for( kids = np->kids; kids ; kids=kids->next )
      if( (rc=sms_kill(kids,rerun,FALSE)) != SMS_E_OK )
        return rc;
  }

  if(firsttime && count==0)
    return sms_error(SMS_E_KILL,"kill:%s",STR(sms_node_full_name(np)));

  return SMS_E_OK;
}

int cdp_kill_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static int   rerun;
  static char *dummy;

  if( called )
  {
    char     *av[2] = {"kill"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,rerun,&names);
  }
  else
    ioi_exe_add("kill:cdp",cdp_kill_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-rrerun",IOI_L_BOOLEAN,ioi_exe_argv(
            "Re-run the job after killing it",
            "Currently not implemented.",
            NULL
          ),NULL,1,&rerun
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
#ifdef SMS_RECURSIVE_KILL
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name of the node(s) to be killed. If the node is a task",
            "it is killed, otherwise it is recursive searched for active",
            "tasks, which are killed.",
#else
          "task(s)",IOI_L_STRING,ioi_exe_argv(
            "The name of the task(s) to be killed.",
#endif

#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            "Killing only sets the kill flag, it does not resend the task.",
            "That is, it's up to the task to receive the kill signal or the",
            "user reruns the task(s)",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Kill sms-job(s) while in execution.",
        "Only works on active tasks. The contents of the variable %SMSKILL%",
        "for the task is executed, but only if tasks request identification",
        "(RID) is known. RID is cleared when task completes and when jobs",
        "is submitted (this is needed if job is rerun while active.)",
        "Example edit SMSKILL 'qdel -u xxxx -15 %SMSRID% &'",
        NULL
      )
    );

  return called = TRUE;
}

/*======================================================================================*/

int sms_jobcheck(
    sms_node *np                  /* Privileges are already checked */
	)
/**************************************************************************
?  The SMS part of the jobcheck
=  SMS-RETURN-CODE
************************************o*************************************/
{
	char line[1024];
	int rc;
	sms_list *lp = 0;

	if( ! sms_cmd_typeok("jobcheck",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,
		NODE_TASK,NODE_ALIAS,0)) return SMS_E_TYPE;

	if(!sms_edit_variable(np,"SMSJOBCHECK",line))
		return SMS_E_JOBCHECK;

	rc = sms_file_read2(line,&lp,MAXLINES,TRUE,NULL);
	if(rc == SMS_E_OK)
	{
		ls_join(&sms_._reply, lp);
	}
	else
	{
		ls_delall(&lp);
		lp = 0;
		return rc;
	}
	return SMS_E_OK;
}

int cdp_jobcheck_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    char     *av[2] = {"jobcheck"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,0,&names);
  }
  else
    ioi_exe_add("jobcheck:cdp",cdp_jobcheck_cmd,
      ioi_exe_link_param(
	  	NULL
		),
      ioi_exe_link_param(
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name of the node(s) to be checked. If the node is a task",
            "it is checked, otherwise it is recursive searched for active",
            "tasks, which are hecked.",

#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Check if sms-job(s) are running.",
        "Only works on active tasks. The contents of the variable %SMSJOBCHECK%",
        "for the task is executed, but only if tasks request identification",
        "(RID) is known. RID is cleared when task completes and when jobs",
        "is submitted (this is needed if job is rerun while active.)",
        NULL
      )
    );

  return called = TRUE;
}
