/**************************************************************************
.TITLE    CDP
.NAME     MAIL
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     05-DEC-1998 / 03-DEC-1998 / OP
.LANGUAGE ANSI-C
.FILE     mail.c
.VERSION  4.4
*         Primitive talk/mail
*         Message Of Today (MOT)
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*         This file handles the SMS mail
*
* Notice! This whole thing grew up from ECMWF's totally iron age policy
*         regarding the use of tools like talk/talkd and mobile phone
*         Hey a......s this is 1998! Next you'll band Java because it
*         could be usefull?
*
*         Ok, at the same time implement something which normal e-mail
*         does not have, you can check if user has read your mail ;-)
*
************************************o*************************************/

#include "smslib.h"

static sms_list *mot;

static int ismot(char *user)
{
  return ! strcmp(user,"SMS");
}

static int match(char *user, sms_connect *cp)
{
  int ulen = strlen(user);

  if( ismot(user) ) return 1;
  if( strcmp(user,"*")==0 ) return 1;
  if( strcmp(user,cp->name)==0 ) return 1;
  if( strncmp(user,cp->name,ulen)==0 && cp->name[ulen]=='@' ) return 1;

  return 0;
}

static void prefix(sms_list *lp)
{
  char        buff[MAXLEN];
  time_t      stamp;
  struct tm  *tod;

  stamp = sms_time_t(NULL);        /* Build the time format */
  tod   = localtime(&stamp);

  for( ; lp ; lp=lp->next )
  {
    sprintf(buff,"%02d:%02d:%02d %s: %s",
            tod->tm_hour, tod->tm_min, tod->tm_sec,
            STR(SMS_USER), STR(lp->name));
    IFFREE(lp->name);
    lp->name = strdup(buff);
  }
}

static int mail_add(char *user, sms_list *lines)
/**************************************************************************
?  Add lines into users mailbox
=  SMS_ERROR
************************************o*************************************/
{
  sms_connect *cp;
  int          len = ls_len(&lines);
  int          delivered = 0;

  prefix(lines);
  
  for( cp=sms_._connect ; cp ; cp=cp->next )
    if(match(user, cp))
    {
      ls_copy(&cp->mail, lines);
      cp->num += len;

      delivered++;
      spit(0,IOI_MSG,"mail:from %s to %s",STR(SMS_USER),STR(cp->name));
    }

  if( ismot(user) )
    ls_copy(&mot,lines);

  if( !delivered )
    return sms_error(SMS_E_USERFOUND,"mail:send to %s",STR(user));

  return SMS_E_OK;
}

static int mail_delete(int lastline)
/**************************************************************************
?  Delete lines from your own mailbox
=  SMS_ERROR
************************************o*************************************/
{
  sms_connect *cp = sms_._current_con;

  int len = ls_len(&cp->mail);

  if(lastline > cp->num)           /* I haven't made these lines yet! */
    return sms_error(SMS_E_MAIL,"mail:%s line does not exist?",STR(SMS_USER));

  if(lastline < (cp->num-len))     /* Heck I don't have these lines! */
    return sms_error(SMS_E_MAIL,"mail:%s line does not exist??",STR(SMS_USER));

  len = lastline - (/*firstline*/ cp->num - len);

  spit(0,IOI_MSG,"mail:deleted %d lines from %s",len,STR(SMS_USER));

  for( ; len ; len-- )
    ls_delete( &cp->mail, cp->mail );

  return SMS_E_OK;
}

static mail_get(int lastline)
/**************************************************************************
?  Get lines after lastline
|  Compute the right line number, if nothing to be send return NONEWS
=  SMS_ERROR
************************************o*************************************/
{
  static sms_list lp;
  static char     buff[20];        /* Overflow? not that many lines? */

  sms_connect *cp    = sms_._current_con;
  int          len   = ls_len(&cp->mail);
  int          first = cp->num - len;
  int          skip  = lastline - first;

  /* printf("MAIL get: last=%d first=%d len=%d skip=%d\n",lastline,first,len,skip); */

  if(skip<0) skip=0;
  if(skip>len) skip=len;

  lp.type = NODE_LIST;
  lp.name = buff;
  lp.next = ls_item(&cp->mail,skip);

  sprintf(buff,"%d",cp->num);

  cp->received = cp->num;

  sms_._staticlist = &lp;

  if( !lp.next )
    return SMS_E_NONEWS;

  return SMS_E_OK;
}

int sms_mail(int cmd, int number, sms_list *lines)
/**************************************************************************
?  Delete lines from your own mailbox
=  SMS_ERROR
************************************o*************************************/
{
  int rc = SMS_E_OK;

  switch(cmd)
  {
    case MAIL_GET:
      rc = mail_get(number);
      break;

    case MAIL_DEL:
      rc = mail_delete(number);
      break;

    case MAIL_SEND:
      if( (strcmp(lines->name,"*")==0 || ismot(lines->name)) &&
          ! (PRIVILEGE(PR_ADMIN) || PRIVILEGE(PR_OPER)) )
        return sms_error(SMS_E_PRIVILEGE,"mail:to all");

      rc = mail_add(lines->name,lines->next);
      break;

    case MAIL_DELMOT:
      ls_delall(&mot);
      break;
  }

  return rc;
}

void sms_mail_init(sms_connect *cp)
/**************************************************************************
?  Add Message Of Today to the users mail at the login
************************************o*************************************/
{
  if(!cp) return;

  ls_copy(&cp->mail, mot);
  cp->num += ls_len(&mot);
}
