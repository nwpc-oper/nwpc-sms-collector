/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     OVERVIEW
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     05-NOV-1992 / 07-APR-1992 / OP
.VERSION  4.1
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     overview.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     10-OCT-1998 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
************************************o*************************************/

#include "smslib.h"

static sms_list *list[STATUS_USABLE];

static int statusmask;
static int tasks;                  /* If TRUE do NOT include */
static int families;               /* If TRUE do NOT include */
static int suites;                 /* If TRUE do NOT include */

static void process(sms_node *np)
/**************************************************************************
?  Build the lists.
************************************o*************************************/
{
  if( ( np->type == NODE_TASK   && !tasks    ) ||
      ( np->type == NODE_FAMILY && !families ) ||
      ( np->type == NODE_SUITE  && !suites   ) )
    sms_list_add(&list[np->status],sms_node_create(sms_node_full_name(np)));

  for( np=np->kids ; np ; np=np->next )
    process(np);
}

int sms_overview(int status, sms_node *np)
/**************************************************************************
?  Count the number of nodes having the status asked
|  Used by the curses status.
************************************o*************************************/
{
  static int count;

  if( np->type == NODE_SUPER )
    count = 0;
  else
    if( np->status == status )
      count++;

  for( np=np->kids ; np ; np=np->next )
    sms_overview(status,np);

  return count;
}

int cdp_overview_cmd(int argc, char **argv)
/**************************************************************************
?  Crude overview command a'la XCdp
************************************o*************************************/
{
  static int   called;
  static int   order;
  static int   print;
  static char  masks[10];

  if( called )
  {
    int i;

    if( sms_cdp_update(HANDLE) != SMS_E_OK ) return 0;

#if 0
    statusmask = 0xffffffff;       /* By default show every status */

    if( masks[0] )                 /* User requests only these 2 B shown */
    {
      char *t;

      statusmask = 0;
        for( t=masks ; *t ; t++ )
          for( i=0 ; i<STATUS_SHUTDOWN ; i++ )
            if( status_char[i][0] == *t )
              statusmask |= (1<<i);
 
      if( !statusmask )
        return ioi_out(0,IOI_ERR,"overview:mask:nothing to show");
    }
#else
    statusmask = sms_status_mask(0xffffffff, masks);

    if( !statusmask )
      return ioi_out(0,IOI_ERR,"overview:mask:nothing to show");
#endif

    process(sms_._super);

    for( i=0 ; i<STATUS_USABLE ; i++ )
      if( statusmask & (1<<i) )
      {
        printf("%10s: %d\n",status_name[i],ls_len(&(list[i])));

        if(print)
        {
          if(order) sms_list_sort(&list[i],NULL);
          sms_list_fancy(&list[i]);    /* FIX IT */
        }

        NODE_FREE(list[i],sms_list);
      }

    return TRUE;
  }
  else
    ioi_exe_add("overview:cdp",cdp_overview_cmd,
      ioi_exe_link_param(

        ioi_exe_param(
          "-Ttask",IOI_L_BOOLEAN,ioi_exe_argv(
            "Ignore tasks in the output.",
            NULL
          ),NULL,1,&tasks
        ),
        ioi_exe_param(
          "-Ffamily",IOI_L_BOOLEAN,ioi_exe_argv(
            "Ignore families in the output.",
            NULL
          ),NULL,1,&families
        ),
        ioi_exe_param(
          "-Ssuite",IOI_L_BOOLEAN,ioi_exe_argv(
            "Ignore suites in the output.",
            NULL
          ),NULL,1,&suites
        ),

        ioi_exe_param(
          "-sstatusmask",IOI_L_CHARACTER,ioi_exe_argv(
            "Mask given status from the display. The characters given are",
            "the same as in the curses mode. Use status -h to get curses help.",
            "By default all the modes are displayed.",
            NULL
          ),NULL,10,masks
        ),
        ioi_exe_param(
          "-oorder",IOI_L_BOOLEAN,ioi_exe_argv(
            "Order the nodes alphabetically in each group.",
            NULL
          ),NULL,1,&order
        ),
        ioi_exe_param(
          "-pprint",IOI_L_BOOLEAN,ioi_exe_argv(
            "Print the all the selected nodes.",
            "By default the overview only lists the counts.",
            NULL
          ),NULL,1,&print
        ),

        NULL
      ),
      NULL,
      ioi_exe_argv(
        "Give an overview of the SMS.",
        "By default give a summary of nodes in different status.",
        "List the current SMS (use swap to switch between SMS's.",
        NULL
      )
    );

  return called = TRUE;
}
