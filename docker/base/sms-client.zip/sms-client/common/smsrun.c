/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMSRUN
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     smsrun.c
.DATE     30-MAR-1999 / 10-FEB-1999 / OP
.VERSION  4.4.2
.LANGUAGE ANSI-C
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  Agent to run a script with some tolerance against failures
*  Makes scripts easier to write
*
*
*  environment:
*
*    SMSNAME
*    SMSPASS
*    SMSNODE
*    SMS_PROG
*
************************************o*************************************/

static char *my_name;

static int usage(int code)
{
  fprintf(stderr,"usage: %s [-o outfile] [-m] [-u umask] [-t time] [job]",STR(my_name));
  fprintf(stderr,"  -o outfile  # Full path name for the stdout/stderr\n");
  fprintf(stderr,"  -m          # Make the directory for the output if it does not exist\n");
  fprintf(stderr,"  -t time     # Timeout after secs\n");
  fprintf(stderr,"  -u umask    # Use umask\n");
  fprintf(stderr,"  job         # Execute this job, otherwise read and execute stdin\n");

  exit(code);
}

static int command(int argc, char **argv)
{
  return sms_client_cmd();
}

static int smsinit()
{
  char  rid[MAXLEN];
  char *argv[2];

  if( ! (sms_client_login() )
  {
    error...
  }

  argv[0] = command_name[CMD_INIT];
  sprintf(rid,"%d",getpid());
  argv[1] = rid;

  return command(2,argv);
}

static int smsabort()
{
  char *argv[1];

  argv[0] = command_name[CMD_ABORT];

  return command(1,argv);
}

static int catch(int sig)
{
  smsabort();
  kill the process group();
  exit(1);
}

static void handle_output(char *output, int makedir)
{
  int  i;
  char path[MAX_LEN];

  if(makedir)
    sms_edit_mkdir_reverse(path);

  for( i=0 ; i<NFILES ; i++ )
    close(i);

  open(..)
  dup().
}

static void make_session()
{
  setsid()
  ...
}

static void timeout(int sig) /* Handle timeout */
{
  smsabort();
  kill_session();
  exit(-1)
}

main()
{
  int pid = 0;

  my_name = argv[0];

  handle_output();
  make_session();
  smsinit()

  switch( (pid=fork() )
  {
    case 0: 
      exec
      exit(1);

    case -1:
      exit(1);

  }

  if( time_limit )
  {
    alarm(...);
    signal(SIGALRM,timeout);
  }

  signal(catch, *)
wait -> smscomplete
     -> smsabort

polling
}
