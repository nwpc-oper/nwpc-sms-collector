/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     XDR-SMS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     12-MAR-1992 / 09-AUG-1991 / OP
.ORIGIN   sms_xdr.c by rpcgen & xdr_str.c
.FILE     xdr_sms.c
.VERSION  4.0
*
.DATE     20-APR-1993 / 20-APR-1993 / OP
.VERSION  4.2
.DATE     07-AUG-1994 / 23-FEB-1994 / OP
.VERSION  4.3
.LANGUAGE ANSI-C
*         Added support for meter and label structures
*         Node and repeat modified
*         sms_gen removed (sms_gen == sms_list)
.DATE     13-OCT-1994 / 01-SEP-1994 / OP
.VERSION  4.3.2
*         Added support for the fast login for tasks
*         Suite registering logic changed
.DATE     30-AUG-1995 / 30-AUG-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     27-SEP-1995 / 26-SEP-1995 / OP
.VERSION  4.3.11
*         Added per node logging
*         Label has default
.DATE     16-JAN-1996 / 16-JAN-1996 / OP
.VERSION  4.3.13
*         Added today time dependency
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Added autorestore
.DATE     11-JUN-1998 / 15-JUN-1998 / OP
.VERSION  4.3.19
*         Server timeout
.DATE     18-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     15-DEC-1998 / 24-SEP-1998 / OP
.VERSION  4.4
*         Variables have NIDs
*         Login with nick names
*         Zombie passwords
*         Limit (pseudo queues)
*         Aliased tasks
*         Primitive talk
*         User and zombie requests
.DATE     09-FEB-1999 / 05-FEB-1999 / OP
.VERSION  4.4.1
*         Limit changed
*         Inlimit own type
*         Wait
.DATE     18-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
.DATE     04-FEB-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
*         Times for task state change
.DATE     28-JUN-2001 / 28-JUN-2001 / OP
.VERSION  4.4.5
*         Enumerated repeat
*
*  Routines to "xdr" the SMS-structures.
*
*  The reason not to use the rpcgen(1) generated routines is:
*
*    They don't handle properly the strings and the backfolded structrures
*    (eg parent field in the sms_node) does cause problebs. These can be
*    overcome by cpp(1) directives in the sms.x and by useing own string
*    routine.
*
*    The real reason is that in SMS structures the type field actually
*    defines the type of the structure and different types can be linked
*    together (normally casted as sms_list).
*
*  If a variable named SMSPASS is found and the SMS is configured to strip
*  the passwords and SMS is XDR'ing to unauthorized user the value of the
*  variable is replaced by "stripped"
*
*  Generated variables are not send. The protocol relies on been able to
*  recreate them.
*
************************************o*************************************/

#include "smslib.h"

#define IF         if( !
#define THEN       || cought ) return FALSE;
#define CHAR       (char **)
#define POINT(y)   sms_xdr_pointer(x,(sms_list **)&sp->y)
#define NEXT       sms_xdr_pointer(x,(sms_list **)&sp->next)

#if 0
#define THEN       ) return FALSE;
#endif

#define xdr_time_t(x,y) xdr_int(x,(int *)y)
#define sms_xdr_gen sms_xdr_list

static int timeout = 0;
static int cought  = 0;

static void catch(int sig)
{
  cought++;

  spit(0,IOI_WAR,"xdr-alarm:%s %d",STR(SMS_USER),cought);

  signal(sig,catch);

#ifdef SMS_USE_ALARM
  alarm(1);
#else
#ifdef SMS_USE_JUMP
if (recover_jump)
  longjmp(sms_jump_station,1);
#endif
#endif

}

void sms_xdr_signal(int sec)
{
  timeout = sec;
  signal(SIGALRM,catch);
}

void sms_xdr_arm(void)
{
#if defined(SMS_USE_ALARM) || defined(SMS_USE_JUMP)
  cought = 0;
  if(timeout>0)
    alarm(timeout);
#endif
}

void sms_xdr_release(void)
{
  int left = alarm(0);

  cought = 0;
}

int sms_xdr_list(XDR *x, sms_list *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  return TRUE;
}

int sms_xdr_user(XDR *x, sms_user *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->uid) THEN
  IF xdr_int(x,&sp->gid) THEN
  return TRUE;
}

int sms_xdr_map(XDR *x, sms_map *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF sms_xdr_string(x,&sp->netname) THEN
  IF xdr_int(x,&sp->prog) THEN
  IF xdr_int(x,&sp->vers) THEN
  return TRUE;
}

int sms_xdr_connect(XDR *x, sms_connect *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF sms_xdr_string(x,&sp->host) THEN
  IF xdr_int(x,&sp->uid) THEN
  IF xdr_int(x,&sp->gid) THEN

#if 0                              /* Security!!! */
  IF xdr_int(x,&sp->handle) THEN
#endif

  IF xdr_int(x,&sp->passok) THEN
  IF xdr_time_t(x,&sp->login) THEN
  IF xdr_time_t(x,&sp->idle) THEN

#if 0
  IF xdr_int(x,&sp->clocks) THEN
#endif

  IF xdr_int(x,&sp->vers) THEN
  IF xdr_int(x,&sp->rev) THEN
  IF xdr_int(x,&sp->mod) THEN
  IF xdr_int(x,&sp->newsuites) THEN
  IF POINT(suites) THEN

#if 0
  IF POINT(mail) THEN              /* Cann't read others mail */
#endif
  IF xdr_int(x,&sp->num) THEN
  IF xdr_int(x,&sp->received) THEN

  return TRUE;
}

int sms_xdr_zombie(XDR *x, sms_zombie *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF sms_xdr_string(x,&sp->passwd) THEN
  IF sms_xdr_string(x,&sp->host) THEN
  IF sms_xdr_string(x,&sp->sender) THEN
  IF xdr_time_t(x,&sp->t) THEN
  IF xdr_int(x,&sp->count) THEN
  IF xdr_int(x,&sp->why) THEN
  IF xdr_int(x,&sp->fob) THEN
  IF xdr_int(x,&sp->fail) THEN
  IF xdr_int(x,&sp->recover) THEN
  IF xdr_int(x,&sp->tryno) THEN

  return TRUE;
}

int sms_xdr_passwd(XDR *x, sms_passwd *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->uid) THEN
  IF xdr_int(x,&sp->gid) THEN
  IF xdr_int(x,&sp->rights) THEN
  IF sms_xdr_string(x,&sp->passwd) THEN
  IF xdr_time_t(x,&sp->change) THEN
  IF sms_xdr_string(x,&sp->comment) THEN
  return TRUE;
}

int sms_xdr_variable(XDR *x, sms_variable *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN

#ifdef SMS_STRIP_PASSWD
  if( sms_._is_server && x->x_op == XDR_ENCODE )    /* SMS sending */
  {
    static char *nothing = "stripped";

    if( sms_._xdr_privs != XDR_SERVER &&
        sms_._xdr_privs != XDR_OPER )
      if( ! strcmp(sp->name,"SMSPASS") )
      {
        IF sms_xdr_string(x,&nothing) THEN

        if( ! SUPPORTED(4,4,0) )   /* Import field, Remove when */
        {                          /* only 4.4 or higher in use */
          IF xdr_int(x,&sp->user_int) THEN
        }

        return TRUE;
      }
  }
#endif

  IF sms_xdr_string(x,&sp->value) THEN

  if( ! SUPPORTED(4,4,0) )         /* Import field, Remove when */
  {                                /* only 4.4 or higher in use */
    IF xdr_int(x,&sp->user_int) THEN
  }
  return TRUE;

}

int sms_xdr_time(XDR *x, sms_time *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF xdr_time_t(x,&sp->nexttime) THEN
  IF xdr_time_t(x,&sp->lasttime) THEN
  IF xdr_vector(x,(char *)sp->hour,3,sizeof(int),xdr_int) THEN
  IF xdr_vector(x,(char *)sp->minute,3,sizeof(int),xdr_int) THEN
  IF xdr_int(x,&sp->repeat) THEN
  IF xdr_int(x,&sp->relative) THEN

  if( SUPPORTED(4,3,13) )
  {
    IF xdr_int(x,&sp->today) THEN
  }

  if( SUPPORTED(4,4,3) )
  {
    IF xdr_int(x,&sp->iscron) THEN
    IF xdr_int(x,&sp->weekdays) THEN
    IF xdr_int(x,&sp->monthdays) THEN
    IF xdr_int(x,&sp->months) THEN
  }

  return TRUE;
}

int sms_xdr_date(XDR *x, sms_date *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF xdr_time_t(x,&sp->nextdate) THEN
  IF xdr_int(x,&sp->weekdays) THEN
  IF xdr_int(x,&sp->year) THEN
  IF xdr_int(x,&sp->month) THEN
  IF xdr_int(x,&sp->day) THEN
  return TRUE;
}

int sms_xdr_repeat(XDR *x, sms_repeat *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN

  if( ! SUPPORTED(4,4,5) && x->x_op == XDR_ENCODE )
  {
    int mode = sp->mode;
    if(mode == REPEAT_ENUMERATED) mode=REPEAT_STRING;
    IF xdr_int(x,&mode) THEN
  }
  else
    IF xdr_int(x,&sp->mode) THEN

  IF xdr_int(x,&sp->start) THEN
  IF xdr_int(x,&sp->end) THEN
  IF xdr_int(x,&sp->step) THEN
  IF POINT(str) THEN
  return TRUE;
}

int sms_xdr_tree(XDR *x, sms_tree *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF POINT(left) THEN
  IF POINT(right) THEN
  IF xdr_int(x,&sp->mtype) THEN
  IF xdr_int(x,&sp->level) THEN
  /***NOP IF xdr_int(x,&sp->math) THEN ***/
  return TRUE;
}

int sms_xdr_trigger(XDR *x, sms_trigger *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF POINT(math) THEN
  IF xdr_int(x,&sp->status) THEN
  IF xdr_int(x,&sp->mod_no) THEN
  return TRUE;
}

int sms_xdr_event(XDR *x, sms_event *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  if( ! SUPPORTED(4,3,0) )
  {
    IF xdr_int(x,&sp->user_int) THEN
  }
  IF xdr_int(x,&sp->status) THEN
  IF xdr_int(x,&sp->number) THEN
  return TRUE;
}

int sms_xdr_meter(XDR *x, sms_meter *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF xdr_int(x,&sp->min) THEN
  IF xdr_int(x,&sp->max) THEN
  IF xdr_int(x,&sp->color) THEN
  return TRUE;
}

int sms_xdr_label(XDR *x, sms_label *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF sms_xdr_string(x,&sp->value) THEN

  if( SUPPORTED(4,3,11) )
    IF sms_xdr_string(x,&sp->def) THEN

  return TRUE;
}

int sms_xdr_action(XDR *x, sms_action *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->when) THEN
  return TRUE;
}

int sms_xdr_file(XDR *x, sms_file *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  /* Donno */
  return TRUE;
}

int sms_xdr_dir(XDR *x, sms_dir *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->mode) THEN
  IF xdr_int(x,&sp->uid) THEN
  IF xdr_int(x,&sp->gid) THEN
  IF xdr_int(x,&sp->size) THEN
  IF xdr_int(x,&sp->atime) THEN
  IF xdr_int(x,&sp->mtime) THEN
  IF xdr_int(x,&sp->ctime) THEN
  return TRUE;
}

int sms_xdr_limit(XDR *x, sms_limit *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN

  IF xdr_int(x,&sp->limit) THEN
  IF POINT(tasks) THEN

  if( SUPPORTED(4,4,1) )
  {
    IF xdr_int(x,&sp->limittype) THEN
    IF xdr_int(x,&sp->min) THEN
    IF xdr_int(x,&sp->base) THEN
    IF sms_xdr_string(x,&sp->unit) THEN
  }

  return TRUE;
}

static char *old_name(sms_tree *tp)
{
  if(tp->name) return tp->name;

  if( old_name(tp->left)) return old_name(tp->left);
  if( old_name(tp->right)) return old_name(tp->right);

  return 0;
}

int sms_xdr_inlimit(XDR *x, sms_inlimit *sp)
{
  if( ! SUPPORTED(4,4,1) )
  {
    /* Ok, shit I hate this,
       but we must send/read some crap to/from the wire */

    sms_trigger *tp = sms_alloc(NODE_TRIGGER);

    tp->type = NODE_INLIMIT;

    if(x->x_op == XDR_ENCODE)   /* Talk to an old client */
    {
      tp->math = sms_alloc(NODE_TREE);
      tp->math->mtype = M_NAME;
      tp->math->name = strdup("/unknown:limit");
      tp->next = (sms_trigger *)sp->next;
    }

    if( ! sms_xdr_trigger(x,tp) )
      return 0;

    if(x->x_op == XDR_DECODE)   /* Read from an old client */
    if(tp->math && old_name(tp->math))
    {
      sp->type = NODE_INLIMIT;
      sp->name = old_name(tp->math);
      tp->math->name = 0;
      sp->usage = 0;
    }
    else
    {
      spit(0,IOI_ERR,"sms_xdr_inlimit: no name found");
      return 0;
    }

    /* IF NEXT THEN */
  }
  else
  {
    IF xdr_int(x,&sp->type) THEN
    IF sms_xdr_string(x,&sp->name) THEN
    IF NEXT THEN
    IF xdr_int(x,&sp->usage) THEN
    IF xdr_int(x,&sp->mod_no) THEN
    IF xdr_int(x,&sp->priority) THEN
    if( SUPPORTED(4,4,2) )
      IF xdr_int(x,&sp->inlimittype) THEN
  }

  return TRUE;
}

#if 0
int sms_xdr_cron(XDR *x, sms_cron *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF xdr_time_t(x,&sp->nexttime) THEN
  IF xdr_time_t(x,&sp->lasttime) THEN
  IF xdr_vector(x,(char *)sp->hour,3,sizeof(int),xdr_int) THEN
  IF xdr_vector(x,(char *)sp->minute,3,sizeof(int),xdr_int) THEN
  IF xdr_int(x,&sp->repeat) THEN

  IF xdr_int(x,&sp->weekdays) THEN
  IF xdr_int(x,&sp->monthdays) THEN
  IF xdr_int(x,&sp->months) THEN

  return TRUE;
}
#endif

int sms_xdr_node(XDR *x, sms_node *sp)
  /*
   * If SMS is sending to a client of version higher or equal to 4.3.0
   * and the client has registered for suites the kids of super-node
   * (that is suites) are andvanced to the first matchig suite at the
   * time of sending. Similarily when sending suites the field might
   * be advanced to the skip some of the suites.
   */
{
  sms_node *np = NULL;

  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN

  if( SUPPORTED(4,3,0) && sp->type==NODE_SUITE && sms_._is_server && 
      x->x_op == XDR_ENCODE && sms_._xdr_privs != XDR_SERVER )
  {

    /* if( sms_._current_con != NULL && sms_._current_con->suites ) */

    if( sms_._current_con != NULL )
    {
      for( np=sp->next ; np ; np=np->next )
        if( ls_find(&sms_._current_con->suites,np->name) )
          break;

      if( ! sms_xdr_pointer(x,(sms_list **)&np) )
        return FALSE;
    }
    else
      IF NEXT THEN
  }
  else
    IF NEXT THEN

  if( SUPPORTED(4,3,0) )
  {
    if( sp->type==NODE_SUITE )
    IF xdr_int(x,&sp->nid) THEN
  }

  if( ! SUPPORTED(4,3,0) )
  {
    IF xdr_int(x,&sp->user_int) THEN
  }
  IF xdr_int(x,&sp->status) THEN
  IF xdr_int(x,&sp->defstatus) THEN
  IF xdr_int(x,&sp->savedstat) THEN
  IF xdr_int(x,&sp->flags) THEN

  if( SUPPORTED(4,3,0) && sp->type==NODE_SUPER && sms_._is_server && 
      x->x_op == XDR_ENCODE && sms_._xdr_privs != XDR_SERVER )
  {
    /* if( sms_._current_con != NULL && sms_._current_con->suites ) */

    if( sms_._current_con != NULL )
    {
      for( np = sp->kids ; np ; np=np->next )
        if( ls_find(&sms_._current_con->suites,np->name) )
          break;

      if( ! sms_xdr_pointer(x,(sms_list **)&np) )
        return FALSE;
    }
    else
      IF POINT(kids) THEN

  }
  else
    IF POINT(kids) THEN

  IF POINT(text) THEN
  IF POINT(event) THEN
  if(SUPPORTED(4,3,0))
  {
    IF POINT(meter) THEN
    IF POINT(label) THEN
  }
  IF POINT(time) THEN
  IF POINT(date) THEN

#if 0
  if( SUPPORTED(4,4,3) )
    IF POINT(cron) THEN
#endif

  IF POINT(trigger) THEN

  if( SUPPORTED(4,3,20) )
    IF POINT(complete) THEN

  IF POINT(action) THEN

  if( SUPPORTED(4,3,1) )
    IF POINT(autocm) THEN

  if( SUPPORTED(4,3,10) )
    IF POINT(late) THEN

  if( ! SUPPORTED(4,3,0) )
  {
    int tries=SMSDEFTRIES;
    IF xdr_int(x,&tries) THEN
  }
  else
    IF xdr_int(x,&sp->rid) THEN

  if( SUPPORTED(4,4,0) )
    IF xdr_int(x,&sp->alias) THEN

  IF xdr_int(x,&sp->tryno) THEN
  IF sms_xdr_string(x,&sp->passwd) THEN
  IF POINT(user) THEN
  IF POINT(variable) THEN

  if( SUPPORTED(4,4,3) )
    if( sp->type == NODE_TASK )
    {
      IF xdr_time_t(x,&sp->stime) THEN
      IF xdr_time_t(x,&sp->btime) THEN
    }

  if( sp->type == NODE_SUITE )
  {
    IF xdr_int(x,&sp->modified) THEN
    IF xdr_int(x,&sp->clock) THEN
    IF xdr_int(x,&sp->gain) THEN
    IF xdr_time_t(x,&sp->stime) THEN
    IF xdr_time_t(x,&sp->btime) THEN

    if( ! SUPPORTED(4,3,0) )
    {
      int repeat = (sp->repeat)? TRUE: FALSE;
      int dayinc = (sp->repeat && sp->repeat->mode==REPEAT_DAY)?
                   sp->repeat->step : 0;
      IF xdr_int(x,&repeat) THEN
      IF xdr_int(x,&dayinc) THEN
    }

    if( ! SUPPORTED(4,3,0) )       /* Send field old */
    {
      sms_node *tmp = sp->next;
      sp->next = NULL;
      if( ! sms_xdr_pointer(x,(sms_list **)&sp->next) ) { sp->next=tmp; return 0; }
      sp->next=tmp;
    }
  }

  if( SUPPORTED(4,3,0) )
    IF POINT(repeat) THEN

  if( SUPPORTED(4,3,11) )
    IF POINT(log) THEN

  if( SUPPORTED(4,3,15) )
    IF POINT(restore) THEN

  if( SUPPORTED(4,4,0) )
  {
    IF POINT(limit) THEN
    IF POINT(inlimit) THEN
  }

  return TRUE;
}

int sms_xdr_handle(XDR *x, sms_handle *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF xdr_int(x,&sp->vers) THEN
  IF xdr_int(x,&sp->rev) THEN
  IF xdr_int(x,&sp->mod) THEN
  IF xdr_int(x,&sp->security) THEN
  IF xdr_int(x,&sp->rights) THEN
  IF xdr_int(x,&sp->handle) THEN

  if( sp->vers>4 || (sp->rev * 1000 + sp->mod) >= 3002)
  {
    IF POINT(lines) THEN
    IF xdr_int(x,&sp->code) THEN
  }

  return TRUE;
}

int sms_xdr_login(XDR *x, sms_login *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF sms_xdr_string(x,&sp->passwd) THEN
  IF xdr_int(x,&sp->uid) THEN
  IF xdr_int(x,&sp->gid) THEN
  IF xdr_int(x,&sp->vers) THEN
  IF xdr_int(x,&sp->rev) THEN
  IF xdr_int(x,&sp->mod) THEN

  if( sp->vers>4 || (sp->rev * 1000 + sp->mod) >= 3002)
  {
    IF POINT(lines) THEN
  }

  if( sp->vers>4 || (sp->rev * 1000 + sp->mod) >= 4000)
  {
    IF sms_xdr_string(x,&sp->sender) THEN
    IF xdr_int(x,&sp->tryno) THEN
  }

  return TRUE;
}

int sms_xdr_status(XDR *x, sms_status *sp)
{
#if 0
  if( ! SUPPORTED(4,4,0) )         /* Fail for old clients */
    return 0;
#endif

  IF xdr_int(x,&sp->type) THEN
  IF xdr_int(x,&sp->action_n) THEN
  IF xdr_int(x,&sp->modify_n) THEN
  IF xdr_int(x,&sp->status) THEN
  IF POINT(node) THEN
  return TRUE;
}

int sms_xdr_reply(XDR *x, sms_reply *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF xdr_int(x,&sp->code) THEN
  IF POINT(lines) THEN
  return TRUE;
}

int sms_xdr_check(XDR *x, sms_check *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF xdr_int(x,&sp->prog) THEN
  IF xdr_int(x,&sp->vers) THEN
  IF xdr_int(x,&sp->time) THEN
  IF xdr_int(x,&sp->user) THEN
  return TRUE;
}

#if 0
int sms_xdr_project(XDR *x, sms_project *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF POINT(object) THEN
  IF POINT(kids) THEN
  IF POINT(comment) THEN
  return TRUE;
}

int sms_xdr_object(XDR *x, sms_object *sp)
{
  IF xdr_int(x,&sp->type) THEN
  IF sms_xdr_string(x,&sp->name) THEN
  IF NEXT THEN
  IF xdr_int(x,&sp->status) THEN
  IF POINT(param) THEN
  return TRUE;
}
#endif
