/**************************************************************************
.TITLE    CDP
.NAME     PROJECT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-DEC-1998 / 14-DEC-1998 / OP
.VERSION  4.4.?
.FILE     project.c
.LANGUAGE ANSI-C
*         Project processing
************************************o*************************************/

#if 0

XCdp to have an editor for suites:

Requirements:

  Toolbox with all the basic nodes (elements) used in suite definition
  Grouping throught objects
  Objects into toolbox
  Objects should be mutable at least to some degree.

  The whole definition must be kept in an ascii file, or files.
  Single project file to contain all the objects and their use.
  This ascii file is, obviously, editable, but highly structured.

  Tranlator needed from project to definition (sanity check)

  Support for the .sms-files in some form a'la mkdirs(CDP) but with the
  knowledge of object calls (they would be symbolic links) Variables
  inserted as comments etc.
  Include file support etc.

  Acceptable solution is to be able to define the ECMWF's opetational suites
  using project-files.

Solutions:

  changes:
    sms_play_definition() to be called from XCdp
    it now must return the sms_node pointer.
    (none of the handles must change)

  create routines ...
  copy routine ...

FILE:

  project ::= "project" NAME COMMENT* { [object] | [call] | SUITE }* "endproject"
  object  ::= "object"  NAME { [element]* } "endobject"
  call    ::= "call"    NAME { VALUES }*
  VALUES  ::= NAME=STRING
  COMMENT ::= "comment" STRING

NOTICE:

  object is implisite end-command for things inside the object
  end of file or endproject is implisite end-command for all definitions


EXAMPLE of a-suite as a hand written project file:

project x
  comment "created ..."
  comment "date ..."

  object vpp
    edit SMSCMD "..."
    edit LOGDIR "..."
  endobject vpp

  object marstask name
    task &name
    event 1 fdb
    label info ""
  endobject marstask

  object arcan
    call marstask ansfc ; endcall
    call marstask anml ; endcall
    call marstask anpl ; endcall
  endobject

  object hourfam hour
    family &hour
    call arcan ; endcall
    endfamily
  endobject hourfam

  object fcarch name steps
    family &name
      edit STEPS &steps
      call marstask sp2fdb
        edit EMOS_TYPE fc
        call onvpp ; endcall
      endcall
    endfamily &name
  endobject fcarch name steps

  suite x
    limit mars 3
    inlimit mars

    call hourfam 00 ; endcall
    call hourfam 06 ; endcall

    mutate hourfam 12
      call fcarch fc036 "3/6/9/12/18/24/30/36" ; endcall
      mutate fcarch fc072 "42/48/54/60/66/72"
        trigger fc036 == complete
      endmutate
      mutate fcarch fc120 "78/84/90/96/102/108/114/120"
        trigger fc072 == complete
      endmutate
      mutate fcarch fc240 "132/144/156/168/180/192/204/216/228/240"
        trigger fc120 == complete
      endmutate
    endmutate
    call hourfam 18 ; endcall
  endsuite x

endproject

#endif

sms_node *project_expand(sms_project *pp)
/**************************************************************************
?  Expand objects
************************************o*************************************/
{
  sms_node *result = 0;
  sms_node *start  = pp;

  if( !pp ) return 0;

  if( start->type != NODE_PROJECT )
    for( start=pp->kids ; start ;  start=start->next )
      if( start->type == NODE_SUITE )

  return result;
}

