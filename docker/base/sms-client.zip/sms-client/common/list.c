/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     LIST
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     27-JUL-1992 / 28-JUN-1991 / OP
.VERSION  4.0
.FILE     list.c
.DATE     13-SEP-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     13-SEP-1994 / 25-FEB-1994 / OP
.VERSION  4.3.18
*         Repeat
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     22-MAR-1999 / 22-MAR--1999 / OP
.VERSION  4.4.2
*         Events do not have numbers anymore (only a name)
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  General list and tree handling routines.
*
*  These routines perform siple list handling, more advanced technicues
*  exists, like to update and remember the last element in the list, but
*  here we believe in to the simplisity!
*
************************************o*************************************/

#define SMS_LIBRARY

#include "smslib.h"

#define REMOVE(type,record) sms_list_delete_all( &((type *)old)->record )
#undef REMOVE

sms_list *sms_list_find(
    void *anything,                /* The address of the start */
    char *key)                     /* How to find it?          */
/**************************************************************************
?  Find an item by the key given.
=  ITEM if found, NULL otherwise.
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *start = *root;

  if( !key ) return NULL;
  if( !start ) return NULL;

  while( start )
  {
    if( start->name )
      if( strcmp(start->name,key) == 0 )
        break;

    start = start->next;
  }

  return( start );
}

int sms_list_remove(
    void *anything,                /* The address of the start */
    void *oldp)                    /* The old item to be removed */
/**************************************************************************
?  Remove the node from the list without deleting it.
=  BOOLEAN status, was the old found from the list.
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *start = *root,*last;
  sms_list  *old   = oldp;

  if( !start ) return FALSE;       /* This really shouldn't happed */
  if( !old ) return FALSE;

  if( start == old )
    *root = (*root)->next;
  else
  {
    while( start && start != old ) { last = start; start = start->next; }

    if( start )
      last->next = old->next;
    else
      return FALSE;
  }

  old->next = NULL;
  return TRUE;
}

int sms_list_delete(
    void *anything,                /* The address of the start */
    void *oldp)                    /* The old item to be deleted */
/**************************************************************************
?  Delete an item OLD from the list ROOT
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *start = *root,*last;
  sms_list  *old   = oldp;

  if( !start ) return FALSE;       /* This really shouldn't happed */
  if( !old ) return FALSE;

  if( sms_list_remove(root,old) )
    sms_node_free( old );

  return TRUE;
}

int sms_list_delete_name(
    void *anything,                /* The address of the start */
    char *name)                    /* The old item to be deleted */
/**************************************************************************
?  Delete an item OLD from the list ROOT
************************************o*************************************/
{
  if( sms_list_delete(anything,sms_list_find(anything,name)) );

  return 0;
}

int sms_list_delete_all(
    void *anything)                /* The address of the start */
/**************************************************************************
?  Delete all items in the list OLD from the list ROOT
************************************o*************************************/
{
  sms_list **root  = anything;

  while( *root )
    sms_list_delete( root,*root );

  return 0;
}

int sms_list_add(
    void *anything,                /* The address of the start */
    void *newp)                    /* The new item to be added */
/**************************************************************************
?  Add an item NEW into the list ROOT. If the list was empty the original
|  ROOT will be updated.
-CALL:
|  list *start, *new;
|  ... in the beginning: start=NULL;
|  new = calloc( ... );
|  list_add( &start , new );
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *start = *root;
  sms_list  *die   = NULL;
  sms_list  *new   = newp;

  if( !new ) return FALSE;

  new->next = NULL;

  if( new->name )
  switch(new->type)                /* To avoid duplicates some of the lists */
  {                                /* need to be seached before the adding  */
    case NODE_USER:
    case NODE_VARIABLE:
    case NODE_PASSWD:
    case NODE_EVENT:
    case NODE_METER:
    case NODE_LABEL:
    case NODE_REPEAT:
      if( die=sms_list_find(root,new->name) )
        sms_list_delete(root,die);
      start = *root;
      break;
  }

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = new;
  }
  else
    *root = new;

  return TRUE;
}

void sms_list_join(
    void *anything,                /* The address of the start */
    void *newp)                    /* The new item to be added */
/**************************************************************************
?  JOIN a list NEW into the list ROOT. If the list was empty the original
|  ROOT will be updated.
-CALL  Like sms_list_add()
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list *start  = *root;
  sms_list  *new   = newp;

  if( !new ) return;

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = new;
  }
  else
    *root = new;
}

int sms_list_add_text(
    void      *anything,           /* The address of the start */
    char      *text)
/**************************************************************************
?  Add an item of the type found into the ROOT (can't be an empty list!)
|  with the name field filled with the TEXT.
-CALL:  list_add( &start , "name" );
-NOTICE:  int sms_sizes[] is defined in the sms.h (generated by the rpcgen)
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *new;

  if( !root || !*root) return FALSE;

  if( ! (new=sms_alloc(NODE_LIST)) ) return FALSE;

  if( ! (new->name = strdup(text)) )
  {
    free(new);
    return FALSE;
  }

  new->type = NODE_LIST;
  new->next = *root;
  *root = new;

  return TRUE;
}

int sms_list_print(
    void      *anything,           /* The address of the start */
    FILE      *fp)
/**************************************************************************
?  Print the list on file given.
************************************o*************************************/
{
  sms_list **root  = anything;
  sms_list  *start = *root;

  while(start)
  {
    switch(start->type)
    {
      case NODE_CONNECTION:
        {
           sms_connect *c = (sms_connect *)start;

           fprintf(fp,"%-12s [%5d,%-5d] %s idle %6dsec, %s\n",
             STR(c->name), c->uid, c->gid,
             c->passok? "oper" : "user",
             sms_time_t(NULL) - c->idle,
             STR(sms_time_c(&(c->login))) );
#ifdef SMS_TIMER
           fprintf(fp,"...ticks %d\n",c->clocks);
#endif

           if(c->suites)
           {
             fprintf(fp,"User is following suites:\n");
             ls_fancy(&c->suites,fp,80);
           }
        }
        break;
      case NODE_VARIABLE:
        fprintf(fp,"%s %s\n",STR(start->name),STR(((sms_variable *)start)->value));
        break;
      default:
        fprintf(fp,"%s\n",STR(start->name));
    }
    start = start->next;
  }

  return TRUE;
}

void sms_list_user(sms_connect *cp, char *s)
{
  int          sec,min,hour,day;
  char         buff[MAXNAM];       /* A small buffer to print the idle */

  sec  = sms_time_t(NULL) - cp->idle;
  day  = sec / 86400; sec = sec % 86400;
  hour = sec / 3600;  sec = sec % 3600;
  min  = sec / 60;    sec = sec % 60;

  if( day )
    if( day != 1 )
      sprintf(buff,"%3d days",day);
    else
      sprintf(buff,"  1 day ");
  else if( hour )
    sprintf(buff,"%02d:%02d:%02d",hour,min,sec);
  else if( min )
    sprintf(buff,"   %02d:%02d",min,sec);
  else if( sec )
    sprintf(buff,"      %02d",sec);
  else
    strcpy(buff,"        ");

  sprintf(s,"%-12s %s idle %s %s %s %d.%d.%d %s",
          STR(cp->name),
          /* cp->uid, cp->gid, */
          cp->passok? "T" : "F",
          STR(buff),
          STR(sms_time_c(&(cp->login))) ,
          STR(cp->host) ,
          cp->vers,cp->rev,cp->mod,
          (cp->received < cp->num)? "mail":"nomail"
         );
}

void sms_list_users(sms_connect *cp, int full)
/**************************************************************************
?  Print users logged in SMS
************************************o*************************************/
{
  int          sec,min,hour,day;
  char         buff[MAXNAM];       /* A small buffer to print the idle */

  printf("List of users::\n");

  while( cp )
  {
    sms_list_user(cp,buff);
    printf("%s",STR(buff));

    if(full)
    {
      sms_list *lp = cp->suites;

      printf("suites:");

      for( ; lp ; lp=lp->next )
        printf(" %s",STR(lp->name));
    }

    printf("\n");

    cp = cp->next;
  }
}
