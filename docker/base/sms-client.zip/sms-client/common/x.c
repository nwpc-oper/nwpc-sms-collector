#include <stdio.h>
#include <time.h>

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

int line2msg(char *s, char *user, char *stamp, char *msg)
{
  int i;

  if( *s++ != '[' ) return FALSE;

  while( *s && *s != ']' )
    *user++ = *s++;
  *user = '\0';
  if( *s++ != ']' ) return FALSE;

  if( *s++ != ' ' ) return FALSE;
  if( *s++ != '#' ) return FALSE;
  if( *s++ != ' ' ) return FALSE;

  for(i=0;i<3;i++)
    if( ! *s++ ) return FALSE;

  if( *s++ != ':' ) return FALSE;
  if( *s++ != '[' ) return FALSE;

  while( *s && *s != ']' )
    *stamp++ = *s++;
  *stamp = '\0';
  if( *s++ != ']' ) return FALSE;

  s++;                             /* One space before */
  while( *s )
   *msg++ = *s++;
  *msg = '\0';

  return TRUE;
}

time_t atm2time_t(char *s)
{
  struct tm tm,*new;
  time_t     t;

  memset(&tm,0,sizeof tm);

  if( sscanf(s,"%d:%d:%d %d.%d.%d",
      &(tm.tm_hour), &(tm.tm_min), &(tm.tm_sec),
      &(tm.tm_mday), &(tm.tm_mon), &(tm.tm_year) ) < 6 )
  return 0;

  tm.tm_year  -= 1900;
  tm.tm_mon   -=    1;
  tm.tm_isdst  =   -1;

  putenv("TZ=GMT");
/*
  tzset();
*/

#if defined(CRAY) || defined(__convexc__) || defined(ultrix) || \
    defined(AIX)  || defined(mips) || defined(hpux) || defined(__mips)
  t = mktime(&tm);
#else
  t = timegm(&tm);
#endif

  new = gmtime(&t);

  if( new->tm_year != tm.tm_year ||
      new->tm_mon  != tm.tm_mon  ||
      new->tm_mday != tm.tm_mday ||
      new->tm_hour != tm.tm_hour )
   return 0;

  return t;
}

main(int argc, char **argv)
{
  char name[100];
  char msg[100];
  char tm[100];
  time_t t;
  if( argc<2 )
  {
    fprintf(stderr,"%s:Too few parameters?\n",STR(*argv));
    exit(1);
  }

  if( ! line2msg(argv[1],name,tm,msg) )
  {
    fprintf(stderr,"%s:parameter did not make sense\n",STR(*argv));
    printf("[%s] [%s] [%s]\n",STR(name),STR(msg),STR(tm));
    exit(2);
  }

  printf("[%s] [%s] [%s]\n",STR(name),STR(tm),STR(msg));

  t = atm2time_t(tm);

  printf("Time t is %d %s\n",t,STR(ctime(&t)));
}
