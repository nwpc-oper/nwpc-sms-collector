/**************************************************************************
.TITLE    C-SMS-CDP Utility
.NAME     STATUS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     17-FEB-1993 / 08-SEP-1991 / OP
.VERSION  4.1
.FILE     cstatus.c
.DATE     31-MAR-1993 / 31-MAR-1993 / OP
.VERSION  4.1
*         Removed call to vwprintw (not in ultrix!)
.DATE     13-OCT-1994 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.2
.DATE     08-DEC-1994 / 08-DEC-1994 / OP
.VERSION  4.3.4
*         Show if any flag is set (not which flags are set)
.DATE     23-MAY-1995 / 23-MAY-1995 / OP
.VERSION  4.3.8
*         Modified curses to work with IOI 3.2 line editing
.DATE     16-JAN-1996 / 16-JAN-1996 / OP
.VERSION  4.3.13
*         Bug fix for selecting curses/printf
.DATE     16-JUL-1998 / 18-JUN-1998 / OP
.VERSION  4.3.18-19-20
*         Labels and repeat processed, complete trigger
*         Bug fix if decoding fails
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     28-JAN-1999 / 23-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
.DATE     09-JUN-2000 / 08-JUN-2000 / OP
.VERSION  4.4.3-4
*         Ifdef for CRAY T3E
.DATE     28-JUN-2001 / 28-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         Enumerated repeat
|
|  This file contains the routines for the CDP-status command and also
|  the code for Command-status which is a stand-alone tool to monitor
|  the status of a SMS.
|
|  Use curses to repeatedly display and refres the status tree of the SMS.
|
************************************o*************************************/

#include "smslib.h"

static void debug(char *fmt,...)   /* For debugging only */
{
  static FILE *fp;
  va_list      ap;

  if(!fp)
    fp=fopen("debug.out","w");

  if(!fp)
    return;

  va_start(ap,fmt);
  vfprintf(fp,fmt,ap);
  fflush(fp);
  va_end(ap);
}

#ifdef HZ
#  undef HZ                        /* Defined in the curses */
#endif

#ifdef ultrix
#  include <cursesX.h>
#else
#  include <curses.h>
#endif

#ifdef hpux
#  include <termio.h>
#endif

#ifdef CRAY
#  include <sys/ioctl.h>
#endif

#ifdef CRAY
extern int printw(char *, ...);
#endif

#ifdef AIX
extern int printw(char *, ...);
#undef lines
#define lines printed_lines
#endif

#define CONTROL(x) ((x)-64)

static void header();

#ifndef A_UNDERLINE                /* The old curses! */
#  define SCREEN WINDOW
#  define newterm(x,y,z) initscr()

#  define A_REVERSE       000001000000L
#
#  define KEY_DOWN        0402     /* Sent by terminal down arrow key */
#  define KEY_UP          0403     /* Sent by terminal up arrow key */
#  define KEY_LEFT        0404     /* Sent by terminal left arrow key */
#  define KEY_RIGHT       0405     /* Sent by terminal right arrow key */
#  define KEY_HOME        0406     /* Sent by home key. */

#  define KEY_A1          0534     /* Upper left of keypad */
#  define KEY_A3          0535     /* Upper right of keypad */
#  define KEY_B2          0536     /* Center of keypad */
#  define KEY_C1          0537     /* Lower left of keypad */
#  define KEY_C3          0540     /* Lower right of keypad */
#
#  define attron(x)       standout()
#  define beep()
#  define nodelay(x,y)    { if(y) raw(); else noraw(); }
#  define intrflush(x,y)
#  define attroff(x)      standend()
#  define keypad(x,y)
#  define set_term(x)

static void catch_alarm(int sig)
/**************************************************************************
?  Catch the alarm signal used for non-blocking read for the old curses.
|  This should cause read(2) in wgetch(CSTATUS) to return either -1 or 0.
************************************o*************************************/
{
  FILE *fp = fopen("alarm.data","a");
  fprintf(fp,"alarm at %d\n",time(NULL));
  fclose(fp);

  signal(sig,catch_alarm);
}

static int wgetch(SCREEN *x)
/**************************************************************************
?  Read characters if any (sleep 0.1 sec if no char!)
=  wgetch(3V)  // curses
!  This causes the -i option to work slower that requested!
************************************o*************************************/
{
  char buff;                       /* Yeps! Read only a single char */
  int  rc;                         /* How many character were read? */

  alarm(1);
  rc = read(0,&buff,1);
  alarm(0);

  if( rc==-1 || rc==0 ) return ERR;
  return (int) buff;
}
#endif                             /* old curses! */

#ifdef MAIN
#  define CDP_STATUS main
   int cdp_status(int argc, char **argv) {;} /* To make the ld happier */
#else
#  define CDP_STATUS cdp_status
#endif

#define SINGLE_CHAR  0             /* Modes to display the status */
#define THREE_CHAR   1
#define FULL_NAME    2

#define RPC_NONE     0             /* Messages to display the RPC  */
#define RPC_OFF      1
#define RPC_ON       2


#define CD_LEFT      0             /* Codes to change current node */
#define CD_DOWN      1             /* keyboard order: h j k l      */
#define CD_UP        2
#define CD_RIGHT     3
#define CD_BOTTOM    4
#define CD_TOP       5
#define CD_ROOT      6

/**************************************************************************
*        T h e   g l o b a l s   u s e d   i n   t h i s   f i l e
************************************o*************************************/

static int       c_break;          /* Break out from the loop    */
static int       empty;            /* Empty line outputted       */
static int       spaces;           /* Spaces before the name?    */
static int       selected_line;    /* # of lines from the root   */
static int       skip_lines;       /* # of first lines to skip   */

static int       statusmask;       /* Mask nodes to display      */
static int       news;             /* From the SMS!              */
static int       told;             /* The news by beeping?       */

static int       allnodes;         /* To process also parents    */
static int       centre;           /* The CWN on the screen      */

static int       fullmode;         /* Show the kids also         */
static int       showdeps;         /* Show the reason for queued */
static int       showevents;       /* Also the events as nodes   */
static int       waitme;           /* Don't update the screen    */
static int       bracetmode;       /* Layout of status / or [ ]  */
static int       slow_flag;        /* TRUE? We'll use scrolling  */

static int       statusmode;       /* How to display the status  */

static int       interval,         /* How often "talk" 2 the SMS */
                 interval_min=0,   /* Minimum interval (seconds) */
                 interval_def=0;   /* Default interval           */

static int       depth;            /* How many levels of nodes   */
static int       lines;            /* Lines printed              */
static int      *indent;           /* Max length of names/level  */
static int       skip_indent;      /* Indents not displayed      */
static char    **fmt;              /* Format string to print em  */
static char    **fmtf;             /* Format if flags are set    */

static int       search_dir;       /* TRUE down, FALSE up        */
static char      pattern[MAXLEN];  /* Pattern to search for      */

static SCREEN   *scr;              /* In SUN use /usr/5bin/cc !  */
static FILE     *input;
static int       curses_lines;     /* Remember between terminals */
static int       use_curses;       /* It's ! enought 2 check scr */

static char      cnode[MAXNAM];    /* Current name   */
static sms_node *ref;              /* CWN in status */

static void (* old_int)();         /* The status of the signals before */
static void (* old_quit)();        /* entering into this module.       */
static void (* old_stop)();        /* Restored before leaving.         */
static void (* old_cont)();

static void catch(int sig)
/**************************************************************************
?  Catch the terminal interrupt for the repeated status.
************************************o*************************************/
{
  c_break = TRUE;
  signal(sig,catch);
}

static void restore_signals(void)
/**************************************************************************
?  Restore the signals after the window has been deleted, (left the curses)
************************************o*************************************/
{
  signal(SIGINT ,old_int);
  signal(SIGQUIT,old_quit);
 
#ifdef SIGCONT
  signal(SIGTSTP,old_stop);
  signal(SIGCONT,old_cont);
#endif
 
#ifdef SIGWINCH
  signal(SIGWINCH,SIG_IGN);
#endif

#ifndef A_UNDERLINE                /* The old curses! */
  signal(SIGALRM,SIG_IGN);
#endif
}

static int initialize_win(void)
/**************************************************************************
?  Initialize the curses(3V) after a valid window (screen) pointer.
************************************o*************************************/
{
#if defined(VMS) || defined(_CONVEX_SOURCE)
#  define cbreak crmode
#  define idlok dummy
#endif

  set_term(scr);
  cbreak();                        /* crmode(); */
  noecho();
  nodelay(stdscr,TRUE);
  nonl();
  if(slow_flag) idlok(stdscr,TRUE);
  intrflush(stdscr, FALSE);
  keypad(stdscr,TRUE);

  return 0;
}

static int restore_win(int truly)
/**************************************************************************
?  Restore the terminal into normal operation and possible end using the
|  curses(3V) (quit from keyboard)
************************************o*************************************/
{
  echo();
  nodelay(stdscr,FALSE);

#ifdef A_UNDERLINE
  endwin();                        /* Only one terminal! */
#if 0
  if(truly)
  {
    delscreen(scr);                /* On some systems descreen closes */
    fclose(input);                 /* this file pointer ... (shit)    */
    input = NULL;
  }
#endif

#else
  endwin();                        /* Only one terminal! */
#endif

  return 0;
}

#ifdef SIGCONT                     /* Eg not in UNICOS 5.1 or VMS 5.4 */
static void catch_continue(int);

static void catch_stop(int sig)
/**************************************************************************
?  Catch the stop signal (usually ^Z from keyboard) when in the curses(3V)
|  is used. Prepare the terminal for normal operation and "act" normally
|  to the signal (suspend the process)
************************************o*************************************/
{

  restore_win(FALSE);
  signal(sig,SIG_DFL);             /* Cruel but simple! */
  signal(SIGCONT,catch_continue);
  kill(getpid(),sig);
}

static void catch_continue(int sig)
/**************************************************************************
?  Catch the continue signal (usually csh command fg) when in the 
|  curses(3V) is used. Reinitialize the terminal for curses operation and
|  reload the stop-catching routine.
************************************o*************************************/
{
/* #if defined(_CONVEX_SOURCE) */
#ifndef A_UNDERLINE                /* The old curses! */
#  define doupdate refresh
#endif

  initialize_win();
  doupdate();  
  signal(sig,catch_continue);
  signal(SIGTSTP,catch_stop);      /* Will be in UNICOS 6.0 */
}
#endif /* SIGCONT */

static void scroll_it(int lines)
/**************************************************************************
?  Scroll the curses display by "lines" lines!
|  If the scroll request is too large the whole screen will be cleared.
|  Nothing is done if the lines requested is zero 
************************************o*************************************/
{
  int i;

  if(lines==0) return;

  if(lines>=LINES || lines<=(-LINES))
  {
    clear();
    return;
  }

  move(LINES-1,0);                 /* Clear the possible message */
  clrtoeol();

  move(1,0);                       /* Let's not alter the header */

  if(lines>0)                      /* Scroll forward */
  {
    for( i=0 ; i<lines ; i++ )
    {
      move(1,0);
      deleteln();
    }
  }
  else                             /* Scroll backward */
  {
    lines = (-lines);
    for( i=0 ; i<lines ; i++ )
    {
      move(1,0);
      insertln();
    }
  }
}

static void count_depth(
    void      *anything,           /* The nodes to count */
    int        brothers,           /* Flag to process also the brothers  */
    int        current)            /* The current depth in the tree      */
/**************************************************************************
?  Count the maximum depth of the nodes relative to the given one.
@  depth
************************************o*************************************/
{
  sms_node *np = anything;

  current++;                       /* Entered one level up! */

  if( current > depth )            /* Deaper than prevoiusly? */
    depth = current;

  if( np->type==NODE_EVENT || np->type==NODE_METER ||
      np->type==NODE_LABEL || np->type==NODE_REPEAT ) return;

  while( np )
  {
    if( np->kids )
      count_depth(np->kids,TRUE,current);

    /* if( showevents ) */
    {
      if( np->event ) count_depth(np->event,TRUE,current);
      if( np->meter ) count_depth(np->meter,TRUE,current);
      if( np->label ) count_depth(np->label,TRUE,current);
      if( np->type != NODE_SUITE )
        if( np->repeat ) count_depth(np->repeat,TRUE,current);
    }

    np = brothers? np->next : NULL;
  }
}

static int count_width(
    void      *anything,           /* The nodes to count */
    int        brothers,           /* Flag to process also the brothers  */
    int        current)            /* The current depth in the tree      */
/**************************************************************************
?  Count the maximum widths of the different levels in the tree.
@  indent[ 0,...,@depth-1 ], statusmask
=  Did any of the nodes match the statusmask
************************************o*************************************/
{
  int       len;
  int       match = FALSE;
  sms_node *np    = anything;

  while( np )
  {
    int len = strlen(np->name);
    int kids_match = FALSE;

    if( ! (np->type==NODE_EVENT || np->type==NODE_METER ||
           np->type==NODE_LABEL || np->type==NODE_REPEAT  ) )
    {
      if( (kids_match=count_width(np->kids,TRUE,current+1)) == TRUE )
        match = TRUE;

      /* if( showevents ) */
      {
        if( np->event ) count_width(np->event,TRUE,current+1);
        if( np->meter ) count_width(np->meter,TRUE,current+1);
        if( np->label ) count_width(np->label,TRUE,current+1);
        if(np->type != NODE_SUITE)
          if( np->repeat ) count_width(np->repeat,TRUE,current+1);
      }
    }

    /* if( ((1<<(np->status))&statusmask) || kids_match ) */

    if( TRUE )
    {
      indent[current] = MAX(indent[current],len);
      match = TRUE;
    }

    np = brothers? np->next : NULL;
  }

  return match;                    /* Have U C'n the light? */
}

static int count_tables(sms_node *np)
/**************************************************************************
?  Count the table indent and depth
=  BOOLEAN status.
************************************o*************************************/
{
  int i,len,mlen=0;

  if( fmt )
    for( i=0 ; i<depth ; i++ )
      IFFREE( fmt[i] );
  IFFREE( fmt );

  if( fmtf )
    for( i=0 ; i<depth ; i++ )
      IFFREE( fmtf[i] );
  IFFREE( fmtf );

  IFFREE(indent);

  depth       = 0;

  count_depth(np,allnodes,0);

  indent=calloc(sizeof(int),depth);
  count_width(np,allnodes,0);

  fmt  = (char **)calloc(sizeof(char *),depth);
  fmtf = (char **)calloc(sizeof(char *),depth);

  for(i=0 ; i<STATUS_USABLE ; i++) /* Count the max length */
  {
    len = strlen(status_name[i]);
    mlen = MAX(len,mlen);
  }

  for( i=0 ; i<depth ; i++ )
  {
    char f[80];
    char ff[80];

    if( bracetmode )               /* The default mode */
      switch( statusmode )
      {
        case SINGLE_CHAR:
          sprintf(f,"%%-%ds/%%-1.1s  ",indent[i]);
          indent[i] += 4;
          break;
        case THREE_CHAR:
          sprintf(f,"%%-%ds/%%-3.3s  ",indent[i]);
          indent[i] += 6;
          break;
        case FULL_NAME:
          sprintf(f,"%%-%ds/%%-%d.%ds  ",indent[i],mlen,mlen);
          indent[i] += 3+mlen;
          break;
      }
    else
      switch( statusmode )
      {
        case SINGLE_CHAR:
          sprintf(f ,"%%-%ds[%%-1.1s]   ",indent[i]);
          sprintf(ff,"%%-%ds{%%-1.1s}   ",indent[i]);
          indent[i] += 6;
          break;
        case THREE_CHAR:
          sprintf(f ,"%%-%ds[%%-3.3s]   ",indent[i]);
          sprintf(ff,"%%-%ds{%%-3.3s}   ",indent[i]);
          indent[i] += 8;
          break;
        case FULL_NAME:
          sprintf(f ,"%%-%ds[%%-%d.%ds]   ",indent[i],mlen,mlen);
          sprintf(ff,"%%-%ds{%%-%d.%ds}   ",indent[i],mlen,mlen);
          indent[i] += 5+mlen;
          break;
      }

    fmt[i] = strdup(f);
    fmtf[i] = strdup( bracetmode ? f : ff );
  }

  return TRUE;
}

static int is_visible(sms_node  *np)
/**************************************************************************
?  Check if the node should be visible.
|  If the status of the node says it is not visible check the kids.
=  Boolean status
************************************o*************************************/
{
  int match = FALSE;

  if((1<<(np->status))&statusmask) /* Not masked out? */
    return TRUE;

  if( np == ref )                  /* The current node is always visible */
    return TRUE; 

  if((np=np->kids)==NULL)          /* Nothin' left? */
    return FALSE;

  if( !fullmode )
    return FALSE;

  if(np->type==NODE_EVENT || np->type==NODE_METER ||
     np->type==NODE_LABEL || np->type==NODE_REPEAT )
    return FALSE;                  /* Events/meters don't count here */

  while( np )                      /* Loop the kids */
  {
    if( is_visible(np) )           /* If any of the kids is visible */
      return TRUE;                 /* the parent is also */
    np = np->next;
  }

  return FALSE;
}

static sms_node *next(sms_node *np, int dir)
/**************************************************************************
?  Get the next visible node.
|  Go down if DIR is TRUE, go up is DIR is FALSE (previous)
|
|  The logic is to select the one below(above) the current node, if the
|  current node is the last(first) in a family we'll jump into the
|  next(previous) family until well find one. Then we try to reach the
|  same depth as where we were.
=  NULL if none visible is available
************************************o*************************************/
{
  sms_node *new   = NULL;
  sms_node *tmp   = NULL;
  int       level = 0;             /* Number of CD's up */

  if(dir)                          /* Go down == NEXT */
  {
    new = np->next;

    while( new && ! is_visible(new) )
      new = new->next;

    if(!new && np->parent)         /* The next visible family! */
    {
      tmp = np;

      do
      {
        level++;
        tmp = tmp->parent;
        new = tmp->next;

        while( new && ! is_visible(new) )
          new = new->next;

      } while( !new && tmp->type != NODE_SUPER );

      if(new)                      /* There is a visible family at least */
      {
        for( ; level ; level-- )   /* Let's try 2 go down on right level */
        {
          tmp = new->kids;

          while( tmp && ! is_visible(tmp) )
            tmp = tmp->next;

          if(tmp) new = tmp;
        }
      }
    }
  }
  else                             /* Go up == PREVIOUS */
  {
    sms_node *first = NULL;

    if( np->parent )               /* Same level, but before np */
    {
      first = np->parent->kids;

      while( first != np )
      {
        if( is_visible(first) )
          new = first;
        first = first->next;
      }
    }

    if(!new && np->parent && np->parent->parent)
    {                              /* The previous visible family */
      tmp = np;

      do
      {
        level++;


        tmp = tmp->parent;
        first = tmp->parent->kids;

        while( first != tmp )
        {
          if( is_visible(first) )
            new = first;
          first = first->next;
        }

      } while( !new && tmp->parent->parent && 
               tmp->parent->parent->type != NODE_HANDLE );

      if(new)                      /* There is a visible family at least */
      {
        for( ; level ; level-- )   /* Let's try 2 go down on right level */
        {
          tmp = new->kids;

          while( tmp )
          {
            if( is_visible(tmp) )
              new = tmp;
            tmp = tmp->next;
          }
        }
      }
    }

  }

  return new;
}

static int cd_to(int dir)
/**************************************************************************
?  Change the current node.
@  ref, statusmask
=  Boolean status , do we need to update the screen?
************************************o*************************************/
{
  int rc = FALSE;                  /* Do we need to update the screen? */
  sms_node *new = NULL;

  switch( dir )
  {
    case CD_LEFT:
      if( ref->parent && ref->parent->type != NODE_HANDLE )
        new = ref->parent;
      break;

    case CD_DOWN:
      new = next(ref,TRUE);

      break;

    case CD_UP:
      new = next(ref,FALSE);
      break;

    case CD_RIGHT:
      new = ref->kids;

      while( new && ! is_visible(new) )
        new = new->next;
      break;

    case CD_TOP:
      do
      {
        new = ref;
        cd_to(CD_UP);
      }
      while( new != ref );         /* OK! We'll try one too many times! */
      break;

    case CD_BOTTOM:
      do
      {
        new = ref;
        cd_to(CD_DOWN);
      }
      while( new != ref );         /* OK! We'll try one too many times! */
      break;

    case CD_ROOT:
      if( ref->parent )
      {
        new = ref;
        while(new->parent && new->parent->type != NODE_HANDLE)
          new = new->parent;
      }
      break;
  }

  if( new )                        /* Scroll the screen if needed */
  {
    int old = skip_lines;
    int LEN = LINES-3;

    selected_line += new->user_int - ref->user_int;

    if( centre )
      if( selected_line < LEN/2 )
        skip_lines = 0;
      else
        if( (lines - selected_line) < LEN )
          skip_lines = lines - LEN - 1;
        else
          skip_lines = selected_line - LEN/2;
    else
      if( (lines - selected_line) < LEN )
        skip_lines = lines - LEN - 1;
      else
        skip_lines = selected_line;

    if( skip_lines < 0 ) skip_lines = 0;

    ref = new;
    rc = TRUE;
  }

  strcpy(cnode,sms_node_full_name(ref));

  return rc;
}

static int dummy(void)
/**************************************************************************
?  Dummy routine to be used by status_print to count the lines
************************************o*************************************/
{
  return 1;                        /* Well, we did say it's an int! */
}

#ifndef hpux_1

static int c_print(char *fmt, ...)
/**************************************************************************
?  Output using curses, but only if the line is visible
************************************o*************************************/
{
  if( lines >= skip_lines && lines < (skip_lines+LINES-2) )
  {
    va_list  ap;

    va_start(ap,fmt);
 
#if defined(ultrix) || defined(VMS) || 1
    {
      char buff[MAXNAM];
      vsprintf(buff,fmt,ap);
      printw("%s",buff);
    }
#else
    vwprintw(stdscr,fmt,ap);
#endif

    va_end(ap);
  }

  return 1;
}

#else

static int c_print(a1,a2,a3,a4,...)
{
  if( lines >= skip_lines && lines < (skip_lines+LINES-2) )
    printw(a1,a2,a3,a4);

  return 1;
}

#endif

static void new_line( int (* print)() )
/**************************************************************************
?  "Line feed" in printing.
|  If the line is visible clear the end of the line (only in curses)
************************************o*************************************/
{
  if( (int (*)())print == (int (*)())c_print )
    if( lines >= skip_lines && lines < (skip_lines+LINES-2) )
      clrtoeol();

  print("\n");
  spaces = TRUE;                   /* Next line needs indentation */

  lines++;
}

static void display(
    void      *anything,           /* The nodes to count */
    int        brothers,           /* Flag to process also the brothers  */
    int        current,            /* The current depth in the tree      */
    int     (* print)() )          /* The routine to print the result    */
/**************************************************************************
?  Display the node and its kids using the indentation and format string.
@  fmt,fmtf[ 0,...,@depth-1 ], indent[ 0,...,@depth-1 ]
@  empty, spaces                   // To beautify the output //
************************************o*************************************/
{
  int i,j,LEN;
  sms_node *np = anything;
  char    **format = fmt;

  LEN = LINES-2;

  if( !use_curses || print==dummy ) 
    LEN = 1<<30;                   /* Any huge number will do */

  while( np )
  {
    if( np->type==NODE_EVENT || np->type==NODE_METER  ||
        np->type==NODE_LABEL || np->type==NODE_REPEAT ||  is_visible(np) )
    {
      if( empty )                  /* Eg last task in a family was printed */
        new_line(print);

      if( spaces )                 /* Eg another task in a family */
      {
        for( i=0,j=skip_indent ; j<(current+skip_indent) ; j++)
          i += indent[j];

        if( (int (*)()) print == (int (*)()) printf )
          for( ; i ; i-- )
            print(" ");
        else
        {
          int x,y;

          if( lines >= skip_lines && lines < (skip_lines+LEN) )
          {
            clrtoeol();
            getyx(stdscr,y,x);
            move(y,x+i);
          }
        }
      }

      np->user_int = lines;

      spaces = FALSE;
      empty  = FALSE;

      if( ! (np->type==NODE_EVENT || np->type==NODE_METER  ||
             np->type==NODE_LABEL || np->type==NODE_REPEAT   ) )
      {
        if( np==ref )
        {
          selected_line = lines;
          if( use_curses ) attron(A_REVERSE);
        }

        format = np->flags? fmtf : fmt;

        if(np->status==STATUS_QUEUED && showdeps)
        {
          int code;

          if( !(code = sms_time_dependent(np)) )  /* 0 == free to go */
            if( sms_status_trigger2(np,NODE_TRIGGER) )
              code = 3;
  
          if( statusmode == SINGLE_CHAR )
            print(format[current+skip_indent],np->name,why_char[code]);
          else
            print(format[current+skip_indent],np->name,why_name[code]);

        }
        else
          if( statusmode == SINGLE_CHAR )
            print(format[current+skip_indent],np->name,status_char[np->status]);
          else
            print(format[current+skip_indent],np->name,status_name[np->status]);

        if( use_curses && np==ref ) attroff(A_REVERSE);

        if( showevents )
        {
          if( np->event ) display(np->event,TRUE,current+1,print);
          if( np->meter ) display(np->meter,TRUE,current+1,print);
          if( np->label ) display(np->label,TRUE,current+1,print);
          if( np->type != NODE_SUITE )
            if( np->repeat ) display(np->repeat,TRUE,current+1,print);
        }
  
        if( np->kids && (current<1 || fullmode) )
          display(np->kids,TRUE,current+1,print);
        else
          new_line(print);
      }
      else                         /* Is an event or meter */
      {
        char buff[MAXLEN];
        sms_label  *lp;
        sms_repeat *rp;
        sms_list   *l;

        buff[0] = 0;

        switch (np->type)
        {
          case NODE_EVENT:
            strcpy(buff,event_name[np->status]);
            break;

          case NODE_LABEL:
            lp = (sms_label *)np;
            strcpy(buff,lp->value);
            break;

          case NODE_REPEAT:
            rp = (sms_repeat *)np;

            if(rp->mode == REPEAT_INTEGER ||
               rp->mode == REPEAT_ENUMERATED ||
               rp->mode == REPEAT_DATE)
              sprintf(buff,"%d",np->status);

            if(rp->mode == REPEAT_STRING)
            {
              l = ls_item(&rp->str,rp->status);
              if( ! l ) l = ls_last(&rp->str);

              strcpy(buff,l->name);
            }

            break;

          default:
            sprintf(buff,"%d",np->status);
            break;
        }

        print(fmt[current+skip_indent],np->name,buff);

        if( np->next )             /* Special treatment for the events! */
          new_line(print);
      }
  
      np = brothers? np->next : NULL;
  
    }
    else                           /* This node was masked out! */
      np = brothers? np->next : NULL;
  
    if( !np )
      empty = TRUE;
  }
  spaces = TRUE;

  if( (int (*)())print == (int (*)())c_print )
    clrtobot();
}

static int status_print(int ind)
/**************************************************************************
?  Print the node(s)
=  BOOLEAN status. TRUE if there was lines to display.
************************************o*************************************/
{
  sms_node  *np;                   /* The nodes to print                */
  int i;                           /* Loop counter and return code  */
  int len;                         /* For the full status name calc */

  ref = sms_node_find_full(cnode);

  if(!ref) ref = sms_._super;      /* If the structure has been changed */

  np = allnodes ? sms_._super : ref;

  if( !np )                        /* Just clear the screen in the  */
  {                                /* curses mode and return        */
    if( use_curses )
    {
      clear();
      header( RPC_NONE );
      refresh();
    }
    return FALSE;
  }

  lines       = 0;
  empty       = FALSE;
  spaces      = FALSE;

  for(skip_indent=0;np->type != NODE_SUPER;skip_indent++) np = np->parent;

  np = allnodes? sms_._super:ref; 

  if( use_curses )                 /* Make sure the "cwn" is on screend */
  {
    int LEN = LINES-3;             /* The decrement must be odd number! */

    selected_line = 0;
    skip_lines    = 0;

    display(np,allnodes,0,dummy);  /* Just count the lines */

    if( centre )
      if( selected_line < LEN/2 )
        skip_lines = 0;
      else
        if( (lines - selected_line) < LEN )
          skip_lines = lines - LEN - 1;
        else
          skip_lines = selected_line - LEN/2;
    else
      if( (lines - selected_line) < LEN )
        skip_lines = lines - LEN - 1;
      else
        skip_lines = selected_line;

    if( skip_lines < 0 )
      skip_lines = 0;

    lines       = 0;
    empty       = FALSE;
    spaces      = FALSE;

    /* clear(); */
    header( RPC_NONE );
  }

  indent[skip_indent] += ind;      /* Tis's a hack */

  if( use_curses )
    display(np,allnodes,0, (int (*)()) c_print);
  else
  {
    display(np,allnodes,0, (int (*)()) printf);
    if(empty) printf("\n");
  }

  indent[skip_indent] -= ind;      /* Tis's a hack */

  if( use_curses ) refresh();

  return lines? TRUE:FALSE;
}

static void message(char *msg, int wait_me)
/**************************************************************************
?  Print a message on the bottom line and wait? for users responce.
************************************o*************************************/
{
  int rch;

  move(LINES-1,0);
  clrtoeol();
  attron(A_REVERSE);
  printw("%s",msg);
  attroff(A_REVERSE);
  refresh();

  if(wait_me)
  {
    /* while( (rch=wgetch(scr)) == ERR && ! c_break ) */
    while( (rch=getch()) == ERR && ! c_break )
      sms_nap( 100000 );

    move(LINES-1,0);
    clrtoeol();
    refresh();
  }
  else
    sms_nap( 100000 );
}

static void header(int calling_sms)
/**************************************************************************
?  Display the header line in the curses screen.
|  In non curses mode this is void.
*NOTICE! Remember to update the help() when you modify the keys!
************************************o*************************************/
{
#define PUT(x,flag) addch( (x)+(flag? A_REVERSE : 0) )

  int rch;
  int i;
  time_t t;

  char buff[MAXLEN];

  if( !use_curses ) return;

  move(0,0);
  printw("%s: options ",sms_._logins? sms_._logins->name : "unknown");

  PUT( 'a' , allnodes    );
  PUT( 'c' , centre      );
  PUT( 'd' , showdeps    );
  PUT( 'e' , showevents  );
  PUT( 'f' , fullmode    );
  PUT( 'w' , waitme      );

  printw("  mask[");

  for( i=0 ; i<STATUS_USABLE ; i++ )
    PUT( status_char[i][0] , ((1<<i)&statusmask) );

  printw("]  ");

  if( waitme && news )
  {
    attron(A_REVERSE);
    printw("NEWS!");
    attroff(A_REVERSE);

    if( !told )
      beep();
    told = TRUE;
  }

  if( ! IS_RUNNING )
  {
    attron(A_REVERSE);

    if( IS_HALTED )
      printw("HALT");
    else
      printw("DOWN");

    attroff(A_REVERSE);
  }

  if(calling_sms==RPC_ON)
  {
    attron(A_REVERSE);
    printw("<RPC>");
    attroff(A_REVERSE);
  }
  if(calling_sms==RPC_OFF)
    printw("     ");
  
  t = sms_time_t(NULL);

  move(0,COLS-25);
  printw("%s\n",sms_time_c(&t));

  refresh();
}

static int edit_line(
    char  c,                       /* "prompt" character */
    char *buff,                    /* input buffer         */
    int   len)                     /* max lenght of the buff */
/**************************************************************************
?  Edit a line of characters on the bottom line of the curses screen
=  Boolean success; +line in the buff
|  - TRUE  if the line contains user input
|  - FALSE if the line is empty (user cancelled operation)
************************************o*************************************/
{
  int go_on = TRUE;
  int rch;
  int i     = 0;

  move(LINES-1,0);
  clrtoeol();
  addch(c);
  refresh();

  len = MAX(COLS-2,len);

  while( go_on && !c_break )
  {
    /* while( (rch=wgetch(scr)) == ERR && ! c_break ) */
    while( (rch=getch()) == ERR && ! c_break ) 
      sms_nap( 100000 );

    switch(rch)
    {
      case CONTROL('U'):           /* Clear the line */
        if(i>0)
        {
          move(LINES-1,1);
          clrtoeol();
          refresh();
          buff[(i=0)] = '\0';
        }
        else
          return FALSE;
        break;
      case '\b':                   /* Clear the last character   */
      case 127:                    /* DEL (like in SYSV           */
#ifdef KEY_BACKSPACE
      case KEY_BACKSPACE:          /* Does any terminal send this? */
#endif
        if(i>0)
        {
          move(LINES-1,i);
          clrtoeol();
          refresh();
          buff[i--] = '\0';
        }
        break;
      case '\r':                   /* Finish the line! */
        go_on = FALSE;
        break;
      default:
        if( isalnum(rch) || rch==' ' || rch=='_' || ispunct(rch) )
        {
          if( i<len )
          {
            buff[i++] = rch;
            addch(rch); refresh();
          }
          else beep();
        }
        else                       /* Fix this if needed */
        {
          beep();
          go_on = FALSE;
        }
    }
  }

  buff[i]='\0';

  return TRUE;
}

static void help(int (* print)(const char *,...) )  /* The routine to print the help */
/**************************************************************************
?  Print the help for the curses screen manipulation.
*  REMEMBER to update this whne you update the header()!
************************************o*************************************/
{
  int i;

  if( use_curses ) clear();

  print("To toggle different modes\n");
  print("a = all nodes         ");
  print("c = centre screen     ");
  print("d = dependencies      \n");
  print("e = event showing     ");
  print("f = show full tree    ");
  print("w = wait (no update)  \n");

  print("\n");

  print("To move the current working node use:\n");
  print("h or <left>  --> father       ");
  print("j or <down>  --> next         \n");
  print("k or <up>    --> previous     ");
  print("l or <right> --> the child    \n");

  print("g or <PgDn>  --> last node    ");
  print("t or <PgUp>  --> top node     \n");
  print("= or <home>  --> suite node   \n");

  print("\n");

  print("To set the status length for nodes:\n");
  print("1   = 1-character        ");
  print("3   = 3-character        ");
  print("9/0 = Full status name   \n");

  print("\n");

  print("To toggle the status masks:\n");
  for( i=0 ; i<STATUS_USABLE ; i++ )
  {
    print("%s = for the status %-10s       ",
      status_char[i],status_name[i]);
    if( i % 2 || i == (STATUS_USABLE-1) )
      print("\n");
  }

  print("\n");

  print("H or !   to get this help page      ");
  print("q or ^C  teminate the status\n");
  print("+ or -   to adjust the interval     ");
  print("/ or ?   to search a pattern\n");
  print("n or N   to search next/previous    ");
  print(":        to execute a command\n");

  if( use_curses ) message("Hit any key to continue.",TRUE);
}

static int search(int dir, char *new_pattern)
/**************************************************************************
?  Search for a next node/string in dir (TRUE==forwards, FALSE==backwards)
=  Boolean status was a next one found
!  If the new node isn't visible it is not always displayed???
************************************o*************************************/
{
  int       found = FALSE;
  char      buff[MAXLEN];          /* To build the message */

  sms_node *last,*next;
  sms_node *new;

  if( new_pattern && *new_pattern )
  {
    last = NULL;
    strcpy(pattern,new_pattern);
  }

  if( !pattern[0] )
  {
    message("No pattern?",FALSE);
    return FALSE;
  }

  if(!sms_cd_find(pattern,ref->nid,sms_._super,&last,&next))
  {
    sprintf(buff,"%s (no match)",pattern);
    message(buff,FALSE);
    return FALSE;
  }

  new = (dir^search_dir)?last:next;

  if( new != ref )
  {
    strcpy(cnode,sms_node_full_name((dir^search_dir)?last:next));
    return TRUE;
  }

  message("No more matches!",FALSE);
  return FALSE;
}

static int user_input(void)
/**************************************************************************
?  Read next character(s), if any, and process it/(them)
|  In non curses mode this is void.
=  BOOLEAN status was the parameters modified.
*NOTICE! Remember to update the help() when you modify the keys!
************************************o*************************************/
{
  int rch;
  int i;
  int rc = FALSE;

  char buff[MAXLEN];

  if( !use_curses ) return rc;

  while( !c_break && (rch=wgetch(stdscr)) != ERR )
  {
    i = 0;                         /* Used to count the status maks bit */
    switch( rch )
    {
      case 'A': i++;               /* Do NOT change the order! */
      case 'R': i++;
      case 'S': i++;
      case 'Q': i++;
      case 'C': i++;
      case 'P': i++;
      case 'U':
        statusmask ^= (1<<i);
        if( sms_overview(i,sms_._super) ) rc = TRUE;
        break;
                                   /* Options */
      case 'a':
        allnodes = !allnodes;
        if(allnodes) fullmode = TRUE;
        /* count_tables(sms_._super); */
        rc = TRUE;
        break;
      case 'c':
        centre = !centre;
        rc = TRUE;
        break;
      case 'd': case 'D':
        showdeps = !showdeps;
        rc = TRUE;
        break;
      case 'e': case 'E': 
        showevents = !showevents;
        rc = TRUE;
        break;
      case 'f': case 'F': 
        if( allnodes ) beep();
        else           { fullmode = !fullmode; rc = TRUE; }
        break;
      case 'w': case 'W':
        waitme = !waitme; told=FALSE;
        header( RPC_NONE );
        break;

      case '9': case '0':
        if(statusmode != FULL_NAME )
        {
          rc = TRUE;
          statusmode  =  FULL_NAME;
          count_tables(sms_._super);
        }
        break;
      case '3': 
        if(statusmode != THREE_CHAR )
        {
          rc = TRUE;
          statusmode  =  THREE_CHAR;
          count_tables(sms_._super);
        }
        break;
      case '1':
        if(statusmode != SINGLE_CHAR )
        {
          rc = TRUE;
          statusmode  =  SINGLE_CHAR;
          count_tables(sms_._super);
        }
        break;

      case 'q':
        c_break = TRUE;
        rc = TRUE;
        break;

      case '!': case 'H':
        help(printw);
        rc = TRUE;
        break;

      case '':
        clear();
        rc = TRUE;
        break;

      case '=': case KEY_HOME:   i++;
      case 't': case KEY_A3:     i++;
      case 'g': case KEY_C3:     i++;

      case 'l': case KEY_RIGHT:  i++;
      case 'k': case KEY_UP:     i++;
      case 'j': case KEY_DOWN:   i++;
      case 'h': case KEY_LEFT:
        if( cd_to(i) )
        {
          count_tables(sms_._super);
          rc = TRUE;
        }
        break;

      case '+': 
        interval++;
        break;
      case '-': 
        if( interval > 1 ) interval--;
        break;

      case ':': 
        edit_line(rch,buff,MAXLEN);
        message("Command not implemented yet (sorry!)",FALSE);
        break;

      case '/': 
      case '?': 
        search_dir = (rch=='/');
        if( edit_line(rch,buff,MAXLEN) )
          if( search(TRUE,buff) ) rc = TRUE;
        break;

      case 'n':
      case 'N':
        if( search( rch=='n',NULL ) ) rc = TRUE;
        break;

      default:
        beep();
        message("key not in use; use H or ? to get help",FALSE);
        break;
    }
  }

  return rc;
}

static void catch_win(int);

static void build_win(void)
/**************************************************************************
?  Create the "terminal" and catch the signals if defined in the system
|  The method of scrolling is different for a "fast" device xterm.
@  environment TERM
************************************o*************************************/
{
  int   fd    = -1;

  old_int  = signal(SIGINT,catch);        /* Remember the old */
  old_quit = signal(SIGQUIT,catch);       /* signal positions */
 
#ifdef SIGCONT
  old_stop = signal(SIGTSTP,catch_stop);
  old_cont = signal(SIGCONT,catch_continue);
#endif
 
  input = NULL;

  if( ! scr )
  {
    slow_flag = strcmp(getenv("TERM"),"xterm");  /* xterm is fast */

    if( (fd = dup(fileno(stdin))) == -1 )
    {
      ioi_perror("BUILD-WIND","file creation failed");
      return;
    }
    /* Some systems have stupid stdio.h ... so we cast it */
    input = (FILE *)fdopen(fd,"r");

    scr = newterm(getenv("TERM"),stdout,input);
  }
 
  if(scr)
  {
    signal(SIGINT,catch);        /* Got 2 tell them again since */
    signal(SIGQUIT,catch);       /* the newterm() modifies them */
 
#ifdef SIGCONT
    signal(SIGTSTP,catch_stop);
    signal(SIGCONT,catch_continue);
#endif
 
#if defined(SIGWINCH) && defined(TIOCGWINSZ)
    signal(SIGWINCH,catch_win);
#endif

#ifndef A_UNDERLINE                /* The old curses! */
    signal(SIGALRM,catch_alarm);
#endif

  }
  else
  {
    ioi_out(0,IOI_WAR,"status:TERM unknown by the curses");
    ioi_out(0,IOI_WAR,"status:continuing in line mode");
    fclose(input);
    input = NULL;
  }
}

#if defined(SIGWINCH) && defined(TIOCGWINSZ)
static void catch_win(int sig)
/**************************************************************************
?  Catch the window change signal (eg reshape of the xterm) and act
|  accordingly.
************************************o*************************************/
{
  struct winsize size;

  int err = 0;

  if (ioctl(fileno(stdout), TIOCGWINSZ, &size) >= 0)
  {
#if 0
FILE *fp=fopen("foobar","a");
fprintf(fp,"TIOCGWINSZ got %d x %d (was %d %d)\n",
size.ws_row,size.ws_col,  LINES,COLS);
fclose(fp);
#endif

    if(size.ws_row > 0) LINES = size.ws_row;
    if(size.ws_col > 0) COLS = size.ws_col;
  }

  signal(SIGWINCH,catch_win);

#if 0
  restore_win(TRUE);
  restore_signals();
  build_win();
#endif

/*
  restartterm(NULL,fileno(stdout),&err);
*/

  initialize_win();

  status_print(0);
}
#endif

int CDP_STATUS(int argc, char **argv)
/**************************************************************************
?  Display the status in the tree fashion.
************************************o*************************************/
{
  static int   called;

  static int   help_curses;
  static int   why;
  static int   smode_def = THREE_CHAR;
  static char *smode_name[] = { "single","three","full", NULL };

  static char *hostname;
  static char *nodename;
  static char  masks[10];

  statusmask = 0xffffffff;         /* By default show every status */

  if( called )
  {
    sms_list *names = NULL;
    int       first_time = TRUE;

    char  *to;
    char  *t;
    int    i;

    if( help_curses )
    {
      help((int (*)(const char *,...))printf);
      return TRUE;
    }

    if( masks[0] )                 /* User requests only these 2 B shown */
    {
      statusmask = 0;
        for( t=masks ; *t ; t++ )
          for( i=0 ; i<STATUS_SHUTDOWN ; i++ )
            if( status_char[i][0] == *t )
              statusmask |= (1<<i);

      if( !statusmask )
        return ioi_out(0,IOI_ERR,"status:mask:nothing to show");
    }

    ref = NULL;

    if( nodename ) { argc++; argv--; }

    names = sms_cd_names2(argc,argv,NULL);
    
    if( !names )
      return FALSE;

    to = names->name;

#ifdef MAIN
    {
      char name[L_cuserid+10];

      cuserid(name);
      strcat(name,"-s");

      if( sms_client_login(hostname,name,NULL,0,0,NULL) != SMS_E_OK )
        return FALSE;
    }
#endif
    if( sms_client_is_ok(HANDLE) != SMS_E_OK )
      return ioi_out(0,IOI_ERR,"status:Not connected.");

    if( allnodes )
      fullmode = TRUE;

    if( interval )
      build_win();

    use_curses = (scr != 0 && interval != 0);

    if( use_curses )
      initialize_win();
#ifdef MAIN
    else
      printf("Welcome to status version 1.0 compiled on %s\n",TODAY);
#endif
 
    c_break = FALSE;

    strcpy(cnode,to);
    waitme = FALSE;
    pattern[0] = '\0';
    search_dir=TRUE;

    news = TRUE;

    do
    {
      int mod_num = NIL;

      header(RPC_ON);
      news=(sms_client_news(HANDLE,sms_._action_number)==SMS_E_OK);
      header(RPC_OFF);

      if( first_time || (news && !waitme) )
      {
        int rc;

        header(RPC_ON);
        rc = sms_cdp_update(HANDLE);

        if(rc==SMS_E_OK)
        if(mod_num != sms_._modify_number)
          count_tables(sms_._super);
        mod_num = sms_._modify_number;

        header(RPC_OFF);

        if( rc == SMS_E_OK )
        {
          sms_node_clear_user_data(sms_._super);
          ref = NULL;

          if( first_time )
            if( !(IS_ROOT(cnode)) )
              if( !(sms_node_find_full(cnode)) )
                strcpy(cnode,"/");

          if( !c_break )
            if( !use_curses )
              while( names )
              {
                char *s;
                int   len;

                strcpy(cnode,names->name);

                s = names->name + strlen(names->name) - 1;

                while( isalnum(*s) || *s=='_' ) s--;
                s[1]='\0';

                if( (len=strlen(names->name)) != 1)   /* The super node is */
                  printf("%s",names->name);           /* a special case    */
                else
                  len = 0;

                status_print(len);

                names = names->next;
              }
            else
              status_print(0);
        }
        else
          c_break = TRUE;

        first_time = FALSE;
      }
      else 
      {
        int i;

        if( !news && !c_break )
          c_break = (sms_client_is_ok(HANDLE)!=SMS_E_OK);

        if( !c_break )
        {
          header( RPC_NONE );
          if( user_input() )
            status_print(0);
          else
            if( interval )         /* Sleep but process the keyboard */
              for(i=0 ; i<interval*10 ; i++)
              {
                header( RPC_NONE );
                if( user_input() )
                  status_print(0);

                if(c_break)
                  i=(1<<30);       /* Any huge number will do */
                else
                  sms_nap( 100000 );
              }
        }
      }

    }
    while( interval && !c_break );

#ifdef MAIN
    sms_client_logout();
#endif

    if(use_curses) restore_win(TRUE);

    if( interval )                 /* Put the original routines back! */
    {
      signal(SIGINT ,old_int);
      signal(SIGQUIT,old_quit);

#ifdef SIGCONT
      signal(SIGTSTP,old_stop);
      signal(SIGCONT,old_cont);
#endif

#ifdef SIGWINCH
      signal(SIGWINCH,SIG_IGN);
#endif
    }
  }
  else
  {
#ifdef MAIN
    ioi_exe *exe = 
#endif
    ioi_exe_add("status:cdp",cdp_status,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display all the nodes (parents and brothers).",
            "The default is to display only the selected one(s).",
            NULL
          ),NULL,1,&allnodes
        ),
        ioi_exe_param(
          "-ccentre",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display the selected node (cwn) on the centre of the screen.",
            "The default is to display the selected on top of the screen.",
            "In any case the full screen is utilized.",
            NULL
          ),NULL,1,&centre
        ),
        ioi_exe_param(
          "-ddependencies",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display queued nodes with the dependency information.",
            "That is whether it is waiting for date[D] or time[T] or",
            "father[F] or trigger[t].",
            NULL
          ),NULL,1,&showdeps
        ),
        ioi_exe_param(
          "-eevent",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display also the information of the events on node(s).",
            "By default the events are not displayed.",
            NULL
          ),NULL,1,&showevents
        ),
        ioi_exe_param(
          "-ffull",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display the full tree from the node requested.",
            "If the all option is used this is automatically turned on.",
            NULL
          ),NULL,1,&fullmode
        ),
        ioi_exe_param(
          "-iinterval",IOI_L_INTEGER,ioi_exe_argv(
            "The interval in seconds to repeat the status request.",
            "If the interval is zero the status is executed only once.",
            "",
            "The display doesn't change unless something has changed in",
            "the SMS. The interval is used to poll the SMS. So even",
            "small numbers can be used.",
            "Notice also that any change in SMS, not necessarily in the node",
            "been monitored, will cause the display to be refreshed.",
            "",
            "Use terminal q-command to get out of the loop.",
            "",
            "This uses curses(3) screen handling package, if terminal is",
            "known by the curses (env TERM).",
            NULL
          ),NULL,1,&interval,&interval_min,NULL,&interval_def
        ),
        ioi_exe_param(
          "-hhelp",IOI_L_BOOLEAN,ioi_exe_argv(
            "Display the curses help text.",
            NULL
          ),NULL,1,&help_curses
        ),
        ioi_exe_param(
          "-mmode",IOI_L_ENUM,ioi_exe_argv(
            "Mode to display the status after the node name.",
            "  single == [A]        a single character.",
            "  three  == [abo]      three characters of the status name",
            "  full   == [aborted]  the full status name",
            NULL
          ),NULL,1,&statusmode,smode_name,&smode_def
        ),
        ioi_exe_param(
          "-sstatusmask",IOI_L_CHARACTER,ioi_exe_argv(
            "Masks given status from the initial display. The characters given",
            "are the same as in the curses mode. Use -h to get curses help.",
            "By default all the modes are displayed.",
            "","NOTICE","",
            "Only nodes specifiend in the mask are shown.",
            "This has changend on 19-MAR-1992 / OP",
            NULL
          ),NULL,10,masks
        ),
#ifdef IMPOSSIBLE
        ioi_exe_param(
          "-wwhy",IOI_L_BOOLEAN,ioi_exe_argv(
            "Why the node is not running. This option can not be used",
            "with the curses and applies only to nodes given.",
            "It only answers to the nodes that are queued.",
            NULL
          ),NULL,1,&why
        ),
#endif
        NULL
      ),
      ioi_exe_link_param(
#ifdef MAIN
        ioi_exe_param(
          "host",IOI_L_STRING,ioi_exe_argv(
            "The host name to connect to.",
            NULL
          ),NULL,-1,&hostname
        ),
#endif
        ioi_exe_param(             /* This must be the last param */
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The node(s) to examine. If not given the SMS root node is used.",
#ifdef MAIN
            "The default node to examine is the IOI-variable \"cwn\" and",
            "if it doesn't exist the root node of the SMS.",
#endif
            "If the interval option (-i) is used, there can only be a single",
            "node, the rest of the nodes given are silently ignored.",
            NULL
          ),NULL,1,&nodename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Status of the node(s) in the SMS.",
        "Get the status from the SMS and display it in text.",
        "","EXAMPLE","",
        "To get a 'colorful' display use options [-acdei5 ]",
        "","FEATURES","",
        "This is version of the status now uses scrolling.",
        "It also vi type commands to search.",
        NULL
      )
    );
#ifdef MAIN
    if( ! exe ) exit(0);  
    called     = TRUE;
    ioi_open(0,NULL,NULL);         /* Nop! I'm not giving the args yet! */
    ioi_exe_substitute(exe,--argc,++argv);
#endif
  }

  return called = TRUE;
}

