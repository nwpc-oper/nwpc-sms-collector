/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     MIGRATE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     09-MAR-1995 / 08-DEC-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.5
.FILE     migrate.c
.DATE     10-OCT-1995 / 06-OCT-1995 / OP
.VERSION  4.3.12
.DATE     07-FEB-1997 / 07-FEB-1997 / OP
.VERSION  4.3.14
*         Bug fix for the triggers
.DATE     11-JUN-1998 / 11-JUN-1998 / OP
.VERSION  4.3.19
*         Migrate force-option
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     20-JAN-1999 / 18-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
*         Migrate with cancel and plug
.DATE     09-FEB-1999 / 08-FEB-1999 / OP
.VERSION  4.4.1
*         Plug modified
.DATE     26-MAR-1999 / 26-MAR--1999 / OP
.VERSION  4.4.2
*         Cancel aliases in bulk
*
*  Migrate a node (typically a suite):
*    XDR the node into a checkpoint file with a magic cookie
*    Cancel all it's kids
*    Mark the node as being migrated and remember the magic cookie
*
*  Restore a migrated node:
*    Check that the file really contains the migrated node (magic cookie)
*    Restore the node
*
*  Magic cookie is really the name of the node.
*
************************************o*************************************/

#include "smslib.h"

static int has_running(sms_node *np)
/**************************************************************************
?  Check if node has any tasks in active or submitted state
=  Boolean status: TRUE np is running or one of it's kids is running
************************************o*************************************/
{
  if( np->status == STATUS_ACTIVE || np->status == STATUS_SUBMITTED )
    return TRUE;

  if( np->status == STATUS_SUSPENDED )
    if( np->savedstat == STATUS_ACTIVE || np->savedstat == STATUS_SUBMITTED )
      return TRUE;

  for( np = np->kids; np ; np=np->next )
    if( has_running(np) )
      return TRUE;

  return FALSE;
}

int sms_migrate(sms_node *np,      /* Privileges are already checked */
                char     *filename,
                int       options)
/**************************************************************************
?  The SMS part of the migrate
=  SMS-RETURN-CODE
************************************o*************************************/
{
  int       rc = TRUE;
  sms_node *brother;
  char     *base;
  char      name[MAXLEN];
  int       force;
  int       autom;
  int       cancel;
  int       running = 0;
  char      fn[MAXLEN];

  strcpy(fn, sms_node_full_name(np));

  sms_decode(options,&autom,&force,&cancel,0);

  if( np->type!=NODE_SUITE && np->type!=NODE_FAMILY ) 
    return sms_error(SMS_E_MIGRATE,"migrate:not a suite nor a family %s",STR(fn));

  if( FLAG_ISSET(np,FLAG_MIGRATED) )
    if( autom )                    /* Auto migration */
      return SMS_E_OK;
    else
      return sms_error(SMS_E_MIGRATE,"migrate:%s already done",STR(fn));

  running = has_running(np);

  if( running && !force )
    if( autom )                    /* Auto migration */
      spit(0,IOI_WAR,"migrate:%s tasks running",STR(sms_node_full_name(np)));
    else 
      return sms_error(SMS_E_MIGRATE,"migrate:%s tasks running",STR(fn));

  if( ! np->kids )
    return SMS_E_OK;

  if( !filename )
  {
    base = sms_variable_get("SMSHOME",np);
    if( !base )
      base=".";

    if( ! sms_edit_mkdir_reverse(base, np) ) return
      sms_error(SMS_E_MIGRATE,"migrate:no dir %s",STR(fn));

    sprintf(name,"%s/%s.check",STR(base),STR(fn));
  }
  else
    strcpy(name,filename);

  brother = np->next;
  np->next = NULL;
  rc = sms_node_write(np,name);
  np->next = brother;

  if( !rc )
    return sms_error(SMS_E_WRITE,"migrate:for %s aborted",STR(fn));

  if( cancel )
  {
    LOGGING(np->parent);
    sms_cancel(np,FALSE,FALSE,TRUE);
  }
  else
  {
    while( np->kids )
      sms_cancel(np->kids,FALSE,FALSE,TRUE);

    FLAG_SET(np,FLAG_MIGRATED);
    SUITE_MODIFIED(np);
  }

  GET_TRIGGERS;
  spit(0,IOI_MSG,"migrate:%s by %s%s%s",STR(fn),STR(SMS_USER),
       (running && force)? " using force" : "",
       (cancel)? " with cancel" : "");

  return SMS_E_OK;
}

int sms_restore(sms_node *np,      /* Privileges are already checked */
                char     *filename, 
                int       options)
/**************************************************************************
?  The SMS part of the restore
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_status *sp = NULL;
  char     *base;
  char      name[MAXLEN];
  int       rc = TRUE;

  if( ! FLAG_ISSET(np,FLAG_MIGRATED) )
    return sms_error(SMS_E_RESTORE,"restore:%s not migrated",
                     STR(sms_node_full_name(np)));

  if( np->kids )
    return sms_error(SMS_E_RESTORE,"restore:%s has kids?",
                     STR(sms_node_full_name(np)));

  if( np->type!=NODE_SUITE && np->type!=NODE_FAMILY ) 
    return sms_error(SMS_E_MIGRATE,"restore:not a suite nor a family %s",
                     STR(sms_node_full_name(np)));

  if( !filename )
  {
    base = sms_variable_get("SMSHOME",np);
    if( !base )
      base=".";
    sprintf(name,"%s/%s.check",STR(base),STR(sms_node_full_name(np)));
  }
  else
    strcpy(name,filename);

  sms_node_read(name,&sp);

  if( sp && sp->node && sp->node->kids &&
      sp->node->name && strcmp(sp->node->name,np->name)==0 )
  {
    np->kids = sp->node->kids;

    if( ! sms_node_after_receive(np) )
    {
      np->kids = NULL;
      spit(0,IOI_ERR,"restore:%s validation problem",STR(sms_node_full_name(np)));
      rc = FALSE;
    }
    else
    {
      sms_time *cp = np->autocm;

      sp->node->kids = NULL;

      FLAG_CLEAR(np,FLAG_MIGRATED);
      SUITE_MODIFIED(np);
      GET_TRIGGERS;

      if(cp && np->status==STATUS_COMPLETE)
      {
        cp->status = TIME_UNUSED;  /* Start counting again */
      }
    }
  }
  else
    rc = spit(0,IOI_ERR,"restore:%s file read error",STR(sms_node_full_name(np)));

  NODE_FREE(sp,sms_status);

  if(rc)
    spit(0,IOI_MSG,"restore:%s by %s",STR(sms_node_full_name(np)),
         options? "SMS" : STR(SMS_USER));

  return rc? SMS_E_OK : SMS_E_RESTORE;
}

int sms_restore_plug(sms_node *np,      /* Privileges are already checked */
                     sms_node *moved)   /* The new stuff to be plugged    */
/**************************************************************************
?  The SMS part of the plug (plug "moved" into "np"
=  SMS-RETURN-CODE
************************************o*************************************/
{
  char     *base;
  char      name[MAXLEN];
  int       rc = TRUE;
  sms_node *kid = 0;

  if( FLAG_ISSET(np,FLAG_MIGRATED) )
    return sms_error(SMS_E_RESTORE,"plug:%s is migrated, cannot plug",
                     STR(sms_node_full_name(np)));

  if(!sms_cmd_typeok("plug",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,0))
    return SMS_E_TYPE;

  if(np->type==NODE_SUPER)
  {
    if(!sms_cmd_typeok("plug",moved,NODE_SUITE,0))
      return SMS_E_TYPE;
  }
  else
    if(!sms_cmd_typeok("plug",moved,NODE_FAMILY,0))
      return SMS_E_TYPE;

  if( ! ls_find(&np->kids, moved->name) )
  {
    ls_add(&np->kids, moved);


    if( ! sms_node_after_receive(np) )
    {
      ls_remove(&np->kids, moved);
      spit(0,IOI_ERR,"plug:%s validation problem",STR(sms_node_full_name(np)));
      rc = FALSE;
    }
    else
    {
      sms_time *cp = moved->autocm;

      sms_status_change(np,sms_status_max(np->kids),FALSE,FALSE);

      SUITE_MODIFIED(moved);
      GET_TRIGGERS;

      if(cp && moved->status==STATUS_COMPLETE)
        cp->status = TIME_UNUSED;  /* Start counting again */
    }
  }
  else
    rc = spit(0,IOI_ERR,"plub:%s already has %s",
              STR(sms_node_full_name(np)), STR(moved->name));

  if(rc)
    spit(0,IOI_MSG,"plug:%s into %s by %s",STR(moved->name),STR(sms_node_full_name(np)), STR(SMS_USER));

  return rc? SMS_E_OK : SMS_E_RESTORE;
}

int cdp_migrate_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   force;
  static int   autom = 0;          /* Must be 0 always */
  static int   cancel;

  if( called )
  {
    char     *av[2] = {"migrate"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,sms_encode(&autom,&force,&cancel,0),&names);
  }
  else
    ioi_exe_add("migrate:cdp",cdp_migrate_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ccancel",IOI_L_BOOLEAN,ioi_exe_argv(
            "Cancel the node(s) after migration is done.",
            "Used when suites/families are moved between SMS's",
            "There is no automatic restore possible anymore with this option",
            NULL
          ),NULL,1,&cancel
        ),
        ioi_exe_param(
          "-fforce",IOI_L_BOOLEAN,ioi_exe_argv(
            "Migrate node(s) even if they should not be migrated",
            "This means that jobs will not be able to complete",
            NULL
          ),NULL,1,&force
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name of the node(s) to be migrated.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Migrate node(s) into files.",
        "The node(s) are written into a checkpoint-file(s) and the",
        "definition removed from SMS. Only an empty node is left with",
        "a flag MIGRATED on.",
        "Node can be restored later on with restore(cdp) command.",
        "Only SUITES and FAMILIES can be migrated and none of the tasks",
        "in them may be active or submitted. Otherwise the tasks would",
        "not be able to login to SMS. The node to be migrated must have",
        "kids.",
        "The checkpoint file is written in SMSHOME/SMSNAME.check",
        "Migrated nodes are automatically resotred at suite begin and",
        "suite/family requeue. A node migrated while queued is NOT restored",
        "when suite is processed normally.",
        NULL
      )
    );

  return called = TRUE;
}

int cdp_restore_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    char *av[2] = {"restore"};
    sms_list *names = NULL;

    if(dummy) { argc++; argv--; }  /* GOT 2 BE */

    if( ! sms_cd_names2(argc,argv,&names) )
      return FALSE;

    return ! COMMAND(1,av,NULL,0,&names);
  }
  else
    ioi_exe_add("restore:cdp",cdp_restore_cmd,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "node(s)",IOI_L_STRING,ioi_exe_argv(
            "The name of the node(s) to be restored.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Restore migrated node(s) from files.",
        "The node(s) are read back into SMS from checkpoint-file(s)",
        "The node read must be empty and to have the MIGRATE flag on.",
        NULL
      )
    );

  return called = TRUE;
}

int cdp_migrate_plug(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *filename;
  static char *from, *into;

  if( called )
  {
    sms_status *sp    = 0;
    sms_node   *fp, *ip;
    int         rc;
    
    if(! (ip=sms_node_net_find(into)) )
      return spit(0,IOI_ERR,"plug:%s (into) not found?",STR(into));

    if( filename )
    {
      sms_node_read(filename,&sp);

      if( sp && sp->node && sp->node->name )
        fp = sp->node;
      else
        rc = spit(0,IOI_ERR,"plug:%s file read error",STR(filename));
    }
    else
      if( ! (fp=sms_node_net_find(from)) )
        return spit(0,IOI_ERR,"plug:%s (from) not found?",STR(from));

    rc = cdp_plug(ip, fp);

    if(sp) NODE_FREE(sp,sms_status);

    return ! rc;
  }
  else
    ioi_exe_add("plug:cdp",cdp_migrate_plug,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ffile",IOI_L_STRING,ioi_exe_argv(
            "CDP reads the node to be plugged from a checkpoint-file/imigration-file.",
            "That is, plug the node in this file as a kid to node given",
            "(only one node need to be given.)",
            NULL
          ),NULL,1,&filename
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "intonode",IOI_L_STRING,ioi_exe_argv(
            "The name of the node to be plugged into.",
            "The node name can be a netname (//host/suite[/family[/task]])",
            NULL
          ),NULL,-1,&into
        ),
        ioi_exe_param(
          "fromnode",IOI_L_STRING,ioi_exe_argv(
            "The name of the node to be plugged.",
            "The node name can be a netname (//host/suite[/family[/task]])",
            "Ignored if -f option is used.",
            NULL
          ),NULL,1,&from
        ),
        NULL
      ),
      ioi_exe_argv(
        "Move nodes between SMS'es",
        "Plug suite/family fromnode into sms/suite/family intonode",
        "Typically fromnode and intonode are not in the same SMS.",
        "You must be sure to have the latest status (use get(cdp))",
        "in order to get the passwords correctly installed and/or",
        "make sure that there is no tasks running in fromnode.",
        NULL
      )
    );

  return called = TRUE;
}

void sms_restore_auto(sms_node *np)
/**************************************************************************
?  Autorestore other nodes
************************************o*************************************/
{
  sms_list *lp = np->restore;

  for( lp = np->restore; lp ; lp=lp->next )
  {
    sms_node *tmp;

    if( (tmp=sms_node_find(lp->name,np)) )
    {
      spit(0,IOI_MSG,"autorestore:%s on %s being complete",STR(lp->name),
           STR(sms_node_full_name(np)));
      if( ! tmp->kids)
        sms_restore(tmp, 0, TRUE);
    }
    else
    {
      spit(0,IOI_WAR,":autorestore:%s not found on %s being complete",STR(lp->name),
           STR(sms_node_full_name(np)));
    }
  }
}

static void mark_tree(sms_tree *tp)
/**************************************************************************
?  Go down the tree to calculate the connections.
************************************o*************************************/
{
  if( !tp ) return;

  mark_tree( tp->left  );
  mark_tree( tp->right );

  if( tp->math )
    if( tp->math->type == NODE_EVENT )
      tp->math->parent->user_int += 1;
    else
      tp->math->user_int += 1;
}

static void mark(sms_node *np)
/**************************************************************************
?  Loop over the triggers and count the pointers.
************************************o*************************************/
{
  if( np->status != STATUS_COMPLETE )
    if( np->trigger )
      mark_tree( np->trigger->math );

  np = np->kids;
  while(np)
  {
    mark(np);
    np = np->next;
  }
}

static count(sms_node *np)
/**************************************************************************
?  Check that all the nodes are free (the cancel counter is zero)
=  Number of dependencies.
************************************o*************************************/
{
  int rc = 0;

  rc = np->user_int;

  if(np->type==NODE_TASK || np->type==NODE_FAMILY || np->type==NODE_SUITE)
    for(np=np->kids; np ; np=np->next)   /* Only looping kids, not next! */
      rc += count(np);

  return rc;
}

static int migrateble(sms_node *np)
/**************************************************************************
?  The node can be migrated automatically if no node that is not complete
|  uses it in their triggers.
|
|  Since we have single-direction pointers only the only possible way to
|  find out if someone is pointing into this (or it's kids) is to loop over
|  the full tree.
|
|  For every pointer we increment the counter in the node pointed to.
|
|  If in the end any of the counters in the nodes not equals to zero there
|  must be someone outside the node pointing to it and the node can not
|  be automatically migrated.
|
=  Number of outside pointers.
|  0  --->  the node can be migrated.
|  >0 --->  the node is dependent.
************************************o*************************************/
{
  sms_node *super;
  int rc;

  if(np->type==NODE_SUPER)         /* It really isn't a good idea, eh? */
    return 1;

  sms_node_clear_user_data(sms_._super);

  for( super=sms_._super ; super ; super=super->next )
    mark(super);

  rc = count(np);
  rc -= np->user_int;

  sms_node_clear_user_data(sms_._super);

  return rc;
}

void sms_migrate_auto(sms_node *np)
/**************************************************************************
?  Migrate nodes automatically. Called by the SMS ONLY!
|
|  Syntax for automigrate is:
|
|  automigrate +01:00  migrate one hour after complete
|  automigrate 10      migrate 10 days after complete
|  automigrate 0       migrate immediately after being complete
************************************o*************************************/
{
  if(!np) return;

  while(np)
  {
    sms_node *next = np->next;   /* The np might disapper */

    if( sms_time_autocm(np,NODE_MIGRATE) )
    {
      if( migrateble(np) == 0 )
        sms_migrate(np,NULL,TRUE);
    }
    else
      sms_migrate_auto(np->kids);
     
    np=next;
  }
}

void sms_migrate_init(sms_node *np)
/**************************************************************************
?  Restore nodes migrated at the begin of a suite
|  or at requeue
************************************o*************************************/
{
  if(!np) return;

  if(np->type!=NODE_SUITE && np->type!=NODE_FAMILY) return;

  if( FLAG_ISSET(np,FLAG_MIGRATED) )
    sms_restore(np,NULL,TRUE);

  np = np->kids;
  while(np)
  {
    sms_migrate_init(np);
    np = np->next;
  }
}
