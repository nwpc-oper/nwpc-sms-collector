/**************************************************************************
.TITLE    TIMER
.NAME     CDP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-MAR-1992 / 06-DEC-1991 / OP
.VERSION  4.0
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     timer.c
*
*  This code is to be included in to the sms_svc.c
*
*  It handles the timing on successfull rpc call is SMS_STATISTICS is set
*
************************************o*************************************/

#ifdef SMS_STATISTICS
#  ifdef SMS_TIMER
     {
       clock_t end = clock();

       if( end != ((clock_t)-1) && end-smss_._start != ((clock_t)-1) )
         if( end>smss_._start )    /* Yeps, we might miss a few! */
           if( smss_._who == 0 )   /* TASKS */
             smss_._task_clocks += end-smss_._start;
           else if( smss_._who == 1 )
           {
             smss_._user_clocks += end-smss_._start;
             sms_._current_con->clocks += end-smss_._start;
           }
           /* ELSE ERROR */
     }
#  endif
#endif
