/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     YP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     20-APR-1998 / 20-APR-1998 / OP
.VERSION  4.3.18
.LANGUAGE ANSI-C
.FILE     yp.c
*
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     30-OCT-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
*
*  This file contains routines to cache YP related informatio in
*  order to speed up things
* 
************************************o*************************************/

#include "smslib.h"
#include <pwd.h>

struct pw {
  int           type;
  char          *name;
  struct pw     *next;
  struct passwd  p;
};

static struct pw *cachepw;

struct passwd *sms_getpwuid(int uid)
{
  struct passwd *p;
  struct pw     *pw;

  for( pw = cachepw ; pw ; pw=pw->next )
    if( pw->p.pw_uid == uid )
      return &(pw->p);

  /* Get it using libc and remember it */

  if( ! (p = getpwuid(uid)) )
    return 0;

  if( ! (pw=calloc(sizeof(struct pw),1)) )
    return 0;

#define COPY(x) if(p->x) { pw->p.x = strdup(p->x); }

  COPY(pw_name);
  COPY(pw_passwd);
  pw->p.pw_uid = p->pw_uid;
  pw->p.pw_gid = p->pw_gid;
#if !(defined(AIX) || defined(__alpha) || defined(linux))
  COPY(pw_age);
  COPY(pw_comment);
#endif
  COPY(pw_gecos);
  COPY(pw_dir);
  COPY(pw_shell);

  ls_add(&cachepw,pw);

  return &(pw->p);
}

void sms_endpwent() 
{ 
  endpwent();
}

void sms_yp_dump(char *name)
{
  FILE          *fp = 0;
  struct pw     *pw;
  struct passwd *p;

  if( ! (fp=sms_fopen(name,"w","SMS-YP-DUMP")) )
    return;

  for( pw=cachepw ; pw ; pw=pw->next )
  {
    p = &(pw->p);

    fprintf(fp,"%s:%s:%d:%d:%s:%s:%s\n",
            STR(p->pw_name), STR(p->pw_passwd), p->pw_uid, p->pw_gid,
#if !(defined(AIX) || defined(linux))
            STR(p->pw_comment),
#else
            STR(p->pw_name),
#endif
            STR(p->pw_dir),  STR(p->pw_shell));
  }

  FCLOSE(fp);
}
