/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMSLIB-HEADER
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     smslib.h
.DATE     31-JUL-1992 / 21-JUN-1991 / OP
.VERSION  4.0
.DATE     18-MAR-1993 / 18-MAR-1993 / OP
.VERSION  4.1
.DATE     26-APR-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     21-FEB-1994 / 13-FEB-1994 / OP
.VERSION  4.2.1
*         Added support for sending messages into SMS log file (smsmsg)
.DATE     25-AUG-1994 / 22-FEB-1994 / OP
.VERSION  4.3
*         Added support for sending meter and label info into SMS
*         Added support for fast login for tasks
*         Suite registering logic changed
*         Node checkpointing and migration
*         Checked compatibility with 4.2 (needs patches in 4.2)
*         Autocancel / automigration
*         Resubmit (4.3.6)
.DATE     25-SEP-1995 / 01-SEP-1994 / OP
.VERSION  4.3.5-10
*         Late concept
.DATE     26-SEP-1995 / 26-SEP-1995 / OP
.VERSION  4.3.11
*         Added per node logging
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Added autorestore
.DATE     17-OCT-1997 / 17-OCT-1997 / OP
.VERSION  4.3.16
*         Compressed outputfiles
*         Filesystem full for edit
.DATE     27-FEB-1998 / 26-FEB-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     20-APR-1998 / 21-APR-1998 / OP
.VERSION  4.3.18
*         YP-caching
.DATE     04-JUN-1998 / 15-JUN-1998 / OP
.VERSION  4.3.19
*         date-repeat
*         longjump
.DATE     16-JUL-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
*         Run limit
*         Statistics of querying
.DATE     09-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     07-JAN-1999 / 17-AUG-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Variables have NIDs
*         Zombie passwords
*         Limit (pseudo queues)
*         Primitive talk
*         User and zombie requests
*         Task mail & wait
.DATE     05-FEB-1999 / 05-FEB-1999 / OP
.VERSION  4.4.1
*         Limit changed
*         Inlimit own type
*         Locked state
.DATE     04-FEB-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
*         Times for task state change
*         Default MAXLINES 5000 -> 10000
.DATE     07-JUN-2000 / 07-JUN-2000
.VERSION  4.4.4
*         %s for (*)printf is a macro
.DATE     28-JUN-2001 / 15-MAY-2001 / OP
.VERSION  4.4.5 ABT(c)
*         url, jobstatus,
*         Enumerated repeat
************************************o*************************************/

#ifndef SMS_SMSLIB_H
#define SMS_SMSLIB_H

#include <stdio.h>
#include <time.h>
#include <netdb.h>

#include <errno.h>
#include <signal.h>

#ifdef VMS
#  include <socket.h>
#else
#  ifdef xxxxAIX
#    define _POSIX_SOURCE
#    define _XOPEN_SOURCE
#    define _ALL_SOURCE
#  endif
#  include <sys/types.h>
#  include <sys/socket.h>
#endif

#ifdef AIX
#  include <sys/select.h>
#endif

#include <rpc/rpc.h>
#include "sms.h"
#include "smsproto.h"

#include "error.h"
#include "config.h"

#if defined(CRAY)
#  include <sys/unistd.h>          /* CRAY */
#else
#  if defined(__mips)
#    include <unistd.h>            /* MIPS == sgi / cdc */
#  else
#    if defined(VMS)               /* Nothing for the VMS/VAXC */
#    else
#      include <sys/file.h>        /* All the others */
#    endif
#  endif
#endif

#ifndef F_OK                       /* Stupid cyber need KERNEL! in sys/file.h */
#define F_OK            0
#define X_OK            1
#define W_OK            2
#define R_OK            4
#endif

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

#ifndef NIL
#define NIL (-1)
#endif

#ifndef MAXLEN
#define MAXLEN          255        /* For temp names, should be big enough */
#endif

#ifndef MAXNAME
#define MAXNAME          80
#endif

#ifndef MAXLINES
#define MAXLINES      10000
#define GUESSLEN        132
#endif

#ifndef MAXPASSLEN
#define MAXPASSLEN  20
#endif

#define DEF_RETRIES       1
#define SMS_HISTORY_LEN 100

#define LINE_WIDTH       80        /* 2 B replaced by a function */

#ifndef IFFREE
#define IFFREE(a) if(a) { free(a); a=NULL; } else
#endif

#define D(x)    fprintf(stderr,"TRAP %d\n",(x))

#define STR(x) sms_string((x), __FILE__ , __LINE__ )

#ifdef SMS_LIBRARY                 /* Should be in list.c */
#define EXT                        /* Make entry points   */
#else
#define EXT extern                 /* Generate reference  */
#endif

/**************************************************************************
*                              PRIVILEGES
************************************o*************************************/

#define PRIV_NONE     0            /* Monitor only          */
#define PRIV_USER     1            /* Access only own nodes */
#define PRIV_PLAY     2            /* Play / cancel         */
#define PRIV_OPER     3            /* Access all the nodes  */
#define PRIV_SYSTEM   4            /* Shutdown, stop        */
#define PRIV_ADMIN    5            /* Passwords and so on   */

#define PR_NONE      (1<<PRIV_NONE)
#define PR_USER      (1<<PRIV_USER)
#define PR_PLAY      (1<<PRIV_PLAY)
#define PR_OPER      (1<<PRIV_OPER)
#define PR_SYSTEM    (1<<PRIV_SYSTEM)
#define PR_ADMIN     (1<<PRIV_ADMIN)

#define PR_ALL       0x0000fffe    /* All but none */

#define PRIV_MAX      6            /* 32-bits in XDR! */

EXT char *privilege_name[]
#ifdef SMS_LIBRARY
  = { "none", "user", "play", "oper", "system", "admin", NULL }
#endif
;

/**************************************************************************
*                               ORDERING
************************************o*************************************/

#define ORDER_TOP     0
#define ORDER_BOTTOM  1
#define ORDER_ALPHA   2
#define ORDER_ORDER   3
#define ORDER_UP      4
#define ORDER_DOWN    5

EXT char *order_name[]
#ifdef SMS_LIBRARY
  = { "top", "bottom", "alphabetical", "order", "up", "down", NULL }
#endif
;

/**************************************************************************
*                           SUITE REGISTERING
************************************o*************************************/

#define SUITES_ADD    0
#define SUITES_DELETE 1
#define SUITES_SET    2
#define SUITES_LIST   3
#define SUITES_MINE   4
#define SUITES_NEWIN  5            /* Add new suites into my list       */
#define SUITES_NEWOUT 6            /* Don't add new suites into my list */

#define SMS_NEW_SUITES(x) cdp_suites(HANDLE, (x)? SUITES_NEWIN:SUITES_NEWOUT, NULL)

EXT char *suites_name[]
#ifdef SMS_LIBRARY
  = { "add", "delete", "set", "list", "mine", "newin", "newout", NULL }
#endif
;

/**************************************************************************
*  Character names of the enumerations
*
*  A bit clumsy way to do this!
************************************o*************************************/

#ifdef SMS_LIBRARY
  int sms_sizes[] = {              /* To be able to allocate proper size */
    sizeof(struct sms_list),
    sizeof(struct sms_user),
    sizeof(struct sms_connect),
    sizeof(struct sms_variable),
    sizeof(struct sms_time),
    sizeof(struct sms_date),
    sizeof(struct sms_trigger),
    sizeof(struct sms_tree),
    sizeof(struct sms_action),
    sizeof(struct sms_event),
    sizeof(struct sms_node),
    sizeof(struct sms_node),
    sizeof(struct sms_node),
    sizeof(struct sms_node),
    sizeof(struct sms_passwd),
    sizeof(struct sms_login),
    sizeof(struct sms_status),
    sizeof(struct sms_reply),
    sizeof(struct sms_check),
    sizeof(struct sms_nid),
    sizeof(struct sms_file),
    sizeof(struct sms_handle),
    sizeof(struct sms_repeat),
    sizeof(struct sms_dir),
    sizeof(struct sms_meter),
    sizeof(struct sms_label),
    sizeof(struct sms_time),       /* cancel  */
    sizeof(struct sms_time),       /* migrate */
    sizeof(struct sms_time),       /* late    */
    sizeof(struct sms_list),       /* restore  */
    sizeof(struct sms_trigger),    /* complete  */
    sizeof(struct sms_map),        /* nick names */
    sizeof(struct sms_node),       /* alias     */
    sizeof(struct sms_limit),
    sizeof(struct sms_inlimit),
    sizeof(struct sms_node),       /* unknown */
    sizeof(struct sms_zombie),
    sizeof(struct sms_project),
    sizeof(struct sms_object),
    sizeof(struct sms_object),     /* call */
    sizeof(struct sms_time),       /* call */
  };

  int sms_sizes_max = sizeof(sms_sizes)/sizeof(int);
#else
  extern int sms_sizes[];
  extern int sms_sizes_max;
#endif

#define TALLOC(t,i) (t *)sms_alloc(i)

EXT char *status_name[]
#ifdef SMS_LIBRARY
  = { "unknown", "suspended", "complete", "queued", "submitted", "active",
      "aborted", "shutdown",  "halted"  ,  NULL }
#endif
;

EXT char *status_char[]
#ifdef SMS_LIBRARY
  = { "U", "P", "C", "Q", "S", "R", "A", "D", "H", NULL }
#endif
;

EXT char *event_name[]
#ifdef SMS_LIBRARY
  = { "clear", "set", NULL }
#endif
;

EXT char *status_names[]           /* == status_name & event_name  */
#ifdef SMS_LIBRARY                 /* shutdown & halted R missing! */
  = { "unknown", "suspended", "complete", "queued", "submitted", "active",
      "aborted", "clear",     "set", NULL }
#endif
;

#define STATUS_NAMES_MAX (STATUS_USABLE+2)    /* NODE + EVENT */

EXT char *why_name[]
#ifdef SMS_LIBRARY
  = { "parent", "time", "date", "trigger", NULL }
#endif
;

EXT char *why_char[]
#ifdef SMS_LIBRARY
  = { "F", "T", "D", "t", NULL }
#endif
;

EXT char *privilege_do[]
#ifdef SMS_LIBRARY
  = { 
   "only monitor the status of the nodes",
   "only access nodes belonging to the user",
   "define and cancel (own) suites",
   "access all the nodes",
   "perform system activities like stop/shutdown/restart/check",
   "define/modify passwords",
   NULL }
#endif
;

EXT char *time_name[]
#ifdef SMS_LIBRARY
  = { "unused", "holding", "expired", "used", NULL }
#endif
;

EXT char *day_name[]
#ifdef SMS_LIBRARY
  = { "sunday",   "monday",   "tuesday",  "wednesday", 
      "thursday", "friday",   "saturday", NULL }
#endif
;

EXT char *clock_name[]
#ifdef SMS_LIBRARY
  = { "hybrid",  "real" , NULL } 
#endif
;

EXT char *node_name[]
#ifdef SMS_LIBRARY
  = { "list",     "user",     "connection", "variable", "time",
      "date",     "trigger",  "tree",       "action",   "event",
      "task",     "family",   "suite",      "super",    "passwd",
      "login",    "status",   "reply",      "check",    "nid",
      "file",     "handle",   "repeat",     "dir",      "meter",
      "label",    "cancel",   "migrate",    "late",     "restore",
      "complete", "nickname", "alias",      "limit",    "inlimit",
      "unknown",  "zombie",   "project",    "object",   "call",
      "cron",
      NULL  }
#endif
;

EXT char *limit_name[]
#ifdef SMS_LIBRARY
  = { "boolean",   "integer",
      NULL }
#endif
;

EXT char *inlimit_name[]
#ifdef SMS_LIBRARY
  = { "task",   "node",
      NULL }
#endif
;

EXT char *month_name[]
#ifdef SMS_LIBRARY
  = { "january",   "february",  "march",     "april",     "may",
      "june",      "july",      "august",    "september", "october",
      "november",  "december",  NULL }
#endif
;

EXT char *check_name[]
#ifdef SMS_LIBRARY
  = { "none",    "never",  "time",   "always", NULL }
#endif
;

EXT char *flag_name[]
#ifdef SMS_LIBRARY
  = { "has been forced to aborted",
      "user edit failed",
      "the job failed",
      "editing failed (.job file can not be created)",
      "job could not be submitted (SMSCMD failed)",
      "SMS could not find the script",
      "killed by user",
      "has been migrated",
      "is late",
      "has user messages",
      "complete by rule",
      "queue limit reached",
      "running task is waiting for trigger",
      "node is locked by a user",
      NULL }
#endif
;

EXT char *flag_alter_name[]
#ifdef SMS_LIBRARY
  = { "force-aborted", "user-edit",     "task-aborted",
      "edit-failed",   "smscmd-failed", "no-script",
      "killed",        "migrated",      "late",
      "message",       "complete",      "queuelimit",
      "task-waiting",  "locked",
      "*",
      NULL }
#endif
;

EXT char *repeat_name[]
#ifdef SMS_LIBRARY
  = { "day",  "month",  "year",  "integer",  "string", "file", "date", "enumerated", NULL }
#endif
;

EXT char *late_name[]
#ifdef SMS_LIBRARY
  = { "submitted for too long",
      "not yet active",
      "not yet complete",
       NULL }
#endif
;

EXT char *sms_command_name[]
#ifdef SMS_LIBRARY
  = { "null-cmd", "login", "logout", "news",   "history",
      "status",   "play",  "cmd",    "oldcmd", "lists",
       NULL }
#endif
;

EXT char *zombie_whyname[]
#ifdef SMS_LIBRARY
 = { "sms", "user", "net",
     NULL }
#endif
;

EXT char *mail_cmds[]
#ifdef SMS_LIBRARY
 = { "get", "send", "delete", "deletemot",
     NULL }
#endif
;

EXT char *zombie_cmds[]
#ifdef SMS_LIBRARY
 = { "get", "fob", "delete", "fail", "recover",
     NULL }
#endif
;

/**************************************************************************
*  SMS type info
************************************o*************************************/

EXT struct {
  unsigned int is_node:1    ;         /* has kids, variables, ... */
  unsigned int has_kids:1   ;
  unsigned int dummy1:1     ;
  unsigned int dummy2:1     ;
} sms_node_table [] 
#ifdef SMS_LIBRARY
= {
  { 0, 0, 0, 0, }, /* NODE_LIST         */
  { 0, 0, 0, 0, }, /* NODE_USER         */
  { 0, 0, 0, 0, }, /* NODE_CONNECTION   */
  { 0, 0, 0, 0, }, /* NODE_VARIABLE     */
  { 0, 0, 0, 0, }, /* NODE_TIME         */
  { 0, 0, 0, 0, }, /* NODE_DATE         */
  { 1, 1, 0, 0, }, /* NODE_TRIGGER      */
  { 0, 0, 0, 0, }, /* NODE_TREE         */
  { 0, 0, 0, 0, }, /* NODE_ACTION       */
  { 0, 1, 0, 0, }, /* NODE_EVENT        */
  { 1, 1, 0, 0, }, /* NODE_TASK         */
  { 1, 1, 0, 0, }, /* NODE_FAMILY       */
  { 1, 1, 0, 0, }, /* NODE_SUITE        */
  { 1, 1, 0, 0, }, /* NODE_SUPER        */
  { 0, 0, 0, 0, }, /* NODE_PASSWD       */
  { 0, 0, 0, 0, }, /* NODE_LOGIN        */
  { 0, 0, 0, 0, }, /* NODE_STATUS       */
  { 0, 0, 0, 0, }, /* NODE_REPLY        */
  { 0, 0, 0, 0, }, /* NODE_CHECK        */
  { 0, 0, 0, 0, }, /* NODE_NID          */
  { 0, 0, 0, 0, }, /* NODE_FILE         */
  { 0, 0, 0, 0, }, /* NODE_HANDLE       */
  { 0, 1, 0, 0, }, /* NODE_REPEAT       */
  { 0, 0, 0, 0, }, /* NODE_DIR          */
  { 0, 1, 0, 0, }, /* NODE_METER        */
  { 0, 1, 0, 0, }, /* NODE_LABEL        */
  { 0, 0, 0, 0, }, /* NODE_CANCEL       */
  { 0, 0, 0, 0, }, /* NODE_MIGRATE      */
  { 0, 0, 0, 0, }, /* NODE_LATE         */
  { 0, 0, 0, 0, }, /* NODE_RESTORE      */
  { 0, 0, 0, 0, }, /* NODE_COMPLETE     */
  { 0, 0, 0, 0, }, /* NODE_MAP          */
  { 1, 1, 0, 0, }, /* NODE_ALIAS        */
  { 0, 1, 0, 0, }, /* NODE_LIMIT        */
  { 0, 1, 0, 0, }, /* NODE_INLIMIT      */
  { 0, 0, 0, 0, }, /* NODE_UNKNOWN      */
  { 0, 0, 0, 0, }, /* NODE_ZOMBIE       */

  { 1, 1, 0, 0, }, /* NODE_PROJECT      */
  { 1, 1, 0, 0, }, /* NODE_OBJECT       */
  { 1, 1, 0, 0, }, /* NODE_CALL         */
}
#endif
;

/**************************************************************************
*  SMS Macros
************************************o*************************************/

#define DAY_IS(day,now) ( (1<<((day)-1)) & (now) || ((now) | EVERYDAY) )
/* e.g.  if( DAY_IS(MONDAY,date->weekdays) ) ... */
/* NA */

#define SMS_USER   (sms_._current_con != NULL)? sms_._current_con->name : "SMS"

#define PRIVILEGE(priv) ((!sms_._passwd && sms_._current_con->passok) || \
                         priv==PR_NONE || priv==0 || \
                         (sms_._current_con->passok & priv))

/*
 * If the version number is nor right the login fails!
 */
#define SUPPORTED(vers,rev,mod) ( sms_._xdr_version >= rev*1000+mod )
     

#ifdef SMS_CROSS_SUITE             /* Mark all suites modified */

#  define SUITE_CHANGED(x) { if( sms_._is_server ) { \
      sms_node *s = x;                               \
      if(s) {                                        \
        s->act_no = ++sms_._action_number;           \
        while(s->parent) s=s->parent;                \
        for( s = s->kids ; s ; s = s->next )         \
          s->modified=TRUE;                          \
      } } }

#else                              /* Mark only one suite modified */

#  define SUITE_CHANGED(x) { if( sms_._is_server ) { \
      sms_node *s = x;                               \
      if(s) {                                        \
        s->act_no = ++sms_._action_number;           \
        while(s->parent && s->type != NODE_SUITE)    \
          s=s->parent;                               \
        s->modified=TRUE;                            \
      } } }

#endif /* CROSS-SUITE */

#define SUITE_MODIFIED(x) { if( sms_._is_server ) { \
    sms_._action_on_mod = sms_._action_number;      \
    sms_._modify_number++;                          \
    sms_nid_count(0,sms_._super,sms_._action_number); \
    SUITE_CHANGED(x); } }

#define GET_TRIGGERS sms_node_triggers(sms_._super->kids,sms_._super)

#define LOGGING(np) sms_._node = (np)

#define IS_ROOT(x) ( x && *(x)=='/' && !(x)[1] )

#define TEST_ONLY  "This is only in the test version of the SMS."

#define IS_RUNNING  ( sms_._status == SMS_RUNNING  )
#define IS_SHUTDOWN ( sms_._status == SMS_SHUTDOWN )
#define IS_HALTED   ( sms_._status == SMS_HALTED   )
#define IS_DYING    ( sms_._status == SMS_DYING    )

#define FLAG_SET(np,flag)    (np)->flags |=  (1<<(flag))
#define FLAG_CLEAR(np,flag)  (np)->flags &= ~(1<<(flag))
#define FLAG_ISSET(np,flag) ((np)->flags &   (1<<(flag)))

#define NODE_FREE(np,type) if(np) np=(type *)sms_node_free(np)

#define SMSSCRIPT(np,i) sms_variable_get("SMSSCRIPT",np)
#undef  SMSSCRIPT

#define SMSSCRIPT(np,i) sms_edit_script_name(np,i)
#define SMSJOB(np)      sms_variable_get("SMSJOB",np)

#define HANDLE (sms_._logins? sms_._logins : 0)

#define USE_NET_NAMES

#ifdef USE_NET_NAMES
#  define COMMAND(ac,av,lp,opt,nam) sms_client_cmd_any(ac,av,lp,opt,nam)
#else
#  define COMMAND(ac,av,lp,opt,nam) sms_client_cmd(HANDLE,ac,av,lp,opt,nam)
#endif

/**************************************************************************
*  SMS Global variables
************************************o*************************************/

EXT struct {
  /*
   *  Put the following into the checkpoint file:
   */
  sms_node     *_super;            /* The very first level of nodes   */
  int           _action_number;    /* State changes                   */
  int           _modify_number;    /* Changes in the tree             */
  int           _action_on_mod;    /* Action number when last modified*/
  int           _handle;           /* Client handle numbers (in SMS)  */
  sms_handle   *_logins;           /* Logins to SMS's (in (X)CDP)     */

  /*
   *  And the rest of the stuff is automatic.
   */
  sms_passwd   *_passwd;           /* Users with pass words           */
  sms_list     *_whitelist;        /* Users that are ok if in use     */
  sms_list     *_blacklist;        /* Users that are not ok if in use */
  int           _is_server;        /* TRUE if running as a server     */
  int           _is_xcdp;          /* TRUE if running as XCdp         */
  char         *_host;             /* Client connect / Server running */
  char         *_machine;          /* That is trying to connect (SMS) */
  sms_connect  *_connect;          /* Current connections             */
  sms_connect  *_current_con;      /* For SMS the current connection  */
  char          _timer_txt[MAXLEN];/* User field for the timer (if on)*/
  int           _xdr_privs;        /* The level of privs in XDR       */
  int           _xdr_version;      /* Revision/modification # for XDR */
  int           _lockedby;         /* If locked, who did it           */
  sms_node     *_node;             /* 4 SMS: Add per/node messages    */

  sms_list     *_staticlist;       /* Static reply to the client     */
  sms_list     *_reply;            /* The reply to the client       */
  int           _answer;           /* Creating the answer?         */
  sms_list     *_history;          /* Last lines of the log       */
  int           _hist_num;         /* Current line # in the log  */
  int           _hist_len;         /* Current # of lines stored */
  int           _hist_max;         /* MAX # of lines to keep   */
  int           _status;           /* Current st. of the SMS  */
  int           _client_error;     /* Latest error number    */
  char         *_client_msg;       /* And the message text  */
  int           _check_mode;       /* Checkpointing flag   */
  int           _check_time;       /* and repeat interval */
  time_t        _check_last;       /* when it was done   */
  time_t        _start_up;         /* Of the SMS        */
  time_t        _interval;         /* Of time check    */
  int           _tcp_port;         /* 4 direct comm.  */
  int           _udp_port;         /* 4 direct comm. */
  int           _prog;             /* def SMS_PROG  */
  int           _vers;             /* def SMS_VERS */

/* BR -- begin stuff for webcdp */

  int           _web_callable;     /* can be called from webcdp */
  sms_list     *_web_hosts;        /* hosts that where webcdp is running */
  int           _web_uid;          /* user running webcdp */
  int           _web_gid;          /* group of user running webcdp */
  char*         _web_certif_host;  /* machine checking certificates */
  int           _web_certif_port;  /* machine checking certificates */

/* BR -- end */

} sms_;

#ifdef SMS_STATISTICS
EXT struct {                       /* The statistic gathered by the SMS */
  int           _rpc_calls;
  int           _null_proc_calls;  /* Broadcast or prcinfo pings      */
  int           _user_logins;      /*                                 */
  int           _priv_logins;      /*                                 */
  int           _task_logins;      /* ~= init+completed+aborted+set   */
  int           _anonymous_logins; /* weak protocol error or a hacker */
  int           _users_denied;     /**/
  int           _tasks_denied;     /**/
  int           _tasks_zombie;     /**/
  int           _tasks_send;       /* tasks submitted                 */
  int           _tasks_resend;     /* included in the _jobs_send      */
  int           _tasks_init;       /* +   task used the smsinit       */
  int           _tasks_msgs;       /* +   task used the smsmsg        */
  int           _tasks_completed;  /* +                 smscomplete   */
  int           _tasks_aborted;    /* +                 smsabort      */
  int           _tasks_meters;     /* +                 smsmeter      */
  int           _tasks_labels;     /* +                 smslabel      */
  int           _tasks_mails;      /* +                 smsmail       */
  int           _tasks_waits;      /* +                 smswait       */
  int           _tasks_queries;    /* task querying meter/label/event */
  int           _events_set;       /* + = _task_logins  smsevent      */
  int           _auto_begin;       /* # of the suites restarted       */
  int           _suite_complete;   /* and completed                   */
#ifdef SMS_TIMER
  int           _who;              /* User/Task? (1/0) unknown = NIL  */
  clock_t       _start;            /* At the start of the connection  */
  clock_t       _user_clocks;      /* in u-seconds / ticks or in some */
  clock_t       _task_clocks;      /* of the systems CLOCKS_PER_SEC   */
#endif
} smss_;
#endif

static int recover_jump = 0;
EXT jmp_buf sms_jump_station;

#define SMS_VERSION       4
#define SMS_REVISION      4
#define SMS_MODIFICATION  5        /* 0-999 */

#define VERSION_NUMBER(v,r,m) ((v)*10000 + (r)*1000 + (m))

#define SMS_VERSION_NUMBER VERSION_NUMBER(SMS_VERSION,SMS_REVISION,SMS_MODIFICATION)

#endif /* SMS_SMSLIB_H */
