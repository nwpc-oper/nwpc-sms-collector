/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     PLAY
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-AUG-1992 / 30-JUL-1991 / OP
.VERSION  4.0
.FILE     play.c
*
.DATE     06-JUL-1993 / 09-MAR-1993 / OP
.VERSION  4.1
.DATE     25-MAY-1995 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-8
*         Added support for meter and label structures
*         Added support for autocancel and automigrate
*         Added abort for more intelligent play-files
*         Added labels to include newline character (4.3.8)
.DATE     21-SEP-1995 / 31-AUG-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     27-SEP-1995 / 27-SEP-1995 / OP
.VERSION  4.3.11
*         Label has default value
.DATE     16-JAN-1996 / 16-JAN-1996 / OP
.VERSION  4.3.13
*         Added today time dependency
.DATE     08-APR-1997 / 08-APR-1997 / OP
.VERSION  4.3.14
*         Year is now 4 digits
.DATE     29-SEP-1997 / OP
.VERSION  4.3.15+
*         Show full for label, shows the value of the label
.DATE     23-MAR-1998 / OP / MF
.VERSION  4.3.17
*         Allow negative repeat on suites for day/month/year
.DATE     04-JUL-1998 / 04-JUL-1998 / OP
.VERSION  4.3.19
*         date repeat
.DATE     18-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     25-JAN-1999 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Limit (pseudo queues)
.DATE     09-FEB-1999 /  05-FEB-1999 / OP
.VERSION  4.4.1
*         Limit changed
*         Inlimit own type
.DATE     18-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
*         Inlimit has own type
.DATE     03-FEB-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
.DATE     28-JUN-2001 / 28-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         Enumerated repeat
*
*  In this file, there is routines to read the play file.
*
*  -----------------------------------------------------------------------
*  ORIGINALLY
*  -----------------------------------------------------------------------
*  The play command modifies temporarily the IOIs exe stack by removing
*  all the commands and defining the appropriate commands needed for the
*  suite definition as a character menu.
*
*  Since we need to alter the IOI we'll claim to be ioi-module to get hold
*  of the IOI-global ioi_
*  -----------------------------------------------------------------------
*  THE NEW IMPLEMENTATION
*  -----------------------------------------------------------------------
*  We still need to alter the IOI. We'll claim to be ioi-module to get
*  hold of the IOI-global structure named ioi_
*
*  Create IOI-executables and load them into the IOI.
*  The executables should, by a static flag, operate only if play command
*  has been issued.
*
*  (play -> flag on , ... , exit play -> flag off)
*
*  The advantage is to have the suite definition commands in the CDP
*  with the manual pages and to be able to execute all the other CDP
*  and IOI commands, like to build the time dependency from the current
*  time, loops to define different targets with same properties etc.
*
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

static int        playing;         /* The flag to tell are we in play   */
static int        doprompt;        /* Issue the prompt/reading stdin    */
static int        is_ok;           /* No errors so far, eh?             */

static FILE      *playf;           /* Current play file                 */
static int        lineno;          /* Current line number in the file   */
static char      *fname;           /* Name of the play file             */
static sms_node  *root;            /* Used during the play-only         */
static int        recho;           /* Echo while reading the definition */
static int        rlocal;          /* Just keep the structure, no send! */
static char      *rreplace;        /* The node 2 B replaced in the SMS  */
static int        hlen;            /* IOI-history length (stolen)       */
static int        ioiecho;         /* IOI-file/echo flag (stolen)       */

extern int (* ioi_user_input())();

static int      (*input)()  = NULL;
static char      *prompt    = NULL;
static ioi_token *ioistack  = NULL;
static ioi_gen   *ioiaction = NULL;

/**************************************************************************
?  Define a suite by reading the definition file
|
|  Build it separately from the rest of the program.
|  Validate it automatically.
|  CDP: If a SMS is known the result is send there.
|  SMS: Add it into suite list. (Checkpoint file)
************************************o*************************************/

/**************************************************************************
*     A couple of macros to make life easier in the sms_play_CMDs()!
************************************o*************************************/

#define IS_THE if( called ) \
                 if( !playing ) \
                   return not_playing(); \
                 else if(
                        /* sms_play_XXX() */
#define OK              ) return TRUE; \
                      else return quit_playing(FALSE); \
               else

/**************************************************************************
*  Possible commands to modify the existing node.
************************************o*************************************/

#define MOD_ERROR    0
#define MOD_CLOCK    1
#define MOD_REPEAT   2
#define MOD_TRIES    3
#define MOD_STATUS   4

static int not_playing(void)
/**************************************************************************
?  Inform the user that the command is only available as a part of the
|  play command.
|  Dig the command been executed from the IOI args-array (first element!).
=  FALSE
************************************o*************************************/
{
  return ioi_out(0,IOI_ERR,"%s is available only inside the play command",
                 STR(ioi_._argv[0]));
}

static int quit_playing(int really)
/**************************************************************************
?  If an error occured, give up playing.
=  The really flag given.
************************************o*************************************/
{
  NODE_FREE(root,sms_node);        /* Destroy the data structure */

  if( prompt )
  {
    ioi_variable_set("prompt",prompt);
    IFFREE(prompt);
  }

  if( playing )
  {
    ioi_user_input(input);
    input               = NULL;
    ioi_._hist_len      = hlen;
    ioi_._log[IOI_ECHO] = ioiecho;
    ioi_._stack         = ioistack;
    ioi_._action        = ioiaction;
  }

  if( playf == stdin )
    ioi_file_redirection_delete();
  else
    FCLOSE( playf );

  playf    = NULL;
  playing  = FALSE;
  doprompt = FALSE;
  IFFREE(rreplace);

  if( lineno && !really ) ioi_out(
    0,IOI_ERR,"SMS-PLAY:Quiting file %s at line number %d",
      fname?fname:"stdin",lineno);

  sms_node_play(FALSE);

  return really;
}

int sms_play_gets(char *buff, int buffsize, int depth)
/**************************************************************************
?  Read next line from the play file.
|  If end of file ==> cmd 'EOF\n' added into the buffer.
=  TRUE
*  This routine is called only if we are really playing.
*  Depth is in IOI-2.0 (currently running 1.0) but not used by the play.
************************************o*************************************/
{
  if( doprompt )                   /* Reading stdin */
    ioi_file_prompt(depth);        /* Hymm..., should be HERE, no prompt! */

  if( fgets(buff,buffsize,playf) )
    lineno++;
  else
    strncpy(buff,"EOF\n",buffsize);

  if( recho ) printf("%s",buff);   /* ioi_out(0,IOI_ECHO,... */

  return TRUE;
}

int sms_play_definition(
    char  *name,
    int    echo, 
    int    local,
    char  *replace)
/**************************************************************************
?  Load a input feeder to the IOI and modify the prompt for future mod to
|  allow the filename "-" to mean stdin?.
************************************o*************************************/
{
  int  rc = TRUE;

  sms_._action_number = sms_._modify_number = 0;

  if( playing )
    return
      ioi_out(FALSE,IOI_WAR,"SMS-PLAY-DEFINITION:Already playing %s?",STR(fname));

  IFFREE( fname );

  if( !name )
  {
    playf = stdin;

    prompt = strdup(ioi_variable_get("prompt"));
    ioi_variable_set("prompt",ioi_._in?"":"play");

    if(ioi_._in)
    {
      ioi_file_redirection_create(); /* Yeps, neet to save the file pointers */
      fname = strdup("HERE DOCUMENT");
    }
    else
    {
      fname = strdup("stdin");
      doprompt=TRUE;
    }
  }
  else
    if( ! (playf=fopen(name,"r")) )
      return
        ioi_out(FALSE,IOI_ERR,"SMS-PLAY-DEFINITION:Couldn't open file %s",STR(name));

  ioiaction           = ioi_._action;
  ioi_._action        = NULL;

  ioistack            = ioi_._stack;
  ioi_._stack         = NULL;

  hlen                = ioi_._hist_len;
  ioi_._hist_len      = 0;

  ioiecho             = ioi_._log[IOI_ECHO];
  ioi_._log[IOI_ECHO] = FALSE;

  input               = ioi_user_input(sms_play_gets);

  sms_node_play(TRUE);

  if(!prompt)
  {
    prompt = strdup(ioi_variable_get("prompt"));
    ioi_variable_set("prompt","");
  }

  if(!fname)
    fname  = strdup(name);

  lineno = 0;

  NODE_FREE( sms_._super,sms_node );
  sms_._action_number = sms_._modify_number = 0;

  recho    = echo;
  rlocal   = local;
  rreplace = replace?strdup(replace):NULL;
  playing  = TRUE;

  return TRUE;
}

int sms_play_end_reading(void)
/**************************************************************************
?  The normal termination of the play command.
|  End of file or EOF-command in the file.
|  Validate the suite(s) and if needed send them to the SMS
************************************o*************************************/
{
  sms_node *tmp;
  int       rc = FALSE;

  if( !root )
  {
    ioi_out(0,IOI_WAR,"play:Nothing was defined?");
    return quit_playing(TRUE);
  }

  if( root=sms_node_after_receive( root ) )
  {
    sms_._super = root;
    root = NULL;

    sms_status_validate(sms_._super);

    if( rreplace )
    {
      sms_node *cmd,*suite;

      if( suite=sms_node_find_full(rreplace) )
      {
        tmp = suite->next;         /* 2 B able to free... */
        suite->next = NULL;

        cmd = sms_alloc(NODE_SUPER);
        cmd->name = rreplace;
        cmd->kids = suite;

        ioi_out(0,IOI_MSG,"play:Replacing %s in %s",STR(rreplace),STR(sms_._logins->name));

        if( rc = sms_client_play(HANDLE,cmd) )
          ioi_out(0,IOI_ERR,"play:%s:%s",STR(rreplace),error_name[rc]);
        else
          ioi_out(0,IOI_MSG,"play:%s replaced.",STR(rreplace));

        free(cmd);

        suite->next = tmp;         /* Freein' correctly */
        NODE_FREE( sms_._super,sms_node );

        return quit_playing(TRUE);
      }
      else
      {
        ioi_out(0,IOI_ERR,"play:replaced node %s not in the definition",
          STR(rreplace));

        return FALSE;              /* Will call the quit_... */
      }
    }

    if( sms_._super && (sms_client_is_ok(HANDLE)==SMS_E_OK) && !rlocal )
    {
      while( sms_._super )
      {
        int rc;

        tmp = sms_._super->next;
        sms_._super->next = NULL;

        ioi_out(0,IOI_MSG,"play:Sending %s to %s",STR(sms_._super->name),STR(sms_._logins->name));

        if( rc = sms_client_play(HANDLE,sms_._super) )
          ioi_out(0,IOI_ERR,"play:%s:%s",STR(sms_._super->name),error_name[rc]);
        else
          ioi_out(0,IOI_MSG,"play:Suite %s defined.",STR(sms_._super->name));

        NODE_FREE( sms_._super,sms_node );

        sms_._super = tmp;
      }
    }
    else
      ioi_out(0,IOI_MSG,"play:File %s OK.",STR(fname));

    rc = TRUE;
  }
  else
    ioi_out(0,IOI_ERR,"play:Validation problem");

  return quit_playing(rc);
}

/**************************************************************************
*
*               THE BUILDING BLOCKS TO BE USED IN PLAYFILE
*
************************************o*************************************/

sms_user *sms_play_user(char *name, int uid, int gid)
/**************************************************************************
?  SYNTAX: user uid gid name
************************************o*************************************/
{
  sms_user *u = NULL;

  if( u = sms_alloc(NODE_USER) )
  {
    u->uid  = uid;
    u->gid  = gid;
    u->name = strdup(name);
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-USER:No mem.");

  return u;
}

sms_list* sms_play_create_text(int argc, char **argv)
/**************************************************************************
?  SYNTAX: text [anything]
************************************o*************************************/
{
  char      text[MAXLEN];
  sms_list *l;

  if( l = sms_alloc(NODE_LIST) )
  {
    text[0] = '\0';
    while( argc )                  /* Concatenate the arguments */
    {
      strcat(text,*argv++);
      if( --argc ) strcat(text," ");
    }

    l->name = strdup(text);
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-TEXT:No mem.");

  return l;
}

sms_variable *sms_play_variable(char *name, char *value)
/**************************************************************************
?  SYNTAX: edit name anything
************************************o*************************************/
{
  sms_variable *v     = NULL;

  if( strlen(name) && (isalpha(*name) || *name=='_') )
    if( v = sms_alloc(NODE_VARIABLE) )
    {
      v->name   = strdup(name);
      v->value  = strdup(value);
    }
    else ioi_out(0,IOI_ERR,"SMS-PLAY-VARIABLE:No mem.");
  else ioi_out(0,IOI_ERR,"SMS-PLAY-VARIABLE:Illegal name [%s]",STR(name));

  return v;
}

int sms_play_make_time(char *s, int *h, int *m)
/**************************************************************************
?  Cut the hour and minute out of the string s.
|  TIME SYNTAX   [00-23 | '*'] ':' [00-59 | '*']
=  TRUE  If the hour and minute are right
|  FALSE If out of range or unreadable.
************************************o*************************************/
{
  *h = *m = 0;

  if( isdigit(*s) || *s=='*' )
    if(*s=='*') { *h = NIL; s++; }
    else        { *h = atoi(s); while( isdigit(*s) ) s++; }
  else return FALSE;

  if( *s != ':' ) return FALSE;
  s++;

  if( isdigit(*s) || *s=='*' )
    if(*s=='*') { *m = NIL; s++; }
    else        { *m = atoi(s); while( isdigit(*s) ) s++; }
  else return FALSE;

  if( *s ) return FALSE;

  if( *h < NIL || *h > 23  ||
      *m < NIL || *m > 59 ) 
    return FALSE;

  return TRUE;
}

sms_time *sms_play_create_time(char *start, char *end, char *inc, int today)
/**************************************************************************
?  Parse the args to form the time structure.
|  SYNTAX: time [+]hh:mm [ hh:mm hh:mm ]
|                  start    end   inc
|
|  If [+] is used time is relative to the beginning of the suite
************************************o*************************************/
{
  sms_time  *t = NULL;

  if( t = sms_alloc(NODE_TIME) )
  {
    t->repeat = FALSE;
    t->today  = today;

    if( *start == '+' )
    {
      if(today)
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Today relative time not allowed.");
        goto error;
      }

      t->relative = TRUE;
      start++;
    }

    if( ! sms_play_make_time(start,&t->hour[0],&t->minute[0]) ) goto error;

    if(inc)
    {
      if( ! sms_play_make_time(end,&t->hour[1],&t->minute[1]) ) goto error;
      if( ! sms_play_make_time(inc,&t->hour[2],&t->minute[2]) ) goto error;

      t->repeat = TRUE;
    }

    if( t->repeat )                /* Let's check the end and increment */
    {
      if( t->hour[2] <= 0 && t->minute[2] <= 0 )
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Time increment illegal [%s].",STR(inc));
        goto error;
      }
      if( t->hour[0] == NIL || t->minute[0] == NIL )
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Repeat start time [%s].",STR(start));
        goto error;
      }
      if( t->hour[1] == NIL || t->minute[1] == NIL )
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Repeat end time [%s].",STR(end));
        goto error;
      }

      if( t->hour[0] * 60 + t->minute[0] >=
          t->hour[1] * 60 + t->minute[1] )
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Start >= end time [%s >= %s].",
                STR(start),STR(end));
        goto error;
      }
    }

  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:No mem.");

  return t;

  error: 

  ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:Syntax error in args %s %s %s",
       STR(start) , end?end:"" , inc?inc:"");

  free(t); return NULL;
}

static int parse_range(char *s, int range, int sub)
/**************************************************************************
?  Parse the string into a bitmap
************************************o*************************************/
{
  static ls_gen *root;
  ls_gen        *lp;
  int            n = 0;

  if(!s) return 0;

  ls_delall(&root);

  ls_parse(&root, s, ',');

  for( lp = root ; lp ; lp=lp->next )
  {
    if( sms_is_number(lp->name) )
    {
      int i = atoi(lp->name);

      if( i>range || i<sub )
        return ioi_out(-1,IOI_ERR,"SMS-PARSE-RANGE:out of range %s",STR(lp->name));

      if(sub) i -= sub;

      n |= (1<<i);
    }
  }

  return n;
}

sms_time *sms_play_create_cron(char *start, char *end, char *inc,
                               char *weekdays, char *monthdays, char *months)
/**************************************************************************
?  Parse the args to form the cron structure.
|  SYNTAX: time hh:mm [ hh:mm hh:mm ]
|               start    end   inc
|  weekdays   = 0,1,2,3,4,5,6
|  monthdays  = 1,...,31
|  months     = 1,...,12
************************************o*************************************/
{
  sms_time *tp = sms_play_create_time(start, end, inc, TRUE);

  if( ! (tp=sms_play_create_time(start, end, inc, TRUE)) )
  {
    ioi_out(0,IOI_ERR,"SMS-PLAY-CRON:Syntax error in time");
    return 0;
  }

  tp->iscron    = TRUE;
  tp->weekdays  = parse_range(weekdays,   6, 0);
  tp->monthdays = parse_range(monthdays, 31, 1);
  tp->months    = parse_range(months,    12, 1);

  return tp;
}

sms_time *sms_play_create_late(char *submitted, char *active, char *complete)
/**************************************************************************
?  Parse the args to form the time structure for late
|  SYNTAX: late -s [+]hh:mm  -a hh:mm   -c [+]hh:mm 
|                submitted    active     complete
|
|  If [+] is used, time is relative to the task becoming active
|  (for submitted, the time is always relative)
************************************o*************************************/
{
  sms_time  *t = NULL;

  if( t = sms_alloc(NODE_TIME) )
  {
    t->repeat   = FALSE;

    t->hour[0] = t->hour[1] = t->hour[2] = (-1);
    t->type = NODE_LATE;

    if( submitted )
    {
      if( *submitted == '+' )
        submitted++;

      if( ! sms_play_make_time(submitted,&t->hour[0],&t->minute[0]) )
        goto error;

      if( t->hour[0] == 0  && t->minute[0] == 0 )
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-TIME:illegal submitted time");
        goto error;
      }
    }

    if( active )
    {
      if( ! sms_play_make_time(active,&t->hour[1],&t->minute[1]) )
        goto error;
    }

    if( complete )
    {
      if( *complete == '+' )
      {
        t->relative = TRUE;
        complete++;
      }

      if( ! sms_play_make_time(complete,&t->hour[2],&t->minute[2]) )
        goto error;

#if 0   /* Check active before complete, plaah do it later on */
      if(active)
#endif
    }
  }
  else
    ioi_out(0,IOI_ERR,"SMS-PLAY-LATE-CREATE:No mem.");

  return t;

  error: 

  ioi_out(0,IOI_ERR,"SMS-PLAY-LATE-CRETAE:Syntax error in args %s%s %s%s %s%s",
          (submitted)? "-s " : ""  , (submitted)? submitted : "",
          (active   )? "-a " : ""  , (active   )? active    : "",
          (complete )? "-c " : ""  , (complete )? complete  : "" );


  free(t); return NULL;
}

sms_time *sms_play_create_auto(char *start, int type)
/**************************************************************************
?  Parse the args to form the time structure.
|  Used for autocancel automigrate
|  SYNTAX: time [days | +hh:mm ]
************************************o*************************************/
{
  sms_time  *t = NULL;

  if( t = sms_alloc(NODE_TIME) )
  {
    if( *start == '+' )
    {
      t->relative = TRUE;
      start++;

      if( ! sms_play_make_time(start,&t->hour[0],&t->minute[0]) ) goto error;
    }
    else
    {
      if( !sms_is_number(start) ) goto error;

      t->hour[0] = atoi(start);
      if( t->hour[0] < 0 )
        t->hour[0] = 0;

      t->relative = FALSE;
    }

    t->type = type;
  }
  else
    ioi_out(0,IOI_ERR,"SMS-PLAY-%s:No mem.",
            (type==NODE_CANCEL)? "CANCEL" : "MIGRATE" , STR(start));

  return t;

  error: 

  ioi_out(0,IOI_ERR,"SMS-PLAY-%s:Syntax error in args %s",
          (type==NODE_CANCEL)? "CANCEL" : "MIGRATE" , STR(start));

  free(t); return NULL;
}

sms_list* sms_play_create_restore(char *name)
/**************************************************************************
?  SYNTAX: autorestore name
************************************o*************************************/
{
  sms_list *l;

  if( l = sms_alloc(NODE_LIST) )
  {
    l->type = NODE_RESTORE;
    l->name = strdup(name);
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-RESTORE:No mem.");

  return l;
}

int sms_play_make_date(char *str, int any, int *d, int *m, int *y)
/**************************************************************************
?  Parse the args to form the date structure with the day/month/year filled.
|  SYNTAX: date [01-31 | '*'] '.' [01-12 | '*'] '.' [1970-1999 | '*']
|  eg      date 31.12.1999         # The very last day of this millennium
|          date  1.*.*             # Beginning of every month
|
|  If any is TRUE:any of the fields may be '*' -> -1 but then they can't be
|  0, otherwise they can be zero but not '*'
|
=  Boolean status
************************************o*************************************/
{
  char      *s = str;

  if( isdigit(*s) || *s=='*' )
    if(*s=='*') { *d = NIL; s++; }
    else        { *d = atoi(s); while( isdigit(*s) ) s++; }
  else return FALSE;

  if( *s != '.' ) return FALSE;
  s++;

  if( isdigit(*s) || *s=='*' )
    if(*s=='*') { *m = NIL; s++; }
    else        { *m = atoi(s); while( isdigit(*s) ) s++; }
  else return FALSE;

  if( *s != '.' ) return FALSE;
  s++;

  if( isdigit(*s) || *s=='*' )
    if(*s=='*') { *y = NIL; s++; }
    else        { *y = atoi(s); while( isdigit(*s) ) s++; }
  else return FALSE;

  if( *s ) return FALSE;           /* No extra characters */

  if( !any && (*d==NIL || *m==NIL || *y==NIL) ) return FALSE;

  if(  any && (*d==0 || *m==0 || *y==0) ) return FALSE;

  if( *y > 99 && *y < 1900) return FALSE;

  if( *y < 100 && *y >= 0 )
    ioi_out(0,IOI_WAR,"sms_play_make_date:Y2K:please use four digit year");

  if( *y > 1900 ) *y -= 1900;
  if( *d > 31 || *m > 12 ) return FALSE;

  return TRUE;
}

sms_date *sms_play_create_date(char *str)
/**************************************************************************
?  Parse the args to form the date structure with the day/month/year filled.
|  SYNTAX: date [01-31 | '*'] '.' [01-12 | '*'] '.' [1970-9999 | '*']
|  eg      date 31.12.1999         # The very last day of this millennium
|          date  1.*.*             # Beginning of every month
************************************o*************************************/
{
  sms_date  *d = NULL;

  if( d = sms_alloc(NODE_DATE) )
    if( ! sms_play_make_date(str,TRUE,&d->day,&d->month,&d->year) )
      goto error;
    else
      ;
  else
    ioi_out(0,IOI_ERR,"SMS-PLAY-DATE:No mem.");

  return d;

  error:

  ioi_out(0,IOI_ERR,"SMS-PLAY-DATE:Syntax error [%s]",str);

  free(d);
  return NULL;
}

int sms_play_gain(int argc, char **argv, int *gain)
/**************************************************************************
?  Parse the time differences and calculate the gain in seconds.
=  MOD_CLOCK if OK and MOD_ERROR otherwise
|  The computed gain is place into the ->gain.
************************************o*************************************/
{
  struct tm *tm;
  time_t t = sms_time_t(NULL);     /* GMT at the time of play */
  time_t morning;                  /* GMT at 00:00 today      */

  *gain   = 0;                     /* I'll do it again */
  tm      = sms_time_tm( &t );
  morning = t - ( tm->tm_sec + tm->tm_min * 60 + tm->tm_hour * 3600 );

  for( ; argc ; argc-- , argv++ )
  {
    int   sign;                    /* -1,0,1 ==  -REL, ABSOLUTE, +REL */
    int   add = 0;
    char *s = *argv;
    int   ho,mi,da,mo,ye;

    sign = 0;
    if( *s == '+' )      { sign =  1 ; s++; }
    else if( *s == '-' ) { sign = -1 ; s++; }

    if( sms_is_number(s) )         /* Offset in seconds */
      *gain -= (sign == -1)? atoi(s) : -atoi(s);
    else if( sms_play_make_time(s,&ho,&mi) )
    {
      add = 3600*ho + 60*mi;

      switch( sign )
      {
        case -1:
          *gain -= add;
          break;
        case  0:
          *gain = add - t + morning + (*gain / 86400) * 86400;
          break;
        case  1:
          *gain += add;
          break;
      }
    }
    else if( sms_play_make_date(s,FALSE,&da,&mo,&ye) )
    {
      struct tm gmt;

      memset(&gmt,0,sizeof(gmt));
      gmt.tm_mday = da;
      gmt.tm_mon  = mo-1;
      gmt.tm_year = ye;
      
      switch( sign )
      {
        case -1:
          return ioi_out(MOD_ERROR,IOI_ERR,"SMS-PLAY-GAIN:Not yet %s",STR(*argv));
          /* break; */

        case  0:
          if( (add=sms_time_gmt( &gmt )) == NIL )
            return ioi_out(MOD_ERROR,IOI_ERR,"SMS-PLAY-GAIN:%s",STR(*argv));

          *gain = add - morning + (*gain % 86400);

          break;

        case  1:
          return ioi_out(MOD_ERROR,IOI_ERR,"SMS-PLAY-GAIN:Not yet %s",STR(*argv));
          /* break; */

      }
    }
    else 
      return ioi_out(MOD_ERROR,IOI_ERR,"SMS-PLAY-GAIN:%s",STR(*argv));

  }

  return MOD_CLOCK;
}

sms_date *sms_play_create_day(int argc, char **argv)
/**************************************************************************
?  Parse the args to form the date structure with the weekday-bits filled.
************************************o*************************************/
{
  sms_date  *d = NULL;
  int        day;

  if( d = sms_alloc(NODE_DATE) )
  {
    while( argc-- )
    {
      if( (day=ioi_user_cmdf(*argv,day_name,NULL,DAY_MAX)) == (-1))
      {
        ioi_out(0,IOI_ERR,"SMS-PLAY-DAY:Illegal day name [%s]",STR(*argv));
        goto error;
      }

      d->weekdays |= ( 1<<(day) );

      argv++;
    }
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-DAY:No mem.");

  return d;

  error: free(d); return NULL;
}

sms_trigger *sms_play_create_trigger(int argc, char **argv, int type)
/**************************************************************************
?  Form the math tree from the arguments.
*
*  This is a bit dirty one! Let's fix it later on! (not a promise!)
*  It just got worse (4.3.20)
*
*  Need's to change the IOI also!
************************************o*************************************/
{
  ioi_token    *temp = ioi_._token;
  sms_trigger  *t = NULL;

  if( type != NODE_TRIGGER && type != NODE_COMPLETE )
    return 0;

  if( t = sms_alloc(type) )
  {
    ioi_._token = ioi_token_build(argc,argv);

    ioi_math_token(TRUE);          /* Yes! Use special nameing convention */

    if( ! (t->math = (sms_tree *)ioi_math_make()) )
    ;
/* FIX FIX FIX */

    ioi_token_delete(ioi_._token,TRUE);
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-TRIGGER:No mem.");

  ioi_._token = temp;

  if( t && !(t->math) )
  {
    ioi_out(0,IOI_ERR,"SMS-PLAY-TRIGGER:Math not understandable.");
    free(t);
  }

  return t;
}

sms_event *sms_play_create_event(char *name)
/**************************************************************************
?  SYNATX  event name
************************************o*************************************/
{
  sms_event *e      = NULL;
  char       buff[MAXNAM];         /* Temp to build the name <== number */

  if( ! name )
    return 0;

  if( e = sms_alloc(NODE_EVENT) )
  {
    e->name = strdup(name);
  }
  else
    ioi_out(0,IOI_ERR,"SMS-PLAY-EVENT:No mem.");

  return e;
}

sms_meter *sms_play_create_meter(char *name, int min, int max, int color)
/**************************************************************************
?  SYNATX  meter name min max [color]
************************************o*************************************/
{
  sms_meter *m = NULL;
  
  if( m = sms_alloc(NODE_METER) )
  {
    if( color == ~0 ) color=max;

    m->min   = min;
    m->max   = max;
    m->color = color;
    m->name = strdup(name);
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-METER:No mem.");

  return m;
}

int sms_play_label_argv2string(int argc, char **argv, char *buff, int maxlen)
{
  for( *buff='\0' ; argc-- ; argv++ )
  {
    strcat(buff,*argv);
    if(argc>=1)
    strcat(buff,"\n");
  }

  return 0;
}

sms_label *sms_play_create_label(char *name, int argc, char **argv)
/**************************************************************************
?  SYNATX  label name [value [value ...]]
************************************o*************************************/
{
  sms_label *l = NULL;
  char       buff[MAXLEN];

  if( l = sms_alloc(NODE_LABEL) )
  {
    l->name = strdup(name);

    sms_play_label_argv2string(argc,argv,buff,MAXLEN);

    l->value = strdup(buff?buff:"");
    l->def   = strdup(buff?buff:"");
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-LABEL:No mem.");

  return l;
}

sms_repeat *sms_play_create_repeat(
    int    mode,                   /* REPEAT_xxx                      */
    char  *name,                   /* Variable name or increment step */
    int    argc,                   /* Rest of the parameters needed   */
    char **argv)
/**************************************************************************
?  SYNATX  repeat mode value [value]
************************************o*************************************/
{
  sms_repeat *r = NULL;
  int         gain;
  int         i,j;

  if( mode==REPEAT_INTEGER    && argc<2 ||
      mode==REPEAT_STRING     && argc<1 ||
      mode==REPEAT_ENUMERATED && argc<1 ||
      mode==REPEAT_FILE       && argc<1 ||
      mode==REPEAT_DATE       && argc<2 )
  {
    ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:Too few arguments");
    return 0;
  }

#define NUMBER(x,y) if( sms_is_number(y) ) x = atoi(y); else \
  { free(r);  \
    ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:%s is not a number",STR(y)); \
    return 0; }

#define SIGNED_NUMBER(x,y) if( sms_is_signed_number(y) ) x = atoi(y); else \
  { free(r);  \
    ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:%s is not signed number",STR(y)); \
    return 0; }

#define DATEOK(x,y) if( (x = sms_repeat_str2date(y)) == 0 ) \
  { free(r);  \
    ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:%s is not a valid date",STR(y)); \
    return 0; }

  if( r = sms_alloc(NODE_REPEAT) )
  {
    r->mode = mode;

    switch(mode)
    {
      case REPEAT_DAY:
      case REPEAT_MONTH:
      case REPEAT_YEAR:
        r->name = strdup("clock");
        {
          int sign = 1;

          if( *name == '-' )
          {
            sign = (-1);
            name++;
          }
          NUMBER( r->step , name );

          r->step *= sign;

          if(r->step < 0)
            ioi_out(0,IOI_WAR,"SMS-PLAY-REPEAT:negative repeat used");
        }

        if(r->step == 0)
        {
          free(r);
          ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:time repeat with step == 0?");
          return NULL;
        }

        if(mode==REPEAT_MONTH)
          if( r->step < -12 || r->step > 12 )
          {
            free(r);
            ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:wrong monthly step [-12 - 12]");
            return NULL;
          }

        if(argc>0)
          if( sms_play_gain(1, argv, &gain) != MOD_CLOCK )
          { free(r); r=NULL; }
          else
          {
            struct tm *tm;
            time_t     t = sms_time_t(NULL);
            tm           = sms_time_tm( &t );
  
            gain += t - ( tm->tm_sec + tm->tm_min * 60 + tm->tm_hour * 3600 );
            r->end = gain;
          }
        break;

      case REPEAT_INTEGER:
        r->name = strdup(name);
        SIGNED_NUMBER( r->start , argv[0] );
        SIGNED_NUMBER( r->end   , argv[1] );
        if( argc>2 ) SIGNED_NUMBER( r->step   , argv[2] )
        else ;

        if(r->step==0) r->step=1;
        if( (r->step > 0 && (r->start > r->end)) ||
            (r->step < 0 && (r->end > r->start)) )
        {
          free(r);
          ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:loop does not make sense");
          return 0;
        }
         
        break;

      case REPEAT_ENUMERATED:
        r->name = strdup(name);
        for( i=0 ; i<argc ; i++ )
          SIGNED_NUMBER( j, argv[i] );

        for( ; argc ; argc--, argv++ )
        {
          if( ls_find( &(r->str) , *argv ))
          {
            ls_delall( &(r->str) );
            free(r);
            ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:same enumeration %s",STR(*argv));
            return 0;
          }
          ls_add( &(r->str) , ls_create(0,*argv) );
        }
        break;

      case REPEAT_STRING:
        r->name = strdup(name);
        for( ; argc ; argc--, argv++ )
          ls_add( &(r->str) , ls_create(0,*argv) );
        break;

      case REPEAT_FILE:
        r->name = strdup(name);
        break;

      case REPEAT_DATE:
        r->name = strdup(name);
        DATEOK( r->start , argv[0] );
        DATEOK( r->end   , argv[1] );
        if( argc>2 ) SIGNED_NUMBER( r->step   , argv[2] );
        if(r->step==0) r->step=1;
        break;

      default:
        return 0;
    }
  }
#undef NUMBER
#undef SIGNED_NUMBER
#undef DATEOK

  else ioi_out(0,IOI_ERR,"SMS-PLAY-REPEAT:No mem.");

  return r;
}

sms_limit *sms_play_create_limit(char *name, int type, int limit,
                                 int min, int base, char *unit)
/**************************************************************************
?  SYNATX  limit [-b] name limit { limit >= 0 }
|          limit  -i  name limit min base unit
************************************o*************************************/
{
  sms_limit *lp = NULL;

  if( lp = sms_alloc(NODE_LIMIT) )
  {
    lp->name      = strdup(name);
    lp->limit     = limit;
    lp->limittype = type;

    if(type==LIMIT_INTEGER)
    {
      lp->min  = min;
      lp->base = base;
      lp->unit = strdup(unit);
    }
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-CREATE-LIMIT:No mem.");

  return lp;
}

sms_inlimit *sms_play_create_inlimit(char *name, int usage, int priority,
                                     int   type)
/**************************************************************************
?  SYNATX  inlimit name [usage [priority]]
************************************o*************************************/
{
  sms_inlimit *ip = 0;

  if( ip = sms_alloc(NODE_INLIMIT) )
  {
    ip->name     = strdup(name);
    ip->usage     = usage;
    ip->priority   = priority;
    ip->inlimittype = type;
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-CREATE-INLIMIT:No mem.");

  return ip;
}

sms_action *sms_play_create_action(int status, char *name)
/**************************************************************************
?  The script to be executed when the task reaches a state given.
************************************o*************************************/
{
  sms_action *a    = NULL;

  if( a = sms_alloc(NODE_ACTION) )
  {
    a->name = strdup(name);
    a->when = status;
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-ACTION:No mem.");

  return a;
}

sms_node *sms_play_node(char *name, int type)
/**************************************************************************
?  The node type=[suite,family,task].
************************************o*************************************/
{
  sms_node *n = NULL;
  char     *s;

  for( s=name ; *s ; s++ )
    if( ! isalnum(*s) && *s != '_' )
    {
      ioi_out(0,IOI_ERR,"SMS-PLAY-NODE:%s bad name %s",
              node_name[type],STR(name));
      return 0;
    }

  if( n = sms_alloc(type) )
  {
    n->name      = strdup(name);
    n->defstatus = STATUS_QUEUED;
  }
  else ioi_out(0,IOI_ERR,"SMS-PLAY-NODE:No mem.");

  return n;
}

/**************************************************************************
*
*                         THE BUILDING ROUTINES
*
* NOTICE! While building the structure the status field is used to
*         indicate if the end-suite/family/task for that node has 
*         been given.
*
*     --> Movin' it to be user_int
*
************************************o*************************************/

sms_node *sms_play_find_last(void)
/**************************************************************************
?  Find the last node to receive the next node to be added.
|  If the user_int field is set the node can't be modified anymore but it
|  can get a sibling (the next-field).
************************************o*************************************/
{
  sms_node *np = root;

  if(!np) return NULL;

  while( np->next )                /* Let's find the last suite */
    np = np->next;

  while( np->kids && !np->user_int )
  {
    np = np->kids;
    while( np->next )
      np = np->next;
  }

  return np;
}

int sms_play_end( int level )      /* NODE_ SUITE/FAMILY/TASK */
/**************************************************************************
?  Mark the last node(s) to be complete.
|  If the level is eg family the last task has to be marked also.
|  Called by the command(s) endsuite, endfamily & endtask.
************************************o*************************************/
{
  sms_node *np;

  while( TRUE )
  {
    if( ! (np = sms_play_find_last()) ) return FALSE;

    while( np->user_int )
      if( ! np->parent )
        return FALSE;
      else
        np = np->parent;
   
    np->user_int = TRUE;

    if( np->type == level ) return TRUE;
  }
}

int sms_play_add(void *anything)
/**************************************************************************
?  Add a new definition into the tree.
|  The argument is actually any of the types defined as NODE_xxx.
|
|  If the type is not a true node a previous true node is searched and
|  if found the new node is attached to it.
|
|  If the type is a suite the (possible) previous suite is marked complete.
************************************o*************************************/
{
  sms_node *add;                   /* Add the new one into this one */
  sms_node *np = anything;

  if( !np ) return FALSE;          /* Ups! */

  if( np->type == NODE_SUITE )     /* Effectively an endsuite command */
    sms_list_add( &root,np );
  else
    if( !root )
      return FALSE;

  if( ! ( add = sms_play_find_last() ) ) return FALSE;

  if( np->type==NODE_TASK || np->type==NODE_FAMILY )
  {
    /* Find parent and make the links */

    if( add->type == NODE_TASK || add->user_int )
    {
      if( ls_find( &add->parent->kids , np->name ) )
        return ioi_out(0,IOI_ERR,"SMS-PLAY-ADD:Duplicate %s [%s]",
                       node_name[np->type],STR(np->name));

      add->next  = np;
      np->parent = add->parent;    /* They have same parent */
    }
    else                           /* It's the first kid! */
    {
      add->kids  = np;
      np->parent = add;
    }
  }
  else
  {
    while( add->parent && add->user_int )
      add = add->parent;

    if( add->user_int ) return 0;

    switch( np->type )
    {
      case NODE_LIST:
        sms_list_add( &add->text , np );
        break;

      case NODE_INLIMIT:
        if( ls_find(&add->inlimit, np->name) )
          return ioi_out(FALSE,IOI_ERR,"PLAY-INLIMIT:multiple same inlimits not allowed");

        ls_add( &add->inlimit , anything );
        break;

      case NODE_USER:
        sms_list_add( &add->user , np );
        break;

      case NODE_VARIABLE:
        sms_list_add( &add->variable , np );
        break;

      case NODE_TIME:
        if( add->type == NODE_SUITE ) return
          ioi_out(FALSE,IOI_ERR,"PLAY-TIME:No dependencies for suites allowed");
        sms_list_add( &add->time , np );
        break;

      case NODE_CANCEL:
        if( add->type!=NODE_SUITE && add->type!=NODE_FAMILY &&
            add->type!=NODE_TASK )
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-CANCEL:Wrong node type for autocancel.");

        if( add->autocm )
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-CANCEL:Multiple cancels/migrates not allowed.");

        sms_list_add( &add->autocm , np );
        break;

      case NODE_MIGRATE:
        if( add->type!=NODE_SUITE && add->type!=NODE_FAMILY)
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-MIGRATE:Wrong node type for automigrate.");

        if( add->autocm )
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-MIGRATE:Multiple cancels/migrates not allowed.");

        sms_list_add( &add->autocm , np );
        break;

      case NODE_RESTORE:
        if( add->type!=NODE_SUITE && add->type!=NODE_FAMILY &&
            add->type!=NODE_TASK )
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-RESTORE:Wrong node type for autorestore.");

        np->type = NODE_LIST;
        sms_list_add( &add->restore , np );
        break;

      case NODE_LATE:
        if( add->late )
          return ioi_out(FALSE,IOI_ERR,
                         "PLAY-LATE:Multiple late statements not allowed.");

        sms_list_add( &add->late, np );  /* Hmm..., only one, what the ... */
        break;

      case NODE_DATE:
        if( add->type == NODE_SUITE ) return 
          ioi_out(FALSE,IOI_ERR,"PLAY-DATE:No dependencies for suites allowed");
        sms_list_add( &add->date , np );
        break;

      case NODE_TRIGGER:
        if( add->type == NODE_SUITE ) return 
          ioi_out(FALSE,IOI_ERR,"PLAY-TRIGGER:No triggers for suite allowed");
          
        if( add->trigger ) return
          ioi_out(FALSE,IOI_ERR,"PLAY-TRIGGER:Multiple triggers not allowed.");

        sms_list_add( &add->trigger , np );
        break;

      case NODE_COMPLETE:
        if( add->type == NODE_SUITE ) return 
          ioi_out(FALSE,IOI_ERR,"PLAY-COMPLETE:No complete tag for suite allowed");
          
        if( add->complete ) return
          ioi_out(FALSE,IOI_ERR,"PLAY-COMPLETE:Multiple complete tags not allowed.");

        sms_list_add( &add->complete , np );
        break;

      case NODE_ACTION:
        sms_list_add( &add->action , np );
        break;

      case NODE_EVENT:
        sms_list_add( &add->event , np );
        break;

      case NODE_METER:
        sms_list_add( &add->meter , np );
        break;

      case NODE_LABEL:
        sms_list_add( &add->label , np );
        break;

      case NODE_REPEAT:
        if( add->repeat ) return
          ioi_out(FALSE,IOI_ERR,"PLAY-REPEAT:Multiple repeats not allowed.");
        { 
          sms_repeat *r=(sms_repeat *)np;

          if( (r->mode==REPEAT_DAY || r->mode==REPEAT_MONTH ||
               r->mode==REPEAT_YEAR) && add->type != NODE_SUITE )
            return ioi_out(FALSE,IOI_ERR,"SMS-PLAY-REPEAT:Wrong repeat mode");
        }
        sms_list_add( &add->repeat , np );
        break;

      case NODE_LIMIT:
        sms_list_add( &add->limit, np );
        break;
    }
  }

  return TRUE;
}

int sms_play_modify( int cmd, int p1, int p2 )
/**************************************************************************
?  Modify an existing node in the tree.
************************************o*************************************/
{
  sms_node *np;
  int   i;

  if( ! (np = sms_play_find_last()) )
    return FALSE;

  while( np->parent && np->user_int )
    np = np->parent;

  if( np->user_int ) return FALSE;

  switch( cmd )
  {
    case MOD_ERROR:
      return FALSE;
      /* break; */

    case MOD_CLOCK:
      np->clock     = p1;
      np->gain      = p2;
      sms_time_clock_vars(np->gain);
      break;

    case MOD_STATUS:
      np->defstatus = p1;
      break;
  }

  return TRUE;
}

/*------------------------------------------------------------------------
 *
 *         L O A D   T H E   C O M M A N D S   I N T O   I O I
 *
 *-----------------------------------------------------------------------*/

int sms_play_suite(int argc, char **argv)
{
  static int    called;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_node(name,NODE_SUITE) )
  OK
    ioi_exe_add( "suite:play",sms_play_suite,NULL,
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The name of the new suite definition.",
          NULL
        ),NULL,-1,&name
      ),
      ioi_exe_argv(
        "Define a new suite with name given.",
        "The name can later on be reflected by the /name.",
        "If defining multiple suites at the same time, this is also",
        "an implisite endsuite for the previous suite.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_endsuite(int argc, char **argv)
{
  static int    called;

  IS_THE
    sms_play_end( NODE_SUITE )
  OK
    ioi_exe_add( "endsuite:play",sms_play_endsuite,NULL,NULL,
      ioi_exe_argv(
        "Terminate the suite definition.",
        "This is also an implisite endfamily/task for all families/tasks",
        "currently been defined.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_family(int argc, char **argv)
{
  static int    called;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_node(name,NODE_FAMILY) )
  OK
    ioi_exe_add( "family:play",sms_play_family,NULL,
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The name of the new family definition.",
          NULL
        ),NULL,-1,&name
      ),
      ioi_exe_argv(
        "Define a family with name",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_endfamily(int argc, char **argv)
{
  static int    called;

  IS_THE
    sms_play_end( NODE_FAMILY )
  OK
    ioi_exe_add( "endfamily:play",sms_play_endfamily,NULL,NULL,
      ioi_exe_argv(
        "Terminate the family definition.",
        "You must use endfamily to terminate the prevoius family in order",
        "to define a new family on the same level.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_task(int argc, char **argv)
{
  static int    called;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_node(name,NODE_TASK) )
  OK
    ioi_exe_add( "task:play",sms_play_task,NULL,
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The name of the new task definition.",
          NULL
        ),NULL,-1,&name
      ),
      ioi_exe_argv(
        "Define a task with name",
        "This is also an implisite endtask for the previous task",
        "currently been defined.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_endtask(int argc, char **argv)
{
  static int    called;

  IS_THE
    sms_play_end( NODE_TASK )
  OK
    ioi_exe_add( "endtask:play",sms_play_endtask,NULL,NULL,
      ioi_exe_argv(
        "Terminate the task definition.",
        "This is really not needed, unless you want to add properties to",
        "the family where the task belongs.",
        "This is also an implisite endtask for the previous task",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_date(int argc, char **argv)
{
  static int    called;
  static char  *str;

  IS_THE
    sms_play_add( sms_play_create_date( str ) )
  OK
    ioi_exe_add( "date:play",sms_play_date,NULL,
      ioi_exe_param(
        "date",IOI_L_STRING,ioi_exe_argv(
          "The date in format dd.mm.yyyy, eg 31.12.1991.",
          "Any of the fields can be a start (*).",
          "eg 01.*.* means the first day of every month.",
          NULL
        ),NULL,-1,&str
      ),
      ioi_exe_argv(
        "Define a date dependency for the task/family/suite.",
        "This effects the current level been defined.",
        "There can be multiple date dependencies.",
        "currently been defined.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_day(int argc, char **argv)
{
  static int    called;
  static int    days;

  IS_THE
    sms_play_add( sms_play_create_day( ++argc,--argv ) )
  OK
    ioi_exe_add( "day:play",sms_play_day,NULL,
      ioi_exe_param(
        "weekday(s)",IOI_L_ENUM,ioi_exe_argv(
          "The weekday(s).",
          NULL
        ),NULL,-1,&days,day_name,NULL
      ),
      ioi_exe_argv(
        "Define a day dependency for the task/family/suite.",
        "This effects the current level been defined.",
        "There can be multiple day dependencies.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_edit(int argc, char **argv)
{
  static int    called;
  static char  *name;
  static char  *value;

  IS_THE
    sms_play_add( sms_play_variable( name,value ) )
  OK
    ioi_exe_add( "edit:play",sms_play_edit,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "variablename",IOI_L_STRING,ioi_exe_argv(
            "The variable name in the job files or in sending.",
            "Remember SMS is case sensitive.",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "definition",IOI_L_STRING,ioi_exe_argv(
            "The contents to be replaced in place of the SMS variable.",
            "To have special characters in the definition it must be",
            "placed inside quotes, single if no interpretation is needed",
            "of double if IOI variable substitution is needed.",
            NULL
          ),NULL,-1,&value
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a variable for SMS job substitution.",
        "This effects the current level been defined.",
        "There can be any number of variables.",
        "","NOTICE","",
        "The following variables have special meaning for the SMS:",
        "",
        "  SMSHOME  The root for the sms-script files etc",
        "",
        "  SMSCMD   The format to be used for the execution of the jobs. The",
        "           string must have %n to be replaced by the script name and",
        "           if the task is a \"remote\" task also a %h for the SMSHOST",
        "",
        "  SMSHOST  The host where the task is to be executed.",
        "           To have a \"remote\" family you only need to define this",
        "           on the family level, instead for all the tasks.",
        "","EXAMPLES","",
        "edit SMSCMD '/bin/csh %n &'",
        "edit SMSCMD '/usr/local/bin/qsub %n'",
        "edit SMSCMD 'rsh %h csh < %n 1> %n.eo 2>&1 &'",
        "",
        "The submit is done via system(3) call which executes /bin/sh",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_event(int argc, char **argv)
{
  static int    called;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_create_event(name ) )
  OK
    ioi_exe_add( "event:play",sms_play_event,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The possible event name, the default name for the events",
            "is the number, but if name is given you can only refer to",
            "the event by its name, NOT by the number.",
            NULL
          ),NULL,-1,&name
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a event for the task currently been defined.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_meter(int argc, char **argv)
{
  static int    called;
  static char  *name;
  static int    min,max,color;
  static int    color_def = ~0;

  IS_THE
    sms_play_add( sms_play_create_meter( name,min,max,color) )
  OK
    ioi_exe_add( "meter:play",sms_play_meter,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The name of the meter",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "min",IOI_L_INTEGER,ioi_exe_argv(
            "The minimum value that the meter can have",
            "This is also the initial value of the meter.",
            NULL
          ),NULL,-1,&min,NULL,NULL,NULL
        ),
        ioi_exe_param(
          "max",IOI_L_INTEGER,ioi_exe_argv(
            "The maximum value that the meter can have",
            "This must be bigger the min",
            NULL
          ),NULL,-1,&max,NULL,NULL,NULL
        ),
        ioi_exe_param(
          "color",IOI_L_INTEGER,ioi_exe_argv(
            "A value between min and max where to change the color",
            NULL
          ),NULL,1,&color,NULL,NULL,&color_def
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a meter for the task currently been defined.",
        "Meter is an extension to the event and only available after",
        "SMS version 4.3.",
        "Useful when a task needs to send progress reports",
        "Meters can be used in triggers same as events, except that they",
        "have value, eg:","",
        "  task x ; trigger y:meter_name gt 100",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_label(int argc, char **argv)
{
  static int    called;
  static char  *name;
  static char  *value;

  IS_THE
    sms_play_add( sms_play_create_label( name,++argc,--argv ) )
  OK
    ioi_exe_add( "label:play",sms_play_label,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The name of the label",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "value",IOI_L_STRING,ioi_exe_argv(
            "The initial value of the label (typically given as \"\")",
            "The value is cleared to this value at suite begin.",
            NULL
          ),NULL,-1,&value
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a label for the task currently been defined.",
        "Label is an extension to the event and only availabel after",
        "SMS version 4.3.",
        "Labels give only visal feedback, they can not be used in triggers",
        "Labels are set to default values when suite is begin.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_action(int argc, char **argv)
{
  static int    called;
  static int    status;
  static char  *filename;

  IS_THE
    sms_play_add( sms_play_create_action( status,filename ) )
  OK
    ioi_exe_add( "action:play",sms_play_action,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "status",IOI_L_ENUM,ioi_exe_argv(
            "The status to trigger the action to be executed.",
            NULL
          ),NULL,-1,&status,status_name,NULL
        ),
        ioi_exe_param(
          "filename",IOI_L_STRING,ioi_exe_argv(
            "The file to be executed if the node reachecs the status.",
            NULL
          ),NULL,-1,&filename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Action script to be executed on status of node.",
        "The script is simply executed. It is up to the script eg to",
        "communicate to the operators.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_owner(int argc, char **argv)
{
  static int    called;
  static int    uid,u_min=0,gid,g_min=0;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_user( name,uid,gid ) )
  OK
    ioi_exe_add( "owner:play",sms_play_owner,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "uid",IOI_L_INTEGER,ioi_exe_argv(
            "The user identification number.",
            NULL
          ),NULL,-1,&uid,&u_min,NULL,NULL
        ),
        ioi_exe_param(
          "gid",IOI_L_INTEGER,ioi_exe_argv(
            "The group identification number.",
            NULL
          ),NULL,-1,&gid,&g_min,NULL,NULL
        ),
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The user name to be used in logging in to the SMS.",
            NULL
          ),NULL,-1,&name
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define the owners of the node (normally on the suite level).",
        "The suite (node) may be restricted to be modified/altered by",
        "the owners only.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_text(int argc, char **argv)
{
  static int    called;
  static char  *text;

  IS_THE
    sms_play_add( sms_play_create_text( ++argc,--argv ) )
  OK
    ioi_exe_add( "text:play",sms_play_text,NULL,
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "Any information that might be usefult for the users looking",
          "at this node.",
          NULL
        ),NULL,-1,&text
      ),
      ioi_exe_argv(
        "Include information into the node.", 
        "This allowes the users monitoring the SMS to ...",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_time(int argc, char **argv)
{
  static int    called;
  static char  *start,*end,*increment;

  IS_THE
    sms_play_add(sms_play_create_time(start,end,increment,FALSE))
  OK
    ioi_exe_add( "time:play",sms_play_time,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
            "start",IOI_L_STRING,ioi_exe_argv(
            "The starting time of format hh:mm, eg 15:00 (coffee time!)",
            "Unlike the date only numeric values are allowed for the h/m.",
            "",
            "If the start time starts with '+' the times are relative to the",
            "beginning of the suite or in repeated families to the beginning",
            "of the repeated node.",
            NULL
          ),NULL,-1,&start
        ),
        ioi_exe_param(
          "end",IOI_L_STRING,ioi_exe_argv(
            "The end time if multiple times are given.",
            NULL
          ),NULL,1,&end
        ),
        ioi_exe_param(
          "increment",IOI_L_STRING,ioi_exe_argv(
            "The increment in time if multiple times are given.",
            NULL
          ),NULL,1,&increment
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a time dependency for the task/family/suite.",
        "This effects the current level been defined.",
        "There can be multiple time dependencies.",
        "","NOTICE","",
        "If the end time is given, also the increment must be given.",
        "In relative time the end time is also relative.",
        "","EXAMPLES","",
        "time 23:00                # at next 23:00",
        "time 10:00 20:00 01:00    # every hour from 10am to 8pm",
        "time +00:01               # one minute after the begin suite",
        "time +00:10 01:00 00:05   # 10-60 min after begin every 5 min",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_today(int argc, char **argv)
{
  static int    called;
  static char  *start,*end,*increment;

  IS_THE
    sms_play_add(sms_play_create_time(start,end,increment,TRUE))
  OK
    ioi_exe_add( "today:play",sms_play_today,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
            "start",IOI_L_STRING,ioi_exe_argv(
            "The starting time of format hh:mm, eg 15:00 (coffee time!)",
            "Unlike the date only numeric values are allowed for the h/m.",
            NULL
          ),NULL,-1,&start
        ),
        ioi_exe_param(
          "end",IOI_L_STRING,ioi_exe_argv(
            "The end time if multiple times are given.",
            NULL
          ),NULL,1,&end
        ),
        ioi_exe_param(
          "increment",IOI_L_STRING,ioi_exe_argv(
            "The increment in time if multiple times are given.",
            NULL
          ),NULL,1,&increment
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a time dependency for the task/family/suite.",
        "This effects the current level been defined.",
        "There can be multiple time dependencies.",
        "",
        "Unlike time, today does not wrap to tomorrow, if begin time",
        "is past the time given. In that case the node is free to run.",
        "","NOTICE","",
        "If the end time is given, also the increment must be given.",
        "In relative time the end time is also relative.",
        "","EXAMPLES","",
        "today 3:00                 # today at 3:00",
        "today 10:00 20:00 01:00    # every hour from 10am to 8pm",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_cron(int argc, char **argv)
{
  static int    called;
  static char  *start,*end,*increment;
  static char  *weekdays;
  static char  *monthdays;
  static char  *months;

  IS_THE
    sms_play_add(sms_play_create_cron(start,end,increment,weekdays,monthdays,months))
  OK
    ioi_exe_add( "cron:play",sms_play_cron,
      ioi_exe_link_param(
        ioi_exe_param(
          "-wweekdays",IOI_L_STRING,ioi_exe_argv(
            "List of weekdays, range is [0,...,6], eg -w 0,3,6",
            "Sunday==0, Monday == 1, ...",
            NULL
          ),NULL,-1,&weekdays
        ),
        ioi_exe_param(
          "-ddays",IOI_L_STRING,ioi_exe_argv(
            "List of days of month, range is [1,...,31], eg -d 1,2,15,20,21",
            "If month doesn't have the day, eg February 31, it's ignored",
            NULL
          ),NULL,-1,&monthdays
        ),
        ioi_exe_param(
          "-mmonths",IOI_L_STRING,ioi_exe_argv(
            "List of months, range is [1,...,12], eg -m 5,6,7,8",
            NULL
          ),NULL,-1,&months
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
            "start",IOI_L_STRING,ioi_exe_argv(
            "The starting time of format hh:mm, eg 15:00 (coffee time!)",
            "Unlike the date only numeric values are allowed for the h/m.",
            NULL
          ),NULL,-1,&start
        ),
        ioi_exe_param(
          "end",IOI_L_STRING,ioi_exe_argv(
            "The end time if multiple times are given.",
            NULL
          ),NULL,1,&end
        ),
        ioi_exe_param(
          "increment",IOI_L_STRING,ioi_exe_argv(
            "The increment in time if multiple times are given.",
            NULL
          ),NULL,1,&increment
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a cron dependency for the task/family.",
        "This effects the current level been defined.",
        "There can be multiple cron dependencies.",
        "","NOTICE","",
        "Nodes with cron entry never complete!",
        "If the end time is given, also the increment must be given.",
        "","EXAMPLES","",
        "cron 23:00                # at next 23:00",
        "cron 10:00 20:00 01:00    # every hour from 10am to 8pm",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_cancel(int argc, char **argv)
{
  static int    called;
  static char  *start;

  IS_THE
    sms_play_add( sms_play_create_auto(start, NODE_CANCEL) )
  OK
    ioi_exe_add( "autocancel:play",sms_play_cancel,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
            "days/time",IOI_L_STRING,ioi_exe_argv(
            "Number of days to wait until cancel is done or if format",
            "+hh:mm is used the wait time is in hours and minutes",
            NULL
          ),NULL,-1,&start
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define an automatic cancel for the task/family/suite.",
        "This effects the current node been defined.",
        "","NOTICE","",
        "There can only be one autocancel or automigrate per/node.",
        "","EXAMPLES","",
        "  autocancel +01:00  # cancel one hour after complete",
        "  autocancel 10      # cancel 10 days after complete",
        "  autocancel 0       # cancel immediately after being complete",
        "","NOTICE","",
        "If node is suspended it is not subjet to automatic cancellation.",
        "If, however, node is suspended but it's parent is subjet to this",
        "node can be cancelled with its parent.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_migrate(int argc, char **argv)
{
  static int    called;
  static char  *start;

  IS_THE
    sms_play_add( sms_play_create_auto(start, NODE_MIGRATE) )
  OK
    ioi_exe_add( "automigrate:play",sms_play_migrate,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
            "days/time",IOI_L_STRING,ioi_exe_argv(
            "Number of days to wait until migration is done or if format",
            "+hh:mm is used the wait time is in hours and minutes",
            NULL
          ),NULL,-1,&start
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define an automatic migration for the family/suite.",
        "This effects the current node been defined.",
        "","NOTICE","",
        "There can only be one autocancel or automigrate per/node.",
        "","EXAMPLES","",
        "  automigrate +01:00  # migrate one hour after complete",
        "  automigrate 10      # migrate 10 days after complete",
        "  automigrate 0       # migrate immediately after being complete",
        "","NOTICE","",
        "If node is suspended it is not subjet to automatic migration.",
        "If, however, node is suspended but it's parent is subjet to this",
        "node can be migrated with its parent.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_late(int argc, char **argv)
{
  static int    called;
  static char  *submitted;
  static char  *active;
  static char  *complete;

  IS_THE
    sms_play_add( sms_play_create_late(submitted,active,complete) )
  OK
    ioi_exe_add( "late:play",sms_play_late,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ssubmitted",IOI_L_STRING,ioi_exe_argv(
            "The time node can stay submitted (format [+]hh:mm)",
            "Submitted is always relative, so + is simply ignored if present.",
            "If node stays submitted longer than the time specified, the",
            "late flag is set.",
            NULL
          ),NULL,1,&submitted
        ),
        ioi_exe_param(
          "-aactive",IOI_L_STRING,ioi_exe_argv(
            "The time the node must have become active (format hh:mm)",
            "If the node is still queued or submitted by the time,",
            "late flag is set.",
            NULL
          ),NULL,1,&active
        ),
        ioi_exe_param(
          "-ccomplete",IOI_L_STRING,ioi_exe_argv(
            "The time node must become complete (format [+]hh:mm)",
            "If relative, time is taken from the time node becomes active,",
            "otherwise node must be complete by the time given.",
            NULL
          ),NULL,1,&complete
        ),
        NULL
      ),
      NULL,
      ioi_exe_argv(
        "Define late time(s) for a node.",
        "Format for all options is the same hh:mm, except that submitted",
        "may have [+] which is simply ignored, and complete may have [+]",
        "which is taken to mean relative time.",
        "","EXAMPLES","",
        "  late -s +00:15 -a 20:00 -c +02:00",
        "    node can stay submitted max 15 minutes, and it must become",
        "    active by 20:00 and the runtime must not exceed 2 hours.",
        "","NOTICE","",
        "  Relative active time for family is a bit difficult to process.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_restore(int argc, char **argv)
{
  static int    called;
  static char  *name;

  IS_THE
    sms_play_add( sms_play_create_restore(name) )
  OK
    ioi_exe_add( "autorestore:play",sms_play_restore,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
            "name",IOI_L_STRING,ioi_exe_argv(
            "The name of the node to be automatically restored when this",
            "node completes",
            NULL
          ),NULL,-1,&name
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define an automatic restore for the family/suite.",
        "This effects the current node been defined.",
        "There can be multiple of nodes restored.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_extern(int argc, char **argv)
{
  static int    called;
  static char  *nodename;

  IS_THE
    sms_node_external(nodename)
  OK
    ioi_exe_add( "extern:play",sms_play_extern,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "node",IOI_L_STRING,ioi_exe_argv(
            "An external node to the suite that is to be used in the",
            "triggers. All nodes that doesn't belong to the current",
            "suite been defined and are to be used as triggers must",
            "be declared external.",
            "","Some SMS's does not allow external triggers.",
            NULL
          ),NULL,-1,&nodename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define an external node name for the triggers.",
        "These are in effects during the whole play file.",
        "","NOTICE","",
        "This will be discontinued. Do not use it anymore",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_trigger(int argc, char **argv)
{
  static int    called;
  static char  *dummy;

  IS_THE
    sms_play_add( sms_play_create_trigger( ++argc,--argv,NODE_TRIGGER ) )
  OK
    ioi_exe_add( "trigger:play",sms_play_trigger,NULL,
      ioi_exe_param(
        "mathematics",IOI_L_STRING,ioi_exe_argv(
          "The mathematics of the trigger conditions",
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Define a dependency for the task/family.",
        "This effects the current level been defined.",
        "There can be only one trigger dependency.",
        "","EXAMPLE","",
        "trigger ../otherfam/task:1 and prevtask == complete",
        "","NOTICE","",
        "Suites are not allowed to have triggers",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_complete(int argc, char **argv)
{
  static int    called;
  static char  *dummy;

  IS_THE
    sms_play_add( sms_play_create_trigger( ++argc,--argv,NODE_COMPLETE ) )
  OK
    ioi_exe_add( "complete:play",sms_play_complete,NULL,
      ioi_exe_param(
        "mathematics",IOI_L_STRING,ioi_exe_argv(
          "The mathematics of the complete conditions",
          NULL
        ),NULL,-1,&dummy
      ),
      ioi_exe_argv(
        "Define a dependency for the task/family to force it complete.",
        "This effects the current level been defined.",
        "There can be only one complete dependency.",
        "","EXAMPLE","",
        "complete ../otherfam/task:1 and prevtask == complete",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_clock(int argc, char **argv)
{
  static int    called;
  static int    clock;
  static char  *gain;
  int           igain;

#if 0
  IS_THE
    sms_play_modify(sms_play_gain(ioi_._argc-2,ioi_._argv+2,(int *)&gain),
                    clock,(int)gain)
  OK
#endif

#if 0
if(called){
sms_play_gain(ioi_._argc-2,ioi_._argv+2,&igain);
printf("igain is %d\n",igain);
}
#endif

  if( called )
  {
    if( !playing ) return not_playing();

    if(sms_play_gain(ioi_._argc-2,ioi_._argv+2,&igain))
      if(sms_play_modify(MOD_CLOCK,clock,igain))
        return TRUE;

    return quit_playing(FALSE); \
  }
  else
    ioi_exe_add( "clock:play",sms_play_clock,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_ENUM,ioi_exe_argv(
            "Select which type of clock to be used.",
            NULL
          ),NULL,-1,&clock,clock_name,NULL
        ),
        ioi_exe_param(
          "gain",IOI_L_STRING,ioi_exe_argv(
            "The time the clock has gained.",
            " +/-<number>    the gain expressed in seconds.",
            " dd.mm.yy       the new date to use (currently no +/- format)",
            " [+/-] hh:mm    the time to use, can be an offset",
            NULL
          ),NULL,1,&gain
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define a clock to be used by the suite.",
        "Only suite can have a clock.",
        "","EXAMPLES","",
        "clock real 300           # the clock gains 300 sec from now",
        "           +01:00        # the clock gains 3600 sec from now",
        "           01:00         # clock is 01:00 in the morning",
        "           20.1.1992     # clock is many days late but H:M is ok",
        " 20.1.1992 +01:00        # many days late + time gains 3600 sec",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_repeat(int argc, char **argv)
{
  static int    called;
  static int    type;
  static char  *variable;

  IS_THE
    sms_play_add(sms_play_create_repeat(type,variable,argc,argv))
  OK
    ioi_exe_add( "repeat:play",sms_play_repeat,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "type",IOI_L_ENUM,ioi_exe_argv(
            "Type of the repetition",
            "day/month/year is only available for suites",
            NULL
          ),NULL,-1,&type,repeat_name,NULL
        ),
        ioi_exe_param(
          "variable/step",IOI_L_STRING,ioi_exe_argv(
            "The variable name to be used or step for time repeat",
            "For string/integer and file repeat this SMS-variable will be",
            "updated and available for the node",
            NULL
          ),NULL,-1,&variable
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define the repeat for the node.",
        "On completion of the current node it is actomatically restarted",
        "with the increment depending of the repeat type, until a list is",
        "exhausted or end-date is reached",
        "","SYNTAX","",
        "  repeat day        step [ENDDATE]     # only for suites",
        "  repeat month      step [ENDDATE]     # only for suites",
        "  repeat year       step [ENDDATE]     # only for suites",
        "  repeat integer    VARIABLE start end [step]",
        "  repeat enumerated VARIABLE first [second [third ...]]",
        "  repeat string     VARIABLE str1 [str2 ...]",
        "  repeat file       VARIABLE filename",
        "  repeat date       VARIABLE yyyymmdd yyyymmdd [delta]",
        "","NOTICE","",
        "File repeat is not yet implemented, it is silently ignored",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_inlimit(int argc, char **argv)
{
  static int    called;
  static char  *name;
  static int    usage,    usage_min    = 0, usage_def    = 0;
  static int    priority, priority_min = 0, priority_def = 0;
  static int    type;

  IS_THE
    sms_play_add(sms_play_create_inlimit(name,usage,priority,type))
  OK
    ioi_exe_add( "inlimit:play",sms_play_inlimit,
      ioi_exe_link_param(
        ioi_exe_param(
          "-nnode",IOI_L_BOOLEAN,ioi_exe_argv(
            "Create inlimit that limits this node only.",
            "Default is to limit tasks.",
            NULL
          ),NULL,-1,&type
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "limitname",IOI_L_STRING,ioi_exe_argv(
            "The name of the limit to be used.",
            "Multiple inlimits are allowed they are logically ANDed",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "usage",IOI_L_INTEGER,ioi_exe_argv(
            "The usage of the limitname. If the limit is boolean",
            "this can be omitted (one is implied), unless you need to",
            "give priority, (in that case set usage either 0 or 1)",
            NULL
          ),NULL,1,&usage, &usage_min, NULL, &usage_def
        ),
        ioi_exe_param(
          "priority",IOI_L_INTEGER,ioi_exe_argv(
            "The priority of the usage. "
            "Priority processing will be implemented later on.",
            "It is NOT part of 4.4.1, but it is reserved in the protocol."
            "Tasks with same limit are send in priority order, until",
            "the limit is exhausted.",
            NULL
          ),NULL,1,&usage, &usage_min, NULL, &usage_def
        ),

        NULL
      ),
      ioi_exe_argv(
        "Use a limit when submitting tasks",
        "When SMS is about to submit a job (no triggers nor time/date",
        "dependencies hold the task anymore) the named limits are checked",
        "if there is space for another job the limit is modified and",
        "the job is submitted.",
        "","NOTICE","",
        "Tasks may use multiple inlimits",
        "","EXAMPLE","",
        "inlimit /suite:queue1     # use boolean limit",
        "inlimit disk 50           # use 50 units from disk",
        "inlimit -n fams           # count the family, not tasks in it",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_limit(int argc, char **argv)
{
  static int    called;
  static char  *name;
  static int    type;
  static int    limit, limit_min = 0;
  static int    min,   min_min  = 0, min_def  = 0, min_max = 0;
  static int    base,  base_min = 0, base_def = 0;
  static char  *unit;

  IS_THE
    sms_play_add(sms_play_create_limit(name,type,limit,min,base,unit))
  OK
    ioi_exe_add( "limit:play",sms_play_limit,
      ioi_exe_link_param(
        ioi_exe_param(
          "-iinteger",IOI_L_BOOLEAN,ioi_exe_argv(
            "Create integer limit, default is boolean",
            NULL
          ),NULL,-1,&type
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "Name of the limit (pseudo queue)",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param(
          "limit",IOI_L_INTEGER,ioi_exe_argv(
            "The max value of the limit",
            NULL
          ),NULL,-1,&limit,&limit_min,NULL,NULL
        ),
        ioi_exe_param(
          "min",IOI_L_INTEGER,ioi_exe_argv(
            "The minimum value, at the moment only zero will do",
            NULL
          ),NULL,1,&min,&min_min,&min_max,&min_def
        ),
        ioi_exe_param(
          "base",IOI_L_INTEGER,ioi_exe_argv(
            "The base value, or resource used by default",
            NULL
          ),NULL,1,&base,&base_min,NULL,&base_def
        ),
        ioi_exe_param(
          "unit",IOI_L_STRING,ioi_exe_argv(
            "The unit as a string to be displayed by the limit",
            NULL
          ),NULL,1,&unit
        ),
        NULL
      ),
      ioi_exe_argv(
        "Define the limit for a suite.",
        "This limit can be seen as a resource mechanism. Other nodes",
        "can declare (using inlimit) that they want to be using this",
        "resource. This way tasks can be grouped and unnecessary",
        "trigger may be avoided.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_defstatus(int argc, char **argv)
{
  static int    called;
  static int    status,s_def=STATUS_QUEUED;

  IS_THE
    sms_play_modify( MOD_STATUS,status,0 )
  OK
    ioi_exe_add( "defstatus:play",sms_play_defstatus,NULL,
      ioi_exe_param(
        "status",IOI_L_ENUM,ioi_exe_argv(
          "The default status after the begin command.",
          NULL
        ),NULL,-1,&status,status_name,&s_def
      ),
      ioi_exe_argv(
        "Define the status for the task/family for the begin command.",
        "Eg to suspend things in the suite before the begin.",
        "This effects the current level been defined.",
        "For suites this is void, for families anything else than suspended",
        "is void.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_eof(int argc, char **argv)
{
  static int    called;

  IS_THE
    sms_play_end_reading()
  OK
    ioi_exe_add( "EOF:play",sms_play_eof,NULL,NULL,
      ioi_exe_argv(
        "Quit reading the play file.",
        "The cdp stops reading the file at this point.",
        "Used to block out the end of the file.",
        NULL
      )
    );

  return called = TRUE;
}

/*----------------------------------o------------------------------------*/
int sms_play_abort(int argc, char **argv)
{
  static int    called;

  IS_THE
    quit_playing(FALSE)
  OK
    ioi_exe_add( "abort:play",sms_play_abort,NULL,NULL,
      ioi_exe_argv(
        "Abort reading the play file and generate an error.",
        "The cdp stops reading the file at this point.",
        "and the partial definition is discarded.",
        NULL
      )
    );

  return called = TRUE;
}

int sms_play_load(void)
/**************************************************************************
?  Load the suckers into the IOI.
************************************o*************************************/
{
  sms_play_suite    (0,NULL);
  sms_play_endsuite (0,NULL);
  sms_play_family   (0,NULL);
  sms_play_endfamily(0,NULL);
  sms_play_task     (0,NULL);
  sms_play_endtask  (0,NULL);
  sms_play_date     (0,NULL);
  sms_play_day      (0,NULL);
  sms_play_edit     (0,NULL);
  sms_play_event    (0,NULL);
  sms_play_meter    (0,NULL);
  sms_play_label    (0,NULL);
  sms_play_action   (0,NULL);
  sms_play_owner    (0,NULL);
  sms_play_text     (0,NULL);
  sms_play_time     (0,NULL);
  sms_play_cron     (0,NULL);
  sms_play_today    (0,NULL);
  sms_play_trigger  (0,NULL);
  sms_play_clock    (0,NULL);
  sms_play_repeat   (0,NULL);
  sms_play_defstatus(0,NULL);
  sms_play_eof      (0,NULL);
  sms_play_abort    (0,NULL);
  sms_play_extern   (0,NULL);
  sms_play_cancel   (0,NULL);
  sms_play_migrate  (0,NULL);
  sms_play_late     (0,NULL);
  sms_play_restore  (0,NULL);
  sms_play_complete (0,NULL);
  sms_play_limit    (0,NULL);
  sms_play_inlimit  (0,NULL);

  return 0;
}

void sms_play_show(int full, int kids, int mode)
/**************************************************************************
?  To display the current definition.
************************************o*************************************/
{
  sms_list *lp;

  if( !sms_._super ) return;

  if(mode == 0)
    printf("#============================================================\n");

  for( lp=sms_node_get_external(sms_._super,TRUE) ;
       lp ; lp=lp->next )
    if(mode == 0)
      printf("extern %s\n",STR(lp->name));
    else
      printf("<extern name=\"%s\"/>\n",STR(lp->name));

  sms_play_write_definition(stdout,sms_._super,0,TRUE,full,kids,mode);

  if(mode == 0)
    printf("#============================================================\n");
}


int sms_play_makebin(char *name)
/**************************************************************************
?  Write the current definition into a binary file.
************************************o*************************************/
{
  if( !sms_._super )
    return 
      ioi_out(0,IOI_ERR,"SMS-PLAY_MAKEBIN:Nothing defined at the moment.");

  return sms_node_write(sms_._super,name);
}

int sms_play_binfile(char *name)
/**************************************************************************
?  This is either a complete checkpoint file or a bin-definition file.
|  Anyway get rid of the old stuff.
=  TRUE if the reading was successfull.
************************************o*************************************/
{
  NODE_FREE( sms_._super,sms_node );
  sms_._action_number = sms_._modify_number = 0;

  return sms_node_read(name,NULL);
}

/**************************************************************************
?  To make the coding easier.
************************************o*************************************/

#define DEF(x) sms_play_write_definition(fp,(x),indent,TRUE,full,kids,xml);
#define IND    { int i; for(i=0;i<indent;i++) fprintf(fp," "); }
#define PR(x)  fprintf(fp,((x)==(-1))?"*":"%02d",(x))
#define PU(c)  putc((c),fp)

static void print_range(FILE *fp, char *s, int n, int range, int add)
{
  int i;

  fprintf(fp,"%s",STR(s));
  for(i=0 ; i<range ; i++)
  {
    if( n & 0x01 )
    {
      fprintf(fp,"%d",i+add);
      if( n>1 ) fprintf(fp,",");
    }
    n >>= 1;
  }
  fprintf(fp," ");
}

#define EOL fprintf(fp,"%s\n", xml? ">" : "");
#define EOS fprintf(fp,"%s\n", xml? "/>" : "");    /* End of Simple */

int sms_play_write_definition(
    FILE     *fp,                  /* This only displays into the files  */
    void     *anything,            /* The startting node to be displayed */
    int       indent,              /* Initial indentation, beautifull!   */
    int       brothers,            /* Flag to display also the brothers  */
    int       full,                /* Print full contents of the nodes   */
    int       kids,                /* Print kids also (for XCdp)         */
    int       xml)                 /* Print in XML                       */
/**************************************************************************
?  Write an ascii file of the current definitions.
|  Used for debugging and to turn a checkpoint file readable.
************************************o*************************************/
{
  if(xml) full=0;

  while( anything )
  {
    sms_node *np = anything;

    IND;
    switch( np->type )
    {
      case NODE_LIST:
        {
          sms_list *l = anything;
          fprintf(fp,xml? "<text>'%s'/>\n" : "text '%s'\n",STR(l->name));
        }
        break;

      case NODE_USER:
        {
          sms_user *u = anything;
          if(xml) fprintf(fp,"<owner uid=%d gid=%d name=\"%s\"/>\n",u->uid,u->gid,STR(u->name));
          else fprintf(fp,"owner %d %d %s\n",u->uid,u->gid,STR(u->name));
        }
        break;

      case NODE_VARIABLE:
        {
          sms_variable *v = anything;
          if(xml) fprintf(fp,"<variable name='%s' value='%s'/>\n",STR(v->name),STR(v->value));
          else    fprintf(fp,"edit %s '%s'\n",STR(v->name),STR(v->value));
        }
        break;

      case NODE_TIME:
        {
          sms_time *t = anything;

          if(t->iscron)
          {
            fprintf(fp,"%scron ", xml?"<":"");

            if(t->weekdays)  print_range(fp, "-w ", t->weekdays,   6, 0);
            if(t->monthdays) print_range(fp, "-d ", t->monthdays, 31, 1);
            if(t->months)    print_range(fp, "-m ", t->months,    12, 1);
          }
          else
          {
            if(t->today)
              fprintf(fp,"%stoday ",xml?"<":"");
            else
              fprintf(fp,"%stime ",xml?"<":"");

            if(t->relative) PU('+');
          }

          PR(t->hour[0]); PU(':'); PR(t->minute[0]);
          
            if(t->repeat)
            {
              PU(' '); PR(t->hour[1]); PU(':'); PR(t->minute[1]);
              PU(' '); PR(t->hour[2]); PU(':'); PR(t->minute[2]);
            }

            fprintf(fp,"\n");

            if(full)
            {
              indent += 2;
              IND; fprintf(fp,"# currenlty %s\n",time_name[t->status]);
              IND; fprintf(fp,"# last time GMT:%d %s\n",
                           t->lasttime,STR(sms_time_c(&t->lasttime)));
              IND; fprintf(fp,"# next time GMT:%d %s\n",
                           t->nexttime,STR(sms_time_c(&t->nexttime)));
              indent -= 2;
            }
          }
        break;

      case NODE_DATE:
        {
          sms_date *d = anything;
          int       i;

          if( d->weekdays )
          {
            fprintf(fp,"day");
            for( i=0 ; i<DAY_MAX ; i++ )
              if( d->weekdays & ( 1<<i ) )
                fprintf(fp," %s",day_name[i]);
          }
          else
          {
            fprintf(fp,"date ");
            PR(d->day); PU('.'); PR(d->month); PU('.');
            if( d->year == NIL ) PR(d->year);
            else                 PR(d->year+1900);
          }
          fprintf(fp,"\n");

          if(full)
          {
            indent += 2;
            IND; fprintf(fp,"# currenlty %s\n",time_name[d->status]);
            IND; fprintf(fp,"# GMT's %d\n",d->nextdate);
            indent -= 2;
          }
        }
        break;

      case NODE_TRIGGER:
      case NODE_COMPLETE:
        {
          sms_trigger *tp = anything;

          fprintf(fp,"%s ",node_name[tp->type]);
          ioi_math_list(fp,(ioi_node *)tp->math,2);
          fprintf(fp,"\n");

          if(full)
          {
            indent += 2;
            IND; fprintf(fp,"# currenlty %s\n",tp->status?"free":"normal");
            indent -= 2;
          }
        }
        break;

      case NODE_ACTION:
        {
          sms_action *a = anything;
          if(xml) fprintf(fp,"<action status=\"%s\" file=\"%s\"/>\n",status_name[a->when],STR(a->name));
          else    fprintf(fp,"action %s %s\n",status_name[a->when],STR(a->name));
        }
        break;

      case NODE_EVENT:
        {
          sms_event *e = anything;
          fprintf(fp,xml?"<event name='%s'" : "event %s",e->name?e->name:"");

          if(full)
            fprintf(fp,xml? " value='%s'" : " # currently %s",event_name[e->status]);
          EOS;
        }
        break;

      case NODE_METER:
        {
          sms_meter *m = anything;
          if(xml) fprintf(fp,"<meter name='%s' minimum=%d maximum=%d threshold=%d",
                          STR(m->name),m->min,m->max,m->color);
          else    fprintf(fp,"meter %s %d %d %d",STR(m->name),m->min,m->max,m->color);

          if(full)
            fprintf(fp,xml? " value=%d" : " # currently %d", m->status);
          EOS;
        }
        break;

      case NODE_LABEL:
        {
          sms_label *l = anything;
          char      *s = l->def;

          fprintf(fp,"label %s",STR(l->name));
          if(!s || !*s)
            fprintf(fp," \"\"");
          while( s && *s )
          {
            fprintf(fp," \"");
            while( *s && *s != '\n' )
              fprintf(fp,"%c",*s++);
            fprintf(fp,"\"");
            if( *s == '\n' )
              s++;
          }
          if( full )
          {
            if( strcmp(l->def,l->value) )
              /* fprintf(fp," # currently not default"); */
              fprintf(fp," # currently \"%s\"",STR(l->value));
          }

          fprintf(fp,"\n");

        }
        break;

      case NODE_LIMIT:
        {
          sms_limit *l = anything;
          if(xml)
            fprintf(fp,"limit %sname='%s' maximum=%d",
                    l->limittype == LIMIT_INTEGER? "type=integer ":"",
                    STR(l->name), l->limit);
          else
            fprintf(fp,"limit %s%s %d",
                    l->limittype == LIMIT_INTEGER? "-i " : "",
                    STR(l->name), l->limit);

          if(l->limittype == LIMIT_INTEGER)
            fprintf(fp,xml? " minimum=%d base=%d unit=%s" : " %d %d %s",
                    l->min,l->base,STR(l->unit));

          if(full)
            fprintf(fp,xml?" status=%d" : " # status %d",l->status);

          if(full)
          {
            sms_list *lp = l->tasks;
            for( ; lp ; lp=lp->next )
            {
              fprintf(fp,"\n"); IND;
              fprintf(fp,xml? "taskin='%s'" : "  # %s",STR(lp->name));
            }
          }
          EOS;
        }
        break;

      case NODE_SUPER:
        if(kids) DEF(np->kids);
        break;

      case NODE_ALIAS:
      case NODE_TASK:
      case NODE_FAMILY:
      case NODE_SUITE:
        if(xml)
          fprintf(fp,"<%s name=\"%s\"",node_name[np->type],STR(np->name));
        else
          fprintf(fp,"%s %s",node_name[np->type],STR(np->name));
 
        if(full)
          if(xml)
          {
            fprintf(fp," status=\"%s\"",status_name[np->status]);
            fprintf(fp," timestamp=(%d)",np->stime);
          }
          else
          {
            fprintf(fp," # currently %s",status_name[np->status]);
            fprintf(fp," (%s)", STR(sms_time_c(&np->stime)));
          }

        fprintf(fp,"%s\n",xml?">":"");

        indent += 2;

        if( np->defstatus != STATUS_QUEUED )
        { 
          IND; 
          if(xml) fprintf(fp,"<defstatus %s/>\n",status_name[np->defstatus]);
          else    fprintf(fp,"defstatus %s\n",status_name[np->defstatus]);
        }

        if( np->type == NODE_SUITE )
        {
          IND;
#ifdef IMPOSSIBLE
          fprintf(fp,"clock %s %d # %s\n",
            clock_name[np->clock],np->gain,
            np->stime? STR(sms_time_c(&(np->stime))):"");
#endif
          if(np->stime)
            fprintf(fp,"clock %s %d # %s %s\n",
              clock_name[np->clock],np->gain,
              STR(sms_variable_get("DATE",np)),
              STR(sms_variable_get("SMSTIME",np))
            );
          else
            fprintf(fp,"clock %s %d # NOT started\n",
              clock_name[np->clock],np->gain
            );
        }

        if( full )
          if( np->genvars )
          {
            sms_variable *v = np->genvars;
            while( v )
            {
              IND; fprintf(fp,"# genvar %s '%s'\n",STR(v->name),STR(v->value));
              v = v->next;
            }
          }

        {
          sms_inlimit *ip;

          for( ip=np->inlimit ; ip ; ip=ip->next )
          {
            IND;
            fprintf(fp,"inlimit %s%s",
                    (ip->inlimittype == INLIMIT_NODE)? "-n " : "",
                    STR(ip->name));

            if(ip->usage != 0 || ip->priority != 0)
              fprintf(fp," %d",ip->usage);
            if(ip->priority != 0)
              fprintf(fp," %d",ip->priority);
            fprintf(fp,"\n");
          }
        }

        if(np->repeat)
        {
          IND;
          fprintf(fp,"repeat %s\n",STR(sms_repeat_string(np,FALSE)));
        }

        if(np->autocm)
        {
          IND;
          fprintf(fp,"auto%s %s\n",
                  (np->autocm->type==NODE_CANCEL)? "cancel" : "migrate",
                  STR(sms_cancel_string(np,FALSE)));
        }

        if(np->late)
        {
          IND;
          fprintf(fp,"late %s\n",STR(sms_late_string(np,FALSE)));
        }

        if( np->restore )
        {
          sms_list *lp = np->restore;
          for( lp = np->restore; lp ; lp=lp->next )
          { IND; fprintf(fp,"autorestore %s\n",STR(lp->name)); }
        }

        DEF(np->limit);
        DEF(np->trigger);
        DEF(np->complete);
        DEF(np->variable);
        DEF(np->event);
        DEF(np->meter);
        DEF(np->label);
        DEF(np->time);
        DEF(np->date);
        DEF(np->action);
        DEF(np->user);
        DEF(np->text);

        if(np->type != NODE_TASK || full)
          if(kids) DEF(np->kids);

        indent -= 2;
        if( np->type != NODE_TASK || xml )
        {
          IND;
          fprintf(fp,xml? "</%s>\n" : "end%s\n",node_name[np->type]);
        }
        break;

    }
    anything = brothers? np->next : NULL;
  }

  return 0;
}
