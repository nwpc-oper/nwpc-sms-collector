/**************************************************************************
.TITLE    CRED
.NAME     CDP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-MAR-1992 / 14-AUG-1991 / OP
.VERSION  4.0
.DATE     22-SEP-1994 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.2
.DATE     12-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*         Added support for version/revision/modification mismatch
.FILE     cred.c
*
*  This code is to be included into the sms_svc.c
*
*  It handles the authentication and identification of the client.
*
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
************************************o*************************************/

  struct authunix_parms *ux;

  ux = (struct authunix_parms *) rqstp->rq_clntcred;

#ifdef SMS_STATISTICS
  smss_._rpc_calls++;

  if(rqstp->rq_proc == NULLPROC)
    smss_._null_proc_calls++;

#  ifdef SMS_TIMER
     smss_._start = clock();
     smss_._who   = NIL;
#  endif

#endif

  if( rqstp->rq_proc != NULLPROC )
    sms_._machine = ux->aup_machname;

  if( rqstp->rq_proc != NULLPROC &&  rqstp->rq_proc != SMS_LOGIN )
    if( rqstp->rq_cred.oa_flavor == AUTH_UNIX )
    {
      sms_connect           *con = sms_._connect;

      sms_._current_con = NULL;

      if( ux->aup_len != 1 )
      {
        spit(0,IOI_ERR,"SMS-PROG-1:Handle verification failed");
        svcerr_systemerr(transp);
        return;
      }

      /* Just to look at the activity */
/*
      printf("%s %d,%d - [%d] %s\n",
        STR(ux->aup_machname),
        ux->aup_uid,
        ux->aup_gid,
        ux->aup_gids[0],
        STR(sms_time_c(&ux->aup_time))
      );
*/
      while( con )
        if( con->handle == ux->aup_gids[0] )
        {
          sms_._current_con = con;
          con = NULL;
        }
        else
          con = con->next;
  
      if( ! (sms_._current_con) )
      {
        spit(0,IOI_ERR,"SMS-PROG-1:User %d,%d from %s not registered",
             ux->aup_uid,ux->aup_gid,STR(ux->aup_machname));
        svcerr_systemerr(transp);
        return;
      }
      else
      {
        sms_time_t( &(sms_._current_con->idle) );
#ifdef SMS_TIMER
        smss_._who = (sms_._current_con->name[0] != '/');
#endif
      }

      sms_._xdr_privs = (
          ( sms_._current_con->passok & PR_OPER   ) ||
          ( sms_._current_con->passok & PR_SYSTEM ) ||
          ( sms_._current_con->passok & PR_ADMIN  )
        ) ?
        XDR_OPER : XDR_NONE;

      sms_._xdr_version = sms_._current_con->rev*1000 + sms_._current_con->mod;
    }
    else
    {
      spit(0,IOI_ERR,"SMS-PROG-1:Authentication error");
      svcerr_weakauth(transp);
      return;
    }

