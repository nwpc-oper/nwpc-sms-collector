/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     09-NOV-1992 / 30-JUL-1991 / OP
.VERSION  4.0
.FILE     cd.c
.DATE     22-SEP-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-2
.DATE     08-DEC-1994 / 08-DEC-1994 / OP
.VERSION  4.3.4
.DATE     31-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     30-OCT-1998 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
.DATE     04-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  FROM: node.c:sms_node_find()
*
*  compile the debug main routine:
*
*  cc -DMAIN=main -I../include -o cd cd.c ../lib/ioi.a libsms.a -lm
*
************************************o*************************************/

#ifdef MAIN
#define SMS_MAIN_MODULE
#endif

#include "smslib.h"

#ifdef __STDC__
#   define  PROTO(DEF) DEF
#else
#   define  PROTO(_A) ()
#endif

extern char *re_comp PROTO((const char *s));
/*
// On success NULL, otherwise a string containing an error message.
*/
extern       re_exec PROTO((const char *s));
/*
// 1 if a match, 0 if not and -1 in case of error.
*/
/* A problem with the CDC 4xx0 / epix@ecmwf.co.uk */

#define ISALPHA(c) (isalnum((c)) || (c)=='_')

/**************************************************************************
*         L O C A L   T Y P E S   A N D   D E F I N I T I O N S
************************************o*************************************/

/*
//  Must be bigger than any NODE_XXXX in sms.x (list_add())
//
//  And don't use any of the routines than interpretes the node.
//  list_add() and list_join() are OK.
*/

#define CD_ROOT  100               /* "/"  Only the first one */
#define CD_THIS  101               /* "."                     */
#define CD_UP    102               /* ".."                    */
#define CD_NAME  103               /* [a-z,A-Z,0-9,'_']+      */
#define CD_RE    104               /* Regular Expression      */
#define CD_EVENT 105               /* ":"                     */

struct cd_dir {
  int                   type;      /* SMS_GEN!!! == NODE_LIST */
  char                 *name;
  struct cd_dir        *next;
};

typedef struct cd_dir cd_dir;

static cd_dir *cd_make(char *name, int type)
/**************************************************************************
?  Make a new node of cd-special type. Own routine to also install the
|  special type and name at the same time.
=  The structure pointer
************************************o*************************************/
{
  cd_dir *cd = calloc(1,sizeof(cd_dir));

  cd->type = type;
  cd->name = strdup(name);

  return cd;
}

static cd_dir *cd_error(char *msg, char *orig, char *path)
/**************************************************************************
?  Produce an error message and point where the mistake was
=  (cd_dir *)NULL
************************************o*************************************/
{
  char  buff[MAXNAM];
  char *b;

  ioi_out(0,IOI_ERR,"pattern:%s",STR(msg));
  ioi_out(0,IOI_ERR,"%s",STR(orig));

  for(b=buff ; orig<path ; orig++)
    *b++ = '-';
  *b++ = '>';
  *b++ = '\0';

  ioi_out(0,IOI_ERR,"%s",STR(buff));

  return NULL;
}

static sms_list *expand(char *from, cd_dir *path)
/**************************************************************************
?  Produce a list of names if one would "cd" FROM to CD-list.
=  .
************************************o*************************************/
{
  sms_list *lp = NULL;
  sms_node *np;
  char      result[MAXLEN];
  char     *s,*t;
  int       event = FALSE;

  if( !from || *from != '/' )
    strcpy(result,"/");
  else
  {
    strncpy(result,from,MAXLEN);   /* This is the starting point! */
    result[MAXLEN-1] = '\0';
  }
  s = result + strlen(result) - 1;

  while( path )
  {
    switch(path->type)
    {
      case CD_ROOT:
        strcpy(result,path->name);
        s = result + strlen(result) - 1;
        break;
      case CD_THIS:                /* Could be ignored at build up */
        break;
      case CD_UP:
        while( ISALPHA(*s) ) s--;
        if( *s == '/' && s != result ) s--;
        break;
      case CD_EVENT:
        event = TRUE;
        break;
      case CD_NAME:

        if( *s != '/' && *s != ':' ) *++s = (event)? ':' : '/';

        for( t=path->name ; *t ; t++ )
          *++s = *t;
        break;
      case CD_RE:
        s[1] = '\0';

        if( ! (np=sms_node_find_full(result)) )
          return lp;

        np = (event)? (sms_node *)np->event : np->kids;
        if( event )
          *++s = ':';

        if( np )
        {
          re_comp(path->name);     /* "compile" the current pattern */

          while(np)
          {
            if( re_exec(np->name)==1 )
            {
              if( *s != '/' && *s !=':' ) *++s = '/';   /* CD s in the node */
              for( t=np->name ; *t ; t++ )
                *++s = *t;
              s[1] = '\0';

              if( path->next )
              {
                sms_list_join(&lp,expand(result,path->next));
                re_comp(path->name);
              }
              else
                sms_list_add(&lp,sms_node_create(result));

              while(ISALPHA(*s)) s--;       /* CD .. in the s */
                if( *s == '/' && s != result ) s--;
              s[1] = '\0';
            }
            np = np->next;
          }
        }

        return lp;
        /* break; */
    }
    path = path->next;
  }

  *++s = '\0';

  if( sms_node_find_full(result) )
    lp = sms_node_create(result);  /* A single match */

  return lp;
}

static int has_pattern(cd_dir *cd)
/**************************************************************************
?  Does any of the components of the path have a pattern.
=  BOOLEAN answer.
************************************o*************************************/
{
  for( ; cd ; cd=cd->next ) 
    if( cd->type == CD_RE ) return TRUE;

  return FALSE;
}

static cd_dir *chop(char *path)
/**************************************************************************
?  Called only by the client.
=  The list components in the path
|  NULL = error
************************************o*************************************/
/**************************************************************************
|  <ROOT>    ::= '/'
|  <THIS>    ::= '.'
|  <UP>      ::= ".."
|  <LETTER>  ::= [a-z,A-Z,0-9,'_']
|  <ONE>     ::= '?'
|  <ANY>     ::= '*'
|  <LIST>    ::= <LETTER>+ | <LETTER> '-' <LETTER>
|  <RANGE>   ::= '[' <LIST> [',' <LIST>]*  ']'
|  <REGEXP>  ::= [<LETTER> | <ONE> | <ANY> | <RANGE>]+
|  <DIR>     ::= <REGEXP> | <UP> | <THIS>
|  <PATH>    ::= <ROOT>* <DIR> ['/'+ <DIR>]* [ ':' <REGEXP>]
|  ------------------------------------------------------------------------
|  <NAME>    :== <LETTER>+           // Part of the REGEXP
|  ------------------------------------------------------------------------
|  task name is numder construction
************************************o*************************************/
{
  cd_dir   *cd = NULL;             /* List of paths                      */
  char     *orig = path;           /* Just 2 B able 2 give error message */

  char      buff[MAXNAM];          /* To build the part of the path      */
  char     *b;                     /* Pointer in the buff                */

  int       event = FALSE;         /* Does path have event introducer?   */

  if( !path || !*path )
    return (cd=cd_make(".",CD_THIS));

  if( *path == '/' )
  {
    cd = cd_make("/",CD_ROOT);
    path++;
    while( *path =='/' ) path++;
  }

  while( *path )
  {
    if( *path == '.' )
    {
      if( event )
        return cd_error("no \"cd\" form event",orig,path);

      if( *++path=='.')
        sms_list_add(&cd,cd_make("..",CD_UP)) , path++;
      else
        sms_list_add(&cd,cd_make(".",CD_THIS));
    }
    else
    {
      int   inside    = FALSE;
      int   ispattern = FALSE;
      int   ascii     = TRUE;

      for(b=buff , *b++ = '^' ; *path && *path != '/' && *path != ':' ; path++)
        if( inside )
          if( *path == ']' ) inside = FALSE , *b++ = *path;
          else            *b++ = *path;
        else
          switch ( *path )
          {
            case '?' : *b++ = '.';                    ispattern = TRUE; break;
            case '*' : *b++ = '.';    *b++ = '*';     ispattern = TRUE; break;
            case '[' : inside = TRUE; *b++ = *path;   ispattern = TRUE; break;
            case '.' : *b++ = '\\';   *b++ = *path;                     break;
            default  : *b++ = *path;  ascii = ISALPHA(*path);
          }

      if( event && *path == '/' )
        return cd_error("no / in events",orig,path);

      *b++ = '$'; *b++ = '\0';     /* Finish the buffer */

      if( ispattern )
        if( (b=re_comp(buff)) )
          return cd_error(b,orig,path);
        else
          sms_list_add(&cd,cd_make(buff,CD_RE));
      else
        if(!ascii)
          return cd_error("illegal name",orig,path);
        else
        {
          b[-2] = '\0';              /* Remove the $-sign */
          sms_list_add(&cd,cd_make(buff+1,CD_NAME));
        }                            /* Skip the ^-sign   */
    }

    if(*path && !(*path == '/' || *path == ':'))
      return cd_error("syntax error",orig,path);

    if(*path == ':')
    {
      sms_list_add(&cd,cd_make(":",CD_EVENT));
      event = TRUE;
      *path++;
    }

    while( *path =='/' ) path++;   /* OK 4 events this is a bit dirty! */
  }

  return cd;
}

char *sms_cd_to(char *from, char *to)
/**************************************************************************
?  Compute the new directory name if one would 'cd' form FROM to TO.
|  The FROM must start with the slash '/'
|  The result always starts with the '/'
|  The originals are not affected.
*
|  Current implementation allows to 'CD' as follows
|  .                                This directory
|  ./                               - " -
|  ./[anything]                     Relative to this directory
|
|  ..                               The previous directory
|  ../                              - " -
|  ../[anything]                    Relative to the previous directory
|
|  /                                The root directory
|  /[anything]                      Starting from the root directory
|
|  name                             Name in the current directory
|  name/                            - " -
|  name/[anything]                  Down in the name
|
|  ""                               Empty TO, do nothing!
|
|  // = /                           Multiple slashes are treated as a single one
|  name[*] = [a-z,A-Z,0-9,'_']      The dot is not allowed in the names!
*
=  The new path containing only the names and startting with the '/'
|  NULL is returned in case of errors along with an warning message.
|  If both FROM and TO are NULL's a '/' is returned
|  FROM is returned if the TO is NULL
************************************o*************************************/
{
  static char result[MAXLEN];      /* The result of the cd FORM -> TO  */
  char *s;                         /* Current character in the result  */
  int   len;                       /* Current length of the result     */

  strcpy(result,"/");              /* By default it must be the ROOT   */

  if( !to )
    return from? from : result;

  if( !from || *from != '/' || *to == '/' )
  {
    if( *to == '/' )               /* CD starting from the ROOT */
      to++;

    result[0] = '/';
    len       = 1;
    s         = result;
  }
  else
  {
    strncpy(result,from,MAXLEN);   /* This is the starting point! */
    result[MAXLEN-1] = '\0';
    len = strlen(result);
    s = result + len - 1;
  }

  while( *to )                     /* Loop over the TO */
    if( ISALPHA(*to) )
    {
      if( *s != '/' )              /* Might be the root! */
        *++s = '/' , len++;

      while( ISALPHA(*to) )
      {
        if( ++len >= MAXLEN )
        {
          ioi_out(0,IOI_WAR,"SMS-CD-TO:result too long %d",MAXLEN );
          return 0;
        }
        *++s = *to++;
      }
    }
    else if( *to == '.' )          /* Relative to the current */
      if( *++to == '.' )           /* It's the DOTDOT */
        if(!to[1] || to[1]=='/')   /* LEGAL? */
        {
          while( ISALPHA(*s) )     /* It will stop! */
            s-- , len-- ;
          if( *s=='/' && len>1 )
            s-- , len-- ;
          to++;                    /* Skip the other dot */
        }
        else
        {
          ioi_out(0,IOI_WAR,"SMS-CD-TO:illegal .. [%s]",STR(&to[1]) );
          return 0;
        }
      else                         /* It's the DOT */
        if( !*to || *to=='/' )     /* LEGAL? */
          ;
        else
        {
          ioi_out(0,IOI_WAR,"SMS-CD-TO:illegal . [%s]",STR(to) );
          return 0;
        }
    else if( *to == '/' )          /* Skip multiples fo the SLASH */
      to++;
    else
    {
      ioi_out(0,IOI_WAR,"SMS-CD-TO:illegal char %c",*to );
      return 0;
    }

  *++s = '\0';

  return result;
}

sms_list *sms_cd_names2(int argc, char **argv, sms_list **lp)
/**************************************************************************
?  Generate names that match the pattern given.
=  Full names that match the pattern
-NOTICE  Under construction
************************************o*************************************/
{
  static sms_list *names;
  char            *cwn = ioi_variable_get("cwn");
  char            *to;

  NODE_FREE(names,sms_list);

  if( sms_client_is_ok(HANDLE) == SMS_E_OK )
  {
    sms_cdp_update(HANDLE);
    
    if( !sms_._super )
      return NULL;
  }
  else
  {
    ioi_out(0,IOI_WAR,"match:not logged on");
    return 0;
  }

  if( !cwn ) cwn="/";             /* Not to get NULL from the cd_to() */

  if( !argc )
    names = sms_node_create(cwn);
  else
    while( argc-- )
    {
      cd_dir   *temp;
      cd_dir   *cdto = 0;
      cd_dir   *from = 0;
      char *s = *argv;

      /* if( s[0] == '/' && s[1] == '/' ) */
      if( sms_node_net_find(s) )
        ls_add(&names,ls_create(0,*argv));
      else
      {
        cdto = chop(*argv);
        from = chop(cwn);

        if( cdto )
        {
          sms_list *lp;

          sms_list_join(&from,cdto);
          cdto = NULL;                 /* No need to free the cdto */
 
          sms_list_join(&names,expand("/",from));
        }
      }

      for( ; from ; from=temp )
      { temp=from->next; IFFREE(from->name); free(from); }

      argv++;
    }

  if( !names )
    ioi_out(0,IOI_ERR,"match:none found");

  if( lp )                         /* Remove the previous list if any */
  {
    NODE_FREE( *lp,sms_list );

    *lp = names;
    names = NULL;                  /* We ain;t gonna release 'em */
    return *lp;
  }

  return names;
}

char *sms_cd_name2(char *name)
/**************************************************************************
?  Generate a cd'd name from a single name
|  Actually the first one mathcing is been returned.
~  sms_cd_names2()
=  Full names
************************************o*************************************/
{
  sms_list *lp;

  lp = sms_cd_names2( name?1:0 , name?(&name):NULL , NULL );

  if( lp && lp->next ) ioi_out(0,IOI_WAR,"match:only the first one used");

  if( lp ) return lp->name;

  return name;
}

static void match(sms_node *np, int status, sms_list **lp)
/**************************************************************************
?  The routine to match individual components of the pattern
************************************o*************************************/
{
  sms_list *tmp;

  if( re_exec(np->name)==1  ||
      (status && re_exec(status_name[np->status])==1) )
  {
    tmp = sms_node_create(sms_node_full_name(np));

    tmp->next = *lp;
    *lp = tmp;
  }

  for( np=np->kids ; np ; np=np->next )
    match(np,status,lp);
}

sms_list *sms_cd_pattern(
    char      *pattern,            /* Part of the name to match to */
    int        status,             /* Match also the status name   */
    sms_list **lp)                 /*  */
/**************************************************************************
?  Match pattern in individual names
=  Full names that match the pattern
************************************o*************************************/
{
  static sms_list *names;

  NODE_FREE(names,sms_list);

  re_comp(pattern);

  match(sms_._super,status,&names);

  if( lp )                         /* Remove the previous list if any */
  {
    NODE_FREE( *lp,sms_list );

    *lp = names;
    names = NULL;                  /* We ain;t gonna release 'em */
    return *lp;
  }

  return names;
}

sms_cd_find(
    char      *pattern,            /* 2 match */
    int        nid,                /* The CWN nid                */
    sms_node  *np,                 /* Current node 2 search 4    */
    sms_node **last,               /* The previous and next node */
    sms_node **next)
/**************************************************************************
?  
=  
************************************o*************************************/
{
  if(np->type == NODE_SUPER)
  {
    *last = NULL; 
    *next = NULL;
    re_comp(pattern);
  }

  if( re_exec(np->name)==1  ||
      re_exec(status_name[np->status])==1 )
  {
    if( np->nid < nid )
    {
      *last = np;
      if( ! *next ) *next = np;    /* Wrap around */
    }

    if( np->nid == nid )           /* Same again? */
    {
      if( ! *last ) *last = np;
      if( ! *next ) *next = np;
    }

    if( np->nid > nid )            /* OK, ok, we could use else! BFD */
    {
      if( ! *last || (*last)->nid >= nid ) *last = np;
      if( ! *next || (*next)->nid <= nid ) *next = np;
    }
  }

  for( np=np->kids ; np ; np=np->next )
    sms_cd_find(pattern,nid,np,last,next);

  return (*next != NULL)?TRUE:FALSE;
}

sms_list *sms_cd_names(int argc, char **argv)
/**************************************************************************
?  Generate names that match the pattern given.
=  Full names that match the pattern
!  Currently no pattern matching. Under construction.
************************************o*************************************/
{
  static sms_list *names;
  char            *cwn = ioi_variable_get("cwn");
  char            *to;

  NODE_FREE(names,sms_list);

  if( !cwn ) cwn="/";             /* Not to get NULL from the cd_to() */

  if( !argc )
    names = sms_node_create(cwn);
  while( argc-- )
  {
    if( ! (to=sms_cd_to(cwn,*argv)) )
      return NULL;

    sms_list_add(&names,sms_node_create(to));
    argv++;
  }

  return names;
}

char *sms_cd_name(char *name)
/**************************************************************************
?  Generate a cd'd name from a single name
|  Actually the first one mathcing is been returned.
~  sms_cd_names()
=  Full names
************************************o*************************************/
{
  sms_list *lp;

  lp = sms_cd_names( name?1:0 , name?(&name):NULL );

  if( lp ) return lp->name;

  return name;
}

#ifdef MAIN2
MAIN2(int argc, char **argv)
{
  char  cwd[MAXLEN];
  char *to;

  ioi_open(argc,argv,NULL);
  ioi_variable_set("prompt","CD");

  strcpy(cwd,"/");

  while( ioi_user_cmd( &argc , &argv ) )
  {
    if( to = sms_cd_to(cwd,argv[0]) )
      strcpy(cwd,to);
    printf("%s\n",STR(cwd));
  }
  ioi_close(0);
}
#endif

#ifdef MAIN
static print(cd_dir *cd)
/*
//  Just C wot U got / TEMP ONLY
*/
{
  while(cd)
  {
    printf("%s",STR(cd->name));
    if(cd->type != CD_ROOT && cd->next)
      printf("/");
    cd = cd->next;
  }
  printf("\n");
}

MAIN(int argc, char **argv)
{
  char  cwn[MAXLEN];
  char *to;

  ioi_open(argc,argv,NULL);
  ioi_variable_set("prompt","CD");

  sms_node_read("TEMP",NULL);

  strcpy(cwn,"/");

  while( ioi_user_cmd( &argc , &argv ) )
  {
    sms_list *lp = sms_cd_names2(argc,argv,NULL);

    if(lp)
      if(lp->next)
        printf("EXPANDS:\n") , sms_list_print(&lp,stdout);
      else
        strcpy(cwn,lp->name);

    ioi_variable_set("cwn",cwn);
    printf("cwn :%s\n",STR(cwn));
  }

  ioi_close(0);
}
#endif
