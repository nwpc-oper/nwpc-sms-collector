/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     DELETE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     10-AUG-1992 / 22-OCT-1991 / OP
.VERSION  4.0
.DATE     22-SEP-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.2
.FILE     delete.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     01-OCT-1998 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
************************************o*************************************/

#include "smslib.h"

static int tdelete(void *anything, int all, int permanently)
/**************************************************************************
?  Delete time/date dependency.
=  Boolean status was something modified.
|  TRUE == yes, FALSE == no.
************************************o*************************************/
{
  sms_time **tp       = anything;
  sms_time  *t        = *tp;
  int        modified = FALSE;

  if( !t ) return modified;

  if( all )
  {
    if( permanently )
    {
      sms_list_delete_all(tp);
      return TRUE;
    }

    for( ; t ; t = t->next )
    {
      int temp = t->status;
      t->status = t->next? TIME_USED : TIME_EXPIRED;
      if(t->status != temp) t->act_no = ++sms_._action_number;
      modified |= (t->status != temp);
    }
  }
  else
  {
    while( t &&                    /* Find the current dependency */
           t->status != TIME_EXPIRED && t->status != TIME_HOLDING )
      t = t->next;

    if( permanently )
    {
      if( !t )                     /* Remove the first one */
        t = *tp;

      sms_list_delete(tp,t);

      return TRUE;
    }

    if( t && t->status==TIME_HOLDING )
    {
      if( (modified = (t->status != TIME_EXPIRED)) )
      {
        t->act_no = ++sms_._action_number;
        t->status = TIME_EXPIRED;
      }
    }
  }

  return modified;
}

int sms_delete(sms_node *np, int options)
/**************************************************************************
?  Delete the dependencies of the node. USED BY SMS ONLY.
|  The permanently option removes requested dependencies by actually
|  releasing the memory while the default action is to mark them to be
|  free.
=  BOOLEAN status was something actually done == TRUE.
************************************o*************************************/
{
  int modified = FALSE;            /* Was the node actually modified */

  int       trigs;                 /* Remove triggers  */
  int       d_dep;                 /* Remove date deps */
  int       t_dep;                 /* Remove time depd */
  int       all;                   /* Remove all of the requested types */
  int       permanently;           /* Remove them beyond recovery */

  int       mod_da = FALSE;
  int       mod_ti = FALSE;
  int       mod_tr = FALSE;

  if( !np )                        /* Just to be on the safe side */
    return SMS_E_NOTFOUND;

  sms_decode(options,&all,&d_dep,&permanently,&t_dep,&trigs,NULL);

  if( d_dep )                      /* At least one date dep is removed */
    mod_da = tdelete( &np->date,all,permanently );

  if( t_dep )
    mod_ti = tdelete( &np->time,all,permanently );

  if( trigs )
    if( np->trigger )
      if( permanently )
      {
        mod_tr = np->trigger? TRUE:FALSE;
        NODE_FREE(np->trigger,sms_trigger);
      }
      else
      {
        if( (mod_tr = (np->trigger->status != TRIGGER_FREE)) )
        {
          np->trigger->act_no = ++sms_._action_number;
          np->trigger->status = TRIGGER_FREE;
        }
      }

  if( (modified=mod_da || mod_ti || mod_tr) )
  {
    if( permanently )
    { SUITE_MODIFIED(np); }
    else
    { SUITE_CHANGED(np); }

/*  spit(0,IOI_MSG,"delete:%s by %s",sms_node_full_name(np), SMS_USER); */

    {
      char *d_mod = "";
      char *t_mod = "";

      if( mod_da ) d_mod = (all)? " date-all" : " date";
      if( mod_ti ) t_mod = (all)? " time-all" : " time";

      spit(0,IOI_MSG,"delete:%s%s%s%s%s by %s",STR(sms_node_full_name(np)),
        d_mod ,
        t_mod ,
        mod_tr      ? " triggers"    : "",
        permanently ? " permanently" : "",
        STR(SMS_USER)
      );
    }
  }
  else
    spit(0,IOI_WAR,"delete:%s had no effect, by %s",
         STR(sms_node_full_name(np)), STR(SMS_USER));

  return modified;
}

int sms_delete_cmd(int argc, char **argv)
/**************************************************************************
?  Delete triggers/time-deps/date-deps. USED BY THE CDP ONLY
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   trigs,t_dep,d_dep,all,permanently;
  static int   status_def = 0;

  static char *delete_name[] = {
    "trigger", "time", "date", "all", NULL
  };

  if( called )
  {
    int       options;             /* Well, currently only one */
    char     *av[2];               /* The SMS client-command   */
    sms_list *names = 0;

    av[0] = "delete";

    if(dummy) { argc++; argv--; }  /* GOT 2 B */

    if( !t_dep && !d_dep ) trigs = TRUE;

    sms_cd_names2(argc,argv,&names);
    if( !names )
      return 0;

    options = sms_encode(&all,&d_dep,&permanently,&t_dep,&trigs,NULL);

    return ! COMMAND(1,av,0,options,&names);
  }
  else
    ioi_exe_add("delete:cdp",sms_delete_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete all the dependencies of requested type",
            "Should only be needed with the -p option",
            NULL
          ),NULL,1,&all
        ),
        ioi_exe_param(
          "-ddate",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the currently holding date dependency.",
            "","NOTICE","",
            "This never works with the hybrid clock.",
            NULL
          ),NULL,1,&d_dep
        ),
        ioi_exe_param(
          "-ttime",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the currently holding time dependency.",
            NULL
          ),NULL,1,&t_dep
        ),
        ioi_exe_param(
          "-Ttriggers",IOI_L_BOOLEAN,ioi_exe_argv(
            "Delete the triggers. This is the default and not needed unless",
            "combined with the options -d and -t.",
            NULL
          ),NULL,1,&trigs
        ),
        ioi_exe_param(
          "-ppermanently",IOI_L_BOOLEAN,ioi_exe_argv(
            "Remove the information beyond recovery. This is not very wise",
            "on repeated suites.",
            NULL
          ),NULL,1,&permanently
        ),
        NULL
      ),
      ioi_exe_param(
        "node(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the node(s) to be freed from dependencies.",
#ifdef USE_NET_NAMES
          "The node names can be netnames (//host/suite[/family[/task]])",
#endif
          "The $cwn is used for names that does not begin with '/'.",
          "To delete dependencies from the current node use '.' as the name.",
          NULL
        ),"cwn",-1,&dummy
      ),
      ioi_exe_argv(
        "Delete the dependencies of the node.",
        "By default the triggers are deleted.",
        "","EXAMPLES","",
        "CDP> alias letgo delete -dtT   # 2 safely release a node to run",
        NULL
      )
    );

  return called = TRUE;
}

