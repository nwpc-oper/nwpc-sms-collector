/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     VARIABLE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     08-DEC-1992 / 10-SEP-1991 / OP
.VERSION  4.1
.FILE     variable.c
*
.DATE     16-APR-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     28-JUL-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     17-FEB-1995 / OP
.VERSION  4.3.4
*         Bux fix: no more .out in the SMSJOBOUT
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     15-DEC-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
*         Aliased tasks
*
*  Variable manipulating routines for SMS variables.
*
************************************o*************************************/

#include "smslib.h"

sms_variable *sms_variable_getvar(char *name, sms_node *np)
/**************************************************************************
?  Search for the value of the variable NAME.
=  The variable definition or NULL if not found.
************************************o*************************************/
{
  sms_node     *suite = np;
  sms_variable *var = NULL;

  while( !var && np )
  {
    if( var=ls_find(&np->variable,name) )
      return var;

    if( var=ls_find(&np->genvars,name) )
       return var;

    np = np->parent;
  }

  if(sms_._super && sms_._super->type == NODE_SUPER)
    if( var=ls_find(&sms_._super->variable,name) )
      return var;

  return NULL;
}

char *sms_variable_get(char *name, sms_node *np)
/**************************************************************************
?  Search for the value of the variable NAME.
=  The value of the variable or NULL if not found.
************************************o*************************************/
{
  sms_node     *suite = np;
  sms_variable *var = NULL;

  if( var=sms_variable_getvar(name,np))
    return var->value;

  return NULL;
}


sms_variable *sms_variable_create(char *name, char *value)
/**************************************************************************
?  Create a variable.
=  NULL if no mem otherwise the pointer to the structure.
************************************o*************************************/
{
  sms_variable *v;

  if( v = sms_alloc(NODE_VARIABLE) )
  {
    if( 
        ( v->name  = strdup(name)  ) &&
        ( v->value = strdup(value) )
       )
      return v;

    IFFREE( v->name  );
    IFFREE( v->value );
  }

  spit(0,IOI_ERR,"SMS-VARIABLE-CREATE:No mem.");
  return 0;
}

void sms_variable_update(sms_node *np, char *name, char *value,
                         nid_func func, void *userdata)
/**************************************************************************
?  Update a generated variable
|  Take care if this is not a new variable to only update an existing one,
|  and call func for the variables that changed (for XCdp)
************************************o*************************************/
{
  sms_variable *vp;

  if( ! (vp=ls_find(&np->genvars, name)) )
  {
    vp = sms_variable_create(name,value);
    vp->parent = np;
    ls_add(&np->genvars, vp);

    if(func) printf("UPDATE: FUNC: and new variable? oops\n");
  }
  else
  {
    if( strcmp(vp->value, value) != 0 )
    {
      char *temp;

      temp = vp->value;
      vp->value = strdup(value);
      if(vp->value)
      IFFREE(temp);

      if(func) func( (sms_node*)vp, 0, 0, 0, userdata );
    }
  }
}

int sms_variable_generate(
    sms_node *np, int edit, int alias, nid_func func, void *userdata)
/**************************************************************************
?  Build the names for the node and place them in the (np)->genvar
************************************o*************************************/
{
  char     *family;
  char     *full;
  char     *base;
  char      tmp[MAXNAM];
  sms_node *ref = np;
  int       len;

  switch(np->type)
  {
    case NODE_SUITE:
      sms_variable_update(np,"SUITE",np->name,func,userdata);
      break;

    case NODE_FAMILY:
      while(ref->parent && ref->type != NODE_SUITE)
        ref = ref->parent;         /* Find the suite */

      family = sms_node_full_name(np);
      family += 1 + strlen(ref->name) + 1;    /* '/' + len + '/'  */

      sms_variable_update(np,"FAMILY",family,func,userdata);
      sms_variable_update(np,"FAMILY1",np->name,func,userdata);
      break;

    case NODE_TASK:
    case NODE_ALIAS:
      full = sms_node_full_name(np);
      base = sms_variable_get("SMSHOME",np);
      if( !base ) base = ".";

      sprintf(tmp,"%d",np->rid);
      sms_variable_update(np,"SMSRID",tmp,func,userdata);

      sprintf(tmp,"%d",np->tryno);
      sms_variable_update(np,"SMSTRYNO",tmp,func,userdata);

      sms_variable_update(np,"TASK",np->name,func,userdata);
      sms_variable_update(np,"SMSNAME",full,func,userdata);

      if(np->type == NODE_TASK)
        sprintf(tmp,"%s%s.%s", STR(base), STR(full), edit?"usr":"sms");
      else
        sprintf(tmp,"%s%s.usr", STR(base), STR(full));

      sms_variable_update(np,"SMSSCRIPT",tmp,func,userdata);
     
      if(alias)
        sprintf(tmp,"%s%s.edt", STR(base), STR(full));
      else
        sprintf(tmp,"%s%s.job%d", STR(base), STR(full) , np->tryno);

      sms_variable_update(np,"SMSJOB",tmp,func,userdata);

      /*
       *  Add the SMSOUT or SMSHOME into the SMSJOBOUT
       */

      base = sms_variable_get("SMSOUT",np);
      if( !base ) base = sms_variable_get("SMSHOME",np);
      if( !base ) base = ".";

      sprintf(tmp,"%s%s.%d", base?base:"." , STR(full) , np->tryno);
      sms_variable_update(np,"SMSJOBOUT",tmp,func,userdata);
      break;
  }

  return 0;
}

void sms_variable_time(
    sms_node *np,                  /* SUITE! */
    nid_func  func,
    void     *userdata,
    char     *name,                /* Name of the new variable */
    char     *fmt,                 /* Format string            */
    ...)
/**************************************************************************
?  Update a time dependent generated variable, call update on it
************************************o*************************************/
{
  char     s[MAXNAM];              /* Should be enough!     */
  va_list  ap;

  va_start(ap,fmt);

  vsprintf(s,fmt,ap);

  va_end(ap);

  sms_variable_update(np,name,s,func,userdata);
}

int sms_variable_makesms(char *name, char *def)
/**************************************************************************
?  Create a SMS-variable by checking first if the environment variable
|  exists. If so use it, otherwise use defaut, and create the variable.
|  This first deletes the old variable (if found)
|  Used only by the SMS
************************************o*************************************/
{
  extern char   *getenv();
  sms_variable  *svar;
  char          *env;

  env = getenv(name);

  if(!def) def="";

  if( (svar=sms_variable_create(name, env?env:def)) )
  {
    sms_list_delete(
      &sms_._super->variable,
      sms_list_find(&sms_._super->variable,name)
    );

    sms_list_add( &sms_._super->variable, svar );
  }

  return 0;
}

int sms_variable_tries(sms_node *np)
/**************************************************************************
?  Return the number of tries for this node.
=  SMSDEFTRIES if variable "SMSTRIES" is not defined or contains garbage.
************************************o*************************************/
{
  char *tries = sms_variable_get("SMSTRIES",np);

  if( tries ) if(sms_is_number(tries))
    return atoi(tries);

  return SMSDEFTRIES;
}

/*
 *  The following (clumsy) code was taken from the smsedit(L/ECMWF)
 */

static char *ask(char *question, char *def_answer)
/**************************************************************************
?  Ask the question and input an answer. The default answer should be
|  stored in the ANSWER and if it's not empty it is displayed with the
|  QUESTION.
************************************o*************************************/
{
  int len;
  static char answer[MAXLEN];

  if(*def_answer)
    printf("%s [%s]? ",STR(question),STR(def_answer));
  else
    printf("%s? ",STR(question));

  fgets(answer,MAXLEN,stdin);
  sms_no_newline(answer);
  len = strlen(answer);

  if(!len) return NULL;

  return answer;
}

static yes_no(char *question)
/**************************************************************************
?  Ask the question and accept as an answer one of the YES/NO/QUIT.
|  The first character matters (not case sensitive).
=  TRUE if yes, FALSE if no and NIL for quit.
************************************o*************************************/
{
  char tmp[MAXNAM];                /* Temp to store the answer */
  int  i;
  char *first;                     /* Points the first non blank */

  while( TRUE )
  {
    printf("%s [Yes/No/Quit]? ",STR(question));
    fflush(stdout);
    fgets(tmp,MAXNAM,stdin);
    for( first=tmp ; *first ; first++ )
      switch(*first)
      {
        case 'y':
        case 'Y': return TRUE;
        case 'n':
        case 'N': return FALSE;
        case 'q':
        case 'Q': return NIL;
      }
  }
}

int sms_variable_edit(sms_variable *vp, char *name)
/**************************************************************************
?  Replace the old smsedit(ECMWF)
=  BOOLEAN status.
************************************o*************************************/
{
  int  i;
  int  ok=FALSE;
  sms_variable *tmp;

  while(ok==FALSE)
  {
    if(name)
      if( yes_no("Want to edit the file") )
      {
        char cmd[MAXLEN];

        sprintf(cmd,"vi %s",STR(name));
        sms_system_execute(cmd);
      }

    printf("\n");
    sms_list_print(&vp,stdout);
    printf("\n");
    ok=yes_no("Happy with this");

    if(ok==FALSE)
    {
      char *s;

      printf("\nFill in the definition for the variable\n");
      printf("use the default, if supplied, by just pressing <return>\n\n");

      for( tmp=vp ; tmp ; tmp=tmp->next )
        if( s=ask(tmp->name,tmp->value) )
        {
          free(tmp->value);
          tmp->value = strdup(s);
        }
    }

  }

  return ok==TRUE;
}
