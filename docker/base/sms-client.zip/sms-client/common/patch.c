/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     RPC-PATCH
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     22-APR-1992 / 27-FEB-1992 / OP
.VERSION  4.0
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     patch.c
*
*  Patch for the rpclib under VAX/VMS 5.4 using UCX 1.3
*
*  PROGRESS:
*
*  28-FEB-1992   The client side seems 2 B workin'
*  01-MAR-1992   The server side is ok
*  02-MAR-1992   The portmapper is ok
*  03-MAR-1992   Everything's ok.
*
************************************o*************************************/

#include <stdio.h>
#include <sys/time.h>

#ifdef VMS
#  include <socket.h>
#endif

FD_SET  (int n, int *p)  {        *p |=  (1<<n); }
FD_CLR  (int n, int *p)  {        *p &= ~(1<<n); }
FD_ISSET(int n, int *p)  { return *p &   (1<<n); }
FD_ZERO (       int *p)  { bzero((char *)p,sizeof( *(p) )); }

/* CHEDK this bit! the char is a problem */

char *index (s,c) char *s,c; { return strchr (s,c); } 
char *rindex(s,c) char *s,c; { return strrchr(s,c); }

getgroups(int len, int *table)
/**************************************************************************
?  Get all the groups that the user belongs 2
|  Under VMS there is only 1 group
=  Length of the elements placed in the table.
************************************o*************************************/
{
  if(!len || !table) return 0;

  table[0] = getgid();
  return 1;
}

bzero(char *buff, int len)
/**************************************************************************
?  Clear the memory indicated
************************************o*************************************/
{
  memset(buff,0,len);
}

bcmp(char *b1, char *b2; int len)
/**************************************************************************
?  Compare the two memory buffers up to length specified
=  0 if the buffers are equal, nozero otherwise.
************************************o*************************************/
{
  memcmp(b2,b1,len);               /* Reverse parameter order */
}

bcopy(char *from, char *to, int len)
/**************************************************************************
?  Copy 
=  0 if the buffers are equal, nozero otherwise.
*
*  The VAXC RTL manual doesn't specify the method used
*  so the overlapping might be a problem
*  but wot a hell, this isn't proper installation anyway!
*
*  Look's like workin'!
************************************o*************************************/
{
  memcpy(to,from,len);             /* Reverse parameter order */
}

getdtablesize(void)
/**************************************************************************
?  Get the descriptor table size
=  _NFILE  from  <stdio.h>
************************************o*************************************/
{
  return _NFILE;
}

int gettimeofday(struct timeval *tp, struct timezone *tzp)
/**************************************************************************
?  Get the time of today more accurately
|  VMS doesn't know of GMT, thus the time is in LOCAL TIME since 1.1.70
=  0 for success and (-1) if there is errors.
|  The micro-second field is always zero.
|  The timezone is NOT revisited.
************************************o*************************************/
{
  tp->tv_sec  = time(NULL);
  tp->tv_usec = 0;

  return 0;
}

#include <netdb.h>
#include <in.h>

struct protoent *getprotobyname(char *name)
/**************************************************************************
?  The RTL-routine doesn't seem 2 B workin'
|  This recognizes "udp" and "tcp" only
=  NULL if not known
|  othwerwise a pointer 2 a static area.
|  there will be one alias, the name itself.
************************************o*************************************/
{
  static struct protoent  pe;
  static char            *aliases[2];

  aliases[0]    = name;
  aliases[1]    = NULL;

  pe.p_aliases  = aliases;
  pe.p_name     = name;

  if( strcmp(name,"tcp") == 0 )
  {
    pe.p_proto = IPPROTO_TCP;
    return &pe;
  }

  if( strcmp(name,"udp") == 0 )
  {
    pe.p_proto = IPPROTO_UDP;
    return &pe;
  }

  return NULL;
}

