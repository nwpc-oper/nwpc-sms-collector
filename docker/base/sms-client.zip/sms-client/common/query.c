/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMS-CMD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-OCT-1997 /  17-OCT-1997 / OP
.FILE     query.c
.VERSION  4.3.16
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     05-DEC-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
*         Old child commands removed
************************************o*************************************/

#include "smslib.h"

int sms_query(sms_node *np, int cmd, sms_list *args)
/**************************************************************************
?  Execute the child query command.
|  (smsebent, smsmeter or smslabel)
=  SMS-RETURN-CODE
************************************o*************************************/
{
#include "child.h"
#undef SMS_CHILD_H

  sms_event *ep;
  sms_meter *mp;
  sms_label *lp;

  sms_node  *foo;

  char       name[MAXNAM];
  char       tmp[MAXNAM];

  strcpy(name,sms_node_full_name(np));
  strcpy(tmp,args->name);

  if( tmp[0] == '.' )
    foo=sms_node_find(tmp,np);
  else
  {
    if( tmp[0] != '/' )
      sprintf(tmp,"%s:%s",STR(name),STR(args->name));

    foo=sms_node_find_full(tmp);
  }

  switch( cmd )
  {
    case CMD_SMSEVENT:
      ep = (sms_event *)foo;

      if( !ep || ep->type != NODE_EVENT )
        return SMS_E_NOTFOUND;

      sprintf(tmp,"%d",ep->status);
      ls_add(&sms_._reply,ls_create(0,tmp));

      return SMS_E_QUERY;
      /* break; */

    case CMD_SMSMETER:
      mp = (sms_meter *)foo;

      if( !mp || mp->type != NODE_METER )
        return SMS_E_NOTFOUND;

      sprintf(tmp,"%d",mp->status);
      ls_add(&sms_._reply,ls_create(0,tmp));

      return SMS_E_QUERY;
      /* break; */

    case CMD_SMSLABEL:
      lp = (sms_label *)foo;

      if( !lp || lp->type != NODE_LABEL )
        return SMS_E_NOTFOUND;

      ls_add(&sms_._reply,ls_create(0,lp->value));

      return SMS_E_QUERY;
      /* break; */
  }

  return SMS_E_OK;
}
