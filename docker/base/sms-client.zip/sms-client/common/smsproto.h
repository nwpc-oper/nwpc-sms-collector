/**************************************************************************
.TITLE    SMS
.NAME     PROTOTYPES HEADER FILE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
.FILE     smsproto.h
.DATE     19-JAN-1999 / 17-AUG-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Login with nick names
*         Net names for nodes
*         HTML output
*         Zombie passwords
*         Fetch-command for sms-files
*         Limit (pseudo queues)
*         New commands: run, reset
*         Aliased tasks
*         Task mail & wait
.DATE     09-FEB-1999 / 05-FEB-1999 / OP
.VERSION  4.4.1
*         Limit changed
*         Inlimit own type
.DATE     26-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Events do not have numbers anymore (only a name)
*         Cancel aliases in bulk
.DATE     04-FEB-2000 / 04-FEB-2000
.VERSION  4.4.3
*         Cron type
*         Currnt time
.DATE     28-JUN-2001 / 15-MAY-2001 / OP
.VERSION  4.4.5 ABT(c)
*         jobstatus
.DATE     08-10-2002 / BR
.VERSION  ???
*         Add support for filter in sms_cmd_read(2)
************************************o*************************************/

#ifndef SMS_PROTO_H

#define SMS_PROTO_H

/* alias.c */
sms_node *sms_alias_create(sms_node *np, sms_variable *vars);

/* alter.c */
int cdp_alter_meter(sms_handle *hp, sms_meter *mp, int value);
int cdp_alter_label(sms_handle *hp, sms_label *lp, char *value);
int cdp_alter_repeat(sms_handle *hp, sms_repeat *rp, int value);
int sms_alter(sms_node *np, int options, sms_list *arg);
int sms_alter_cmd(int argc, char **argv);

/* cancel.c */
int   sms_cancellable(sms_node *np);
int   sms_cancel(sms_node *np, int force, int aliases, int migrate);
void  sms_cancel_auto(sms_node *np);
char *sms_cancel_string(sms_node *np, int who);

/* cd.c */
char     *sms_cd_to(char *from, char *to);
sms_list *sms_cd_names2(int argc, char **argv, sms_list **lp);
char     *sms_cd_name2(char *name);
sms_list *sms_cd_pattern(char *pattern, int status, sms_list **lp);
int       sms_cd_find(char *pattern, int nid, sms_node *np, sms_node **last, sms_node **next);
sms_list *sms_cd_names(int argc, char **argv);
char     *sms_cd_name(char *name);

/* cdp_cmd.c */
int cdp_check(sms_handle *hp, char *name, int mode, int t);
int cdp_scan(sms_handle *hp, char *name, int edit, int preprocess,
             sms_variable **var, char **filename);
int cdp_send(sms_handle *hp, char *name, int alias, int run,
             sms_variable **var, char **filename);
int cdp_file(sms_handle *hp, char *nodename, char *localname, 
             int maxlines, char **filename);
int cdp_jobcheck(
    sms_handle    *hp,        
    char          *nodename, 
    int            maxlines,
    char         **filename);
int cdp_manual(sms_handle *hp, char *nodename, int maxlines, char **filename);
int cdp_dir(sms_handle *hp, char *nodename, char *pattern, sms_dir **list);
int cdp_suites(sms_handle *hp, int mode, sms_list **list);
int cdp_users(sms_handle *hp, int tasks, sms_connect **cp);
int cdp_zombies(sms_handle *hp, int cmd, sms_list *names, sms_zombie **zp);
int cdp_mail(sms_handle *hp, int mode, int *number, char *sendto, sms_list **lp);
int cdp_plug(sms_node *into, sms_node *from);
int cdp_jobstatus(sms_handle *hp, char *nodename, int maxlines, char **filename);
int sms_cdp_update(sms_handle *hp);
int cdp_exit(int code);
int cdp_init(int *argc, char **argv, int xcdp);
int cdp_command(sms_handle *hp, int argc, char **argv, sms_list **lp);

/* client.c */
int         sms_client_init(int *argc, char **argv);
int         sms_client_is_ok(sms_handle *hp);
void        sms_client_copy(sms_list **lp);
int         sms_client_error(char *host, CLIENT *client);
int         sms_client_terminate(sms_handle *hp, int rc);
int         sms_client_remove(sms_handle *hp, int rc);
AUTH       *sms_client_auth_unix(int handle);
int         sms_client_ping(char *host, int quiet, int number);
sms_handle *sms_client_login(char *host, char *user, char *passwd, int t_out, int port, sms_list **lp, int *code);
int         sms_client_logout(sms_handle *hp);
int         sms_client_news(sms_handle *hp, int last);
int         sms_client_status(sms_handle *hp, sms_status **st, int all);
int         sms_client_history(sms_handle *hp, sms_list **lp, int last);
int         sms_client_play(sms_handle *hp, sms_node *np);
int         sms_client_cmd(sms_handle *hp, int argc, char **argv, sms_list **lp, int options, sms_list **gp);
int         sms_client_cmd_keepgp(sms_handle *hp, int argc, char **argv, sms_list **lp, int options, sms_list *gp);
int         sms_client_cmd_any(int argc, char **argv, sms_list **lp, int options, sms_list **gp);
int         sms_client_smscmd(sms_handle *hp, int argc, char **argv);
int         sms_client_servers(sms_list **ls, int maxnum, int verbose, char *pingfile,
                               int (*func)(void *, char *), void *userdata);

/* connect.c */
void sms_connect_check(char *name);
void sms_connect_login(sms_connect *con);
void sms_connect_recover(void);

/* cstatus.c */
int cdp_status(int argc, char **argv);

/* delete.c */
int sms_delete(sms_node *np, int options);
int sms_delete_cmd(int argc, char **argv);

/* edit.c */
int   sms_edit_string(sms_node *np, char *cmd, char *line);
int   sms_edit_variable(sms_node *np, char *cmd, char *line);
int   sms_edit_mkdir_reverse(char *path, sms_node *np);
char *sms_edit_script_name(sms_node *np, int *ispipe);
int   sms_edit_send(sms_node *np);
int   sms_edit_scan(sms_node *np, sms_variable **var, int edit, int pre);
int   sms_edit_cmd(sms_node *np, sms_variable *var, int edit, int alias, int run);
int   sms_edit_manual(sms_node *np, sms_list **lp);

/* file.c */
int      sms_file_read(char *name, sms_list **lp, int max_lines);
int      sms_file_read2(char *name, sms_list **lp, int max_lines, int ispipe,char *filter);
int      sms_file_write(char *name, sms_list *lp);
char    *sms_file_extract(sms_list **gp, sms_node *np);
sms_dir *sms_file_dir(char *path, char *pattern, int fullname);
int      sms_file_list(FILE *fp, sms_dir *dp);

/* info.c */
sms_list *sms_info_pointed(sms_node *np);
sms_list *sms_info_points(sms_node *np);
int       sms_info(sms_node *np, int variables);

/* kill.c */
int sms_kill(sms_node *np, int rerun, int firsttime);
int cdp_kill_cmd(int argc, char **argv);

int sms_jobcheck(sms_node *np);
int cdp_jobcheck_cmd(int argc, char **argv);

/* late.c */
void  sms_late_process(void);
char *sms_late_string(sms_node *np, int who);

/* limit.c */
double     sms_limit_evaluate(sms_tree *node);
int        sms_limit_isholding(sms_node *np);
void       sms_limit_mark(sms_limit *lp, int usage, char *fullname);
int        sms_limit_count(sms_node *np);
int        sms_limit_reached(sms_node *np);
void       sms_limit_running(sms_node *np);
void       sms_limit_remove(sms_node *np);
void       sms_limit_init(sms_node *np);
void       sms_limit_reset(sms_node *np);
void       sms_limit_info(sms_node *np);

/* list.c */
sms_list *sms_list_find(void *anything, char *key);
int       sms_list_remove(void *anything, void *oldp);
int       sms_list_delete(void *anything, void *oldp);
int       sms_list_delete_name(void *anything, char *name);
int       sms_list_delete_all(void *anything);
int       sms_list_add(void *anything, void *newp);
void      sms_list_join(void *anything, void *newp);
int       sms_list_add_text(void *anything, char *text);
int       sms_list_print(void *anything, FILE *fp);
void      sms_list_user(sms_connect *cp, char *buff);
void      sms_list_users(sms_connect *cp, int full);


/* log.c */
void sms_log_clear(sms_node *np, int first, int last);
int  sms_log_summary(sms_node *np);
void sms_log_add(sms_node *np, char *message);
void sms_log_begin(sms_node *np);
void sms_log_message(sms_node *np);
int  cdp_message(sms_handle *hp, char *name, sms_list **lp, int options);
int  cdp_message_add(sms_handle *hp, char *name, char *line);
int  cdp_log_cmd(int argc, char **argv);

/* loggen.c */
int cdp_loggen_cmd(int argc, char **argv);

/* migrate.c */
int  sms_migrate(sms_node *np, char *filename, int options);
int  sms_restore(sms_node *np, char *filename, int options);
int  cdp_migrate_cmd(int argc, char **argv);
int  cdp_restore_cmd(int argc, char **argv);
int  cdp_migrate_plug(int argc, char **argv);
void sms_restore_auto(sms_node *np);
void sms_migrate_auto(sms_node *np);
void sms_migrate_init(sms_node *np);

/* mail.c */
int  sms_mail(int cmd, int number, sms_list *lines);
void sms_mail_init(sms_connect *cp);


/* misc.c */
char     *sms_string(char *str, char *file, int lineno);
int       spit(int code, int type, char *fmt, ...);
int       sms_error(int code, char *fmt, ...);
int       sms_perror(char *callname);
int       sms_output(char *fmt, ...);
void      sms_numbers(int prog, int vers);
void     *sms_alloc(int type);
FILE     *sms_fopen(char *name, char *mode, char *who);
int       sms_is_number(char *s);
int       sms_is_signed_number(char *s);
char     *sms_to_char(int x);
int       sms_encode(int *first, ...);
int       sms_decode(int bits, ...);
char     *sms_no_newline(char *s);
int       sms_getsize(void);
int       sms_nap(int usec);
int       sms_confirm(char *cmd);
double    sms_drand48(void);
char     *sms_password(char *prompt);
char     *strext(char *new, char *old, char *ext);

/* nick.c */
void     sms_nick_delete(char *name);
void     sms_nick_update(char* nick,char *name, char *netname, int prog);
int      sms_nick_write(char *filename);
sms_map *sms_nick_servers(char *name);
char    *sms_nick_name(char *name);
int      sms_nick_number(char *name);
int      sms_nick_origin(char *name);
int      sms_nick_vers(char *name);
sms_map *sms_nick_broadcast(int maxnum, int verbose, char *pingfile,
                            int (*func)(void *, char *), void *userdata);

/* nid.c */
void     sms_nid_count(sms_handle *hp, void *anything, int acn);
sms_nid *sms_nid_build(void *anything, int acn);
void     sms_nid_version(sms_handle *hp);
void     sms_nid_update(void *anything, sms_nid *nid, nid_func func, void *userdata);

/* node.c */
void       *sms_node_free(void *anything);
sms_list   *sms_node_create(char *text);
int         sms_node_play(int mode);
int         sms_node_external(char *name);
sms_list   *sms_node_get_external(sms_node *np, int init);
int         sms_node_clear_user_data(sms_node *np);
sms_node   *sms_node_find(char *name, sms_node *ref);
sms_node   *sms_node_find_full(char *name);
char       *sms_node_full_name(void *anything);
sms_handle *sms_node_find_handle(sms_node *np);
sms_node   *sms_node_net_find(char *name);
char       *sms_node_net_name(void *anything);
void        sms_node_before_send(sms_node *np);
int         sms_node_get_trigger(sms_tree *trg, sms_node *ref);
void        sms_node_update(sms_node *np, nid_func func, void *userdata);
sms_node   *sms_node_parents(sms_node *np, sms_node *parent);
int         sms_node_get_limit(sms_inlimit *ip, sms_node *ref);
int         sms_node_triggers(sms_node *np, sms_node *parent);
sms_node   *sms_node_after_receive(sms_node *np);
int         sms_node_write(sms_node *np, char *name);
int         sms_node_read(char *name, sms_status **sp);
int         sms_node_check(void);
int         sms_node_begin(sms_node *np, int byuser);
int         sms_node_requeue(sms_node *np, int repeat);
void        sms_node_resubmit(sms_node *np, int aborted, int clear);
void        sms_node_run(sms_node *np, int force, int clear);
int         sms_node_mkdir(sms_node *np, char *base, char *start, char *end, int t_sleep, int e_sleep, int overwrite, double abort_rate, int verbose);

/* order.c */
int sms_order(sms_node *np, int how, sms_list *args);
int cdp_order_cmd(int argc, char **argv);

/* overview.c */
int sms_overview(int status, sms_node *np);
int cdp_overview_cmd(int argc, char **argv);

/* passwd.c */
int           sms_passwd_zombies();
void          sms_passwd_zombie_fmt(sms_zombie *zp);
void          sms_passwd_zombie_str(sms_zombie *zp, char *buff, time_t t);
void          sms_passwd_zombie_print(sms_zombie *zp);
void          sms_passwd_zombie(sms_node *np);
int           sms_passwd_zombie_cmd(int cmd, sms_list *lp);
void          sms_passwd_zombie(sms_node *np);
void          sms_passwd_process(time_t t);
int           sms_passwd_is_zombie(sms_login *who, int *fail);
int           sms_passwd_read(char *name);
int           sms_passwd_write(char *name);
char         *sms_passwd_user(char *user);
int           sms_passwd_ok(char *user, char *passwd);
int           sms_passwd_task_ok(sms_login *who);
char         *sms_passwd_crypt(char *passwd);
sms_variable *sms_passwd_generate(sms_node *np);
int           sms_passwd_legal(char *passwd);
int           sms_passwd_add(char *user, int uid, int gid, int rights, char *passwd, char *comment);
int           sms_passwd_delete(char *user);
int           sms_passwd_list(int std);
void          sms_passwd_privileges(void);
int           sms_passwd_list_read(char *name);
int           sms_passwd_list_write(char *name);

/* play.c */
int           sms_play_gets(char *buff, int buffsize, int depth);
int           sms_play_definition(char *name, int echo, int local, char *replace);
int           sms_play_end_reading(void);
sms_user     *sms_play_user(char *name, int uid, int gid);
sms_list     *sms_play_create_text(int argc, char **argv);
sms_variable *sms_play_variable(char *name, char *value);
int           sms_play_make_time(char *s, int *h, int *m);
sms_time     *sms_play_create_time(char *start, char *end, char *inc, int today);
sms_time     *sms_play_create_late(char *submitted, char *active, char *complete);
sms_time     *sms_play_create_auto(char *start, int type);
sms_list*     sms_play_create_restore(char *name);
int           sms_play_make_date(char *str, int any, int *d, int *m, int *y);
sms_date     *sms_play_create_date(char *str);
int           sms_play_gain(int argc, char **argv, int *gain);
sms_date     *sms_play_create_day(int argc, char **argv);
sms_trigger  *sms_play_create_trigger(int argc, char **argv, int type);
sms_event    *sms_play_create_event(char *name);
sms_meter    *sms_play_create_meter(char *name, int min, int max, int color);
int           sms_play_label_argv2string(int argc, char **argv, char *buff, int maxlen);
sms_label    *sms_play_create_label(char *name,int argc, char **argv);
sms_repeat   *sms_play_create_repeat(int mode, char *name, int argc, char **argv);
sms_inlimit  *sms_play_create_inlimit(char *name, int usage, int priority, int type);
sms_action   *sms_play_create_action(int status, char *name);
sms_node     *sms_play_node(char *name, int type);
sms_node     *sms_play_find_last(void);
int           sms_play_end(int level);
int           sms_play_add(void *anything);
int           sms_play_modify(int cmd, int p1, int p2);
int           sms_play_suite(int argc, char **argv);
int           sms_play_endsuite(int argc, char **argv);
int           sms_play_family(int argc, char **argv);
int           sms_play_endfamily(int argc, char **argv);
int           sms_play_task(int argc, char **argv);
int           sms_play_endtask(int argc, char **argv);
int           sms_play_date(int argc, char **argv);
int           sms_play_day(int argc, char **argv);
int           sms_play_edit(int argc, char **argv);
int           sms_play_event(int argc, char **argv);
int           sms_play_meter(int argc, char **argv);
int           sms_play_label(int argc, char **argv);
int           sms_play_action(int argc, char **argv);
int           sms_play_owner(int argc, char **argv);
int           sms_play_text(int argc, char **argv);
int           sms_play_time(int argc, char **argv);
int           sms_play_today(int argc, char **argv);
int           sms_play_cancel(int argc, char **argv);
int           sms_play_migrate(int argc, char **argv);
int           sms_play_late(int argc, char **argv);
int           sms_play_restore(int argc, char **argv);
int           sms_play_extern(int argc, char **argv);
int           sms_play_trigger(int argc, char **argv);
int           sms_play_complete(int argc, char **argv);
int           sms_play_clock(int argc, char **argv);
int           sms_play_repeat(int argc, char **argv);
int           sms_play_tries(int argc, char **argv);
int           sms_play_defstatus(int argc, char **argv);
int           sms_play_eof(int argc, char **argv);
int           sms_play_abort(int argc, char **argv);
int           sms_play_load(void);
void          sms_play_show(int full, int kids, int mode);
int           sms_play_makebin(char *name);
int           sms_play_binfile(char *name);
int           sms_play_write_definition(FILE *fp, void *anything, int indent, int brothers, int full, int kids, int xml);

/* query.c */
int sms_query(sms_node *np, int cmd, sms_list *args);

/* repeat.c */
long  sms_repeat_julian_to_date(long jdate);
long  sms_repeat_date_to_julian(long ddate);
int   sms_repeat_str2date(char *s);
void  sms_repeat_init(sms_node *np);
void  sms_repeat_variable(sms_node *np, nid_func func, void *userdata);
int   sms_repeat_node(sms_node *np);
int   sms_repeat_alter(sms_repeat *rp, char *str);
void  sms_repeat_info(sms_repeat *r);
void  sms_repeat_show(sms_repeat *r, FILE *fp);
char *sms_repeat_string(sms_node *np, int who);

/* sms_cmd.c */
int sms_cmd_typeok(char *cmd, sms_node *np, ...);
int sms_cmd_log_user(sms_node *np);
int sms_cmd_suites(sms_list *args);
int sms_cmd_order(sms_list *args);
int sms_cmd_kill(sms_list *args);
int sms_cmd_migrate(sms_list *args);
int sms_cmd_restore(sms_list *args);
int sms_cmd_message(sms_list *args);
int sms_cmd_alter(sms_list *args);
int sms_cmd_begin(sms_list *args);
int sms_cmd_cancel(sms_list *args);
int sms_cmd_check(sms_list *args);
int sms_cmd_child(int cmd, int old, sms_list *args);
int sms_cmd_delete(sms_list *args);
int sms_cmd_exists(sms_list *args);
int sms_cmd_file(sms_list *args);
int sms_cmd_manual(sms_list *args);
int sms_cmd_dir(sms_list *args);
int sms_cmd_force(sms_list *args);
int sms_cmd_passwd(sms_list *args);
int sms_cmd_privileges(void);
int sms_cmd_auto_recover(void);
int sms_cmd_recover(sms_list *args);
int sms_cmd_requeue(sms_list *args);
int sms_cmd_resubmit(sms_list *args);
int sms_cmd_run(sms_list *args);
int sms_cmd_restart(void);
int sms_cmd_resume(sms_list *args);
int sms_cmd_scan(sms_list *args);
int sms_cmd_send(sms_list *args);
int sms_cmd_shutdown(void);
int sms_cmd_halt(void);
int sms_cmd_sms(void);
int sms_cmd_terminate(void);
int sms_cmd_suspend(sms_list *args);
int sms_cmd_expire(sms_list *args);
int sms_cmd_users(void);
int sms_cmd_number(char *command_name, int *old);
int sms_cmd(int cdp_options, sms_list *cmd);

/* sms_svc_run.c */
int  sms_svc_run(void);
int sms_svc_quit(void);
void svc_main(void);

/* sort.c */
int  sms_list_sort(sms_list **root, int (*routine )());
void sms_list_fancy(sms_list **root);

/* status.c */
int       sms_status_mask(int def, char *mask);
sms_list *sms_status_why(sms_node *np);
int       sms_status_privilege(sms_node *np);
int       sms_status_validate(sms_node *np);
int       sms_status_default(sms_node *np);
int       sms_status_max(sms_node *np);
int       sms_status_change_meter(sms_meter *np, int to);
int       sms_status_change_label(sms_label *np, char *to);
int       sms_status_change(sms_node *np, int to, int force, int recursively);
double    sms_status_evaluate(sms_tree *node);
int       sms_status_trigger_wait(sms_node *np, sms_trigger *tp);
int       sms_status_trigger2(sms_node *np,int type);
int       sms_status_trigger(sms_trigger *tp);
int       sms_status_process(sms_node *np);
int       sms_triggers(sms_node *np);

/* system.c */
void sms_system_process_list(void);
void sms_process_child(void);
void sms_system_block(void);
void sms_system_start_kid(void);
int  sms_system_kid(char *cmd);
int  sms_system(sms_node *np, char *cmd);
int  sms_system_execute(char *cmd);
int  sms_system_submit(sms_node *np, char *name);
int  sms_system_kill(sms_node *np);

/* time.c */
time_t     sms_time_t(time_t *t);
time_t     sms_time_current(time_t *t);
struct tm *sms_time_tm(time_t *t);
char      *sms_time_c(time_t *t);
time_t     sms_time_gmt(struct tm *tm);
char      *sms_time_gmt2s(time_t t);
int        sms_time_s2gmt(char *s);
void       sms_time_load(sms_node *np);
int        sms_time_suite(sms_node *np, int init, nid_func func, void *userdata);
void       sms_time_clock_vars(int gain);
int        sms_time_free(sms_time *tp);
int        sms_time_date_free(sms_date *dp);
sms_date  *sms_time_date_holding(sms_date *dp);
int        sms_time_complete(sms_node *np);
int        sms_time_autocm(sms_node *np, int type);
void       sms_time_autocm_string(sms_node *np, char *str);
void       sms_time_autocm_init(sms_node *np);
int        sms_time_mark(sms_node *np);
void       sms_time_waiting(sms_node *np);
void       sms_time_requeue(sms_node *np);
void       sms_time_used(sms_node *np);
int        sms_time_dependent(sms_node *np);
sms_list  *sms_time_why(sms_node *np);
int        sms_time_calc(sms_time *tp);
int        sms_time_date_calc(sms_date *dp);
void       sms_time_out(void);
void       sms_time_expire(sms_node *np);

/* variable.c */
sms_variable *sms_variable_getvar(char *name, sms_node *np);
char         *sms_variable_get(char *name, sms_node *np);
sms_variable *sms_variable_create(char *name, char *value);
void          sms_variable_update(sms_node *np, char *name, char *value, nid_func func, void *userdata);
int           sms_variable_generate(sms_node *np, int edit, int alias, nid_func func, void *userdata);
int           sms_variable_makesms(char *name, char *def);
int           sms_variable_tries(sms_node *np);
int           sms_variable_edit(sms_variable *vp, char *name);

/* why.c */
int cdp_why(int argc, char **argv);

/* xdr.c */
int sms_xdr_string(register XDR *x, char **str);
int sms_xdr_pointer(register XDR *x, sms_list **gpp);
int sms_xdr_nid(register XDR *x, sms_nid *nidp);

/* xdr_sms.c */
void sms_xdr_signal(int sec);
void sms_xdr_arm(void);
void sms_xdr_release(void);
int  sms_xdr_list(XDR *x, sms_list *sp);
int  sms_xdr_user(XDR *x, sms_user *sp);
int  sms_xdr_connect(XDR *x, sms_connect *sp);
int  sms_xdr_passwd(XDR *x, sms_passwd *sp);
int  sms_xdr_variable(XDR *x, sms_variable *sp);
int  sms_xdr_time(XDR *x, sms_time *sp);
int  sms_xdr_date(XDR *x, sms_date *sp);
int  sms_xdr_repeat(XDR *x, sms_repeat *sp);
int  sms_xdr_tree(XDR *x, sms_tree *sp);
int  sms_xdr_trigger(XDR *x, sms_trigger *sp);
int  sms_xdr_event(XDR *x, sms_event *sp);
int  sms_xdr_meter(XDR *x, sms_meter *sp);
int  sms_xdr_label(XDR *x, sms_label *sp);
int  sms_xdr_action(XDR *x, sms_action *sp);
int  sms_xdr_file(XDR *x, sms_file *sp);
int  sms_xdr_dir(XDR *x, sms_dir *sp);
int  sms_xdr_node(XDR *x, sms_node *sp);

int  sms_xdr_handle(XDR *x, sms_handle *sp);
int  sms_xdr_login(XDR *x, sms_login *sp);
int  sms_xdr_status(XDR *x, sms_status *sp);
int  sms_xdr_reply(XDR *x, sms_reply *sp);
int  sms_xdr_check(XDR *x, sms_check *sp);
int  sms_xdr_limit(XDR *x, sms_limit *sp);
int  sms_xdr_inlimit(XDR *x, sms_inlimit *sp);
 
/* xdrtimer.c */
void sms_xdrtimer_setup(double value);
void sms_xdrtimer_start(void);
void sms_xdrtimer_stop(char *command);

/* yp.c */
/* struct passwd *sms_getpwuid(int uid); */
void  sms_endpwent(void);
void  sms_yp_dump(char *name);

/*   G E N E R A T E D   C O D E   */

/* sms_clnt.c */
#ifdef SERVER_SIDE
  sms_handle *sms_login_1(sms_login *who);
  int        *sms_logout_1(void);
  int        *sms_news_1(int *handle);
  sms_list   *sms_history_1(int *last);
  sms_status *sms_status_1(int *all);
  int        *sms_play_1(sms_node *play);
  sms_reply  *sms_cmd_1(sms_reply *cmd);
  int        *sms_cmd_old_1(char **s);
#else
  sms_handle *sms_login_1(sms_login *argp, CLIENT *clnt);
  int        *sms_logout_1(void *argp, CLIENT *clnt);
  int        *sms_news_1(int *argp, CLIENT *clnt);
  sms_list   *sms_history_1(int *argp, CLIENT *clnt);
  sms_status *sms_status_1(int *argp, CLIENT *clnt);
  int        *sms_play_1(sms_node *argp, CLIENT *clnt);
  sms_reply  *sms_cmd_1(sms_reply *argp, CLIENT *clnt);
  int        *sms_cmd_old_1(char **argp, CLIENT *clnt);
#endif /* SERVER_SIDE */

#endif

