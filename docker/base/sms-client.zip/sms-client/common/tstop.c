/**************************************************************************
.TITLE    TSTOP
.NAME     CDP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.14
.FILE     tstop.c
*
*  Code to be inserted into xdr_sms.c for debugging the time
*  it takes to talk to different users.
*
*  Add also the tstart.c which initializes the variables needed
*
************************************o*************************************/

#ifdef SMS_TIMER

  if( ioi_._log[IOI_DBG] && sms_._is_server )
  {
    time_t  sec;
    long    usec;
    if( gettimeofday(&stop, 0) != 0 )
    {
      stop.tv_sec  = 0;
      stop.tv_usec = 0;
    }
    sec  = stop.tv_sec  - start.tv_sec;
    usec = stop.tv_usec - start.tv_usec;

    if( usec < 0 )
    {
      usec += 1000000;
      sec  -= 1;
    }

    spit(0,IOI_DBG,"Timer:%4d.%06d, command %s, user %s from %d",
         sec,usec, STR(XDR_COMMAND), ,STR(SMS_USER)
  }
#endif
