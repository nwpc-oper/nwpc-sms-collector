/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     EDIT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-APR-1992 / 29-AUG-1991 / OP
.FILE     edit.c
.VERSION  4.0
.DATE     09-MAR-1993 / 25-FEB-1993 / OP
.VERSION  4.1
.DATE     16-SEP-1993 / 25-FEB-1993 / OP
.VERSION  4.2.1
.MOD      Total rewrite of the module to allow preprocessing
.DATE     09-DEC-1994 / 16-FEB-1994 / OP
.VERSION  4.3.1-4
.MOD      SMSFILES search introduced
.LANGUAGE ANSI-C
.DATE     09-JUN-1995 / 17-MAY-1995 / OP
.VERSION  4.3.8
.MOD      Bug fix for sms-edit command. Add variables in the node
|         into the list send to the user
|         np->passwd freeing (in case of status force)
.DATE     16-OCT-1997 / 11-SEP-1997 / OP
.VERSION  4.3.16
|         Bug fix for manual (meter, label)
|         Bug fix for send (file write error)
.DATE     23-APR-1998 / 23-APR-1998 / OP
.VERSION  4.3.18
|         Repeat has a name now
.DATE     07-AUG-1998 / 23-JUL-1998 / OP
.VERSION  4.3.21
|         Running job limit
*         Cleaning up + prototypes
.DATE     03-FEB-1999 / 23-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Fetch-command for sms-files
*         Aliased tasks
.DATE     23-MAR-1999 / 19-MAR--1999 / OP
.VERSION  4.4.2
*         New preprocessor symbols
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
.DATE     13-JUN-2001 / 13-JUN-2001 / OP
.VERSION  4.4.5 ABT(c)
*         Unknown variables with syntax: VARIABLENAME:defaultvalue
*         as per RFM20010613
*
*  Read the job-file and edit the SMS-variables.
*
*  In normal running the file is first read and the variables extracted 
*  then the names are sought and in second phase .
*  Variable find direction: task -> family (->family) -> suite -> SMS.
*
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

#include <sys/stat.h>

static sms_variable *password;     /* If the SMSPASS was added */

/**************************************************************************
*
*                      N E W   C O D E   S T A R T S
*
************************************o*************************************/

#define C_NORMAL      0
#define C_INCLUDE     1
#define C_MANUAL      2
#define C_COMMENT     3
#define C_END         4
#define C_MICRO       5
#define C_NOPP        6
#define C_EXPORT      7
#define C_INCLUDENOPP 8

#define CMD_SCAN    1
#define CMD_LINK    2
#define CMD_REPLACE 3
#define CMD_MANUAL  4

static FILE         *jobfile;      /* File pointer to the output  */
static sms_variable *variables;    /* Variables found from the input */
static sms_list     *lines;

static char *option_name[] = {
  "-s", "-i", "-m", "-c",
};

/* 445 ABT(c) */
static int default_variable(sms_node *np, sms_variable *var)
/**************************************************************************
?  Check if variable has the syntax of a default variable
=  BOOLEAN status
************************************o*************************************/
{
  char *temp;
  char *n = var->name;

  while( *n && *n != ':' )
    n++;

  if( *n == ':' )
  {
    IFFREE(var->value);

    *n = 0;
    temp = sms_variable_get(var->name,np);
    *n = ':';

    if(temp)
      var->value = strdup(temp);
    else
      var->value = strdup(n+1);

    return 1;
  }


  return 0;
}

static int find_variables(
    sms_node      *np,             /* Search from this node upwards    */
    sms_variable  *var)            /* Variables found by the edit-file */
/**************************************************************************
?  In input to the routine the variables have empty value-field.
|  This rotuine fills in the values (by making copies of the values find.)
|  In operational run all the variables must be found!
|  While in scan-command the results are send to the CDP for filling.
=  BOOLEAN status of was all the variables found? (TRUE == all was found)
************************************o*************************************/
{
  char          *temp;
  sms_node      *ref = np;
  sms_variable **genvar;
  char          *family;
  int            len;              /* To build the $FAMILY */
  int            rc = TRUE;        /* SO far so good!      */

  while( var )
  {
    /* 445 ABT(c) */
    default_variable(np,var);

    temp = sms_variable_get(var->name,np);

    if( temp )
    {
      IFFREE(var->value);
      var->value = strdup(temp);
    }

    if( ! var->value )
    {
      spit(0,IOI_WAR,"variable:%s for %s not found?",STR(var->name),
           STR(sms_node_full_name(np)));
      var->value = strdup("unknown-value");
      rc = FALSE;
    }

    var = var->next;
  }

  return rc;
}

static int check(sms_node *np, char *s, char *micro, char *name, int pp)
/**************************************************************************
?  Check if the line is a prerocessor command
|  Include can have following format:
|    %include file.name        -> file.name
|    %include "file.name"      -> %SMSHOME%/%SUITE%/%FAMILY%/file.name
|    %include <file.name>      -> %SMSINCLUDE%/file.name
=  C_XXXX The type of line.
|  NIL in case of errors
************************************o*************************************/
{
#ifdef TEST
#undef TEST
#endif
#define TEST(text) if(strncmp(s,text,sizeof(text)-1)==0)

  *name = '\0';

#if 1 /* Until XCdp is fixed */
  TEST("%comment") return C_COMMENT;
  TEST("%end")     return C_END;
#endif

  if(*s != *micro)
    return C_NORMAL;

  s++;

  if(!pp)
  {
    TEST("end") return C_END;
    return C_NORMAL;
  }
  
  if( *s == *micro )               /* A line can start with double micro */
  {
    strcpy(s-1,s);
    return C_NORMAL;
  }

  TEST("end")     return C_END;
  TEST("manual")  return C_MANUAL;
  TEST("comment") return C_COMMENT;

  TEST("nopp")      return C_NOPP;
  TEST("export")    return C_EXPORT;

  TEST("smsmicro")
  {
    s += sizeof("smsmicro");
    while( *s && isspace(*s) ) s++;
    if( *s )
    {
      *micro = *s;
      return C_MICRO;
    }
    else
      return spit(NIL,IOI_ERR,"smspreproces: smsmicro missing");
  }

  TEST("include")                  /* Get a file name out */
  {
    int   rc = C_INCLUDE;
    char *newname;
    char stop = '\n';

    TEST("includenopp")
    {
      rc = C_INCLUDENOPP;
      s += sizeof("includenopp");
    }
    else
      s += sizeof("include");

    while( *s && isspace(*s) )     /* Skip spaces */
      s++;

    if( *s=='<' )      { stop='>'; s++; }
    else if( *s=='"' ) { stop='"'; s++; }
    newname = s;

    while( *s && (isalnum(*s) || ispunct(*s)) && *s != stop ) s++;

    if( *s==stop || (*s==' ' && stop=='\n') )
    {
      char *path;

      *s='\0';

      if( stop == '>' )
      {
        if( ! (path=sms_variable_get("SMSINCLUDE",np)) )
          return spit(NIL,IOI_ERR,"SMS-EDIT-INCLUDE:No include path");

        sprintf(name,"%s/%s",STR(path),STR(newname));
      }
      else if( stop == '"' )
      {
        char *fam;

        if( ! (path=sms_variable_get("SMSHOME",np)) )
          return spit(NIL,IOI_ERR,"SMS-EDIT-INCLUDE:No SMSHOME");

        fam =  sms_variable_get("FAMILY",np);
        if(!fam) fam="";

        sprintf(name,"%s/%s/%s/%s",STR(path),
                STR(sms_variable_get("SUITE",np)), STR(fam), STR(newname));
      }
      else
        strcpy(name,newname);

      return rc;
    }
    else
      return spit(NIL,IOI_ERR,"include:bad name");
  }

  return NIL;

#undef TEST
}

static int process_line(
    char *in,                      /* Input buffer            */
    char *out,                     /* Output buffer           */
    char  micro,                   /* SMS variable introducer */
    int   edit)                    /* TRUE==edit the line     */
/**************************************************************************
?  Get/put the SMS-variables in the line;
|  double %-sign is converted to a singe %-sign.
=  Boolean status
************************************o*************************************/
{
  char          v[MAXLEN];         /* Current variable in the file     */
  char         *vp;                /* and the pointers to them         */
  int           len;               /* Needed in line scanning */
  int           i;                 /* Looping in the line     */
  int           inside;            /* Inside %...% ?          */
  sms_variable *temp;

  len = strlen(in);

  if(len && in[len-1]=='\n')       /* Remove newline and decrement */
    in[--len]='\0';                /* string length */

  inside=FALSE;
  vp = 0;

  for( ; *in ; in++)
    if(*in == micro)
    {
      if(inside)                   /* End of a variable in input */
      {
        *vp++  = '\0';
        inside = FALSE;

        if( edit )
          if( temp = ls_find( &variables,v ) )
          {
            strcpy(out,temp->value);
            out += strlen(temp->value);
          }
          else
          {
            spit(0,IOI_ERR,"edit:Variable %s missing?",STR(v));
            return FALSE;
          }
        else
          if( !sms_list_find( &variables,v ) )
            if( temp=sms_alloc(NODE_VARIABLE) )
            {
              temp->type  = NODE_VARIABLE;
              temp->name  = strdup(v);
              temp->value = NULL;

              sms_list_add( &variables,temp );
            }
            else
            {
              spit(0,IOI_ERR,"edit:No mem");
              return FALSE;
            }
      }
      else
      {
        vp = v;

        if(in[1] == micro)
          *out++ = *++in;
        else
          inside = TRUE;
      }
    }
    else
      if(inside)
        *vp++ = *in;
      else
        *out++ = *in;

  if( inside )
  {
    spit(0,IOI_ERR,"edit:SMS-variable not terminated");
    return FALSE;
  }

  if( edit )
  {
    *out++ = '\n';
    *out++ = '\0';
  }

  return TRUE;
}

int sms_edit_string(sms_node *np, char *cmd, char *line)
/**************************************************************************
?  Substitute variables in cmd and place the result in line
=  BOOLEAN status if the edit was successfull (==1) or not (==0)
************************************o*************************************/
{
  char *s;
  char *c;

  char      micro = SMSMICRO(np);

  if( !cmd )
    return spit(FALSE,IOI_ERR,"edit-string:empty cmd?");

  for( s=line , c=cmd ; *c ; c++ ) /* Build the command */
    if( *c == micro )
      if( *++c == micro )          /* Substitute by a single micro */
        *s++ = *c;
      else                         /* Find the name and replace */
      {
        char *v;
        char *var_name = c;        /* Mark the variable name */

        for( ; *c && *c != micro ; c++ ) ;

        if( *c != micro )
          return spit(FALSE,IOI_ERR,"edit-string:bad CMD %s",STR(cmd));

        *c = '\0';                 /* Temp only! */
        var_name=strdup(var_name);
        *c = micro;                /* Put it back */

        if( ! (v=sms_variable_get(var_name,np)) )
          spit(FALSE,IOI_ERR,"edit-string:variable %s in cmd [%s] missing",
               STR(var_name),STR(cmd));

        free(var_name);
        if( !v ) return FALSE;

        strcpy(s,v);
        s += strlen(v);
      }
    else
      *s++ = *c;

  *s = '\0';

  return TRUE;
}

int sms_edit_variable(sms_node *np, char *varname, char *line)
/**************************************************************************
?  Substitute "varname" from variables found in "np" and place
|  the output into "line".
=  Boolean status, was the substitution ok.
************************************o*************************************/
{
  char *v;

  if( ! (v=sms_variable_get(varname,np)) )
    return spit(0,IOI_ERR,"edit-variable:%s not found for %s?",STR(varname),
                STR(sms_node_full_name(np)));

  return sms_edit_string(np, v, line);
}

static int is_pipe(sms_node *np, char *name, int cmd)
{
  char tmp[MAXLEN];
  char *fetch = sms_variable_get("SMSFETCH",np);

  if( !fetch )
    return 0;

  if( sms_edit_string(np,fetch,tmp) )
  {
    int len = strlen(tmp);

    sprintf(tmp+len," %s %s",STR(option_name[cmd]),STR(name));
    strcpy(name,tmp);

    return 1;
  }

  return 0; /* Failed */
}

static int out_var(FILE *fp, char *fmt, sms_variable *vp, sms_list **names)
{
  if(ls_find(names,vp->name)) return 1;

  ls_add(names,ls_create(0,vp->name));

  return fprintf(fp,"export %s='%s'\n",STR(vp->name),STR(vp->value));
}

static int export_vars(FILE *fp, char *in, sms_node *np)
/**************************************************************************
?  Export variables
************************************o*************************************/
{
  sms_variable    *vp;
  static sms_list *names = 0;
  char *fmt = 0;

  static sms_list *tokens;
  sms_list *lp;

  NODE_FREE(tokens,sms_list);
  tokens = (sms_list *)ioi_token_parse(in,TRUE);

  if(ls_len(&tokens) < 3)
    return spit(-1,IOI_ERR,"export:too few tokens");

  lp = tokens;
  lp = lp->next;
  fmt = lp->name;
  lp = lp->next;

  NODE_FREE(names,sms_list);

  for( vp=variables; vp ; vp=vp->next )
    if(out_var(fp,fmt,vp,&names) < 0) return -1;

  while(np)
  {
    for( vp=np->variable; vp ; vp=vp->next )
      if(out_var(fp,fmt,vp,&names) < 0) return -1;

    for( vp=np->genvars; vp ; vp=vp->next )
      if(out_var(fp,fmt,vp,&names) < 0) return -1;

    np = np->parent;
  }

  NODE_FREE(names,sms_list);

  return 0;
}

static int edit_file(
    char     *name,                /* Name of the file to be edited */
    int       usepipe,             /* Is the name pipe or a file    */
    sms_node *np,                  /* 2 print reference into error  */
    int       command,             /* What to do with the file      */
    int       pre,                 /* Is the preprocessor activated */
    char     *micro)               /* Current preprocessor char     */
/**************************************************************************
?  Scan the file and apply "command"
|
|  Preprocessing can only be turned off if command is LINK
|
|  Command can be
|    CMD_SCAN     scan variables in the file
|    CMD_REPLACE  repace the variables in the file
|    CMD_LINK     generate linked list of lines
|    CMD_MANUAL   generate linked list of manual
|
|  Errors
|    variable not found
|    no mem
|    no closing %end
|    include file not found
=  Boolean status
@  jobfile, variables, lines
|  It's easier to have the globals for the module than pass them around
************************************o*************************************/
{
  FILE *fp;
  char  in[MAXLEN];                /* Buffer to hold the original line */
  char  out[MAXLEN];               /* Buffer to hold the edited line   */
  char  newname[MAXLEN];           /* Name of a file to be included    */
  int   line_no = 0;               /* Line number in file "name"       */
  int   skipping=C_NORMAL;         /* Skipping lines in the input      */

  int   interpret = TRUE;          /* Are we interpreting the input?   */

  char  nopp[MAXLEN];
  char  end[MAXLEN];

#if 0
  if( command != CMD_LINK && !pre ) return 
    spit(0,IOI_ERR,"edit:internal error with pre-command");
#endif

  if(usepipe)
  {
    spit(0,IOI_DBG,"popen for:%s",STR(name));
    fp=popen(name,"r");
  }
  else        fp=sms_fopen(name,"r","editfile");

  if(!fp)
  {
    FLAG_SET(np,FLAG_NO_SCRIPT);
    return FALSE;
  }

  FLAG_CLEAR(np,FLAG_NO_SCRIPT);

  while( fgets(in,MAXLEN,fp) )
  {
    int  ispipe = 0;

    line_no++;

    switch( pre? check(np,in,micro,newname,interpret) : C_NORMAL )
    {
      case C_INCLUDE:
        ispipe = is_pipe(np,newname,C_INCLUDE);

        if( skipping==C_MANUAL && command != CMD_LINK )
          if( !edit_file(newname,ispipe,np,CMD_LINK,pre,micro) )
            goto error;

        if( skipping==C_NORMAL )
          if( !edit_file(newname,ispipe,np,command,pre,micro) )
            goto error;
        break;

      case C_INCLUDENOPP:
        sprintf(nopp,"%cnopp",*micro);
        sprintf(end,"%cend",*micro);

        ispipe = is_pipe(np,newname,C_INCLUDE);

        if(command==CMD_LINK && skipping==C_NORMAL)
          sms_list_add(&lines,sms_node_create(nopp));

        if( skipping==C_MANUAL && command != CMD_LINK )
          if( !edit_file(newname,ispipe,np,CMD_LINK,FALSE,micro) )
            goto error;

        if( skipping==C_NORMAL )
          if( !edit_file(newname,ispipe,np,command,FALSE,micro) )
            goto error;

        if(command==CMD_LINK && skipping==C_NORMAL)
          sms_list_add(&lines,sms_node_create(end));

        break;

      case C_MANUAL:
        skipping=C_MANUAL;
        break;

      case C_COMMENT:
        skipping=C_COMMENT;
        break;

      case C_END:
        if(!interpret)
        { 
          interpret=TRUE;
          if(command==CMD_LINK && skipping==C_NORMAL)
            sms_list_add(&lines,sms_node_create(sms_no_newline(in)));
        }
        else
          skipping=C_NORMAL;
        break;

      case C_NOPP:
        interpret=FALSE;
        if(command==CMD_LINK && skipping==C_NORMAL)
           sms_list_add(&lines,sms_node_create(sms_no_newline(in)));
        break;

      case C_MICRO:
        if(command==CMD_LINK && skipping==C_NORMAL)
          sms_list_add(&lines,sms_node_create(in));
        break;

      case C_EXPORT:
        if(command==CMD_LINK && skipping==C_NORMAL)
          sms_list_add(&lines,sms_node_create(in));

        if(command==CMD_REPLACE)
          if( export_vars(jobfile,in,np) < 0 )
            goto error;
        break;

      case NIL:
        goto error;

      default: 

        switch( command )
        {
          case CMD_MANUAL:
            if(skipping==C_MANUAL)
              sms_list_add(&lines,sms_node_create(sms_no_newline(in)));
            break;

          case CMD_LINK:
            if(skipping==C_NORMAL)
              sms_list_add(&lines,sms_node_create(sms_no_newline(in)));
            break;

          case CMD_REPLACE:
            if(skipping==C_NORMAL)
            {
              int rc;

              if(interpret && pre)
              {
                if( !process_line(in,out,*micro,TRUE) )
                  goto error;
              }
              else
                strcpy(out,in);

              rc=fprintf(jobfile,"%s",STR(out));

              if(rc < strlen(out) || rc == (-1))
              {
                FLAG_SET(np,FLAG_EDIT_FAILED);
                spit(0,IOI_ERR,"edit:file write error %s",STR(name));
                sms_perror("edit");
                goto error;
              }
            }
            break;

          case CMD_SCAN:
            if(skipping==C_NORMAL && interpret && pre)
              if( !process_line(in,out,*micro,FALSE) )
                goto error;
            break;
        }
      }
  }

  if(usepipe) pclose(fp);
  else        FCLOSE(fp);

  if( skipping != C_NORMAL )
    spit(0,IOI_WAR,"edit:Line %d in %s no %cend",line_no,STR(name),micro?*micro:'%');
  skipping = FALSE;

  return TRUE;

  error:
  
  if(usepipe) pclose(fp);
  else        FCLOSE(fp);

  spit(0,IOI_ERR,"edit:Line number %d in file %s",line_no,STR(name));
  return FALSE;
}

int sms_edit_mkdir_reverse(char *path, sms_node *np)
/**************************************************************************
?  Make all directories needed for this task.
|  Check first if the directory already exists (bail out in that case)
=  BOOLEAN status if the direcotry exists or not
************************************o*************************************/
{
  char        fullpath[MAXLEN];
  struct stat st;

  if( np->type == NODE_HANDLE )    /* Shouldn't be here, but safety... */
    return 1;

  if(np->type==NODE_FAMILY || np->type==NODE_SUITE)
  {
    sprintf(fullpath,"%s%s",STR(path),STR(sms_node_full_name(np)));

    if( stat(fullpath,&st) == 0 )
      if( st.st_mode & S_IFDIR )
        return TRUE;
  }

  if(np->parent)
    if(! sms_edit_mkdir_reverse(path,np->parent))
      return FALSE;

  if(np->type==NODE_TASK || np->type==NODE_SUPER)
    return TRUE;

  if(np->type==NODE_ALIAS)         /* Check the task itself */
  {
    sprintf(fullpath,"%s%s",STR(path),STR(sms_node_full_name(np->parent)));

    if( stat(fullpath,&st) == 0 )
      if( st.st_mode & S_IFDIR )
        return TRUE;
  }

  if( mkdir(fullpath,SMSMKDIRPROT) != 0 )
  {
    sms_perror("mkdir-reverse");
    sms_perror(fullpath);
    return FALSE;
  }

  return TRUE;
}

char *sms_edit_script_name(sms_node *np, int *ispipe)
/**************************************************************************
?  Get the name of the smsfile.
|
|  Use variable SMSSCRIPT as the starting point and if that file exists
|  use it.
|
|  Otherwise if variable SMSFETCH exists, it forms a command to be
|  executed and the output of the command to be used as the input.
|
|  ???
|  Variable SMSFETCHINCLUDE may be used to fetch the include files
|  found in the output of the fetch command.
|  ???
|
|  Otherwise if variable SMSFILES exists, it points to a directory
|  which is searched in reverse order, an example will clarify this:
|
|  np = /o/12/fc/model
|  SMSFILES = /home/ecmwf/emos_sms/def/o
|
|  1) %SMSFILES%/%SMSNAME%
|  == /home/ecmwf/emos_sms/def/o  /o/12/fc/model.sms
|  2) /home/ecmwf/emos_sms/def/o  /12/fc/model.sms
|  3) /home/ecmwf/emos_sms/def/o  /fc/model.sms
|  4) /home/ecmwf/emos_sms/def/o  /model.sms
|
|  The first one is of cource a bit of overkill, but one might put all
|  the files on a separate files system etc.
|
|  If the original SMSSCRIPT didn't exist, SMS will create the directories
|  for the job file in SMSHOME (SMSSCRIPT is derived from SMSHOME.)
=  name in static buffer or variable name
************************************o*************************************/
{
  struct stat  st;
  int          depth=0;
  int          i;
  sms_node    *tmp;
  static char  fullpath[MAXLEN];
  char        *base;
  char        *names[100];
  sms_node    *orig = np;
  char        *script;
  char        *extension = (np->type==NODE_TASK || np->type==NODE_ALIAS)? ".sms" : ".man";

  *ispipe = 0;
  script = sms_variable_get("SMSSCRIPT",np);

  /* Just check that file exists, if it's a dir -> bad luck */

  if( stat(script, &st) == 0)
    return script;

  /* Make sure the dir for .job file exists */


  base = sms_variable_get("SMSHOME",np);
  if( !base ) base=".";

  if( ! sms_edit_mkdir_reverse(base,np) )          /* 4 the JOB file */ 
    return NULL;

  /* Check if we should use fetch */

  if(script)
    strcpy(fullpath, script);
    if( is_pipe(np,fullpath,C_NORMAL ) )
    {
      *ispipe = 1;
      return fullpath;
    }

  /* OK we need to find the file now using variable SMSFILES */

  /* 
   * Special case if someone is stupid enough to put the man 
   * amongst the generated files
   */
  if( np->type != NODE_TASK && np->type != NODE_ALIAS )
  {
    sprintf(fullpath,"%s%s/%s.man", STR(base) ,
            STR(sms_node_full_name(np)) , STR(np->name) );

    if( stat(fullpath, &st) == 0)
      return fullpath;
  }

  base = sms_variable_get("SMSFILES",np);
  if( !base )
  {
    spit(0,IOI_ERR,"SCRIPT-NAME, variable SMSFILES not set, node %s",
          STR(sms_node_full_name(np)));
    return NULL;
  }

  while( np )
  {
    names[depth++] = np->name;

    np = np->parent;
    if(np && np->type==NODE_SUPER) np=NULL;
  }
  np = orig;

  while( depth )
  {
    strcpy(fullpath,base);

    for(i=0; i<depth ; i++)
    {
      strcat(fullpath,"/");
      strcat(fullpath,names[depth-i-1]);
    }

    if(np->type == NODE_SUITE || np->type == NODE_FAMILY)
    {
      strcat(fullpath,"/");
      strcat(fullpath,np->name);
    }
    strcat(fullpath, extension);

    if( stat(fullpath, &st) == 0) return fullpath;

    depth--;
  }

  if(np->type == NODE_SUITE || np->type == NODE_FAMILY)
  {
    sprintf(fullpath,"%s/%s%s",STR(base),STR(np->name),STR(extension));
    if( stat(fullpath, &st) == 0) return fullpath;
  }

  spit(0,IOI_WAR,"SCRIPT-NAME will return NULL, script is [%s]",STR(script));

  return 0;
}

int sms_edit_send(sms_node *np)
/**************************************************************************
?  Send the job. (When the SMS itself is sending jobs)
=  BOOLEAN status.
************************************o*************************************/
{
  char *jobname;
  char *script;
  int   ispipe = 0;
  char  micro = SMSMICRO(np);

  sms_variable *pw;

  if( !np ) return FALSE;
  
  NODE_FREE(lines,sms_list);
  NODE_FREE(variables,sms_variable);

  IFFREE(np->passwd);

  /* if(np->type != NODE_ALIAS) */
    sms_variable_generate(np,FALSE,FALSE,NULL,NULL);

  script  = SMSSCRIPT(np,&ispipe);
  jobname = SMSJOB(np);

  if( ! edit_file(script,ispipe,np,CMD_SCAN,TRUE,&micro) ) goto error;

  if( !(pw=ls_find(&np->variable,"SMSPASS")) )
    password = sms_passwd_generate(np);
  else
    np->passwd = strdup(sms_passwd_crypt(pw->value));

  if( ! find_variables(np,variables) ) goto error;

  unlink(jobname);

  micro = SMSMICRO(np);            /* Start again with the default */

  if( ! (jobfile=sms_fopen(jobname,"w","editfile")) ) goto error;
  if( ! edit_file(script,ispipe,np,CMD_REPLACE,TRUE,&micro) ) goto error;
  FCLOSE(jobfile);
  if( ! sms_system_submit(np,jobname) ) goto error;

  if( password ) sms_list_delete(&np->variable,password);
  password = NULL;

  sms_status_change(np,STATUS_SUBMITTED,FALSE,FALSE);
  sms_limit_running(np);

#ifdef SMS_STATISTICS
  if( np->tryno == 1 ) smss_._tasks_send++;
  else                 smss_._tasks_resend++;
#endif

  /* Send the prepared aliases */

  if(np->type == NODE_TASK && np->tryno == 1)
  {
    sms_node *ap;

    for( ap=np->kids ; ap ; ap=ap->next )
      if(ap->status == STATUS_QUEUED)
        sms_edit_send(ap);
  }

  return TRUE;

  error:

  FLAG_SET(np,FLAG_EDIT_FAILED);
  FCLOSE(jobfile);
  IFFREE(np->passwd);
  if( password ) sms_list_delete(&np->variable,password);
  password = NULL;
  sms_status_change(np,STATUS_ABORTED,FALSE,FALSE);
  return FALSE;
}

int sms_edit_scan(
    sms_node      *np,            /* Node to scan                      */
    sms_variable **var,           /* Scan the file for variables       */
    int            edit,          /* Flag to request for the file also */
    int            pre)           /* Inlucde the include-files if TRUE */
/**************************************************************************
?  Scan the file for the node and get the variables.
=  BOOLEAN status and the predefined variables in the var-list.
|  TRUE == Okay!
************************************o*************************************/
{
  sms_variable *pw;
  char *script;
  int   ispipe = 0;
  char  micro = SMSMICRO(np);

  NODE_FREE(lines,sms_list);
  NODE_FREE(variables,sms_variable);
  NODE_FREE( *var,sms_variable );

  sms_variable_generate(np,FALSE,TRUE,NULL,NULL);
  script  = SMSSCRIPT(np,&ispipe);

  if( ! edit_file(script,ispipe,np,CMD_SCAN,TRUE,&micro) ) return FALSE;

  if( ! find_variables(np,variables) ) return FALSE;

/* 4.3.8 Bug fix: add variables defined in the task itself */
  {
    sms_variable *vp = np->variable;
    sms_variable *temp;

    for( ; vp ; vp=vp->next )
      if( !ls_find( &variables,vp->name) )
        ls_add(&variables, sms_play_variable(vp->name, vp->value));
  }
/* 4.3.8 */

  *var = variables;                /* Give them to the parent */
  variables = NULL;

  micro = SMSMICRO(np);            /* Start again with the default */

  if( edit ) 
  {
    lines = (sms_list *)*var;      /* Add the file into variables */

    if( ! edit_file(script,ispipe,np,CMD_LINK,pre,&micro) ) 
    {
      lines=NULL;
      NODE_FREE( *var,sms_variable );
      return FALSE;
    }
    lines=NULL;
  }

  return TRUE;
}

int sms_edit_cmd(sms_node *np, sms_variable *var, int edit, int alias, int run)
/**************************************************************************
?  Send the job. (When the CDP is editing the variables)
=  BOOLEAN status.
************************************o*************************************/
{
  sms_variable *pw;
  char         *jobname;
  char         *script;
  int           rc = TRUE;
  int           ispipe = 0;
  char          micro = SMSMICRO(np);

  if( !np ) return FALSE;

  NODE_FREE(lines,sms_list);
  NODE_FREE(variables,sms_variable);

  sms_variable_generate(np,edit,alias,NULL,NULL);
  script  = SMSSCRIPT(np,&ispipe);
  jobname = SMSJOB(np);

  unlink(jobname);

  if(alias)
  {
    sms_node *ap = sms_alias_create(np, var);

    if(ap && run)
    {
      ap->tryno++;
      return sms_edit_send(ap);
    }

    return ap? 1:0;
  }

/* ??? */
  if( pw = ls_find(&var,"SMSPASS") )
    if( !alias )
      if( pw )
      {
        IFFREE(np->passwd);        /* SMS only keeps the crypted one! */
        np->passwd = strdup(sms_passwd_crypt(pw->value));
      }
      else
      {
        sms_error(SMS_E_NOPASSWD,"send-cmd:%s",STR(sms_node_full_name(np)));
        return FALSE;
      }
    else                           /* We don't give the jobs any password */
      if( *(pw->value) )
        *(pw->value) = '\0';
/* !!! */

  if( ! (jobfile=sms_fopen(jobname,"w","editfile")) ) return FALSE;

  variables = var;

  if( ! edit_file(script,ispipe,np,CMD_REPLACE,TRUE,&micro) )
  {
    variables = NULL;
    FCLOSE(jobfile);
    return FALSE;
  }

  FCLOSE(jobfile);

  variables = np->variable;        /* Change the variables for submission */
  np->variable = var;

  if( ! sms_system_submit(np,jobname) )
    rc = FALSE;
  else
    if( !alias )
    {
      sms_status_change(np,STATUS_SUBMITTED,FALSE,FALSE);
      sms_limit_running(np);
    }

  np->variable = variables;        /* and change them back before return */
  variables = NULL;

  return rc;
}

int sms_edit_manual(sms_node *np, sms_list **lp)
/**************************************************************************
?  Generate a linked list of lines in order to form a manual page
=  BOOLEAN status.
************************************o*************************************/
{
  char     *full;
  char     *base;
  char      name[MAXLEN];
  char     *filename = name;
  sms_node *vars;
  int       ispipe;
  char      micro = SMSMICRO(np);

  name[0]='\0';

  NODE_FREE(lines,sms_list);

  full = sms_node_full_name(np);
  vars = np;
  if(np->type == NODE_EVENT || np->type == NODE_LABEL || 
     np->type == NODE_METER || np->type == NODE_REPEAT )
    vars = vars->parent;

  base = sms_variable_get("SMSHOME",vars);

  switch( np->type )
  {
    case NODE_FAMILY:
    case NODE_SUITE:
    case NODE_TASK:
    case NODE_ALIAS:
      filename = SMSSCRIPT(np,&ispipe);
      break;

    case NODE_EVENT:
    case NODE_LABEL:
    case NODE_METER:
    case NODE_REPEAT:
      sprintf(name,"%s%s.man", base?base:"." , STR(full) );
      break;

    case NODE_SUPER:
      sprintf(name,"%s/%s.man", base?base:"." , STR(sms_._host) );
      break;

    default:
      sms_error(SMS_E_TYPE,"manual: %s",STR(full));
      return FALSE;
      /*NOTREACHED*/
      break;
  }

  if(!filename || !*filename) return
    spit(FALSE,IOI_ERR,"manual:%s not found",STR(full));

  if( ! edit_file(filename,ispipe,np,CMD_MANUAL,TRUE,&micro) )
    return FALSE;

  *lp = lines ; lines=NULL;

  return TRUE;
}
