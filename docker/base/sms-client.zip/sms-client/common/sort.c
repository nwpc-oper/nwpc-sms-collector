/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SORT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     08-APR-1992 / 06-MAR-1992 / OP
.VERSION  4.0
.FILE     sort.c
*
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     30-OCT-1998 / 30-OCT-1998 / OP
.VERSION  4.4
*         Cleaning up
************************************o*************************************/

#include "smslib.h"

static int name_compare(sms_list **a, sms_list **b)
/**************************************************************************
?  The default comparation routine for the list sort
=  The relation of the names.
************************************o*************************************/
{
  return strcmp((*a)->name,(*b)->name);
}

int sms_list_sort(
    sms_list **root,               /* The address of the start */
    int      (*routine)() )        /* Comparation routine      */
/**************************************************************************
?  Order the list according to the routine given or if not using the name
|  field and string comparation.
=  Boolean status of success.
|  Only reasons that can cause non success if shortage of memory or
|  illegal (empty) input.
************************************o*************************************/
{
  int        len,i;
  sms_list **array,*tmp;           /* Array must be 1 more that input! */

  if(!root || !*root) return FALSE;

  len = ls_len(root);

  if(!(array=(sms_list **)calloc(len+1,sizeof(sms_list *))))
    return spit(FALSE,IOI_ERR,"SMS-LIST-SORT:No mem.");

  for( i=0,tmp=(*root) ; i<len ; i++,tmp=tmp->next )
    array[i] = tmp;

  if( !routine ) routine = name_compare;

  qsort(array,len,sizeof(sms_list *),routine);

  for( i=0 ; i<len ; i++ )
    array[i]->next = array[i+1];   /* The last on will be NULL from calloc */

  *root = array[0];
  free(array);

  return TRUE;
}

void sms_list_fancy(sms_list **root)
/**************************************************************************
?  Print the list in a fancy way!
************************************o*************************************/
{
  sms_list *tmp;
  int       i,n,width;
  int       len=0;                 /* Max width */
  char     *columns;
  char      fmt[10];

  if( !root || !*root ) return;

  tmp = *root;

  for( tmp = *root ; tmp ; tmp=tmp->next )
    len = MAX(len,strlen(tmp->name));

  columns = ioi_variable_get("COLUMNS");
  width = (columns)? atoi(columns) : 80;

  sprintf(fmt,"%%-%ds",len+1);

  n = (width+1)/(len+1);

  for( i=1, tmp = *root ; tmp ; tmp=tmp->next )
  {
    printf( (i!=n)?fmt:"%s\n",STR(tmp->name) );
    i = (i!=n)? i+1 : 1;
  }

  if(i!=1 && n>1) printf("\n");
}
