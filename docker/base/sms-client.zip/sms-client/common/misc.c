/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     MISC
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     14-DEC-1992 / 09-AUG-1991 / OP
.VERSION  4.0
.FILE     misc.c
.DATE     14-SEP-1994 / 25-FEB-1994 / OP
.VERSION  4.3.0-2
.DATE     14-SEP-1994 / 25-FEB-1994 / OP
.VERSION  4.3.17
*         Y2K fix for the log file (Thanx to John Lorkin)
.DATE     04-JUN-1998 / 04-JUN-1998 / OP
.VERSION  4.3.19
*         added signed number check
.LANGUAGE ANSI-C
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     24-JAN-1999 / 30-OCT-1998 / OP
.VERSION  4.4
*
************************************o*************************************/

#define IOI_MODULE                 /* Yeps! We need reference to ioi_ */

#include "smslib.h"

#ifdef linux
#include <pwd.h>                   /* for getpass */
#include <unistd.h>                   /* for getpass */
#endif

#ifdef _CONVEX_SOURCE
  _des_crypt() { ; }
#  include "crypt.c"
#endif

#if (defined(__mips)&& !defined(__sgi)) || defined(_HPUX_SOURCE) || defined(VMS)
#  include "regex.c"
#endif

#if defined(VMS)
bzero(char *addr, int len) { memset(addr,0,len); }
#endif

#if defined(VMS) || defined(__sgi)
time_t timegm(struct tm *tm) { return 0; }
#endif

extern ioi_out(int,int,char *,...);

char *sms_string(char *str, char *file, int lineno)
/**************************************************************************
?  Return string "str" if it is not null, otherwise compose a message
=  str if not NULL
************************************o*************************************/
{
  static char *null = "(null string)";

  if(str) return str;

  spit(0,IOI_ERR,"(null string): file %s lineno %d",file?file:"NO-FILE",lineno);

  return null;
}

int spit(
    int         code,              /* Requested return code      */
    int         type,              /* Output (IOI) type          */
    char       *fmt,               /* Output format for the args */
    ...)
/**************************************************************************
?  Spit into the logfile. Add a time stamp into the format string and
|  save the lines into the logging buffer.
-CALL  return spit(returncode,msg_type,format[,args...])
=  Return code supplied. This simplyfies the error handling in many cases.
~  ioi_out(IOI).
************************************o*************************************/
{
  char        t_fmt[MAXLEN];       /* Build here the time format */
  time_t      stamp;               /* Build the current time     */
  struct tm  *tod;                 /* for the time format        */
  sms_list   *lp;                  /* Is SMS, add into history   */
  va_list     ap;                  /* To loop the arguments      */

  va_start(ap,fmt);

  if( sms_._is_server )
  {
    stamp = sms_time_t(NULL);      /* Build the time format */
    tod   = localtime(&stamp);

    sprintf(t_fmt,"[%02d:%02d:%02d %d.%d.%d] ",
      tod->tm_hour, tod->tm_min, tod->tm_sec,
      tod->tm_mday, tod->tm_mon+1, tod->tm_year + 1900);
  }
  else
    sprintf(t_fmt,"");

  vsprintf(t_fmt+strlen(t_fmt),fmt,ap);

  ioi_out(code,type,"%s",t_fmt);   /* Output filtered through a mask */

  va_end(ap);

  if( sms_._is_server && *ioi_._logmsg ) /* Remember x-number of last lines */
  {
    if( sms_._hist_len >= sms_._hist_max )
      ls_delete(&sms_._history,sms_._history);
    else
      sms_._hist_len++;

    ls_add(&sms_._history,ls_create(0,ioi_._logmsg));
    sms_._hist_num++;
  }

  if( sms_._is_server && sms_._node && *ioi_._logmsg )
    if( type != IOI_ERR )          /* Add per node messages */
      sms_log_add(sms_._node, ioi_._logmsg);

  if( sms_._answer && *ioi_._logmsg ) /* Copy also to the client output */
  {
    char *stripped;                /* Strip the time */

    if( stripped = strchr(ioi_._logmsg,']') )
      if( *++stripped ) stripped++;

    if( !stripped || ! *stripped ) 
      stripped = ioi_._logmsg;

    lp = sms_node_create(stripped);
    sms_list_add(&sms_._reply,lp);
  }

  return(code);
}

int sms_error(
    int         code,              /* Requested return code */
    char       *fmt,               /* Output format for the args */
    ...)
/**************************************************************************
?  Produce an error into the SMS-LOGFILE.
-CALL  return sms_error(sms_error_code,format[,args...])
=  Return code supplied. This simplyfies the error handling in many cases.
~  ioi_out(IOI).
************************************o*************************************/
{
  char        t_fmt[MAXLEN];       /* Build here the time format */
  va_list     ap;                  /* To loop the arguments      */

  va_start(ap,fmt);

  vsprintf(t_fmt,fmt,ap);          /* Build the line for IOI */
  va_end(ap);

  sprintf(t_fmt+strlen(t_fmt),":%s:",error_name[code]);

  spit(code,IOI_ERR,"%s",t_fmt);   /* YEPS! It's allways an ERROR */

  return code;
}

int sms_perror(char *callname)
/**************************************************************************
?  Produce perror to come via the SMS (== ioi_perror but to call spit)
=  FALSE.
-NOTICE  This uses the external errno, sys_nerr & sys_errlist which might
|  be system dependent.
************************************o*************************************/
{
  /* extern int errno, sys_nerr; */
  /* extern char *sys_errlist[]; */

  register const char *errorname = "Unknown error";

  if(errno < sys_nerr)
    errorname = sys_errlist[errno];

  if (callname && *callname)
    return spit(FALSE,IOI_ERR,"%s: %s",STR(callname),STR(errorname));

  return spit(FALSE,IOI_ERR,"%s",STR(errorname));
}

int sms_output(
    char     *fmt,                 /* Output format for the args */
    ...)
/**************************************************************************
?  Output to the client.
|  Add the text to the current list for the reply.
-CALL  sms_output(format[,args...])
-NOTICE  The end of the line is an implicite newline so don't use "\n" in
|  the end of the format string.
=  void
************************************o*************************************/
{
  va_list     ap;                  /* To loop the arguments      */
  char        buff[MAXLEN];        /* Build the line in to this  */
  sms_list   *lp;                  /* Form an item into the reply */

  va_start(ap,fmt);

  vsprintf(buff,fmt,ap);

  lp = sms_node_create(buff);
  sms_list_add(&sms_._reply,lp);

  va_end(ap);

  return 0;
}

void sms_numbers(int prog, int vers)
/**************************************************************************
?  Change the RPC program and version number "in the fly"
|  Made for the XCDP.
************************************o*************************************/
{
  switch(prog)
  {
    case NIL: sms_._prog = SMS_PROG; break;
    case   0: break;
    default : sms_._prog = prog;
  }

  switch(vers)
  {
    case NIL: sms_._vers = SMS_VERS; break;
    case   0: break;
    default : sms_._vers = vers;
  }

  ioi_variable_set_int("SMS_PROG",sms_._prog);
  ioi_variable_set_int("SMS_VERS",sms_._vers);
}

void *sms_alloc(int type)
/**************************************************************************
?  Alloc and clear a memory of TYPE given (NODE_xxx)
=  The structure pointer with the type-field filled.
************************************o*************************************/
{
  sms_list *lp = calloc(1,sms_sizes[type]);

  if(lp) lp->type = type;

  return lp;
}

FILE *sms_fopen(char *name, char *mode, char *who)
/**************************************************************************
?  Open a the file NAME with MODE.
=  FILE pointer or NULL if not open
|  If failed an error message is formed with the WHO field
************************************o*************************************/
{
  FILE  *fp;
  int (* output)(int,int,char *,...);     /* Depends of the application */

  output = (sms_._is_server)? spit : ioi_out;

  if( ! (fp=fopen(name,mode)) )
  {
    output(0,IOI_ERR,"%s:Couldn't open file %s for %s",STR(who),STR(name),STR(mode));
    sms_perror(who);
  }

  return fp;
}

int sms_is_number(char *s)
/**************************************************************************
?  Check if the string given is a pure number.
=  TRUE if this is a purge number, FALSE otherwise.
************************************o*************************************/
{
  if( !s ) return FALSE;
  if( !*s ) return FALSE;

  while( *s && isdigit(*s) ) s++;

  return !*s ;
}

int sms_is_signed_number(char *s)
/**************************************************************************
?  Check if the string given is a number with sign
=  TRUE if this is a number, FALSE otherwise.
************************************o*************************************/
{
  if( !s ) return FALSE;
  if( !*s ) return FALSE;

  if( *s == '+' || *s == '-' )
    s++;

  while( *s && isdigit(*s) ) s++;

  return !*s ;
}

char *sms_to_char(int x)
/**************************************************************************
?  Convert integer to be send as a string.
|  Use atoi() to get it back.
=  STRING
************************************o*************************************/
{
  static char s[MAXNAM];           /* Should be big enough! */

  sprintf(s,"%d",x);

  return s;
}

int sms_encode(int *first, ...)
/**************************************************************************
?  Encode the options for transmission.
-CALL  int options = sms_encode(&opt1,&opt2,...,NULL)
=  The packed bits (YEAH! only 32 can be transmitted, wot a pity!)
************************************o*************************************/
{
  int           bits = 0;          /* The result of packing */
  va_list       ap;                /* To loop the arguments */
  int          *ip;                /* Current option        */
  int           i = 0;             /* The bit to code       */

  va_start(ap,first);

  if( *first )
    bits = 1;
  i++;

  while( ip = va_arg(ap,int *) )
  {
    if( *ip ) bits |= (1<<i);
    i++;
  }
  va_end(ap);

  return bits;
}

int sms_decode(int bits, ...)
/**************************************************************************
?  Decode the options from transmission.
-CALL  sms_decode(packed_int,&opt1,&opt2,...,NULL)
=  The bits set/clear in locations pointed
************************************o*************************************/
{
  va_list       ap;                /* To loop the arguments */
  int           i    = 0;          /* The bit to code       */
  int          *ip;                /* Current integer pointer */

  va_start(ap,bits);

  while( ip = va_arg(ap,int *) )
  {
    *ip = bits & 0x1;
    i++;
    bits >>= 1;
  }
  va_end(ap);

  return 0;
}

char *sms_no_newline(char *s)
/**************************************************************************
?  Remove the newline character form the end of the string given.
|  Normally used after fgets(3).
=  The original buffer. Call can be used in place of the original in 
|  printf statement.
************************************o*************************************/
{
  int len;

  if( !s ) return NULL;            /* Just to prevent illegal use */

  len = strlen(s);

  if( len && s[len-1] == '\n' )
    s[--len] = '\0';

  return s;
}

#ifdef IMPOSSIBLE
int spit_args(char *name, int argc, char **argv)
/**************************************************************************
?  Generate IOI-ERR type message of the arguments.
=  FALSE;
*NA
************************************o*************************************/
{
  char line[MAXLEN];
  int  len;

  len = strlen(name);
  strcpy(line,name);               /* This really shouldn't be > MAXLEN! */

  while( argc )
    if( len+strlen(*argv)+2 < MAXLEN )
    {
      strcat(line," ");
      strcat(line,name);
      len += strlen(*argv)+1;
      argc--;
      argv++;
    }
    else
      argc=0;

  return ioi_out(FALSE,IOI_ERR,"%s",STR(line));
}
#endif

int sms_getsize(void)
/**************************************************************************
?  Get the maximum size of the descriptor table
|  Use static variable to prevent making a system call
************************************o*************************************/
{
  static int tablesize;

#ifdef hpux
  tablesize = FD_SETSIZE;
#else
  if( !tablesize )
    tablesize = getdtablesize();
#endif

  return tablesize;
}

int sms_nap(int usec)              /* Time to sleep in micro seconds */
/**************************************************************************
?  Sleep for a while.
*  In VMS select only applies to open sockets,
*  A fix might be to open an extra socket?
************************************o*************************************/
{
  struct timeval timeout;
  extern int     errno;

  if (usec < 0) usec = 0;

  if (usec)
  {
    timeout.tv_sec  = usec / 1000000;
    timeout.tv_usec = usec % 1000000;

    if( sms_._is_server )          /* Well we have a socket! */
    {
#ifdef FD_SETSIZE
  fd_set     readfds;
#else
  int        readfds;
#endif

#ifdef FD_SETSIZE
      readfds = svc_fdset;

      if( select(sms_getsize(),&readfds,(fd_set *)0,(fd_set *)0,&timeout) == NIL )
#else
      readfds = svc_fds;

      if( select(sms_getsize(),&readfds,(int *)0,(int *)0,&timeout) == NIL )
#endif
        if( errno != EINTR )
          sms_perror("SMS-NAP/select");
    }
    else
#if defined(unix) || defined(__unix)
      if( select (0, NULL, NULL, NULL, &timeout) == (-1) )
        if( errno != EINTR )
          ioi_perror("SMS-NAP/select",0);
#else                              /* Like VMS */
      sleep( (usec+999999)/1000000 );
#endif
  }

  return 0;
}

int sms_confirm(char *cmd)
/**************************************************************************
?  Ask the user are (s)he serious about the commnad?
=  BOOLEAN status.
************************************o*************************************/
{
  char  temp[MAXLEN];
  char *s;
  int   rc;

  printf("Are U serious 'bout %s? ",cmd?cmd:"that");
  fflush(stdout);

  s  = temp;
  *s = '\0';

  fgets(s,MAXLEN,stdin);
  ioi_out(0,IOI_ECHO,"%s",STR(s));

  while( *s && ( *s==' ' || *s=='\t' ) ) s++;

  if( !(rc=(*s=='Y' || *s=='y')) )
  {
    printf("I thought U didn't like the ideas.\n");
    if(cmd) printf("givin' up of %s.\n",STR(cmd));
  }

  return rc;
}

double sms_drand48(void)
/**************************************************************************
?  Random number with timedependent seed.
=  [0.0 - 1.0)
~  drand48(3) srand48(3) rand(3)
************************************o*************************************/
{
  extern double drand48();
  extern void   srand48();
  static int    been_here;

  if( !been_here )
  {
#if defined(RAND_ONLY) || defined(VMS)
    srand( (int) time(NULL) + getpid() );
#else
    srand48( (long) time(NULL) + getpid() );
#endif
    been_here = TRUE;
  }

#if defined(RAND_ONLY) || defined(VMS)
  return (rand()&0xffff) / 65535.0001;
#else
  return drand48();
#endif
}

/**************************************************************************
?  For the password.
|  Currerntly defected.
************************************o*************************************/

static void catch(void) { ; }

char *sms_password(char *prompt)
/**************************************************************************
?  Get the password.
************************************o*************************************/
{
  static char pw[MAXPASSLEN];

#ifndef VMS
  if( isatty(fileno(stdin)) )
    return getpass(prompt);
#endif

  printf("[visible] %s",STR(prompt));
  fgets(pw,MAXPASSLEN-1,stdin);

  pw[MAXPASSLEN-1]='\0';

  return sms_no_newline(pw);
}

/*
 *  This stuff is from ut-library. If problems modify it also.
 *  Keep this in the end of the file.
 */

/**************************************************************************
.TITLE   Utility Library Functions
.NAME    NONE
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    06-SEP-1991 / 09-DEC-1989 / OP
.VERSION 1.0
.FILE    strext.c
************************************o*************************************/

char *strext(
    char *new,                 /* New name with the ext */
    char *old,                 /* Name to be derivated */
    char *ext)                 /* Extension to be added */
/**************************************************************************
?  Add the file-extension to the OLD name by removing the old extension
|  Extension starts from the last dot "." found in the OLD and is
|  replaced by EXT.
|  If the dot cann't be found, a dot and EXT is added to the OLD.
|
|  The strings given must be null terminated and NEW must be large
|  enough to hold the new name.
=  *new
************************************o*************************************/
{
  int i;
  int dot=0;                   /* Flag was the dot found? */

  i=strlen(old);

  while(!dot && i && ! old[i-1]!='/') if(old[--i] == '.') dot=1;

  if(!dot) i=strlen(old);

  strncpy(new,old,i);
  new[i]='.';
  new[i+1]='\0';
  strcat(new,ext);      
  return(new);
}
