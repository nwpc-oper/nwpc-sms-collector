/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     XDR
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-MAY-1992 / 09-AUG-1991 / OP
.ORIGIN   xdr_str.c
.FILE     xdr.c
.VERSION  4.0
*
.DATE     20-APR-1993 / 20-APR-1993 / OP
.VERSION  4.2
.DATE     07-AUG-1994 / 23-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
*         Added support for meter and label structures
.DATE     08-DEC-1994 / 08-DEC-1994 / OP
.VERSION  4.3.4
*         Added support for sending the flags
.DATE     09-MAR-1995 / 09-MAR-1995 / OP
.VERSION  4.3.5
*         Added support automigration
.DATE     30-AUG-1995 / 30-AUG-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Added autorestore
.DATE     18-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Complete trigger
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     21-DEC-1998 / 24-SEP-1998 / OP
.VERSION  4.4
*         Login with nick names
*         Limit (pseudo queues)
*         Aliased tasks and unknown type
*         Zombie passwords
*         Primitive talk
*         User and zombie requests
.DATE     05-FEB-1999 / 05-FEB-1999 / OP
.VERSION  4.4.1
*         Limit changed
*         Inlimit own type
.DATE     03-FEB-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
*         Times for task state change
************************************o*************************************/

#include "smslib.h"

extern sms_xdr_list     ();        /* Must list them here to fill the funs[] */
extern sms_xdr_user     ();
extern sms_xdr_connect  ();
extern sms_xdr_variable ();
extern sms_xdr_time     ();
extern sms_xdr_date     ();
extern sms_xdr_trigger  ();
extern sms_xdr_tree     ();
extern sms_xdr_action   ();
extern sms_xdr_event    ();
extern sms_xdr_node     ();
extern sms_xdr_node     ();
extern sms_xdr_node     ();
extern sms_xdr_node     ();
extern sms_xdr_passwd   ();
extern sms_xdr_login    ();
extern sms_xdr_status   ();
extern sms_xdr_reply    ();
extern sms_xdr_check    ();
extern sms_xdr_nid      ();
extern sms_xdr_file     ();
extern sms_xdr_handle   ();
extern sms_xdr_repeat   ();
extern sms_xdr_dir      ();
extern sms_xdr_meter    ();
extern sms_xdr_label    ();
extern sms_xdr_map      ();
extern sms_xdr_limit    ();
extern sms_xdr_zombie   ();
extern sms_xdr_inlimit  ();

static int (*funs[])() = {        /* To call the right routine */
  sms_xdr_list     ,
  sms_xdr_user     ,
  sms_xdr_connect  ,
  sms_xdr_variable ,
  sms_xdr_time     ,
  sms_xdr_date     ,
  sms_xdr_trigger  ,
  sms_xdr_tree     ,
  sms_xdr_action   ,
  sms_xdr_event    ,
  sms_xdr_node     ,
  sms_xdr_node     ,
  sms_xdr_node     ,
  sms_xdr_node     ,
  sms_xdr_passwd   ,
  sms_xdr_login    ,
  sms_xdr_status   ,
  sms_xdr_reply    ,
  sms_xdr_check    ,
  sms_xdr_nid      ,
  sms_xdr_file     ,
  sms_xdr_handle   ,
  sms_xdr_repeat   ,
  sms_xdr_dir      ,
  sms_xdr_meter    ,
  sms_xdr_label    ,
  sms_xdr_time     ,               /* cancel   */
  sms_xdr_time     ,               /* migrate  */
  sms_xdr_time     ,               /* late     */
  sms_xdr_list     ,               /* restore  */
  sms_xdr_trigger  ,               /* complete */
  sms_xdr_map      ,               /* nickname */
  sms_xdr_node     ,               /* alias    */
  sms_xdr_limit    ,
  sms_xdr_inlimit  ,
  xdr_void         ,               /* unknown, we should never get here! */
  sms_xdr_zombie   ,
  xdr_void         ,               /* project */
  xdr_void         ,               /* object  */
  xdr_void         ,               /* call    */
};

int sms_xdr_string(register XDR *x, char **str)
/**************************************************************************
?  XDR a string pointer correctly. This differs with xdr_string in that
|  it can serialize/deserialiaze strings correctly.
|
|  What's sent is actually an union.
|
|  XDR boolean (string pointer != NULL).
|  If the string pointer is NULL XDR nothing otherwise XDR the string.
~  xdr_pointer()
************************************o*************************************/
{
  bool_t empty;

  empty = (*str == NULL);

  if (! xdr_bool(x,&empty))
    return (FALSE);

  if( empty ) 
  {
    *str = NULL;
    return TRUE;
  }

  return xdr_wrapstring(x,str);
}

int sms_xdr_pointer(register XDR *x, sms_list **gpp)
/**************************************************************************
?  XDR a SMS pointer correctly. This differs with xdr_pointer in that
|  it can (de)serialize SMS-pointers correctly.
|
|  What's sent is actually an union and function arming type.
|
|  XDR boolean (pointer != NULL).
|
|  If the pointer is NULL XDR nothing otherwise XDR the arming function.
|  XDR type and the actual structure.
~  xdr_pointer()
-NOTICE  no information of the size and function is supplied to this
|  routine.
************************************o*************************************/
{
  bool_t    more_data;
  int       type;

  more_data = (*gpp != NULL);

  if(!xdr_bool(x,&more_data)) return FALSE;

  if (! more_data) {
    *gpp = NULL;
    return TRUE;
  }

  if(x->x_op != XDR_DECODE)
    type = (*gpp)->type;

  if(!xdr_int(x,&type)) return FALSE;

  if( type<0 || type>sms_sizes_max ) return FALSE;

#ifdef SMS_DEBUG_XDR
  {
    int rc = xdr_reference(x,gpp,sms_sizes[type],funs[type]);

    printf("XDR:%-10s",node_name[type]); fflush(stdout);
    if( *gpp && type < NODE_LOGIN )
      printf(" %s",STR((*gpp)->name));
    printf("\n");

    return rc;
  }
#else
  return xdr_reference(x,(caddr_t *)gpp,sms_sizes[type],funs[type]);
#endif
}

sms_xdr_nid(register XDR *x, sms_nid *nidp)
/**************************************************************************
?  XDR a NID pointer correctly. This routine takes account that
|
|  What's sent is actually an union.
|
|  report bit fields are coded as follows
|
|  nid         : 20     ( 2^20 = 1M nodes: should B enough)
|  status      :  6     ( bit 0x20 == suspended flag )
|  next?       :  1
|  gen?        :  1
|  tryno?      :  1
|  times?      :  1
|
|  XDR boolean (string pointer != NULL).
|  If the string pointer is NULL XDR nothing otherwise XDR the string.
~  xdr_pointer()
************************************o*************************************/
{
  bool_t    next_exists;
  bool_t    gen_exists;
  bool_t    times_exists;
  bool_t    tryno_exists;
  int       status;
  int       nid;

  int       report;

  do
  {
    if(x->x_op != XDR_DECODE )
    {
      next_exists  = (nidp->next)?         TRUE:FALSE;
      gen_exists   = (nidp->gen)?          TRUE:FALSE;
      times_exists = (nidp->stime)?        TRUE:FALSE;
      tryno_exists = (nidp->tryno != NIL)? TRUE:FALSE;
      status       = nidp->status;
      nid          = nidp->nid;

      report = ( 0x000fffff & nid      ) |
               ( (0x3f & status) << 20 ) |
               ( next_exists     << 26 ) |
               ( gen_exists      << 27 ) |
               ( tryno_exists    << 28 ) |
               ( times_exists    << 29 ) ;
    }

    if( !xdr_int(x,&report)) return FALSE;

    nidp->type   = NODE_NID;
    nid          = ( report       ) & 0x000fffff;
    status       = ( report >> 20 ) & 0x3f;
    next_exists  = ( report >> 26 ) & 0x1;
    gen_exists   = ( report >> 27 ) & 0x1;
    tryno_exists = ( report >> 28 ) & 0x1;
    times_exists = ( report >> 29 ) & 0x1;

    if(!xdr_int(x,&nidp->nid))    return FALSE;
    if(!xdr_int(x,&nidp->status)) return FALSE;

    if( SUPPORTED(4,3,4) )
      if(!xdr_int(x,&nidp->flags)) return FALSE;

    if(tryno_exists) if(!xdr_int(x,(int *)&nidp->tryno)) return FALSE;
    if(times_exists) if(!xdr_int(x,(int *)&nidp->stime)) return FALSE;
    if(times_exists) if(!xdr_int(x,(int *)&nidp->btime)) return FALSE;
    if(gen_exists) if(!sms_xdr_pointer(x,(sms_list **)&nidp->gen)) return FALSE;

    if( x->x_op == XDR_DECODE )
    {
      if( next_exists )
        if( ! (nidp->next = sms_alloc(NODE_NID)) )
          return ioi_out(FALSE,IOI_ERR,"SMS-XDR-NID:No mem.");
    }

    nidp = nidp->next;

  } while( next_exists );

  return TRUE;
}

