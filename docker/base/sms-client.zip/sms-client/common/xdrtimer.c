/**************************************************************************
.TITLE    XDRTIMER
.NAME     CDP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.14
.FILE     xdrtimer.c
*
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  Code to produce timing information into SMS logfile
*
************************************o*************************************/

#include "smslib.h"

static struct timeval start;
static double         doit;

void sms_xdrtimer_setup(double value)
{
  doit = value;
}

void sms_xdrtimer_start(void)
{
  if( (doit>0) && sms_._is_server )
  {
    sprintf(sms_._timer_txt,"%s form %s",
            (sms_._current_con)? STR(sms_._current_con->name) : "NULL" ,
            (sms_._current_con)? STR(sms_._current_con->host) : "NULL" );

    if( gettimeofday(&start, 0) != 0 )
    {
      start.tv_sec  = 0;
      start.tv_usec = 0;
    }
  }
}

void sms_xdrtimer_stop(char *command)
{
  struct timeval stop;
  time_t         sec;
  long           usec;

  if( (doit>0) && sms_._is_server )
  {
    if( gettimeofday(&stop, 0) != 0 )
    {
      stop.tv_sec  = 0;
      stop.tv_usec = 0;
    }
    sec  = stop.tv_sec  - start.tv_sec;
    usec = stop.tv_usec - start.tv_usec;

    if( usec < 0 )
    {
      usec += 1000000;
      sec  -= 1;
    }

    if( (sec+usec/1000000.0) >= doit )
      spit(0,IOI_MSG,"Timer:%4d.%06d, command %s, user %s",
           sec,usec, STR(command), STR(sms_._timer_txt));
  }
  sms_._timer_txt[0] = 0;
}
