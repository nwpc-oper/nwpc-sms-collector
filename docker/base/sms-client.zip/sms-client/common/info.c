/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     INFO
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     01-APR-1992 / 30-JUL-1991 / OP
.VERSION  4.0
.FILE     info.c
.DATE     08-DEC-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.4
.DATE     28-SEP-1995 / 22-SEP-1995 / OP
.VERSION  4.3.10-11
*         Added late concept
*         Info to print the clock for suite
.DATE     08-APR-1997 / 09-FEB-1997 / OP
.VERSION  4.3.14
*         Added info for auto[migrate/cancel]
*         Year is now 4 digits
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     11-DEC-1998 / 23-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
*         Aliased tasks
*
*  Print the into of the node
*
*  LOCAL typedef struct full_variable fvar;
*
************************************o*************************************/

#include "smslib.h"

/**************************************************************************
?  Only needed by this file.
************************************o*************************************/

struct full_variable {
  int                   type;
  char                 *name;
  struct full_variable *next;
  char                 *value;
  char                 *level;     /* Name of the node where defined */
  int                   gen;       /* Was it defined or genereated   */
};
typedef struct full_variable fvar;

static void pointed_tree(
    sms_node  *np,                 /* Node to be find for pointers     */
    sms_node  *ref,                /* Current reference node scanned   */
    sms_tree  *tp,                 /* Its trigger list being scanned   */
    sms_list **lp)                 /* Result to be created here        */
/**************************************************************************
?  Get the fullnames of the node pointed by the NP for the math-TREE.
|  The REF is needed to generate the name
************************************o*************************************/
{
  if( !tp ) return;

  pointed_tree( np , ref , tp->left  , lp );
  pointed_tree( np , ref , tp->right , lp );

  if(tp->math)
    if(tp->math==np || (tp->math->type==NODE_EVENT && tp->math->parent==np))
      ls_add_d(lp,ls_create(0,sms_node_full_name(ref)));
}

static void pointed(sms_node *np, sms_node *ref, sms_list **lp)
/**************************************************************************
?  Loop the reference recurisively to finf the nodes pointing.
************************************o*************************************/
{
  while(ref)
  {
    if( ref->trigger )
      pointed_tree(np,ref,ref->trigger->math,lp);

    pointed(np,ref->kids,lp);
    ref = ref->next;
  }
}

sms_list *sms_info_pointed(sms_node *np)
/**************************************************************************
?  Find out the nodes that has NP as a trigger.
=  A static list of (full)names that point to this node.
************************************o*************************************/
{
  static sms_list *lp;

  NODE_FREE(lp,sms_list);          /* Remove the possible old stuff */

  pointed(np,sms_._super,&lp);

  return lp;
}

static void points_tree(
    sms_tree  *tp,                 /* Trigger list being scanned */
    sms_list **lp)                 /* Result to be created here  */
/**************************************************************************
?  Get the fullnames of the nodes pointed by the trigger math and add them
|  into the list given.
************************************o*************************************/
{
  if( !tp ) return;

  points_tree( tp->left  , lp );
  points_tree( tp->right , lp );

  if(tp->math)
    ls_add_d(lp,ls_create(0,sms_node_full_name(tp->math)));
}

sms_list *sms_info_points(sms_node *np)
/**************************************************************************
?  Find out the nodes used by NP (nodes that trigger NP)
=  A static list of (full)names that point to this node.
************************************o*************************************/
{
  static sms_list *lp;

  NODE_FREE(lp,sms_list);          /* Remove the possible old stuff */

  if(np->trigger)
    points_tree(np->trigger->math,&lp);

  return lp;
}

static fvar *vars(sms_node *np, int init)
/**************************************************************************
?  Gather the variables in the suite
=  A static list of variables
************************************o*************************************/
{
  static fvar  *vp;
  sms_variable *loop;
  int           i;

  if(init)
    while( vp )
    {
      fvar *temp;
      temp = vp->next;
      IFFREE(vp->name);
      IFFREE(vp->value);
      IFFREE(vp->level);
      free(vp);
      vp = temp;
    }

  for( i=0 ; i<2 ; i++ )           /* From defined to generated */
    for( loop = (i==0)?np->variable:np->genvars ; loop ; loop=loop->next )
      if( ! sms_list_find(&vp,loop->name) )
      {
        fvar *var;
        var = calloc(1,sizeof(fvar));

        var->type  = NODE_VARIABLE;
        var->name  = strdup(loop->name);
        var->value = strdup(loop->value);
        var->gen   = i;
        if(!init)
          var->level = strdup(sms_node_full_name(np));

        sms_list_add(&vp,var);
      }

  if(np->parent && np->parent->type != NODE_HANDLE)
    vars(np->parent,FALSE);

  return vp;
}

#define PR(x)  printf(((x)==(-1))?" *":"%02d",(x))
#define PU(c)  putchar((c))

#define WITH(x) for( x=np->x ; x ; x=x->next )

int sms_info(
    sms_node *np,
    int       variables)           /* Display the variables also */
/**************************************************************************
?  Print all the information of the single node
|  Status
|  Reason for not running if status is queued
|  Variables
|  Dependencies   Time/Date/Day  Triggers Triggered
|  Owner
|  Treis  current try
|  Clock for suite with gain
************************************o*************************************/
{
  sms_variable *var;
  sms_list     *lp,*llp;
  struct tm    *tm;

  if( !np ) return 0;

  if( np->type==NODE_SUPER  || np->type==NODE_SUITE ||
      np->type==NODE_FAMILY || np->type==NODE_TASK || np->type==NODE_ALIAS)
    printf("%s [%s] is %s\n",STR(sms_node_net_name(np)),node_name[np->type],
      (np->type == NODE_EVENT)?event_name[np->status]:status_name[np->status]);
  else
    return 0;

  printf("Default status is:  %s\n",status_name[np->defstatus]);

  if(np->status==STATUS_SUSPENDED)
    printf("Saved status is:    %s\n",status_name[np->savedstat]);

  if( np->type == NODE_SUITE )
  {
    int sec = np->gain;

    if(np->clock == CLOCK_HYBRID)
    {
      time_t x = np->btime + np->stime % 86400;
      printf("Suite time is: %s ",STR(sms_time_c(&x)));
    }
    else
      printf("Suite time is: %s ",STR(sms_time_c(&np->stime)));

    if(sec)
    {
      int d,h,m,s;

      d =  sec / 86400;
      h = (sec % 86400) / 3600;
      m = (sec %  3600) / 60;
      s =  sec %    60;

      printf("gain is %d days %02d:%02d:%02d",d,h,m,s);
    }
    printf("\n");
  }

  sms_repeat_info(np->repeat);
  if(np->late) printf("Late %s\n",STR(sms_late_string(np,1)));
  sms_limit_info(np);

  if(np->flags)
  {
    int i;
    int indent=FALSE;

    printf("Flags set:");

    for(i=0;i<FLAG_MAX;i++)
      if( FLAG_ISSET(np,i) )
      {
        if(indent)
          printf("\n          ");
        printf(" %s",flag_name[i]);
        indent=TRUE;
      }
    printf("\n");
  }

  if(np->type==NODE_TASK || np->type==NODE_ALIAS)
  {
    sms_event *event;
    sms_meter *meter;
    sms_label *label;

    printf("Current try number: %d\n",np->tryno);
    /* printf("Maximum try number: %d\n",np->tries); */

    WITH(event)
      printf("  EVENT %s is %s\n",STR(event->name),event_name[event->status]);

    WITH(meter)
      printf("  METER %s is %d limits are [%d - %d]\n",STR(meter->name),
             meter->status,meter->min,meter->max);

    WITH(label)
      printf("  LABEL %s '%s'\n",STR(label->name),
             label->value?label->value:"<not defined>");
  }

  if(np->time)
  {
    sms_time *tp;

    printf("Time dependencies\n");
    for( tp=np->time ; tp ; tp=tp->next )
    {
      printf("    %c",(tp->relative)?'+':' ');
      printf("%02d:%02d",tp->hour[0],tp->minute[0]);
      if(tp->repeat)
        printf(" %02d:%02d",tp->hour[1],tp->minute[1]) ,
        printf(" %02d:%02d",tp->hour[2],tp->minute[2]) ;
      else
        printf("%12s"," ");
      printf(" %-8s",time_name[tp->status]);

      tm = sms_time_tm(&tp->nexttime);

      printf(" next %02d:%02d",tm->tm_hour,tm->tm_min);

      tm = sms_time_tm(&tp->lasttime);

      printf(" last %02d:%02d",tm->tm_hour,tm->tm_min);

      printf("\n");
    }
  }

  if(np->date)
  {
    sms_date *dp;

    printf("Date/day dependencies\n");

    for( dp=np->date ; dp ; dp=dp->next )
    {
      printf("    ");
      if( dp->weekdays )
      {
        int i;

        printf("Daymask:");
        for( i=0 ; i<DAY_MAX ; i++ )
          if( dp->weekdays & ( 1<<i ) )
            printf(" %s",day_name[i]);
      }
      else
      {
        PR(dp->day); PU('.'); PR(dp->month); PU('.'); 
        if(dp->year == NIL ) PR(dp->year);
        else                 PR(dp->year+1900);
        printf(" %-8s",time_name[dp->status]);
        if(dp->year == NIL || dp->month == NIL || dp->day == NIL)

        tm = sms_time_tm(&dp->nextdate);
        printf(" next %02d:%02d:%04d",tm->tm_mday,tm->tm_mon,tm->tm_year+1900);
      }
      printf("\n");
    }
  }

  if( np->autocm )
  {
    printf("Auto%s %s\n",
            (np->autocm->type==NODE_CANCEL)? "cancel" : "migrate",
            STR(sms_cancel_string(np,TRUE)));
  }

  if( (lp=sms_info_pointed(np)) )
  {
    printf("Nodes triggered by this node\n");

    for( ; lp ; lp=lp->next )
      printf("    %s\n",STR(lp->name));
  }

  lp = sms_info_points(np);
  llp=sms_node_get_external(np,TRUE);

  if( lp || llp )
  {
    printf("Nodes that trigger this node\n");

    for( ; lp ; lp=lp->next )
    {
      sms_node *tmp=sms_node_find_full(lp->name);
      sms_repeat *rp;

      printf("    %s",STR(lp->name) );
      if(tmp)
        switch( tmp->type )
        {
          case NODE_EVENT:
            printf(" [%s]\n", event_name[tmp->status]);
            break;

          case NODE_METER:
            printf(" [%d]\n", tmp->status);
            break;

          case NODE_REPEAT:
            rp = (sms_repeat *)tmp;
            if(rp->mode==REPEAT_INTEGER || rp->mode==REPEAT_DATE)
              printf(" [%d]\n", rp->status);
            if(rp->mode==REPEAT_STRING)
              printf(" [string %d]\n", rp->status);
            break;

          case NODE_SUPER:
          case NODE_SUITE:
          case NODE_FAMILY:
          case NODE_TASK:
          case NODE_ALIAS:
            printf(" [%s]\n", status_name[tmp->status]);
            break;

          default:
            break;
        }
      else
        printf(" [undefined]\n");
    }

    for( ; llp ; llp=llp->next )
      printf("    extern %s\n",STR(llp->name));
  }

  if(np->user)
  {
    sms_user *user;

    printf("\nOwners of this node\n");

    WITH(user)
      printf("  %5d %5d %s\n",user->uid,user->gid,STR(user->name));
  }

  if(np->action)
  {
    sms_action *action;

    printf("Actions allocated\n");

    WITH(action)
      printf("    on %s execute %s\n",status_name[action->when],STR(action->name));
  }

  if(variables)
  {
    fvar *vp,*tmp;
    int   name_len=0,value_len=0,level_len=0;
    char  fmt[MAXNAME];

    printf("Variables\n");

    vp = vars(np,TRUE);

    tmp = vp;

    for( tmp=vp ; tmp ; tmp=tmp->next )
      name_len  = MAX(name_len ,strlen(tmp->name)) ,
      value_len = MAX(value_len,strlen(tmp->value)) ,
      level_len = tmp->level? MAX(level_len,strlen(tmp->level)) : level_len;

    sprintf(fmt,"    %%c%%-%ds = %%-%ds%%c [%%s]\n",
      name_len,value_len
    );

    for( tmp=vp ; tmp ; tmp=tmp->next )
      printf(fmt,
        tmp->gen?'(':' ',
        tmp->name,
        tmp->value,
        tmp->gen?')':' ',
        tmp->level?tmp->level:""
      );
  }

  if(np->text)                         /* And last the stored information */
  {
    sms_list *text;

    printf("Description text\n");

    WITH(text)
      printf("    %s\n",STR(text->name));
  }

  return TRUE;
}

