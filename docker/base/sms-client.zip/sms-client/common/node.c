/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     node.c
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     18-DEC-1992 / 30-JUL-1991 / OP
.VERSION  4.0
.FILE     node.c
*
.DATE     02-MAR-1993 / 30-JUL-1991 / OP
.VERSION  4.1
.DATE     22-JUL-1993 / 16-APR-1993 / OP
.VERSION  4.2
.DATE     15-DEC-1993 / 15-DEC-1993 / OP
.VERSION  4.2.1
*         Bug fix with full path name in play file
*         (multiple suites in the same file)
.DATE     13-OCT-1994 / 23-FEB-1994 / OP
.VERSION  4.3
.LANGUAGE ANSI-C
*         Added support for meter and label structures
.DATE     02-DEC-1994 / 02-DEC-1994 / OP
.VERSION  4.3.3
*         Node update for routine to lightweight the NID processing
.DATE     15-MAR-1995 /  09-MAR-1995 / OP
.VERSION  4.3.5-6
*         Auto migration added
*         Resubmit (4.3.6)
.DATE     30-AUG-1995 / 30-AUG-1995 / OP
.VERSION  4.3.10
*         Late concept added
.DATE     05-OCT-1995 / 26-SEP-1995 / OP
.VERSION  4.3.11
*         Added per node logging
*         No more external generation of numbers
*         Label has default value
.DATE     09-OCT-1995 / 06-OCT-1995 / OP
.VERSION  4.3.12
*         Bug fix requeue migrated stuff
.DATE     09-APR-1997 / 09-APR-1997 / OP
.VERSION  4.3.15
*         Added autorestore
.DATE     23-APR-1998 / 21-APR-1998 / OP
.VERSION  4.3.18
*         Bufsize for node_write
*         Repeat handling (repeat is also a node now for find)
.DATE     18-JUN-1998 / 18-JUN-1998 / OP
.VERSION  4.3.20
*         Bufsize for node_write
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     28-JAN-1999 / 22-SEP-1998 / OP
.VERSION  4.4
*         Variables have NIDs
*         Net names for nodes
*         Zombie passwords
*         Limit (pseudo queues)
*         Aliased tasks
*         Primitive talk
.DATE     18-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
*         Inlimit has own type
.DATE     04-FEB-2000 / 03-FEB-2000
.VERSION  4.4.3
*         Cron type
*
*  Full name is of form:
*
*  /[suite[/family[/task[:{event|meter|label|repeat|limit}]]]]
*
*  Net name is of form:
*
*  [sms:]//host.name[:port]/[suite[/family[/task[:{event|meter|lebel|repeat|limit}]]]]
*
*  [sms:] (protocol) is for expansion to use WWW
*
*                   [:port] is optional and is for expansion to use WWW
*
*
*  Node creation, deletion and modifing routines.
*
************************************o*************************************/

#include "smslib.h"

static int       is_validating;    /* Create events automatically? */

static int       is_playing;
static sms_list *external_nodes;   /* If playing */

void *sms_node_free(void *anything)
/**************************************************************************
?  Free the node and its kids.
|  Nexts are also freed.
|  All the NODE_xxx types can be freed by this routine.
=  NULL
~  list_free(), which only removes the item from the list but doesn't
|  free the actual memory.
************************************o*************************************/
{
  sms_node *tmp;
  sms_node *np = anything;

  while( np )
  {
    tmp = np->next;

    switch( np->type )
    {
      case NODE_ALIAS:
      case NODE_SUPER:             /* The basic nodes */
      case NODE_SUITE:
      case NODE_FAMILY:
      case NODE_TASK:
        IFFREE( np->name );
        sms_node_free( np->kids );
        sms_node_free( np->text );
        sms_node_free( np->event );
        sms_node_free( np->meter );
        sms_node_free( np->label );
        sms_node_free( np->time );
        sms_node_free( np->date );
        sms_node_free( np->trigger );
        sms_node_free( np->complete );
        sms_node_free( np->wait );
        sms_node_free( np->action );
        sms_node_free( np->autocm );
        sms_node_free( np->late );
        IFFREE( np->passwd );
        sms_node_free( np->user );
        sms_node_free( np->variable );
        sms_node_free( np->genvars );
        sms_node_free( np->repeat );
        sms_node_free( np->log );
        sms_node_free( np->restore );
        sms_node_free( np->limit );
        sms_node_free( np->inlimit );
        break;

      case NODE_CONNECTION:
        IFFREE( np->name );
        IFFREE( ((sms_connect *)np)->host );
        sms_node_free( ((sms_connect *)np)->suites );
        sms_node_free( ((sms_connect *)np)->mail );
        break;

      case NODE_LIST:
      case NODE_EVENT:             /* Simple ones, nothin' 2 do */
      case NODE_DATE:
      case NODE_TIME:
      case NODE_CANCEL:
      case NODE_MIGRATE:
      case NODE_USER:
      case NODE_ACTION:
      case NODE_METER:
      case NODE_DIR:
      case NODE_LATE:
      case NODE_INLIMIT:
        IFFREE( np->name );
        break;

      case NODE_TRIGGER:           /* Free the math! */
      case NODE_COMPLETE:          /* Free the math! */
        IFFREE( np->name );
        ioi_math_delete( (ioi_node*) (((sms_trigger *)np)->math) );
        break;

      case NODE_TREE:
        ioi_math_delete( (ioi_node*)np );
        break;

      case NODE_VARIABLE:
        IFFREE( np->name );
        IFFREE( ((sms_variable *)np)->value );
        break;

      case NODE_PASSWD:
        IFFREE( np->name );
        IFFREE( ((sms_passwd *)np)->passwd );
        IFFREE( ((sms_passwd *)np)->comment );
        break;

      case NODE_LOGIN:
        IFFREE( np->name );
        IFFREE( ((sms_login *)np)->passwd );
        tmp = NULL;
        break;

      case NODE_STATUS:
        sms_node_free( ((sms_status *)np)->node );
        tmp = NULL;
        break;

      case NODE_REPLY:
        sms_node_free( ((sms_reply *)np)->lines );
        tmp = NULL;
        break;

      case NODE_CHECK:
        tmp = NULL;
        break;

      case NODE_NID:
        sms_node_free( ((sms_nid *)np)->gen );
        break;

      case NODE_FILE:
        IFFREE( np->name );
        IFFREE( ((sms_file *)np)->data.data_val);
        break;

      case NODE_HANDLE:
        break;

      case NODE_REPEAT:
        IFFREE( np->name );
        sms_node_free( ((sms_repeat *)np)->str );
        break;

      case NODE_LABEL:
        IFFREE( np->name );
        IFFREE( ((sms_label *)np)->value );
        IFFREE( ((sms_label *)np)->def );
        break;

      case NODE_LIMIT:
        IFFREE( np->name );
        IFFREE( ((sms_limit *)np)->unit );
        sms_node_free( ((sms_limit *)np)->tasks );
        break;

      case NODE_MAP:
        IFFREE(np->name);
        IFFREE( ((sms_map *)np)->netname );
        break;

      case NODE_ZOMBIE:
        {
          sms_zombie *zp = (sms_zombie *)np;

          IFFREE(zp->name);
          IFFREE(zp->passwd);
          IFFREE(zp->host);
          IFFREE(zp->sender);
        }
        break;

      case NODE_PROJECT:
        IFFREE( np->name );
        sms_node_free( np->kids );
        sms_node_free( ((sms_project*)np)->object );
        sms_node_free( ((sms_project*)np)->comment );
        break;

      case NODE_OBJECT:
      case NODE_CALL:
        IFFREE( np->name );
        sms_node_free( np->kids );
        sms_node_free( ((sms_object*)np)->param );
        break;
    }

    free(np);

    np = tmp;
  }

  return np;
}

sms_list *sms_node_create(char *text)
/**************************************************************************
?  Make a new node. Next field is cleared.
=  NULL if no memory, otherwise the new node.
************************************o*************************************/
{
  register int       len;
  register sms_list *token;

  text = text?text:"";

  len = strlen(text);

  if( !(token=sms_alloc(NODE_LIST)) )
  {
    ioi_out(0,IOI_ERR,"SMS-NODE-CREATE:No mem.");
    return 0;
  }

  token->name = strdup(text);
  token->type = NODE_LIST;

  return token;
}

int sms_node_play(int mode)
/**************************************************************************
?  Mark the local variable are we playing or not.
************************************o*************************************/
{
  is_playing = mode;

  NODE_FREE(external_nodes,sms_list);

  return 0;
}

int sms_node_external(char *name)
/**************************************************************************
?  Add an external node name into the local list
|  Used by the CDP/PLAY
************************************o*************************************/
{
  sms_list *lp;

  if(!(lp=sms_node_create(name))) return FALSE;

  return sms_list_add(&external_nodes,lp);
}

static void get_external(sms_tree *node, sms_list **lp)
/**************************************************************************
?  Get the external triggers of the tree
************************************o*************************************/
{
  if( !node ) return;

  if( node->left )  get_external(node->left,lp);
  if( node->right ) get_external(node->right,lp);

  if( node->mtype == M_NAME )
    if( node->math )
      return;
    else
    {
      if(ioi_user_cmdf(node->name,status_name,NULL,STATUS_USABLE) != NIL)
        return;
      if(ioi_user_cmdf(node->name,event_name,NULL,EVENT_MAX) != NIL)
        return;
      if(sms_is_number(node->name))
        return;

      sms_list_add(lp,sms_node_create(node->name));
    }
}

sms_list *sms_node_get_external(sms_node *np, int init)
/**************************************************************************
?  Get the external triggers of the node
=  The list of external names
************************************o*************************************/
{
  static sms_list *lp;

  if(!np) return NULL;

  if(init) NODE_FREE(lp,sms_list);

  if(np->trigger) get_external(np->trigger->math,&lp);
  if(np->complete) get_external(np->complete->math,&lp);

  for( np=np->kids; np ; np=np->next )
    sms_node_get_external(np,FALSE);

  return lp;
}

int sms_node_clear_user_data(sms_node *np)
/**************************************************************************
?  Clear the user_data field to calculate the connections.
************************************o*************************************/
{
  while( np )
  {
    np->user_int = 0;
    np->user_ptr = 0;
    sms_node_clear_user_data(np->kids);
    if(np->type==NODE_TASK)
    {
      sms_event  *e = np->event;
      sms_meter  *m = np->meter;
      sms_label  *l = np->label;
      sms_repeat *r = np->repeat;
      sms_limit  *i = np->limit;

      for( ; e ; e=e->next ) { e->user_int=0; e->user_ptr=0; }
      for( ; m ; m=m->next ) { m->user_int=0; m->user_ptr=0; }
      for( ; l ; l=l->next ) { l->user_int=0; l->user_ptr=0; }
      for( ; r ; r=r->next ) { r->user_int=0; r->user_ptr=0; }
      for( ; i ; i=i->next ) { i->user_int=0; i->user_ptr=0; }
    }
    np = np->next;
  }

  return 0;
}

sms_node *sms_node_find(char *name, sms_node *ref)
/**************************************************************************
?  Find the node that matches the name.
|  Current implementation allows to find node only in the same suite.
|  Possible starts of the name:
|  .     or ./        this directory
|  ..    or ../       the previous directory
|  ./xxx              xxx in this directory
|  ../xx              xxx in the previous directory
|  xxx                xxx in this directory
|  /                  the root (my suite)
|  ""                 this directory
|  xxx:y              the event y in the name xxx
|                     or if not found, the meter y in xxx
|  The super node can not be referenced by this way.
************************************o*************************************/
{
  sms_node *father = NULL;
  sms_node *start;

  char      temp[MAXNAM];         /* Temp copy of the name for the strcmp */
  char      *s;                   /* Pointer to copy the name into temp   */

  if( ! *name ) return NULL;      /* You really have to give a name */
  if( ! ref )   return NULL;      /* and the reference */

  father = ref->parent ? ref->parent : ref;  /* Like cd .. while cwd=/ */

  father = ref->type==NODE_SUITE? ref : ref->parent;

  if( *name == '.' )
  {
    if( ! *++name ) return father; /* The 'cwd' */

    if( *name == '/' )             /* Reference to the 'cwd' */
    {
      while( *name == '/' ) name++;
      return ( *name )? sms_node_find(name,father->kids) : father;
    }

    if( *name == '.' )             /* Previous 'dir' */
    {
      if( father->parent )
        if(father->parent->type != NODE_SUPER &&
           father->parent->type != NODE_HANDLE)
          father = father->parent;
      /*
      **  father = father->parent ? father->parent : father;
      */

      if( ! *++name ) return father;

      if( *name == '/' )
      {
        while( *name == '/' ) name++;
        return ( *name )? sms_node_find(name,father->kids) : father;
      }

      return NULL;                 /* ..xxx error */
    }

    return NULL;                   /* .xxx error */
  }

  if( *name == '/' )               /* The root! NO CROSS SUITE POINTERS */
  {
#if defined(SMS_CROSS_SUITE)
    while( ref && ref->parent && ref->parent->type != NODE_HANDLE )
      ref = ref->parent;
#endif

    if( ref->type == NODE_SUPER )
    {
      char  suite[MAXNAM];
      char *s = suite;
      char *n = name;

      if( !name[1] ) return ref;

      for( n++ ; *n && *n != '/' && *n != ':' ; )
        *s++ = *n++;

       *s = '\0';

      for( n=name ; *n && *n == '/' ; n++ )
	;

      /* MOD use "n" instead of "name" */
      return sms_node_find( n,(sms_node*)sms_list_find(&ref->kids,suite) );
    }

    while( ref && ref->parent && ref->type != NODE_SUITE )
      ref = ref->parent;

    while( *name == '/' ) name++;

    return (*name)? sms_node_find(name,ref) : ref;
  }

  /*
   *  OK it's a plain name.
   */

  if( ref->type == NODE_SUITE )
    start = ref;
  else
    start = ref->parent ? ref->parent->kids : ref;

  s = temp;
  while( isalnum(*name) || *name=='_' )  /* Copy the name and advance it */
    *s++ = *name++;
  *s = '\0';

  while( start )
    if( strcmp(start->name,temp) )
    {
      if(start->type==NODE_SUITE)
        return 0;
      start = start->next;
    }
    else
      break;

  if( !start ) return NULL;        /* Nop! It doesn't exist */

  if( ! *name ) return start;      /* Finally found it */

  if( *name == '/' )               /* Let's go into the dir */
  {
    while( *name == '/' ) name++;

    return ( *name )? sms_node_find(name,start->kids) : start;
  }

  if( *name == ':' && (start->type==NODE_TASK ||
                       start->type==NODE_FAMILY ||
                       start->type==NODE_SUITE) )
  {
    sms_event *e = start->event;   /* This is special case in nameing */
    int    number;                 /* The reference can be either by  */
                                   /* the name or by the event number */
    sms_node   *np = 0;
    sms_meter  *mp = NULL;
    sms_label  *lp = NULL;
    sms_repeat *rp = NULL;
    sms_limit  *li = 0;

    name++;

    number = atoi(name); if( ! isdigit(*name) ) number = (-1);

#if 0
    /* Old code when events had numbers and names */
    while( e )
    {
      if( e->name )
        if( !strcmp(e->name,name) )
          return (sms_node *)e;    /* The processing routine checks */
                                   /* the type and the status field */
      if( number == e->number )    /* in the event and the node are */
        return (sms_node *)e;      /* in the same place anyway.     */

      e = e->next;
    }
#else
    if( (np=ls_find(&start->event,name)) ) return np;
#endif

    if( (np=ls_find(&start->meter,name)) ) return np;
    if( (np=ls_find(&start->label,name)) ) return np;
    if( (np=ls_find(&start->repeat,name)) ) return np;
    if( (np=ls_find(&start->limit,name)) ) return np;
    if( (np=ls_find(&start->variable,name)) ) return np;
    if( (np=ls_find(&start->genvars,name)) ) return np;

    if(strcmp(name,"trigger") == 0)  return (sms_node*)start->trigger;
    if(strcmp(name,"complete") == 0) return (sms_node*)start->complete;
    if(strcmp(name,"date") == 0)     return (sms_node*)start->date;
    if(strcmp(name,"time") == 0)     return (sms_node*)start->time;
    if(strcmp(name,"late") == 0)     return (sms_node*)start->late;
    if(strcmp(name,"inlimit") == 0)  return (sms_node*)start->inlimit;

#if 0
    if( is_validating )
    {                              /* OK, let's create the event!   */
      char *argv[2];               /* The play_xxx want's argc/v    */
      char *s = name;

      char  buff[MAXNAM];          /* String of the new event #     */
      int   en = 0;                /* New event number              */

      for( e = start->event ; e ; e = e->next )
        en = MAX(en,e->number);

      en++;
      sprintf(buff,"%d",en);

      while(isdigit(*s)) s++;      /* Is it a plain number */

      argv[0] = ( *s )? buff : name;
      argv[1] = ( *s )? name : NULL;

      ioi_out(0,IOI_WAR,"Creating event %s %s for %s",
              STR(argv[0]) , argv[1]? argv[1] : "" , STR(sms_node_full_name(start)) );

      if( e=sms_play_create_event( (*s)?en:atoi(name),(*s)?name:NULL ) )
      {
        e->status=EVENT_CLEAR;
        sms_list_add( &start->event , e );
        e->parent = start;
        return (sms_node *)e;
      }
    }
#endif

  }

  return NULL;
}

sms_node *sms_node_find_full(char *name)
/**************************************************************************
?  Find the node that matches the name.
|  The full name of the node must have been given.
=  NULL if not found or if the name was illegal otherwise the NODE.
************************************o*************************************/
{
  char      suite[MAXNAM];
  char     *s = suite;
  char     *n = name;

  if( ! name )       return NULL;
  if( ! *name )      return NULL; /* You really have to give a name */
  if( *name != '/' ) return NULL; /* that starts with the slash */

  if( ! name[1] ) return sms_._super;

  /*
   *  Cut the suite name out of the full name.
   */

  for( n++ ; *n && *n != '/' && *n != ':' ; )
   *s++ = *n++;

  *s = '\0';

  return
    sms_node_find( name , 
      (sms_._super && sms_._super->type==NODE_SUPER)
      ?
        (sms_node *)sms_list_find(&(sms_._super->kids),suite)
      :
        (sms_node *)sms_list_find(&sms_._super,suite)
    );
}

char *sms_node_full_name(void *anything)
/**************************************************************************
?  Return the full node name in static area.
|  Current implementation starts the full name by the '/'.
NOTICE!  If the name returned is to be used, make a local copy of it
|  eg strdup(sms_node_full_name(np)) ...
!  Processing node types: EVENT METER LABEL REPEAT LIMIT VARIABLE
|                         ALIAS TASK FAMILY SUITE SUPER
************************************o*************************************/
{
  sms_node *np = anything;
  static char name[MAXLEN];

  if(!np) return( NULL );          /* This really is an error! */

  if( np->type==NODE_SUPER )
  {
    strcpy(name,"/");
    return name;
  }

  if( np->type==NODE_SUITE )
  {
    strcpy(name,"/");              /* If names are to start with slash */
    strcat(name,np->name);
  }
  else                             /* This must be family or task */
  {
    if(!np->parent)
    {
      strcpy(name,"/");
      fprintf(stderr,"full-name: %s no parent?\n",STR(np->name));
    }
    sms_node_full_name(np->parent);

    if(np->type==NODE_EVENT || np->type==NODE_METER ||
       np->type==NODE_LABEL || np->type==NODE_REPEAT ||
       np->type==NODE_LIMIT || np->type==NODE_VARIABLE )
      strcat(name, ":" );
    else
      strcat(name, "/" );

    if(np->name)
      strcat(name,np->name);
    else
      sprintf(name+strlen(name),"[%s]",node_name[np->type]);
  }
 
  return name;
}

sms_handle *sms_node_find_handle(sms_node *np)
/**************************************************************************
?  Return the handle where this node belongs to
=  NULL if it can not be traced.
************************************o*************************************/
{
  sms_handle *hp = sms_._logins;

  while( np && np->parent )
    np = np->parent;

  if(!np) return 0;                /* Shouldn't really happen ... */

  if(np->type != NODE_SUPER) return 0;

  for( ; hp ; hp=hp->next )
    if( hp->super == np )
      return hp;

  if( np==sms_._super && !sms_._logins->super ) 
    return sms_._logins;           /* CDP command */

  return 0;
}

char *sms_node_net_name(void *anything)
/**************************************************************************
?  Return the net node name in static area.
|  Current implementation starts the net name by the '@'.
NOTICE!  If the name returned is to be used, make a local copy of it
|  eg strdup(sms_node_net_name(np)) ...
!  Processing node types: EVENT METER LABEL LIMIT
|                         REPEAT TASK FAMILY SUITE SUPER
************************************o*************************************/
{
  static char name[MAXLEN];

  sms_node   *np = anything;
  sms_handle *hp = 0;

  if(!np) return 0;                /* This really is an error! */

  name[0] = 0;

  if( (hp=sms_node_find_handle(np)) )
    sprintf(name,"//%s",STR(hp->name));

  strcat(name,sms_node_full_name(np));

  return name;
}

sms_node *sms_node_net_find(char *name)
/**************************************************************************
?  Find the node that matches the name in any SMS connected
|  Either the net name or the full name of the node must have been given
=  NULL if not found or if the name was illegal otherwise the NODE.
|
|  Net name is of form:
|
|  [sms:]//host.name[:port]/[suite[/family[/task[:{event|meter|lebel|repeat|limit}]]]]
|
|  Full name is of form:
|
|  /[suite[/family[/task[:{event|meter|lebel|repeat|limit}]]]]
|
************************************o*************************************/
{
  char        buff[MAXNAM];
  char       *s = buff;
  char       *n = name;

  sms_handle *hp;
  sms_node   *np;

  if( !name || !*name ) return 0;

  /*
   *  Cut out the WEB protocol, if any (we are not interested of it)
   */

  while( *n && isalpha(*n) )
    n++;

  if( strncmp(n,"://",3) == 0 )
    name = n+1;

  if( strncmp(name,"//",2) != 0 )
    return sms_node_find_full(name);

  name += 2;
  n = name;

  /* Get the host and the node name */

  if( ! (s=strchr(name, '/')) )
    return 0;
  
  strncpy(buff, name, s-name);
  buff[s-name] = 0;

  name = s;                        /* name now point to the super */

  if( (s=strchr(buff,':')) )       /* buff now has the host name */
    *s = 0;

  if( ! (hp = ls_find(&sms_._logins,buff)) )
    return 0;

  np = (hp->super)? hp->super : sms_._super;

  if( ! name[1] )
    return np;

  np = sms_node_find( name , np );

  return np;
}

void sms_node_before_send(sms_node *np)
/**************************************************************************
?  Prepare the node for the writing:
|  - into checkpoint file
|  - on 'wire'
|  In order to write a node:
|  - All triggers has to have character representation.
|  - The suite clock is updated.
|  - The time dependent variables are updated. (in suite and the globals)
*
*  At the moment there is really nothin' 2 do.
*
************************************o*************************************/
{
  if(TRUE) return;

  while( np )
  {
    sms_node_before_send( np->kids );

    if( np->trigger )
      ;
    /* Name should be there already! */

    if( np->type == NODE_SUITE )
      if( np->status == STATUS_UNKNOWN )

#ifdef IMPOSSIBLE
        sms_time_t( &np->stime );
#else
        ;
#endif

    np = np->next;
  }
}

int sms_node_get_trigger(sms_tree *trg, sms_node *ref)
/**************************************************************************
?  Find the trigger nodes by the reference.
=  TRUE  if everything could be find.
|  FALSE if any of the names were missing.
************************************o*************************************/
{
  int  status = (-1);              /* If the trigger is in status_name */
  char buff[MAXNAM];

  if( !trg ) return TRUE;

  if( ! sms_node_get_trigger(trg->left ,ref ) ) return FALSE;
  if( ! sms_node_get_trigger(trg->right,ref ) ) return FALSE;

  if( trg->name )
  {
    if( sms_is_number(trg->name) )
      return TRUE;

    if( isalpha(trg->name[0]) )
      status = ioi_user_cmdf(trg->name,status_names,NULL,STATUS_NAMES_MAX);

    if( status == (-1) )
      if( ! (trg->math = sms_node_find( trg->name,ref )) )
#ifdef SMS_CROSS_SUITE
        if( sms_._is_server || !is_playing ||
            sms_list_find(&external_nodes,trg->name) )
          return TRUE;
        else
#endif
        {
          return
            ioi_out(FALSE,IOI_ERR,"SMS-NODE-GET-TRIGGER:%s not found (ref %s)",
                    STR(trg->name),STR(sms_node_full_name(ref)));
        }
      else
        if( trg->math->type == NODE_LABEL )
          return
            ioi_out(FALSE,IOI_ERR,"SMS-NODE-GET-TRIGGER:%s is label (ref %s)",
                    STR(trg->name),STR(sms_node_full_name(ref)));
  }

  return TRUE;
}

void sms_node_update(sms_node *np, nid_func func, void *userdata)
/**************************************************************************
?  Update a node (after receive or NID update)
************************************o*************************************/
{
  sms_variable_generate(np,FALSE,FALSE,func,userdata);
  sms_repeat_variable(np,func,userdata);

  if( np->type == NODE_SUITE )
    sms_time_suite(np,FALSE,func,userdata);  /* NOT a begin command */
}

sms_node *sms_node_parents(sms_node *np, sms_node *parent)
/**************************************************************************
?  Rebuild the parents after the play/send.
|  This routine succeeds always.
|  Generated variables are recreated.
************************************o*************************************/
{
  sms_event    *e;
  sms_meter    *m;
  sms_label    *l;
  sms_repeat   *r;
  sms_variable *v;
  sms_trigger  *t;
  sms_time     *tp;
  sms_date     *dp;
  sms_limit    *lim;
  sms_inlimit  *ip;

  while(np)
  {
    np->parent = ( np == parent )? NULL : parent;

    if( np->kids )
      sms_node_parents(np->kids,np);

    for( e = np->event ; e ; e = e->next )
      e->parent = np;
    for( m = np->meter ; m ; m = m->next )
      m->parent = np;
    for( l = np->label ; l ; l = l->next )
      l->parent = np;
    for( r = np->repeat ; r ; r = r->next )
      r->parent = np;
    for( v = np->variable ; v ; v = v->next )
      v->parent = np;
    for( t = np->trigger ; t ; t = t->next )
      t->parent = np;
    for( t = np->complete ; t ; t = t->next )
      t->parent = np;
    for( tp = np->time ; tp ; tp = tp->next )
      tp->parent = np;
    for( dp = np->date ; dp ; dp = dp->next )
      dp->parent = np;
    for( lim = np->limit ; lim ; lim = lim->next )
      lim->parent = np;
    for( ip = np->inlimit ; ip ; ip = ip->next )
      ip->parent = np;
    for( tp = np->late ; tp ; tp = tp->next )
      tp->parent = np;

    sms_node_update(np, NULL, 0);

    np = np->next;
  }

  return 0;
}

int sms_node_get_limit(sms_inlimit *ip, sms_node *ref)
/**************************************************************************
?  Find a limit by name
=  Boolean status
************************************o*************************************/
{
  sms_node  *tmp = ref;
  sms_limit *lp;

  if( !ip ) return TRUE;

  for( tmp=ref ; tmp && tmp->type != NODE_SUPER ; tmp=tmp->parent )
    if( (lp=ls_find(&tmp->limit, ip->name)) )
    {
      ip->limit = lp;
      return TRUE;
    }

  if( ! (ip->limit=(sms_limit *)sms_node_find(ip->name, ref)) )
#ifdef SMS_CROSS_SUITE
    if( sms_._is_server || !is_playing ||
        sms_list_find(&external_nodes,ip->name) )
      return TRUE;
    else
#endif
    {
      return
        ioi_out(FALSE,IOI_ERR,"SMS-NODE-GET-LIMIT:%s not found (ref %s)",
                STR(ip->name),STR(sms_node_full_name(ref)));
    }
  else
  {
    if( ip->limit->type != NODE_LIMIT )
    {
      ioi_out(0,IOI_ERR,"SMS-NODE-GET-LIMIT:%s is label (ref %s)",
              STR(ip->name),STR(sms_node_full_name(ref)));

      ip->limit = 0;
      return FALSE;
    }
  }

  return TRUE;
}

int sms_node_triggers(sms_node *np, sms_node *parent)
/**************************************************************************
?  Rebuild the node triggers from the names.
=  BOOLEAN status.
************************************o*************************************/
{ 
  while(np)
  {
    sms_trigger *tp;
    sms_inlimit *ip;

    if( np->kids )
      if( ! sms_node_triggers(np->kids,np) )
        return FALSE;

    if(np->trigger)  np->trigger->mod_no  = sms_._modify_number;
    if(np->complete) np->complete->mod_no = sms_._modify_number;
    for( ip=np->inlimit ; ip ; ip=ip->next )
      ip->mod_no  = sms_._modify_number;

#ifdef SMS_CROSS_SUITE
    if( ! sms_._is_server )      /* Fail only on CDP size */
    {
      if(np->trigger) 
        if( ! (sms_node_get_trigger(np->trigger->math,np)) )
          return FALSE;

      if(np->complete)
        if( ! (sms_node_get_trigger(np->complete->math,np)) )
          return FALSE;

      for( ip=np->inlimit ; ip ; ip=ip->next )
        if( ! sms_node_get_limit(ip,np) )
          return FALSE;
    }
    else
    {
      if(np->trigger)  sms_node_get_trigger(np->trigger->math,np);
      if(np->complete) sms_node_get_trigger(np->complete->math,np);
      for( ip=np->inlimit ; ip ; ip=ip->next )
        sms_node_get_limit(ip,np);
    }
#else
    if(np->trigger) 
      if( ! (sms_node_get_trigger(np->trigger->math,np)) )
        return FALSE;

    if(np->complete)
      if( ! (sms_node_get_trigger(np->complete->math,np)) )
        return FALSE;

    for( ip=np->inlimit ; ip ; ip=ip->next )
      if( ! (sms_node_get_limit(ip,np)) )
        return FALSE;
#endif

    np = np->next;
  }

  return TRUE;
}

sms_node *sms_node_after_receive(sms_node *np)
/**************************************************************************
?  Rebuild the suites after play/send
=  np, node given if everything is ok.
|  NULL, if any errors. All memory is freed.
************************************o*************************************/
{ 
  sms_node  *orig = np;

  is_validating = TRUE;

#if 0
  if(np->type == NODE_SUPER && !sms_._is_server)
    np->parent = (sms_node *)sms_._logins;
#endif

  while(np)                        /* Loop over the suites */
  {
    sms_node_parents(np,(np->parent)?np->parent:np);

    if( ! sms_node_triggers(np,np) )
      return
        sms_node_free(orig);

    np = np->next;
  }

  is_validating = FALSE;

  return orig;
}

int sms_node_write(sms_node *np, char *name)
/**************************************************************************
?  Write the node into the file named.
|  We are using XDR to make sure it will come back on any machine.
=  BOOLEAN status.
!  It's a binary file!
************************************o*************************************/
{
  FILE        *fp;
  XDR          x;
  enum xdr_op  x_op = XDR_ENCODE;
  int          rc   = FALSE;
  int       (* output)(int, int, char*, ...); 
            /* Depends of the application */
  sms_check    cp,*ccp = &cp;      /* The header. | yeps! the XDR needs  */
  sms_status   sp,*ssp = &sp;      /* The body!   | pointers to pointers */

  int                old_xdr_version = sms_._xdr_version;
  char        *buf = 0;

  cp.type = NODE_CHECK;
  cp.prog = sms_._prog;
  cp.vers = SMS_VERSION_NUMBER;
  cp.time = sms_time_t(NULL);

  sp.action_n = sms_._action_number;
  sp.modify_n = sms_._modify_number;
  sp.status   = sms_._handle;      /* NOTICE! Fooled U! */
  sp.node     = sms_._super;

  if( sms_._is_server )
    cp.user = NIL;                 /* SMS! */
  else
  {
    cp.user = getuid();

    memset(&sp,0,sizeof(sp));
  }
  sp.node = np;
  sp.type     = NODE_STATUS;

  sms_node_before_send(sp.node);

  output = (sms_._is_server)? spit : ioi_out;

  if( ! (fp=sms_fopen(name,"w","SMS-NODE-WRITE")) ) return FALSE;

  if( SMS_CHECKBUFFER > BUFSIZ)
    if( (buf=malloc(SMS_CHECKBUFFER + 8)) )
      if( setvbuf(fp, buf, _IOFBF , SMS_CHECKBUFFER + 8) )
      {
        free(buf);
        fclose(fp);
        return output(0,IOI_ERR,"SMS-NODE-WRITE:setvbuf failed for %s",STR(name));
      }
      else
        ;
    else
      output(1,IOI_LOG,"SMS-NODE-WRITE:no buffer, doing without");

  sms_._xdr_version = SMS_REVISION * 1000 + SMS_MODIFICATION;
  sms_._xdr_privs   = XDR_SERVER;  /* Can be left, return is text only */

  xdrstdio_create(&x,fp,x_op);

  if(sms_xdr_pointer(&x,(sms_list **)&ccp))
    rc = sms_xdr_pointer(&x,(sms_list **)&ssp);

  sms_._xdr_version = old_xdr_version;

  if( ! rc )
    output(FALSE,IOI_ERR,"SMS-NODE-WRITE:Write failed for %s",STR(name));

  xdr_destroy(&x);
  fclose(fp);
  IFFREE(buf);
  return rc;
}

int sms_node_read(char *name, sms_status **sp)
/**************************************************************************
?  Read the node from the file named.
|  We are using XDR to make sure it will come back on any machine.
!  It's a binary file!
=  BOOLEAN status.
************************************o*************************************/
{
  int                old_xdr_version = sms_._xdr_version;
  FILE              *fp;
  XDR                x;
  enum xdr_op        x_op = XDR_DECODE;
  int                rc   = FALSE;
  int             (* output)(int, int, char*, ...);    /* Depends of the application */
  static sms_check   cp,*ccp;      /* The header. | yeps! the XDR needs  */
  static sms_status *ssp;          /* The body!   | pointers to pointers */

  int vers;
  int rev;
  int mod;

  output = (sms_._is_server)? spit : ioi_out;

  if( ! (fp=sms_fopen(name,"r","SMS-NODE-READ")) ) return FALSE;

  xdrstdio_create(&x,fp,x_op);

  ccp = &cp;
  ssp = NULL;

  if( sms_xdr_pointer(&x,(sms_list **)&ccp) )
  {
    if( ! sms_._is_server )
    {
      output(0,IOI_MSG,"SMS-NODE-READ:%s is %d.%d",STR(name),cp.prog,cp.vers);
      output(0,IOI_MSG,"SMS-NODE-READ:written %s by %d",
             STR(sms_time_c((time_t *)&(cp.time))),cp.user);
    }

    if( cp.prog != sms_._prog )
    {
      output(0,IOI_WAR,"SMS-NODE-READ:!------------------------------------!");
      output(0,IOI_WAR,"SMS-NODE-READ:%s was written by %d not by %d",
             STR(name), cp.prog, sms_._prog);
      output(0,IOI_WAR,"SMS-NODE-READ:!------------------------------------!");
    }

    if( cp.vers == 1 )
    {
      output(0,IOI_WAR,"SMS-NODE-READ:%s is older than 4.3.10",STR(name));
      vers = 4;
      rev  = 3;
      mod  = 1;
    }
    else
    {
      vers =  cp.vers / 10000;
      rev  = (cp.vers % 10000) / 1000;
      mod  = (cp.vers %  1000);
    }

    if( rev != SMS_REVISION || mod != SMS_MODIFICATION )
    {
      output(0,IOI_WAR,"SMS-NODE-READ:!------------------------------------!");
      output(0,IOI_WAR,"SMS-NODE-READ:%s is %d.%d.%d and SMS is %d.%d.%d",
             STR(name), vers, rev, mod,
             SMS_VERSION,SMS_REVISION,SMS_MODIFICATION);
      output(0,IOI_WAR,"SMS-NODE-READ:!------------------------------------!");
    }

    sms_._xdr_version = rev * 1000 + mod;
    sms_._xdr_privs   = XDR_SERVER;  /* Can be left, return is text only */

    if( vers == SMS_VERSION )
      if( sms_xdr_pointer(&x,(sms_list **)&ssp) )
      {
        rc = TRUE;

        if( !sp )
        {
          if( ssp->node )            /* An empty file? */
            if( !(ssp->node=sms_node_after_receive(ssp->node)) )
              rc=output(FALSE,IOI_WAR,"SMS-NODE-READ:verifiaction problem");

          if( rc )
          {
            sms_node     *tmp;
            sms_variable *var;

            if( sms_._is_server )    /* Save the global variables */
            {
              var = sms_._super->variable;
              sms_._super->variable = NULL;
            }

            NODE_FREE( sms_._super,sms_node );

            if(!sms_._is_server)
            {
              sms_._action_number = ssp->action_n;
              sms_._modify_number = ssp->modify_n;
            }

            if( ssp->status > sms_._handle )
              sms_._handle        = ssp->status; /* NOTICE! Fooled U! */

            sms_._super         = ssp->node;

            if( sms_._is_server )    /* Load the old variables back */
            {
              while( var )
              {
                sms_variable *temp = var->next;
                sms_list_add(&sms_._super->variable,var);
                var = temp;
              }
              FLAG_CLEAR(sms_._super,FLAG_LOCKED);
            }

            for( tmp=sms_._super->kids ; tmp ; tmp=tmp->next )
              SUITE_MODIFIED(tmp);
          }
        }
        else
        {
          *sp = ssp;
           ssp = NULL;
        }
      }
      else output(0,IOI_ERR,"SMS-NODE-READ:read error in the body");
    else output(0,IOI_WAR,"SMS-NODE-READ:File version or program mismatch");
  }
  else output(0,IOI_ERR,"SMS-NODE-READ:read error in the header");

  if( !rc )
  {
    output(0,IOI_ERR,"SMS-NODE-READ:Read failed for %s",STR(name));
    
    if( ssp ) NODE_FREE( ssp->node,sms_node );
  }

  IFFREE(ssp);

  xdr_destroy(&x);
  fclose(fp);

  sms_._xdr_version = old_xdr_version;

  return rc;
}

int sms_node_check(void)
/**************************************************************************
?  Write a checkpoint file.
|  Used by the SMS itself.
=  SMS-RETURN-CODE
~  sms_cmd_check()
************************************o*************************************/
{
  char *name;
  char *oldname;

  static int count;

  sms_._xdr_version = SMS_REVISION * 1000 + SMS_MODIFICATION;

  if( ! sms_._super->kids )
    return spit(SMS_E_OK,IOI_WAR,"checkpoint:nothing defined, ignored");

  if( ! (name=sms_variable_get("SMSCHECK",NULL)) )
    return sms_error(SMS_E_GLOBALVAR,"checkpoint:%s","SMSCHECK");

  if( (oldname=sms_variable_get("SMSCHECKOLD",NULL)) )
    if(access(name,F_OK) == 0)     /* name exists */
      if( rename(name,oldname) == NIL )
        spit(0,IOI_ERR,"check:rename failed from  %s to %s",STR(name),STR(oldname));

  if( !sms_node_write(sms_._super,name) )
    return sms_error(SMS_E_WRITE,"checkpoint:%s",STR(name));

  sms_time_t(&sms_._check_last);

  if( sms_._check_mode == CHECK_ALWAYS )
  {
    if(count >= 100) 
    {
      spit(0,IOI_LOG,"checkpoint:written into %s by SMS x 100",STR(name));
      count=0;
    }
    else
      count++;
  }
  else
  {
    spit(0,IOI_LOG,"checkpoint:written into %s by SMS",STR(name));
    count = 0;
  }
  
  return SMS_E_OK;
}

static void sms_node_clear_labels(sms_node *np)
{
  sms_label *lp;

  for( lp=np->label ; lp ; lp=lp->next )
    if(lp->value)
    {
      IFFREE(lp->value);
      lp->value = strdup(lp->def);
      SUITE_CHANGED((sms_node *)lp);
    }

  for(np=np->kids ; np ; np=np->next)
    sms_node_clear_labels(np);
}

int sms_node_begin(
    sms_node *np,                  /* At the moment must be a suite    */
    int       byuser)              /* A flag telling it's a user / SMS */
/**************************************************************************
?  Begin the node (got 2 B SUITE)
*NA \|/
|  If the SUITE has dependencies (eg time, day) nothing will actually
|  happen, except that the suite starts to wait the dependencies.
*NA /|\   (doesn't actually work)
************************************o*************************************/
{
  sms_migrate_init(np);

  sms_status_default(np);
  sms_time_suite(np,TRUE,NULL,NULL);
  sms_time_mark(np);
  sms_time_waiting(np);

  sms_time_autocm_init(np);
  sms_repeat_init(np);
  sms_log_begin(np);
  sms_node_clear_labels(np);
  sms_limit_init(np);

  if(byuser)
    spit(0,IOI_MSG,"begin:%s started by %s",STR(sms_node_full_name(np)),STR(SMS_USER));
  else
  {
#ifdef SMS_STATISTICS
    smss_._auto_begin++;
#endif
    spit(0,IOI_MSG,"begin:%s started automatically",STR(sms_node_full_name(np)));
  }

  return TRUE;
}

int sms_node_requeue(
    sms_node *np,                  /* Node to be repeated         */
    int       repeat)              /* Is it because of repetition */
/**************************************************************************
?  Requeue a node. Used by the requeue command and repeated nodes
************************************o*************************************/
{
  sms_node *kid;

  sms_migrate_init(np);
  sms_status_default(np);

  if(np->type == NODE_SUITE) sms_time_suite(np,TRUE,NULL,NULL);
  else                       sms_time_load(np);

  sms_time_mark(np);
  sms_time_waiting(np);
  sms_time_autocm_init(np);

  if( repeat )
    for( kid=np->kids ; kid ; kid=kid->next )
      sms_repeat_init(kid);
  else
    sms_repeat_init(np);

  sms_node_clear_labels(np);

  if(np->type != NODE_ALIAS)
  sms_status_change(np->parent,sms_status_max(np->parent->kids),FALSE,FALSE);

  if( ! repeat )
    spit(0,IOI_MSG,"requeue:user %s:%s",STR(SMS_USER),STR(sms_node_full_name(np)));

  return 0;
}

static void sms_node_init(sms_node *np)
/**************************************************************************
?  Clear meters, events, labels, and repeat silently
************************************o*************************************/
{
  sms_event  *ep = np->event;
  sms_meter  *mp = np->meter;
  sms_repeat *rp = np->repeat;

  while( ep )
  {
    ep->act_no = ++sms_._action_number;
    ep->status = EVENT_CLEAR;
    ep = ep->next;
  }

  while( mp )
  {
    mp->act_no = ++sms_._action_number;
    mp->status = mp->min;
    mp = mp->next;
  }

  sms_node_clear_labels(np);

  while( rp )
  {
    rp->act_no = ++sms_._action_number;

    if(rp->mode == REPEAT_INTEGER)
      rp->status = rp->start;
    else
      rp->status = 0;

    rp = rp->next;
  }
}

void sms_node_resubmit(sms_node *np, int aborted, int clear)
/**************************************************************************
?  Resubmit a node. Used by the resubmit command only.
************************************o*************************************/
{
  sms_node *kid;

  if(np->type==NODE_TASK || np->type==NODE_ALIAS)
  {
    int status = np->status;
    if(status == STATUS_SUSPENDED) status = np->savedstat;

    if( status==STATUS_SUBMITTED || status==STATUS_ACTIVE ||
        (aborted && status==STATUS_ABORTED) )
    {
      LOGGING(np);
      sms_status_change(np,STATUS_QUEUED,TRUE,FALSE);
      spit(0,IOI_LOG,"resubmit:%s by %s",STR(sms_node_full_name(np)),STR(SMS_USER));
      np->rid = 0;

      if(clear)
        sms_node_init(np);

      SUITE_CHANGED(np);
    }
  }
  else
    for( kid = np->kids; kid ; kid = kid->next )
      sms_node_resubmit(kid,aborted,clear);

  LOGGING(np);
}

void sms_node_run(sms_node *np, int force, int init)
/**************************************************************************
?  Run a node. Used by the run command only.
************************************o*************************************/
{
  sms_node *kid;

  if(np->type == NODE_TASK || np->type==NODE_ALIAS)
  {
    int status = np->status;
    if(status == STATUS_SUSPENDED) status = np->savedstat;

    if( force ||
        (status != STATUS_SUBMITTED && status != STATUS_ACTIVE) )
    {
      LOGGING(np);
      spit(0,IOI_LOG,"run:%s by %s",STR(sms_node_full_name(np)),STR(SMS_USER));

      if(init)
        sms_node_init(np);

      np->tryno++;
      sms_edit_send(np);
      np->rid = 0;
    }
  }
  else
    for( kid = np->kids; kid ; kid = kid->next )
      sms_node_run(kid,force,init);

  LOGGING(np);
}

/*
 *  Used by the MKDIRS & TOUCH
 */
static sms_list *start_f,*end_f;

static touch(
    char      *name,               /* The name of the file           */
    int        mode,               /* File protection mode           */
    sms_event *ep,                 /* Write setev's for all of these */
    int        t_sleep,            /* Sleep time before endt         */
    int        e_sleep,            /* Sleep time before setev        */
    int        overwrite,          /* Overwrite existing files       */
    double     abort_rate)         /* How often should the job fail  */
/**************************************************************************
?  Create a job file that has some sleeps in between and all the events
|  in a sequence.
|  Used by the CDP only
=  BOOLEAN status (was the file created?);
************************************o*************************************/
{
#undef ROOT

#ifndef VMS
#  define ROOT "$SMSBIN/"
#else
#  define ROOT "$ "
#endif

  FILE *fp;
  sms_list  *start = start_f;    /* Copy these into the new file   */
  sms_list  *end   = end_f;

  if( !overwrite && !access(name,F_OK)) return TRUE;

  if( fp=fopen(name,"w") )
  {
    if(start)
      for( ; start ; start=start->next )
        fprintf(fp,"%s\n",STR(start->name));
    else
    {
      fprintf(fp,"#!/bin/csh -f\n");
      fprintf(fp,"\n");
      fprintf(fp,"setenv SMSNAME %%SMSNAME%%\n");
      fprintf(fp,"setenv SMSNODE %%SMSNODE%%\n");
      fprintf(fp,"setenv SMSPASS %%SMSPASS%%\n");
      fprintf(fp,"\n");
    }

    fprintf(fp,"%ssmsinit\n",STR(ROOT));

    while( ep )
    {
#ifndef VMS
      fprintf(fp,"sleep %d\n",e_sleep);
#else
      {
        int h = e_sleep / 3600;
        int m = (e_sleep % 3600) / 60;
        int s = e_sleep % 60;
        fprintf(fp,"$ wait %02d:%02d:%02d\n",h,m,s);
      }
#endif
      fprintf(fp,"%ssetev %s\n",STR(ROOT),STR(ep->name));
      ep = ep->next;
    }

    
#ifndef VMS
    fprintf(fp,"\n");
    fprintf(fp,"sleep %d\n",t_sleep);
    fprintf(fp,"\n");
#else
      {
        int h = t_sleep / 3600;
        int m = (t_sleep % 3600) / 60;
        int s = t_sleep % 60;
        fprintf(fp,"$ wait %02d:%02d:%02d\n",h,m,s);
      }
#endif

    if( abort_rate > 0.0 )
      fprintf(fp,"%ssmsrand %g && %sabtt || %sendt\n",
              STR(ROOT),abort_rate,STR(ROOT),STR(ROOT));
    else
      fprintf(fp,"%sendt\n",STR(ROOT));

    for( ; end ; end=end->next )
        fprintf(fp,"%s\n",STR(end->name));

    fclose(fp);
    chmod(name,mode); 
  }
  else
    return ioi_perror("touch",0);

  return TRUE;

#undef ROOT
}

int sms_node_mkdir(
    sms_node *np,
    char     *base,                /* Path name for the new files    */
    char     *start,               /* Start every file by this       */
    char     *end,                 /* End every file by this         */
    int       t_sleep,             /* Sleep time before endt         */
    int       e_sleep,             /* Sleep time before setev        */
    int       overwrite,           /* Overwrite existing files       */
    double    abort_rate,          /* How often should the job fail  */
    int       verbose)
/**************************************************************************
?  Create the directories and the job files for the current suite(s)
************************************o*************************************/
{
  char  buff[MAXNAM];
  FILE *fp;
  int   ok = TRUE;

  if( start )
    if( ! sms_file_read(start,&start_f,MAXLINES) )
      return FALSE;

  if( end )
    if( ! sms_file_read(end,&end_f,MAXLINES) )
    {
      NODE_FREE(start_f,sms_list);
      return FALSE;
    }

  while( np && ok )
  {
    if( np->type == NODE_TASK )
    {
      sprintf(buff,"%s%s.sms",base?base:".",STR(sms_node_full_name(np)));

      if( verbose ) printf("TOUCH %s\n",STR(buff));

      ok = touch(buff,0755,np->event,t_sleep,e_sleep,overwrite,abort_rate);
    }
    else
    {
      sprintf(buff,"%s%s",base?base:".",STR(sms_node_full_name(np)));

      if( (ok=mkdir(buff,0755)==0) )
        if( verbose ) printf("MKDIR %s\n",STR(buff));
        else ;
      else
        if( errno==EEXIST )
          if( verbose ) printf("MKDIR %s exists\n",STR(buff));
          else ;
        else
          sms_perror("mkdirs");

      if( ok || errno == EEXIST )
        ok = sms_node_mkdir(np->kids,base,NULL,NULL,
                       t_sleep,e_sleep,overwrite,abort_rate,verbose);
    }
    np = np->next;
  }

  if( start )
  {
    NODE_FREE(start_f,sms_list);
    NODE_FREE(end_f,sms_list);
  }

  return TRUE;
}

