/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     LOGGEN
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     23-SEP-1992 / 07-APR-1992 / OP
.VERSION  4.1
.DATE     06-AUG-1993 / 06-AUG-1993 / OP
.VERSION  4.2
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     loggen.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     11-NOV-1998 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
.DATE     11-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
* cdp_loggen_cmd(int argc, char **argv)
*
************************************o*************************************/

#include "smslib.h"

static sms_variable *nodes;

static int printtime;
static int printuser;
static int printlabel;
static int printmeter;

static time_t str2t(char *s)
/**************************************************************************
?  Convert string s to time_t (GMT seconds) SMS-logfile format
=  0 if errors.
************************************o*************************************/
{
  struct tm tm;

  memset(&tm,0,sizeof(tm));

  if( sscanf(s,"%d:%d:%d %d.%d.%d",
             &tm.tm_hour , &tm.tm_min , &tm.tm_sec ,
             &tm.tm_mday , &tm.tm_mon , &tm.tm_year )
       == 6 )
  {
    tm.tm_mon++;
    if( tm.tm_year > 99 ) tm.tm_year -= 1900;

    return (time_t)sms_time_gmt(&tm);
  }
  else
    return 0;
}

static void timestamp(time_t t)
{
  struct tm *tm;

  if( ! printtime ) return;

  tm = sms_time_tm(&t);
  printf("TIME %02d:%02d:%02d\n", tm->tm_hour, tm->tm_min, tm->tm_sec);
}

static void usercmd()
{
  if( ! printuser ) return;

  printf("USERCMD\n");
}

static gen(
    char   *file,                  /* The file to be read      */
    char   *suite,                 /* Only nodes in this suite */
    time_t  ts,                    /* Start & end times        */
    time_t  te)
/**************************************************************************
?  Read file and process lines.
|  If suite was given only nodes belonging into it are processed.
|  If the times are given, only entries inside the range are are processed.
************************************o*************************************/
{
  FILE         *fp;
  char          buff[MAXLEN];
  char         *cmd;               /* The command used       */
  char         *path;              /* For this node          */
  time_t        t;                 /* Time stamp on the line */
  sms_node     *np;
  sms_variable *vp;

  if( !(fp=sms_fopen(file,"r","loggen")) )
    return FALSE;

  while( fgets(buff,MAXLEN,fp) )
    if( buff[0] == '#' )
    {
      char *s = buff;

      sms_no_newline(buff);

      while( *s && *s != '[' )     /* Skip till start of time-stamp */
           s++;   
      if( *s ) s++;

      if( (t=str2t(s)) > 0 )
        if( ts <= t && t <= te )
        {
          while(*s && *s != ']') s++; 
          if( *s ) s++;            /* Skip till the end of time-stamp */
          while( *s == ' ' ) s++;
          cmd = s;

          while(*s && *s != ':' ) s++;

          if( *s==':' )
          {
            *s++ = '\0';
            path = s;
            while(*s && (isalnum(*s) || *s=='_' || *s=='/' || *s==':')) s++;
            *s++ = '\0';

            np=sms_node_find_full(path);

            if( np && suite )
            {
              sms_node *father = np;

              while(father && father->type != NODE_SUITE )
                father=father->parent;

              if(father && strcmp(father->name,suite))
                np=NULL;
            }

            if(np)
            {
              if(strncmp(s,"to ",3) == 0)
                s += 3;

              if( ioi_user_cmdf(cmd,status_names,NULL,STATUS_USABLE+2) != NIL )
                if( np->type == NODE_TASK || np->type == NODE_EVENT )
                {
                  timestamp(t);
                  printf("force -q %s %s\n",STR(cmd),STR(path));
                  usercmd();
                }

              if( printmeter && strcmp(cmd,"meter") == 0 )
                if( np->type == NODE_METER )
                {
                  timestamp(t);
                  printf("alter -m %s %s\n",STR(path),STR(s));
                  usercmd();
                }

              if( printlabel && strcmp(cmd,"label") == 0 )
                if( np->type == NODE_LABEL )
                {
                  char *sp;

                  timestamp(t);
                  printf("alter -l %s",STR(path));

                  for( sp=s ; *sp ; sp++ )
                    if( *sp == '|' )
                    {
                      *sp = '\0';
                      printf(" \"%s\"", STR(s));
                      s = sp+1;
                    }
                  printf(" \"%s\"\n",STR(s));
                  usercmd();
                }

#if 0
              if( strcmp(cmd,"repat") == 0 )
                if( np->type == NODE_REPEAT )
                {
                  timestamp(t);
                  printf("alter -l %s %s\n",STR(path),STR(s));
                  usercmd();
                }
#endif

            }

          }
        }
    }

#if 0
  for( vp=nodes ; vp ; vp=vp->next )
    printf("force -q %s %s\n",STR(vp->value),STR(vp->name));
    /* printf("force -q %s %s\n",STR(vp->name),STR(vp->value)); */
  NODE_FREE(nodes,sms_variable);
#endif

  fclose(fp);
  return TRUE;
}

int cdp_loggen_cmd(int argc, char **argv)
/**************************************************************************
?  CDP command loggen
************************************o*************************************/
{
  static int   called;
  static char *begin;
  static char *end;
  static char *suite;
  static char *file;

  if( called )
  {
    time_t    ts=0,te=(1<<30);
    char     *s;

    if(begin)
    {
      for( s=begin ; *s ; s++ ) if( *s=='-' ) *s=' ';
      if( (ts=str2t(begin)) == 0 )
        return ioi_out(0,IOI_ERR,"loggen:bad begin time: %s",STR(begin));
    }

    if(end)
    {
      for( s=end   ; *s ; s++ ) if( *s=='-' ) *s=' ';
      if( (te=str2t(end)) == 0 )
        return ioi_out(0,IOI_ERR,"loggen:bad end time: %s",STR(end));
    }

    if( sms_cdp_update(HANDLE) != SMS_E_OK ) return 0;

    if(suite)
      if( ! sms_list_find(&sms_._super->kids,suite) )
        return ioi_out(0,IOI_ERR,"loggen:suite %s doesn't exist",STR(suite));

    gen(file,suite,ts,te);

    return TRUE;
  }
  else
    ioi_exe_add("loggen:cdp",cdp_loggen_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-bbegin",IOI_L_STRING,ioi_exe_argv(
            "Begin time from the file in format HH:MM:SS-DD.MM.YYYY",
            "The default begin time is the first time in the SMS log file.",
            NULL
          ),NULL,1,&begin
        ),
        ioi_exe_param(
          "-eend",IOI_L_STRING,ioi_exe_argv(
            "End time from the file in format HH:MM:SS-DD.MM.YYYY",
            "The default end time is the last time in the SMS log file.",
            NULL
          ),NULL,1,&end
        ),
        ioi_exe_param(
          "-ssuite",IOI_L_STRING,ioi_exe_argv(
            "Process only the suite given.",
            NULL
          ),NULL,1,&suite
        ),
#if 1
        ioi_exe_param(
          "-llabel",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add label changes into the output.",
            NULL
          ),NULL,1,&printtime
        ),
        ioi_exe_param(
          "-mmeter",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add meter changes into the output.",
            NULL
          ),NULL,1,&printmeter
        ),
        ioi_exe_param(
          "-time",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add time commands into the output.",
            NULL
          ),NULL,1,&printtime
        ),
        ioi_exe_param(
          "-uuserproc",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add user command into the output.",
            NULL
          ),NULL,1,&printuser
        ),
#endif
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "logfile",IOI_L_PATH,ioi_exe_argv(
            "The SMS log-file to be processed.",
            NULL
          ),NULL,-1,&file
        ),
        NULL
      ),
      ioi_exe_argv(
        "Generate CDP-commands from the logfile for a suite.",
        "The logfile is read and lines between the BEGIN-time and END-time",
        "specified are used to create force commands in order to bring the",
        "suite(s) in the state at the END time.",
        "",
        "The minus sign between the time and date can be a space, but then",
        "the space must be escaped from the shell by quoting eg:",
        "loggen -b \"time date\" ...",
        "",
        "The suite definition must be known by the SMS. Use get/play/status.",
        NULL
      )
    );

  return called = TRUE;
}

