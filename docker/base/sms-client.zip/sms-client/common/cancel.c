/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CANCEL
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     cancel.c
.DATE     29-JUL-1992 / 01-SEP-1991 / OP
.VERSION  4.0
.DATE     22-SEP-1994 /  25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     09-DEC-1994 / 08-DEC-1994 / OP
.VERSION  4.3.4
*         Node migration support
.DATE     09-MAR-1995 / 09-MAR-1995 / OP
.VERSION  4.3.5
*         Automigration support
.DATE     07-FEB-1997 / 07-FEB-1997 / OP
.VERSION  4.3.14
*         Bug fix for the triggers
*         Update the info command
.DATE     23-APR-1998 / 23-APR-1998 / OP
.VERSION  4.3.18
*         Repeat has a name now
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     11-JAN-1999 / 30-OCT-1998 / OP
.VERSION  4.4
*         Zombie passwords
*         Aliased tasks
.DATE     04-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  Node cancelling logic.
*
*  NOTICE!
*
*  Cancelling is non-recoverable action. The things cancelled are removed
*  permanently. These routines do not actually remove anything, they
*  just checks can the node be cancelled except the sms_cancel().
*
************************************o*************************************/

#include "smslib.h"

static void mark_tree(
    sms_tree *tp,
    int       add)                 /* Direction: +1 / -1 */
/**************************************************************************
?  Go down the tree to calculate the connections.
************************************o*************************************/
{
  if( !tp ) return;

  mark_tree( tp->left  , add );
  mark_tree( tp->right , add );

  if( tp->math )
    if( tp->math->type == NODE_EVENT )
      tp->math->parent->user_int += add;
    else
      tp->math->user_int += add;
}

static void mark(sms_node *np, int add)
/**************************************************************************
?  Loop over the triggers and count the pointers.
************************************o*************************************/
{
  if( np->trigger )
    mark_tree( np->trigger->math , add );

  np = np->kids;
  while( np )
  {
    mark( np,add );
    np = np->next;
  }
}

static int count(sms_node *np)
/**************************************************************************
?  Check that all the nodes are free (the cancel counter is zero)
=  Number of dependencies.
************************************o*************************************/
{
  int rc = 0;

  if( np->user_int )
  {
    rc = np->user_int;
    spit(0,IOI_WAR,"dependencies:%s by %d others",STR(sms_node_full_name(np)),rc);
  }

  if(np->type==NODE_TASK || np->type==NODE_FAMILY || np->type==NODE_SUITE)

  for(np=np->kids; np ; np=np->next)   /* Only looping kids, not next! */
    rc += count(np);

  return rc;
}

int sms_cancellable(sms_node *np)
/**************************************************************************
?  The node can be cancelled if nothing outside of the node points into it.
|
|  Since we have single-direction pointers only the only possible way to
|  find out is someone pointing into this (or it's kids) is to loop over
|  the full tree.
|
|  For every pointer we increment the counter in the node pointed to and
|  then for every pointer internal to the tree being deleted we decremet
|  the counter.
|
|  If in the end any of the counters in the nodes not equals to zero there
|  must be someone outside the node pointing to it and the node can not
|  be cancelled.
=  Number of outside pointers.
|  0  --->  the node can be cancelled.
|  >0 --->  the node is dependent.
************************************o*************************************/
{
  sms_node *super;
  int rc;

  if(np->type==NODE_SUPER)         /* It really isn't a good idea, eh? */
    return 1;

  sms_node_clear_user_data(sms_._super);

  for( super=sms_._super ; super ; super=super->next )
    mark(super,1);

  if(np->type==NODE_TASK || np->type==NODE_FAMILY || np->type==NODE_SUITE)
    mark(np,-1);

  rc = count(np);

  sms_node_clear_user_data(sms_._super);

  return rc;
}

static int cancel_aliases(sms_node *np)
/**************************************************************************
?  Cancel aliases in node. Called by the SMS ONLY! (on user command)
|  No need to check the parent status since alias does not effect it
************************************o*************************************/
{
  if(np->type==NODE_ALIAS && np->status==STATUS_COMPLETE)
  {
    spit(0,IOI_LOG,"cancel:%s removed by %s",STR(sms_node_full_name(np)),STR(SMS_USER));
    SUITE_MODIFIED(np->parent);
    sms_list_delete(&np->parent->kids,np);
  }
  else
  {
    sms_node *next, *kids;

    for(kids=np->kids ; kids ; kids=next)
    {
      next = kids->next;
      cancel_aliases(kids);
    } 
  }

  return SMS_E_OK;
}

int sms_cancel(sms_node *np, int force, int aliases, int migrate)
/**************************************************************************
?  Cancel a node. Called by the SMS ONLY! (maybe on user command)
|  If force option is used the node is cancelled (that is removed) even
|  if it has external triggers.
************************************o*************************************/
{
  char *name = sms_node_full_name(np);

  if( ! sms_status_privilege( np ) )
    return sms_error(SMS_E_NOTOWNER,"cancel:%s",STR(name));
 
  if( np->type == NODE_SUPER )
    return sms_error(SMS_E_PRIVILEGE,"cancel:can't remove super-node");

  if(aliases)
    return cancel_aliases(np);
 
  if(force || migrate || sms_cancellable(np)==0)  /* No dependencies */
  {
    sms_node *parent=np->parent;       /* Must have != SUPER */
    int       type = np->type;

    if( ! migrate )
      if(sms_._current_con == NULL )
        spit(0,IOI_LOG,"autocancel:%s by SMS",STR(name));
      else
        spit(0,IOI_LOG,"cancel:%s by %s",STR(name),STR(SMS_USER));

    switch( type )
    {
      case NODE_ALIAS:
      case NODE_TASK:
      case NODE_FAMILY:
      case NODE_SUITE:
        if( ! migrate )
          sms_passwd_zombie(np);

        sms_list_delete(&parent->kids,np);
        if( ! migrate && type != NODE_ALIAS )
          sms_status_change(parent,sms_status_max(parent->kids),FALSE,FALSE);
        break;

      case NODE_LABEL:
        sms_list_delete(&parent->label,np);
        break;

      case NODE_METER:
        sms_list_delete(&parent->meter,np);
        break;

      case NODE_REPEAT:
        sms_list_delete(&parent->repeat,np);
        break;

      case NODE_EVENT:
        sms_list_delete(&parent->event,np);
        break;

      default:
        return sms_error(SMS_E_TYPE,"migrate: %s",STR(sms_node_full_name(np)));
    }

    SUITE_MODIFIED(parent);
    if(!migrate)
      GET_TRIGGERS;
  }
  else
    return sms_error(SMS_E_NOTFREE,"cancel:%s",STR(name));

  return SMS_E_OK;
}

void sms_cancel_auto(sms_node *np)
/**************************************************************************
?  Cancel a nodes automatically. Called by the SMS ONLY!
|
|  Syntax for autocancel is:
|
|  autocancel +01:00  cancel one hour after complete
|  autocancel 10      cancel 10 days after complete
|  autocancel 0       cancel immediately after being complete
************************************o*************************************/
{
  if(!np) return;

  while(np)
  {
    sms_node *next = np->next;   /* The np might disapper */

    if( sms_time_autocm(np,NODE_CANCEL) )
      sms_cancel(np,TRUE,FALSE,FALSE);
    else
      sms_cancel_auto(np->kids);
     
    np=next;
  }
}

char *sms_cancel_string(sms_node *np, int who)
/**************************************************************************
?  Print a description of a cancel structure into a string
|  ((( The same for automigration )))
|  One single line is produced if "r" is not NLLL
|  Used by XCdp
************************************o*************************************/
{
  static char  str[MAXNAM];
  char        *s;
  sms_time    *cp = np->autocm;

  str[0] = '\0';

  if( cp != NULL )
    if( who )                      /* XCdp */
    {
      if(cp->relative)
        sprintf(str,"relative +%02d:%02d",cp->hour[0],cp->minute[0]);
      else
        sprintf(str,"in %d days",cp->hour[0]);

      sms_time_autocm_string(np, str + strlen(str));
    }
    else
    {
      if(cp->relative)
        sprintf(str,"+%02d:%02d",cp->hour[0],cp->minute[0]);
      else
        sprintf(str,"%d",cp->hour[0]);
    }

  return str;
}
