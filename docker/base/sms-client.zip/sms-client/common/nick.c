/**************************************************************************
.TITLE    CDP
.NAME     NICK
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     11-DEC-1998 / 17-AUG-1998 / OP
.LANGUAGE ANSI-C
.FILE     nick.c
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*
*  This file handles the nickname "database"
*
*  Map between nick-names and real (network) names
*
*  Idea borrowed from XCdp. (Thanx Baudouin!)
*
************************************o*************************************/

#include "smslib.h"

static sms_map *server_map;

void sms_nick_delete(char *name)
{
  sms_map *mp;

  if( (mp=ls_find(&server_map,name)) )
  {
    ls_remove(&server_map,mp);
    sms_node_free(mp);
  }
}

sms_map *sms_nick_create(char *name, char *netname, int prog, int vers, int origin)
{
  sms_map *map = sms_alloc(NODE_MAP);

  if(! map) return 0;

  map->name    = strdup(name);
  map->netname = strdup(netname);
  map->prog    = prog;
  map->vers    = vers;
  map->origin  = origin;

  if(!map->name || !map->netname)
  {
    free(map);
    return 0;
  }

  return map;
}

int sms_nick_write(char *filename)
{
  FILE *fp;
  char buff[MAXLEN];

  sms_map *mp = server_map;

  sprintf(buff,"%s/.xcdprc/servers",STR(getenv("HOME")));

  if( !filename )
    filename = buff;

  if( ! (fp=fopen(filename,"w")) )
    return -1;

  for( ; mp ; mp=mp->next )
    if( mp->origin == NICK_USER )
      fprintf(fp,"%-30s %-30s %d\n",mp->name, mp->netname, mp->prog);

  return fclose(fp);
}

static void nick_read(char *filename, sms_map **mp, int origin)
{
  FILE *fp;
  char buff[MAXLEN];
  char name[MAXLEN];
  char netname[MAXLEN];
  int  prog;
  int  vers;

  if(!filename)  return;

  if( ! (fp=fopen(filename,"r")) )
    return;

  while(fgets(buff,MAXLEN,fp))
  {
     prog = sms_._prog;
     vers = sms_._vers;
     name[0] = netname[0] = 0;

     sscanf(buff,"%s %s %d %d",STR(name),STR(netname),&prog,&vers);

     if(name[0] != 0 && name[0] != '#')
     {
       sms_map *mp;

       if( (mp=ls_find(&server_map,name)) )
       {
         ls_remove(&server_map,mp);
         sms_node_free(mp);
       }
       ls_add(&server_map, sms_nick_create(name,netname,prog,vers,origin));
     }
  }

  fclose(fp);

}

void sms_nick_set(sms_map *mp)
/**************************************************************************
?  Replace the server map
************************************o*************************************/
{
  sms_node_free(server_map);
  server_map = mp;
}

sms_map *sms_nick_servers(char *name)
/**************************************************************************
?  Read servers configuration file(s)
************************************o*************************************/
{
  static int been_here;

  char buff[MAXLEN];

  if(been_here) return server_map;
  been_here = 1;

  if(!name)
  {
    name=getenv("XCDPHOME");
    if(!name)
      name=SMSSERVERS;
  }

  nick_read(name, &server_map, NICK_GLOBAL);

  sprintf(buff,"%s/.xcdprc/servers",STR(getenv("HOME")));
  nick_read(buff, &server_map, NICK_USER);

  nick_read(getenv("SMSSERVERS"), &server_map, NICK_USER);

  return server_map;
}

char *sms_nick_name(char *name)
{
  sms_map *mp;

  if( (mp = ls_find(&server_map,name)) )
    return mp->netname;

  return name;
}

int sms_nick_number(char *name)
{
  sms_map *mp;

  if( (mp = ls_find(&server_map,name)) )
    return mp->prog;

  return sms_._prog;
}

int sms_nick_vers(char *name)
{
  sms_map *mp;

  if( (mp = ls_find(&server_map,name)) )
    return mp->vers;

  return sms_._vers;
}

int sms_nick_origin(char *name)
{
  sms_map *mp;

  if( (mp = ls_find(&server_map,name)) )
    return mp->origin;

  return NICK_USER;
}

void sms_nick_update(char *nick,char *name, char *netname, int prog)
{

  int vers = sms_nick_vers(nick);

  sms_nick_delete(nick);

  ls_add(&server_map, sms_nick_create(name,netname,prog,vers, NICK_USER));
}

static void response(char *name, char *netname, int prog, int vers)
{

  if( ls_find(&server_map,name) )
    return;

  /* printf("Adding %s %s %d into list\n",name,netname,prog); */

  ls_add(&server_map, sms_nick_create(name,netname,prog,vers, NICK_NETWORK));
}


sms_map *sms_nick_broadcast(
    int maxnum,
    int verbose,
    char *pingfile,
    int (*func)(void *, char *),
    void *userdata)
/**************************************************************************
?  Broadcast to find the servers and map them into nick names
=  The SMS-ERROR-CODE
=  SMS_E_OK if the operation was ok. The actual number of servers can be
|  calculated from the list, there are no duplicates in the list.
|  SMS_E_RPC if the broadcast was terminated abnormally (there might still
|  be some entries in the list.)
@  sms_client_servers()
************************************o*************************************/
{
  int numbers[1024];
  int n = 0;
  int i;
  sms_map *mp;
  int smsn, smsv;

  char message[MAXLEN];

  smsn = sms_._prog;
  smsv = sms_._vers;

  numbers[n++] = SMS_PROG;

  if(getenv("SMS_PROG"))
  {
    int prog = atoi(getenv("SMS_PROG"));

    if( prog != SMS_PROG )
      numbers[n++] = prog;
  }

  for(mp=sms_nick_servers(0) ; mp ; mp=mp->next)
  {
    for(i=0 ; i<n ; i++)
      if( numbers[i] == mp->prog )
        break;

    if( i==n )                     /* Add if it's not there */
      numbers[n++] = mp->prog;
  }

  {
    char *s = message;

    strcpy(message,"Found server numbers::");
    for(i=0 ; i<n ; i++)
    {
      s += strlen(s);
      sprintf(s," %d",numbers[i]);
    }
    func(userdata,message);
  }

  for(i=0 ; i<n ; i++)
  {
    sms_list *lp = 0;
    sms_list *l;

    sprintf(message,"Broadcast for SMS_PROG %d",numbers[i]);
    func(userdata,message);

    sms_numbers( numbers[i], SMS_VERS );
    sms_client_servers(&lp, maxnum, verbose, pingfile, func, userdata);

    for( l=lp ; l ; l=l->next )
    {
      /* int match = 0; */

      for(mp=server_map ; mp ; mp=mp->next)
        if( mp->prog == numbers[i] && strcmp(mp->netname,l->name) == 0 )
           break;

      if( mp ) /* We have responce from a nicknamed server */
        response(mp->name,mp->netname,mp->prog,mp->vers);
      else
        response(l->name,l->name,numbers[i],SMS_VERS);
    }
  }

  sms_numbers( smsn, smsv );

  return server_map;
}
