/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     node.c
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     21-JUL-1992 / 11-MAY-1992 / OP
.VERSION  4.0
.FILE     node.c
.DATE     27-JUL-1994 / 24-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
*         Added support for meter and label structures
*         Added suite selection handling (NIDs now send for suites)
.DATE     13-OCT-1994 / 13-OCT-1994 / OP
.VERSION  4.3.2
*         Suite registering logic changed
.DATE     02-DEC-1994 / 02-DEC-1994 / OP
.VERSION  4.3.3
*         Nid-update to call variable update
.DATE     08-DEC-1994 / 08-DEC-1994 / OP
.VERSION  4.3.4
*         Flags added into the nid reports
.DATE     17-MAY-1995 / 17-MAY-1995 / OP
.VERSION  4.3.8
*         XCdp callback changed
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     15-DEC-1998 / 10-SEP-1998 / OP
.VERSION  4.4
*         Variables have NIDs, but only if the server is 4.4 also
*         Limit (pseudo queues)
*         Aliased tasks
.DATE     18-MAR-1999 / 18-MAR--1999 / OP
.VERSION  4.4.2
*         Discontinued SMSLIMIT variable -> int limit field removed
*         Inlimit has own type
.DATE     04-FEB-2000 / 04-FEB-2000
.VERSION  4.4.3
*         Times for task state change
***************************************************************************
*  Node identification (NID) processing routines.
*
*  The idea of having the NID and an action number (ACN) in the node is
*  to reduce the traffic between SMS and CDP.
*
*  When status of a single node is changed (eg the task completes) the
*  CDP should be informed that that specific node now has a new status
*  instead sending the whole new structure (tree). The whole structure
*  is send only when the structure is changed and in the beginning of
*  the (X)CDP status display.
*
*  This greately reduces the traffix in the network. (We R GOOD guys!)
*
*  See also the file xdr.c for an example of reducing the traffic.
************************************o*************************************/

#include "smslib.h"

/**************************************************************************
*        T h e   g l o b a l s   u s e d   i n   t h i s   f i l e
************************************o*************************************/

static sms_nid *nidp;              /* The start of the list */
static sms_nid *last;              /* The latest 1 added    */

static int version;

void sms_nid_count(sms_handle *hp, void *anything, int acn)
/**************************************************************************
?  Count and mark the NIDs.
|
|  This is needed on both SMS and CDP side. But the numbers are not
|  transmitted, instaed they are generated. Integrity is guaranteed
|  by having same routine on both sides.
|
|  The nids are send to (X)CDP and is used as a basis of the calculation
|  on the (X)CDP side.
|
|  As from 4.3 the nid of a suite is send to (X)CDP. This is needed since
|  not all the suites might be "followed" by (X)CDP.
************************************o*************************************/
{
#define COUNT(x,a) if(x) sms_nid_count(hp,x,a)
  sms_node *np = anything;

  static int count;

  if(np->type==NODE_SUPER)
  {
    count = 0;
    if( sms_._is_server )
      version = SMS_VERSION_NUMBER;
    else
      version = hp? VERSION_NUMBER(hp->vers,hp->rev,hp->mod) : SMS_VERSION_NUMBER;
  }

  while(np)
  {
    if(np->type==NODE_SUITE && !sms_._is_server)
    {
      count = np->nid;
      count++;
    }
    else
      np->nid    = count++;

    np->act_no = acn;

    switch(np->type)
    {
      case NODE_SUPER:
      case NODE_SUITE:
      case NODE_FAMILY:
      case NODE_TASK:
      case NODE_ALIAS:
        COUNT(np->event,acn);
        COUNT(np->meter,acn);
        COUNT(np->label,acn);
        COUNT(np->repeat,acn);
        COUNT(np->time,acn);
        COUNT(np->date,acn);
        COUNT(np->trigger,acn);
        if(version >= 44000)
        {
          COUNT(np->variable,acn); /* since 4.4 */
          COUNT(np->complete,acn);
          COUNT(np->limit,acn);
          COUNT(np->inlimit,acn);
        }
        COUNT(np->kids,acn);
        break;

      case NODE_EVENT:
      case NODE_METER:
      case NODE_LABEL:
      case NODE_DATE:
      case NODE_TIME:
      case NODE_TRIGGER:
      case NODE_VARIABLE:
      case NODE_REPEAT:
      case NODE_LIMIT:
      case NODE_COMPLETE:
      case NODE_INLIMIT:
        break;
    }

    np=np->next;
  }
}

static add_nid(sms_node *np)
/**************************************************************************
?  Build the NIDs for the report.
|  The global list (nidp -> last) is advanced.
-NOTICE  This routine is for SMS ONLY
************************************o*************************************/
{
  sms_nid *nid;
  sms_date *dp;
  sms_time *tp;

  if( !(nid = sms_alloc(NODE_NID)) )
    return spit(0,IOI_ERR,"ADD-NID:No mem.");

  nid->nid = np->nid;
  nid->status = np->status & 0x1f;      /* 5 bits */

  if( np->type==NODE_SUPER  || np->type==NODE_SUITE ||
      np->type==NODE_FAMILY || np->type==NODE_TASK || np->type==NODE_ALIAS )
  {
    if( np->status == STATUS_SUSPENDED )
       nid->status = 0x20 | (np->savedstat & 0x1f);   /* The 6th bit */

    nid->flags = np->flags;
  }

  if( np->type==NODE_METER || np->type==NODE_REPEAT || np->type==NODE_LIMIT )
    nid->status = np->status;

  nid->tryno = (np->type==NODE_TASK || np->type==NODE_ALIAS)? np->tryno : NIL;

#if 0
  nid->stime = (np->type==NODE_SUITE)?  np->stime : 0;
  nid->btime = (np->type==NODE_SUITE)?  np->btime : 0;
#else  /* From 4.4.3 onwards */
  if( np->type==NODE_TASK || np->type==NODE_FAMILY || np->type==NODE_SUITE)
  {
    nid->stime = np->stime;
    nid->btime = np->btime;
  }
#endif

  if(np->type==NODE_LIMIT)
    nid->tryno = ((sms_limit *)np)->limit;

  if(np->type == NODE_DATE)
    if( ! (dp=sms_alloc(NODE_DATE)) )
      spit(0,IOI_ERR,"ADD-NID:No mem 2");
    else
    {
      memcpy(dp,np,sizeof(sms_date));
      dp->name = NULL;
      dp->next = NULL;
      nid->gen = (sms_list *)dp;
    }

  if(np->type == NODE_TIME)
    if( ! (tp=sms_alloc(NODE_TIME)) )
      spit(0,IOI_ERR,"ADD-NID:No mem 3");
    else
    {
      memcpy(tp,np,sizeof(sms_time));
      tp->name = NULL;
      tp->next = NULL;
      nid->gen = (sms_list *)tp;
    }

  if( np->type==NODE_LABEL )
  {
    sms_list *lp;

    if( ! (lp=sms_alloc(NODE_LIST)) )
      spit(0,IOI_ERR,"ADD-NID:No mem 4");
    else
    {
      lp->next = NULL;
      lp->name = strdup( ((sms_label *)np)->value);
      nid->gen = (sms_list *)lp;
    }
  }

  if( np->type==NODE_VARIABLE )
  {
    sms_list *lp;

    if( ! (lp=sms_alloc(NODE_LIST)) )
      spit(0,IOI_ERR,"ADD-NID:No mem 5");
    else
    {
      lp->next = NULL;
      lp->name = strdup( ((sms_variable *)np)->value);
      nid->gen = (sms_list *)lp;
    }
  }

  if( np->type==NODE_LIMIT )
  {
    sms_limit *lp = (sms_limit *)np;

    sms_list *tmp = 0;

    if( lp->tasks )
      if( ! ls_copy(&tmp, lp->tasks) )
        spit(0,IOI_ERR,"ADD-NID:No mem 6");

    nid->gen = tmp;
  }

  if( last )                       /* Do it locally for the speed */
    last->next = nid;
  else
    nidp = nid;

  last = nid;                      /* Latest 1 added */

  return TRUE;
}

static void update_nid(sms_node *np, nid_func func, void *userdata)
/**************************************************************************
?  Update a node NP from the current NID report.
|  The global list (last) is advanced.
|  @ the time of the call the LAST points 2 the right NID.
-NOTICE  This routine is for (X)CDP ONLY
************************************o*************************************/
{
  int oldstatus    = np->status;
  int oldtryno     = 0;
  int oldflags     = 0;

  int nid;                         /* 4 time/date copy */

#if 0
printf("Updating NP %s\n",STR(sms_node_full_name(np)));
#endif

  if(np->type==NODE_METER || np->type==NODE_REPEAT || np->type==NODE_LIMIT)
    np->status = last->status;
  else
    np->status = last->status & 0x1f;        /* 5 bits */

  if( np->type==NODE_SUPER  || np->type==NODE_SUITE ||
      np->type==NODE_FAMILY || np->type==NODE_TASK || np->type==NODE_ALIAS )
  {
    if(last->status & 0x20 && 
       !(np->type==NODE_METER || np->type==NODE_REPEAT || np->type==NODE_LIMIT))
    {
       np->savedstat = last->status & 0x1f;  /* The 6th bit */
       np->status = STATUS_SUSPENDED;
    }
    oldflags = np->flags;
    np->flags = last->flags;
  }

  if(np->type==NODE_TASK || np->type==NODE_ALIAS)
  {
    oldtryno   = np->tryno;
    np->tryno = last->tryno;
  }
#if 0
  if(np->type==NODE_SUITE) np->stime = last->stime;
  if(np->type==NODE_SUITE) np->btime = last->btime;
#else   /* From 4.4.3 */
  if( np->type==NODE_TASK || np->type==NODE_FAMILY || np->type==NODE_SUITE)
  {
    np->stime = last->stime;
    np->btime = last->btime;
  }
#endif

  if(np->type == NODE_LABEL)       /* Swap the string */
  {
    sms_label *lp = (sms_label *)np;

    char *tmp       = lp->value;
    lp->value       = last->gen->name;
    last->gen->name = tmp;
  }

  if(np->type == NODE_VARIABLE)    /* Swap the string */
  {
    sms_variable *vp = (sms_variable *)np;

    char *tmp       = vp->value;
    vp->value       = last->gen->name;
    last->gen->name = tmp;
  }

  if(np->type == NODE_LIMIT)       /* Swap the list */
  {
    sms_limit *lp = (sms_limit *)np;
    sms_list  *tmp  = lp->tasks;
    lp->tasks       = last->gen;
    last->gen       = tmp;

    oldtryno   = lp->limit;
    lp->limit  = last->tryno;
  }

  if(np->type == NODE_DATE)
  {
    sms_date *orig = (sms_date *)np;
    sms_date *dp   = (sms_date *)last->gen;

    if(dp)
    {
      orig->status   = dp->status;
      orig->nextdate = dp->nextdate;
      orig->weekdays = dp->weekdays;
      orig->year     = dp->year;
      orig->month    = dp->month;
      orig->day      = dp->day;
    }
    else
      spit(0,IOI_ERR,"NID-UPDATE:No Date\n");
  }

  if(np->type == NODE_TIME)
  {
    sms_time *orig = (sms_time *)np;
    sms_time *tp   = (sms_time *)last->gen;

    if(tp)
    {
      int i;
      orig->status   = tp->status;
      orig->nexttime = tp->nexttime;
      orig->lasttime = tp->lasttime;
      for(i=0 ; i<3 ; i++)
      {
        orig->hour[i]   = tp->hour[i];
        orig->minute[i] = tp->minute[i];
      }
      orig->repeat   = tp->repeat;
      orig->relative = tp->relative;
      orig->today    = tp->today;

    }
    else
      spit(0,IOI_ERR,"NID-UPDATE:No Time\n");
  }

  last = last->next;

  if( func )
    func( np , oldstatus , oldtryno, oldflags, userdata );
}

sms_nid *sms_nid_build( void *anything, int acn )
/**************************************************************************
?  Build the NIDs for the report.
|  The old list is deleted (if found) if the node NP is the super node.
-NOTICE  This routine is for SMS ONLY
************************************o*************************************/
{
#define BUILD(x,a) if(x) sms_nid_build(x,a);
  sms_node *np = anything;

  if(!np) return NULL;

  if(np->type==NODE_SUPER)
  {
    NODE_FREE(nidp,sms_nid);
    last = NULL;
  }

  while(np)
  {
    if( ! SUPPORTED(4,3,0) || np->type != NODE_SUITE ||
        ls_find(&sms_._current_con->suites,np->name) )
    {
      if( np->act_no >= acn )
        add_nid(np);

      if( np->type==NODE_SUPER  || np->type==NODE_SUITE ||
          np->type==NODE_FAMILY || np->type==NODE_TASK || np->type==NODE_ALIAS )
      {
        BUILD(np->event,acn);
        BUILD(np->meter,acn);
        BUILD(np->label,acn);
        BUILD(np->repeat,acn);
        BUILD(np->time,acn);
        BUILD(np->date,acn);
        BUILD(np->trigger,acn);
        BUILD(np->variable,acn);
        BUILD(np->complete,acn);
        BUILD(np->limit,acn);
        BUILD(np->inlimit,acn);
        BUILD(np->kids,acn);
      }
    }

    np = np->next;
  }

  return nidp;
}

void sms_nid_version(sms_handle *hp)
/**************************************************************************
?  Called after sms_client_status if we received nid
-NOTICE  This routine is for (X)CDP ONLY
************************************o*************************************/
{
  version = hp? VERSION_NUMBER(hp->vers,hp->rev,hp->mod) : SMS_VERSION_NUMBER;
}

void sms_nid_update( 
  void      *anything,
  sms_nid   *nid,
  nid_func   func,
  void      *userdata )
/**************************************************************************
?  Walk through the whole tree and update the nodes that have NIDs send.
-NOTICE  This routine is for (X)CDP ONLY
************************************o*************************************/
{
  sms_node *np = anything;


  if(!np) return;

  if(np->type == NODE_SUPER)
  {
    nidp = nid;
    last = nid;
  }

  while(np)
  {
    int update = 0;

    if(!last)
      return;

    if( np->nid == last->nid )
    {
      update_nid(np,func,userdata);
      update=1;
    }

    if( np->type==NODE_SUPER  || np->type==NODE_SUITE ||
        np->type==NODE_FAMILY || np->type==NODE_TASK || np->type==NODE_ALIAS )
    {
      sms_nid_update(np->event,nid,func,userdata);
      sms_nid_update(np->meter,nid,func,userdata);
      sms_nid_update(np->label,nid,func,userdata);
      sms_nid_update(np->repeat,nid,func,userdata);
      sms_nid_update(np->time,nid,func,userdata);
      sms_nid_update(np->date,nid,func,userdata);
      sms_nid_update(np->trigger,nid,func,userdata);
      if(version >= 44000)
      {
        sms_nid_update(np->variable,nid,func,userdata);
        sms_nid_update(np->complete,nid,func,userdata);
        sms_nid_update(np->limit,nid,func,userdata);
        sms_nid_update(np->inlimit,nid,func,userdata);
      }
      sms_nid_update(np->kids,nid,func,userdata);

      if(update)
        sms_node_update(np,func,userdata);
    }

    np = np->next;
  }
}
