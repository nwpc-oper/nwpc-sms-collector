/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     CONNECT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     13-OCT-1994 / 13-OCT-1994 / OP
.VERSION  4.3.2
*         New file to handle connection processing
*         Suite registering logic changed
.FILE     connect.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
************************************o*************************************/

#include "smslib.h"

void sms_connect_check(char *name)
/**************************************************************************
?  Add new suite automatically to users suites to follow (if user has
|  requested that)
|  Called by play, when adding new suites
************************************o*************************************/
{
  sms_connect *con = sms_._connect;

  for( con=sms_._connect; con ; con=con->next )
    if( con->newsuites )
    {
      ls_delname( &con->suites , name );
      ls_add( &con->suites , ls_create(0,name));
    }
}

void sms_connect_login(sms_connect *con)
/**************************************************************************
?  By default add all the suites into the list
|  Called login (SMS)
************************************o*************************************/
{
  sms_node *np = sms_._super->kids;

  for( ; np ; np=np->next )
    ls_add( &con->suites , ls_create(0,np->name));
}

void sms_connect_recover(void)
/**************************************************************************
?  Add suites after reading the checkpoint file
|  Called login (SMS)
************************************o*************************************/
{
  sms_connect *con = sms_._connect;

  for( con=sms_._connect; con ; con=con->next )
    if( con->newsuites )
    {
      sms_node *np = sms_._super->kids;

      for( ; np ; np=np->next )
      {
        ls_delname( &con->suites , np->name );
        ls_add( &con->suites , ls_create(0,np->name));
      }
    }
}
