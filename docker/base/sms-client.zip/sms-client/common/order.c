/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     ORDER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-MAR-1994 / 03-MAR-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3.0-5
.FILE     order.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     11-JAN-1999 / 21-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*         Net names for nodes
*         Aliased tasks
************************************o*************************************/

#include "smslib.h"

int sms_order(
    sms_node *np,                  /* Privileges are already checked */
    int       how,                 /* Type of ordering               */
    sms_list *args)                /* if how==ORDER_ORDER            */
/**************************************************************************
?  The SMS part of the order
=  SMS-RETURN-CODE
************************************o*************************************/
{
  sms_node *parent = np->parent;
  sms_node *start  = NULL;
  sms_node *prev   = NULL;

  if( ! sms_cmd_typeok("order",np,NODE_SUPER,NODE_SUITE,NODE_FAMILY,NODE_TASK,NODE_ALIAS,0))
    return SMS_E_ORDER;

  switch( how )
  {
    case ORDER_TOP:
      if(parent->kids == np)
        return spit(SMS_E_OK,IOI_LOG,"order:%s by %s: already on %s",
                    STR(sms_node_full_name(np)),STR(SMS_USER),order_name[how]);

      ls_remove(&parent->kids,np);
      np->next = parent->kids;
      parent->kids = np;
      break;

    case ORDER_BOTTOM:
      if(np->next == NULL)
        return spit(SMS_E_OK,IOI_LOG,"order:%s by %s: already on %s",
                    STR(sms_node_full_name(np)),STR(SMS_USER),order_name[how]);

      ls_remove(&parent->kids,np);
      ls_add(&parent->kids,np);
      break;

    case ORDER_ALPHA:
      ls_sort(&np->kids,NULL);
      break;

    case ORDER_ORDER:              /* order by the list */
      while( args )
      {
        sms_node *old = ls_find(&np->kids,args->name);
        if( old )
        {
          ls_remove(&np->kids,old);
          ls_add(&start,old);
        }
        else
          spit(SMS_E_OK,IOI_LOG,"order:%s by %s: can not find %s",
                    STR(sms_node_full_name(np)),STR(SMS_USER),STR(args->name));
        args = args->next;
      }
      ls_join(&start,np->kids);    /* Add the rest */
      np->kids = start;
      break;

    case ORDER_UP:
      if( (prev = ls_find_prev(&np->parent->kids,np)) )
        return sms_order(prev,ORDER_DOWN,args);
      else
        return spit(SMS_E_OK,IOI_LOG,"order:%s by %s: already on %s",
                    STR(sms_node_full_name(np)),STR(SMS_USER),order_name[ORDER_TOP]);
      /* break; */

    case ORDER_DOWN:
      if(np->next)
      {
        if( (prev = ls_find_prev(&np->parent->kids,np)) )
        {
          start = prev->next = np->next;
          np->next = start->next;
          start->next = np;
        }
        else
        {
          start = np->parent->kids = np->next;
          np->next = start->next;
          start->next = np;
        }
      }
      else
        return spit(SMS_E_OK,IOI_LOG,"order:%s by %s: already on %s",
                    STR(sms_node_full_name(np)),STR(SMS_USER),order_name[ORDER_BOTTOM]);
      break;

    default:
      return sms_error(SMS_E_PROTOCOL,"order:%s",STR(sms_node_full_name(np)));
  }

  spit(0,IOI_LOG,"order:%s by %s method %s",
       STR(sms_node_full_name(np)),STR(SMS_USER),order_name[how]);

  SUITE_MODIFIED(np);

  return SMS_E_OK;
}

int cdp_order_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *nodename;
  static int   how,how_def=0;
  static char *dummy;

  if( called )
  {
    char     *av[3];
    int       rc;
    sms_list *lp = NULL, *reply = NULL;

    sms_handle *hp;
    sms_node   *np;
    char       *newname;

    if( ! (newname=sms_cd_name2(nodename)) )
      return FALSE;

    if( dummy )
      ls_argv(&lp,++argc,--argv);

    np = sms_node_net_find( newname );
    hp = sms_node_find_handle(np);

    if( !hp ) return 0;

    av[0] = "order";
    av[1] = sms_node_full_name(np);

    rc = sms_client_cmd(hp,2,av,&reply,how,(lp)?&lp:NULL);

    ls_delall(lp);
    ls_print_all(&reply,stdout);
    ls_delall(reply);
    return rc;
  }
  else
    ioi_exe_add("order:cdp",cdp_order_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ttype",IOI_L_ENUM,ioi_exe_argv(
            "Type of ordering",
            "Top and bottom raise/lower the node withing it's parent.",
            "Alpha and order operate kids of the node given.",
            NULL
          ),NULL,-1,&how,order_name,&how_def
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node",IOI_L_STRING,ioi_exe_argv(
            "The node name to be ordered.",
#ifdef USE_NET_NAMES
            "The node names can be netnames (//host/suite[/family[/task]])",
#endif
            "What node is effected depends on the ordering type",
            NULL
          ),NULL,-1,&nodename
        ),
        ioi_exe_param(
          "list",IOI_L_STRING,ioi_exe_argv(
            "Given list for type of \"order\"",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Re-order the suites in the SMS",
        NULL
      )
    );

  return called = TRUE;
}
