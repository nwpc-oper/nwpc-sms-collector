/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     LOG
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     20-OCT-1995 / 26-SEP-1995 / OP
.VERSION  4.3.11-12
*         Bug fix, events etc, do not have log field, stick it in
*         the parent (4.3.12)
.LANGUAGE ANSI-C
.FILE     log.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     30-OCT-1998 / 18-SEP-1998 / OP
.VERSION  4.4
*         Multi SMS login for XCdp and Cdp
*
*  Per node log processing.
*
*  Currently under test use in the SMS.
*
*  Per node log concept added into SMS as a long thought after feature.
*  SMS keeps track of all commands executed by user, and logs a message
*  to be kept until suite is began.
*  This, however, is another deviation from the original KISS principle.
*
************************************o*************************************/

#include "smslib.h"

void sms_log_clear(sms_node *np, int first, int last)
/**************************************************************************
?  Clear all messages
************************************o*************************************/
{
  if(np->log)
  {
    ls_delall(&np->log);
    FLAG_CLEAR(np,FLAG_MESSAGE);
    SUITE_CHANGED(np);
  }

  for( np=np->kids; np; np=np->next )
    sms_log_clear(np,first,last);
}

int sms_log_summary(sms_node *np)
/**************************************************************************
?  Print summary of memory usage for messages
************************************o*************************************/
{
  static int level;
  int        sum = 0;
  sms_list  *lp;
  char      *name;

  if( ! level )
    name = sms_node_full_name(np);

  for( lp = np->log; lp; lp=lp->next )
    sum += strlen(lp->name)+1;

  level++; 
  for( np=np->kids; np; np=np->next )
    sum += sms_log_summary(np);

  if(--level == 0)
    sms_output("memory usage for messages for %s is %d bytes",STR(name),sum);

  return sum;
}

void sms_log_add(sms_node *np, char *message)
/**************************************************************************
?  Add the message into the node
|  Don't worry too much about performance in list handling;
|  this is only done when users execute commands
************************************o*************************************/
{
  char line[MAXLEN];

  while(np && np->parent && 
     ! (np->type==NODE_TASK  || np->type==NODE_FAMILY ||
        np->type==NODE_SUITE || np->type==NODE_SUPER || np->type==NODE_ALIAS) )
    np = np->parent;

  if( !np ) return;

  sprintf(line,"[%s] %s",STR(SMS_USER),STR(message));

  FLAG_SET(np,FLAG_MESSAGE);
  SUITE_CHANGED(np);
  ls_add( &np->log , ls_create(0, line) );

  if( ls_len( &np->log ) > SMSNODEHISTORY )
    ls_delete( &np->log, np->log );
}

void sms_log_begin(sms_node *np)
/**************************************************************************
?  Remove the messages at the beginning of the suite
|  This is not! done if requeue is being used
************************************o*************************************/
{
  if(!np) return;


  if(np->log)
    ls_delall( &np->log );
  np->log = NULL;
  FLAG_CLEAR(np,FLAG_MESSAGE);

  for( np = np->kids ; np ; np = np->next )
    sms_log_begin(np);
}

void sms_log_message(sms_node *np)
/**************************************************************************
?  Copy per node messages into the reply to the user
************************************o*************************************/
{
  if( np->log )
    ls_copy( &sms_._reply , np->log );
  else
    ls_add( &sms_._reply , ls_create(0,"NODE HAS NO HISTORY"));
}

static void all_messages(sms_node *np)
{
  if(np->log)
    printf("%s::\n",STR(sms_node_full_name(np)));

  ls_print_all(&np->log,stdout);

  for( np = np->kids ; np ; np = np->next )
    all_messages(np);
}

int cdp_message(
    sms_handle *hp,
    char       *name,
    sms_list  **lp,
    int         options)
/**************************************************************************
?  Get the messages of the current node (called by XCdp and cdp_log_cmd())
=  SMS-ERROR-CODE
************************************o*************************************/
{
  int       rc;
  char     *av[2];

  sms_node *np;

  av[0] = "messages";
  av[1] = name;

  return sms_client_cmd(hp, 2,av,lp,options,NULL);
}

int cdp_message_add(sms_handle *hp, char *name, char *line)
/**************************************************************************
?  Called by XCdp ?
************************************o*************************************/
{
  int       rc;
  char     *av[3];

  sms_node *np;

  av[0] = "messages";
  av[1] = name;
  av[2] = line;

  return sms_client_cmd(hp,3,av,NULL,0,NULL);
}

static char *ioi_misc_argv2char(
    int    argc,
    char **argv,
    char  *buff,
    int    maxlen,
    int    c)
/**************************************************************************
?  Called by CDP
=  "buff"
************************************o*************************************/
{
  char *s = buff;

  for( *s='\0' ; argc-- && maxlen > strlen(*argv) ; argv++ )
  {
    strcpy(s,*argv);
    s += strlen(s);
    if(argc>=1)
      *s++ = c;
    *s = '\0';
  }

  return buff;
}

int cdp_log_cmd(int argc, char **argv)
/**************************************************************************
?  Called by CDP
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static char *text;
  static int   clear;
  static int   summary;
  static int   all;
  static int   insert;
  static int   first, f_min=0, f_def=0;
  static int   last , l_min=0, l_def=0;

  if( called )
  {
    int       rc2 = TRUE;
    sms_list *names = NULL;

#if 0
    int       options = sms_encode(&clear,&summary,first,last,NULL);
#else
    int       options = sms_encode(&clear,&summary,NULL);
#endif

    if( sms_cdp_update( HANDLE ) != SMS_E_OK )
      return FALSE;

    if( insert )
      if( text )
      {
        char buff[MAXLEN];

        if( ! (names=sms_cd_names2(1,argv-2,NULL)) )
          return FALSE;

        return
          cdp_message_add(HANDLE,names->name,
                          ioi_misc_argv2char(argc+1,argv-1,buff,MAXLEN,' '));
      }
      else
        return ioi_out(FALSE,IOI_ERR,"message:parameter text missing");

    if( dummy ) { argc++; argv--; }

    if( ! (names=sms_cd_names2(argc,argv,NULL)) )
      return FALSE;

#if 0
    if(all)
      sms_client_status(HANDLE,NULL,NIL); /* Get the full picture */
#endif

    while( names )
    {
      int       rc;
      sms_list *reply = NULL;

      sms_node *np;

#if 1
      if( all )
        all_messages(sms_node_find_full(names->name));
      else
      {
        if( (rc=cdp_message(HANDLE, names->name,&reply,options)) == SMS_E_OK )
          if( reply )
          {
            ls_print_all(&reply,stdout);
            ls_delall(reply);
          }
          else
            ;
        else
          rc2=FALSE;
      }
#else
      if( (np=sms_node_find_full(names->name)) )
        ls_print_all(&np->log,stdout);
#endif

      names = names->next;
      if(names)
        printf("--------------------------------------------------\n");
    }

    return rc2;
  }
  else
    ioi_exe_add("messages:cdp",cdp_log_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "Print messages of all nodes",
            NULL
          ),NULL,1,&all
        ),
        ioi_exe_param(
          "-cclear",IOI_L_BOOLEAN,ioi_exe_argv(
            "Clear all messages (also for the kids)",
            NULL
          ),NULL,1,&clear
        ),
#if 0
        ioi_exe_param(
          "-ffirst",IOI_L_INTEGER,ioi_exe_argv(
            "Leave this many lines from the beginning when clearing.",
            "Only useful with clear option (-c)",
            NULL
          ),NULL,1,&first,&f_min,NULL,&f_def
        ),
        ioi_exe_param(
          "-llast",IOI_L_INTEGER,ioi_exe_argv(
            "Leave this many last lines when clearing.",
            "Only useful with clear option (-c)",
            NULL
          ),NULL,1,&first,&f_min,NULL,&f_def
        ),
#endif
        ioi_exe_param(
          "-iinsert",IOI_L_BOOLEAN,ioi_exe_argv(
            "Inser message into a node.",
            "NOTICE: node name must be given (use . for current node)",
            NULL
          ),NULL,1,&insert
        ),
        ioi_exe_param(
          "-ssummary",IOI_L_BOOLEAN,ioi_exe_argv(
            "Get the summary of memory usage",
            NULL
          ),NULL,1,&summary
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "node",IOI_L_STRING,ioi_exe_argv(
            "The node name to be printed.",
            NULL
          ),NULL,1,&dummy
        ),
        ioi_exe_param(
          "text",IOI_L_STRING,ioi_exe_argv(
            "The text to be inserted with -i option.",
            NULL
          ),NULL,1,&text
        ),
        NULL
      ),
      ioi_exe_argv(
        "Manage per node history",
        "SMS keeps history of user actions in every individual node",
        "since the beginning of the suite. This command manages them.",
        "Useful to find out who did what/when?",
        NULL
      )
    );

  return called = TRUE;
}
