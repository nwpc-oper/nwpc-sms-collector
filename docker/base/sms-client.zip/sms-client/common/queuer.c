/**************************************************************************
.TITLE    C-SMS-CDP Utility
.NAME     QUEUER
.SECTION  L
.AUTHOR   Otto Pesonen
.ORIG     05-AUG-1990 / 05-AUG-1990 / OP for ymp8:~map/src/lib/mcft77.c
.DATE     10-SEP-1991 / 08-SEP-1991 / OP
.DATE     02-OCT-1991 / OP
*         fork -> vfork
.DATE     20-NOV-1991 / OP
.DATE     27-JAN-1992 / OP
*         signal  handling
.DATE     27-FEB-1992 / OP
.DATE     10-MAR-1992 / OP
*         signal interrupt -> dump / quickly repeat -> exit
.DATE     16-MAR-1992 / OP
*         catch alarm
.DATE     15-APR-1992 / OP
.DATE     22-APR-1992 / OP
.VERSION  4.0
.DATE     22-APR-1993 / 22-APR-1993 / OP
.VERSION  4.2
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.FILE     queuer.c
*
*  This is part of the C-SMS-CDP package. Used for testing the queueing
*  large number of simultaenous jobs.
*
*  Execute effectively the files given with the maximum number of 
*  simultaenous processes selected by the argument or NPROC environment.
*  the sms.
*
*  Read the file (usually a pipe) name QUEUE.
*  In case the end of the file is reached the queuer repeatedly tries
*  to read more lines in an endless loop by first sleeping a second and
*  then attemping to read again in the hope that the file is growing
*  or that someone is writing in to the pipe.
*
*  See also the file ymp8:~map/src/lib/mcft77.c
*
*  compile: cc -o queuer queuer.c
*
*  use:     csh: setenv NPROC 8
*           sh:  NPROC=8 export NPROC
*
*           queuer                  # use QUEUE, def = create pipe, 10 proc
*           queuer filename         # use filename to read, and 10 prco
*           queuer QUEUE 20         # use QUEUE to read, and 20 prco
*
************************************o*************************************/

#define D(x)    fprintf(stderr,"TRAP %d\n",(x))

#include <stdio.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/stat.h>

#ifdef VMS
#  include <processes.h>
#else
#  include <sys/wait.h>
#endif

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

#ifndef MAXLEN
#define MAXLEN 1024
#endif

#ifndef NIL
#define NIL (-1)
#endif

extern int execl(), fork(), vfork(), close();

/**************************************************************************
*  Remember the name - process id relation
************************************o*************************************/

struct process {
  int   pid;
  char *name;
};

typedef struct process proc;

/**************************************************************************
*  The globals needed by the QUEUER
************************************o*************************************/

char *my_name;
int   kids;                        /* Current number of children to wait */
int   nproc;                       /* Number of processors to use        */
int   my_id;                       /* Who am I? */
proc *ptable;

/**************************************************************************
.TITLE   Utility Library Functions
.NAME    NONE
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    06-SEP-1991 / 09-DEC-1989 / OP
.VERSION 1.0
.FILE    strext.c
*
*  Stolen from the ut-library (also in the top.a)
*  Modify the original not this!
*
************************************o*************************************/

char *strext(
    char *new,                 /* New name with the ext */
    char *old,                 /* Name to be derivated */
    char *ext)                 /* Extension to be added */
/**************************************************************************
?  Add the file-extension to the OLD name by removing the old extension
|  Extension starts from the last dot "." found in the OLD and is
|  replaced by EXT.
|  If the dot cann't be found, a dot and EXT is added to the OLD.
|
|  The strings given must be null terminated and NEW must be large
|  enough to hold the new name.
=  *new
************************************o*************************************/
{
  int i;
  int dot=0;                   /* Flag was the dot found? */

  i=strlen(old);

  while(!dot && i && ! old[i-1]!='/') if(old[--i] == '.') dot=1;

  if(!dot) i=strlen(old);

  strncpy(new,old,i);
  new[i]='.';
  new[i+1]='\0';
  strcat(new,ext);
  return(new);
}

/**************************************************************************
.TITLE   C-SMS-CDP
.NAME    MISC
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    10-MAR-1992 / 09-AUG-1991 / OP
.VERSION 4.0
.FILE    misc.c
*
*  Stolen from the SMS-library 
*  Modify the original not this!
*
************************************o*************************************/

char *sms_no_newline(char *s)
/**************************************************************************
?  Remove the newline character form the end of the string given.
|  Normally used after fgets(3).
=  The original buffer. Call can be used in place of the original in
|  printf statement.
************************************o*************************************/
{
  int len;

  if( !s ) return NULL;            /* Just to prevent illegal use */

  len = strlen(s);

  if( len && s[len-1] == '\n' )
    s[--len] = '\0';

  return s;
}

sys(char *cmdname)
/**************************************************************************
?  Execute the command (cmdname) and return, DO NOT WAIT for the termination
|  of the children.
|  The stdout for the call is redirected into cmdname.o (extension mod)
|  The stderr for the call is redirected into cmdname.e. (extension mod)
=  PID in case of succes or 0 in case of errors.
************************************o*************************************/
{
  int	 status, pid, w;
  time_t t = time(NULL);
  int    mask = 0;

/*
  signal(SIGCHLD,SIG_IGN);
  signal(SIGTERM,SIG_IGN);
  signal(SIGHUP,SIG_IGN);

  sigblock(sigmask(SIGTERM));
  sigblock(sigmask(SIGHUP));
*/

/*
  mask = sigblock(sigmask(SIGCHLD));
*/

  if((pid = fork()) == 0)          /* The child */
  {
    char oname[MAXLEN];
    char ename[MAXLEN];

#ifdef SIGCHLD
    signal(SIGCHLD,SIG_IGN);
#endif

    strext(oname,cmdname,"o");
    strext(ename,cmdname,"e");

    close(1);
    if( ! fopen(oname,"w") )
      fprintf(stderr,"redirection failed 1\n");

    close(2);
    if( ! fopen(ename,"w") )
      fprintf(stderr,"redirection failed 2\n");

    execl(cmdname,cmdname,(char *)0);
    fprintf(stderr,"EXECV returned!!!\n");
    /*
     *  Mayby the file protection failed (no executable bit set)
     *  or the shell couldn't be found. Look at man execve(2).
     */
   _exit(127);
  }

  if (pid == -1)
  {
    fprintf(stderr,"VFORK error for %s !!!\n",STR(cmdname));
    exit(1);
  }
  else
  {
    int  i;
    proc *process;

    for( process=ptable , i=0 ; i<nproc ; i++,process++ )
      if( process->pid == 0 )
      {
        process->name = (char *)strdup(cmdname);
        process->pid  = pid;
        break;
      }
  }

/*
  sigsetmask(mask);
*/

  printf("[%s] %5d %s\n",STR(sms_no_newline((char *)ctime(&t))),pid,STR(cmdname));
  fflush(stdout);

  return pid;
}

void catch_hup(int sig)
/**************************************************************************
?  Print the current active process table
************************************o*************************************/
{
  static  time_t last_time;
  time_t  t;
  int     i;
  proc   *process;

  if(sig == SIGINT)
  {
    t = time(NULL);
    if( t-last_time <= 2 )
      exit(0);
    last_time = t;
  }

  printf("QUEUER[%d]: %d of %d [sig %d]\n",my_id,kids,nproc,sig);

  for( process=ptable , i=0 ; i<nproc ; i++,process++ )
    if( process->pid )
      printf("%5d %s\n",process->pid,STR(process->name));

  signal(sig,catch_hup);
}

void catch(int sig)
/**************************************************************************
?  Catch the deth of the child process
************************************o*************************************/
{
  int     status;
  int     pid;
  time_t  t     = time(NULL);
  char   *str   = sms_no_newline((char *)ctime(&t));
  int     i;
  proc   *process;

  if( (pid=wait(&status)) != NIL )
  {
    for( process=ptable , i=0 ; i<nproc ; i++,process++ )
      if( process->pid == pid )
        break;

    if( i>=nproc )                 /* NOT FOUND? */
    {
      fprintf(stderr,"DONNO BOUT %d?\n",pid);
      return;
    }

    if( WIFSTOPPED(status) )
      printf("[%s] %5d %s STOPPED???\n",STR(str),pid,STR(process->name));
    else                           /* Process terminated */
    {
      if( WIFSIGNALED(status) )
        printf("[%s] %5d %s died of signal %d\n",
               STR(str),pid,STR(process->name),WTERMSIG(status));
      else                         /* Must be exit! */
        if(WEXITSTATUS(status))
          printf("[%s] %5d %s exited with status %d\n",
                 STR(str),pid,STR(process->name),WEXITSTATUS(status));
        else
          printf("[%s] %5d %s exited\n",STR(str),pid,STR(process->name));

      free(process->name);
      process->name = NULL;
      process->pid  = 0;

      kids--;
    }
  }
  else
  {
/*
    fprintf(stderr,"CHILD NOT DEAD\n");
*/
    sleep(1);
  }

  signal(sig,catch);
}

void usage(void)
/**************************************************************************
?  Print the syntax of the command and the explanation of the parameters.
=  This never returns.
************************************o*************************************/
{
  fprintf(stderr,"usage: %s [queuefile [nprocess]]\n",STR(my_name));
  fprintf(stderr,"  queuefile: contains the names of the executables.\n");
  fprintf(stderr,"             default name is QUEUE.\n");
  fprintf(stderr,"             default type is PIPE.\n");
  fprintf(stderr,"             if the file doesn't exist, it's created.\n");
  fprintf(stderr,"  nprocess : is the number of simultaenous processes.\n");
  fprintf(stderr,"             default is 10.\n");
  fprintf(stderr,"             altered by the evironment variable NPROC.\n");
  fprintf(stderr,"\n");

  exit(1);
}

readline(FILE *fp, char *buff)
/**************************************************************************
?  Read the next line in the input file/pipe and remove the newline from 
|  the streem.
=  Number of characters read. If zero the caller should sleep.
!  A possible time problem if the full line is not written by the 
|  application.
************************************o*************************************/
{
  int n;
  int len = 0;
  int fn  = fileno(fp);

  do
    if( n = read(fn,buff,1) )
      buff++;
  while( n && len < MAXLEN && buff[-1] != '\n' );

  if( n )
     buff--;

  *buff = '\0';

  return n;
}

main(int argc, char **argv)
/**************************************************************************
?  This is it!
=  If started properly, this never returns. You must use kill.
************************************o*************************************/
{
  char  executable[1024];          /* Name of the next file              */
  char *in_file;                   /* File to read                       */
  int   is_pipe = FALSE;           /* If to create a pipe                */
  int   go_on   =  TRUE;           /* Keep on going                      */
  int   status;                    /* Just needed for the wait()         */
  FILE *fp;                        /* Input file/pipe                    */

  nproc = 10;

  if( getenv("NPROC") )            /* The environment is the default */
    nproc = atoi( getenv("NPROC") );

  in_file = NULL;
  my_name = *argv;
  my_id   = getpid();

  if( argc>1 && *argv[1] == '?' ) usage();

  switch( argc )
  {
    case 3: nproc = atoi(argv[2]);
    case 2: in_file = argv[1];
    case 1: my_name = argv[0];
      break;
    default:
      usage();
  }

  if( nproc<1 )
  {
    fprintf(stderr,"%s: error nproc<1 !\n",STR(my_name));
    exit(1);
  }

  if( !(ptable=(proc *)calloc(nproc,sizeof(proc))) )
  {
    fprintf(stderr,"%s: no mem for process table!\n",STR(my_name));
    exit(2);
  }

  if( ! in_file )
  {
    in_file = "QUEUE";
    is_pipe = TRUE;
  }

  signal(SIGHUP  , catch_hup);
  signal(SIGTERM , catch_hup);
  signal(SIGINT  , catch_hup);
  signal(SIGALRM , catch_hup);

#ifdef SIGCHLD
  signal(SIGCHLD,catch);
#endif

  catch_hup(SIGHUP);

  if( ! (fp=fopen(in_file,"r")) && is_pipe )
  {
    int mask = 0620;               /* -rw- -w- ---  */

    umask( 0777 ^ mask );

#if !defined(vms)
    if( mknod(in_file,S_IFIFO|mask,0) == (-1) )
    {
#endif
      fprintf(stderr,"%s: can't create pipe %s\n",STR(my_name),STR(in_file));
      perror(my_name);
      exit(1);
#if !defined(vms)
    }
#endif
    fp = fopen(in_file,"r");
  }

  if( ! fp )
  {
    fprintf(stderr,"%s: can't open file %s\n",STR(my_name),STR(in_file));
    exit(1);
  }

  while( go_on )                   /* Loop forever */
  {
    if( readline(fp,executable) )
      if( executable[0] )
      {
        sys(executable);
        kids++;
      }
      else                         /* It's garbage! */
      /*  sleep(1);  */
      ;
    else
      sleep(1);                    /* Nothin' 2 do */

#ifdef SIGCHLD
    while( kids>=nproc )
      kill(my_id,SIGCHLD);         /* We might catch a zombie! */
#endif
  }

  while( kids )                    /* Currently this shouldn`t happen */
    sleep(1);                      /* Wait for the kids to terminate */
}

