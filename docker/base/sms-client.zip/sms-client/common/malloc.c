/**************************************************************************
.TITLE    ECMWF Utility
.NAME     MALLOC
.SECTION  DEBUG-L
.AUTHOR   Otto Pesonen
.DATE     12-AUG-1994 / 09-AUG-1994 / OP
.VERSION  1.0
.FILE     malloc.c
*
.DATE     23-AUG-1994 / 12-AUG-1994 / OP
.VERSION  1.1
*         Free space rejoining added
*         Dump of allocation added
.DATE     01-DEC-1994 / 23-AUG-1994 / OP
.VERSION  4.3.0-2
*         Part of SMS now
*         Illegal free -> abort
*         Signal -> dump (for XCdp)
.LANGUAGE ANSI-C
.DATE     12-AUG-1998 / 11-AUG-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
*
*  Memory allocation for DEBUG purposes only.
*
*  This is similar to malloc(3C) but has dummy routines to replace
*  and warn users if they uses malloc(3X) routines.
*
*  Like malloc(3C) free will leave the contents undisturbed, that is until
*  next malloc() is called. Users are warned not to rely on this. An
*  exeption handler could be called in between your free and use of freed
*  memory.
*
*  No special cases for small elements, this is bound to get slow
*  after a while when the lists get bigger.
*
*  Adjoining of the free blocks is now implemented. This grately reduces
*  the fragmentation of the free store.
*
*  No mallopt (return 1 in every case)
*
*  All blocks double-word aligned (32bit word == 8-byte aligned) this
*  is controlled by the "MINSIZE" which should be a multiple of at least
*  a word (on 32-bit machines 4 (bytes), and on 64-bit 8 bytes.) This
*  allowes the blocks returned by the malloc to be used for data that
*  requires alignment (like floating point numbers)
*
*  This package is able to dump both free and used memory.
*
*  Added stuff for HPUX XDR.
*
************************************o*************************************/

#ifdef STANDALONE
#  include <stdio.h>
#  define SMS_MALLOC
#  define SMS_MALLOC_CHECK
#  define MAXNAM 1024
   extern char *strdup(char *);
#else
#  include "config.h"
#  include "ioi.h"
#endif

#if 0
#define SMS_MALLOC       
#define SMS_MALLOC_CHECK 
#if 0
#define SANITY_CHECK
#endif
#endif

#if 0
#define size_t int
#endif

#define MINSIZE 8                  /* Min allocation */

#define SANITY_CHAR 0x59
#define SANITY_LEN 32

#define tohex(a) ((a)<10)? (a)+'0' : (a)-10+'a'

//#if ( defined AIX || defined FUJITSU || defined(__alpha) )
//extern void *sbrk (long incr);
//#else
//extern void *sbrk (int incr);
//#endif
/* extern void bzero(void *, int); */
/* extern void bcopy(void *, void *, int); */

typedef struct _mlist {
  struct _mlist *next;
  int            size;
#ifdef SANITY_CHECK
  char           under[SANITY_LEN];
#endif
} mlist;

#ifdef SMS_MALLOC                  /* Otherwise this renders empty */

static mlist *free_mem;
static mlist *used_mem;

#ifdef SMS_MALLOC_CHECK
  static int malloc_calls;
  static int malloc_mega_bytes;
  static int malloc_bytes;
#endif

static int malloc_sbreak;

static int sanity_count;
static int hash_count;

static void dump8(FILE *fp, char *s)
{
  int j;
  int *k;

  fprintf(fp,"%x %d 0x",s,s);
  for( j=0 ; j<8 ; j++,s++ )
  {
    char a = (*s & 0xf0)>>4;
    char b = *s & 0x0f;
    fprintf(fp,"%c%c", tohex(a) , tohex(b) );
  }

  for( j=0,s-=8,k=(int *)s,fprintf(fp," ") ; j<2 ; j++,k++ )
    fprintf(fp,"%010d ", *k);

  for( j=0,fprintf(fp," ") ; j<8 ; j++,s++ )
    fprintf(fp,"%c", (*s<32 || *s>126)? '.' : *s );
  fprintf(fp,"\n");
}

static void dump(FILE *fp, mlist *mp, int limit)
{
  char *s;
  int   i,j;

#ifdef SANITY_CHECK
  s = mp->under;
  for( i=0 ; i<SANITY_LEN ; i += 8 )
  {
    dump8(fp, s);
    s += 8;
  }
#endif

  s = (char *)(mp+1);

  for( i=0 ; i<mp->size-sizeof(mlist) && i<limit ; i += 8 )
  {
    dump8(fp, s);
    s += 8;
  }
}

#ifdef SANITY_CHECK
void hash(mlist *mp)
{
  int i;
  char *x = mp->under;

  for( i=0 ; i<SANITY_LEN ; i++)
    *x++ = SANITY_CHAR;

  hash_count++;
}

void sanity(mlist *mp)
{
  char *x;
  int   i;

  x = (char *)mp->under;
  for( i=0 ; i<SANITY_LEN ; i++,x++ )
    if( *x != SANITY_CHAR )
    {
      fprintf(stderr,"sanity check:underflow at 0x%x\n",mp);
      dump(stderr,mp,1024);
    }

  sanity_count++;
}
#else
#define hash(x)
#define sanity(x)
#endif

void *malloc(register size_t sz)
{
  mlist *mp,*pp;
  int    cutsize;
  int    size = sz;

#ifdef SMS_MALLOC_CHECK
  malloc_calls++;
  if( (malloc_bytes += size) > (1<<20) )
  {
    malloc_mega_bytes += malloc_bytes / (1<<20);
    malloc_bytes %= (1<<20);
  }
#endif

  size = ( (size+MINSIZE-1)/MINSIZE )*MINSIZE + sizeof(mlist);

  if( free_mem )
  {
    mp=free_mem;                   /* First check for exact match */
    if(mp->size == size)           /* The first element ok? */
    {
      free_mem = free_mem->next;
#ifdef SMS_MALLOC_CHECK
      mp->next = used_mem;
      used_mem=mp;
#endif

      hash(mp);
      return mp+1;
    }

    for( pp=mp, mp=mp->next ; mp; mp=mp->next )
      if(mp->size == size)         /* Find it from the middle */
      {
        pp->next = mp->next;
#ifdef SMS_MALLOC_CHECK
        mp->next = used_mem;
        used_mem=mp;
#endif

        hash(mp);
        return mp+1;
      }
      else
        pp=mp;

    cutsize = size + sizeof(mlist) + MINSIZE;

    mp=free_mem;                   /* Secondly cut from another bigger chunk */

    if(mp->size >= cutsize)
    {
      free_mem = (mlist *)(((char *)free_mem) + size );
      free_mem->size = mp->size - size;
      free_mem->next = mp->next;

      mp->size = size;
#ifdef SMS_MALLOC_CHECK
      mp->next = used_mem;
      used_mem=mp;
#endif

      hash(mp);
      return mp+1;
    }

    for( pp=mp, mp=mp->next ; mp; mp=mp->next )
      if(mp->size >= cutsize)      /* Find it from the middle and cut */
      {
        pp->next = (mlist *)(((char *)mp) + size );
        pp->next->size = mp->size - size;
        pp->next->next = mp->next;

        mp->size = size;
#ifdef SMS_MALLOC_CHECK
        mp->next = used_mem;
        used_mem=mp;
#endif

        hash(mp);
        return mp+1;
      }
      else
        pp=mp;
  }

  /*
   * No suitable chunk available in the free list, lets break for more memory 
   * We'll break in pages.
   */

  cutsize = ((size+BUFSIZ-1)/BUFSIZ)*BUFSIZ;

  if( (mp=(mlist *)sbrk(cutsize)) == (mlist *)(-1) )
    return NULL;

  malloc_sbreak += cutsize;

  if( (size+MINSIZE+sizeof(mlist)) >cutsize)
  {
    mp->size = size;
#ifdef SMS_MALLOC_CHECK
    mp->next = used_mem;
    used_mem=mp;
#endif

    hash(mp);
    return mp+1;
  }

  if(free_mem)
  {
    for(pp=free_mem ; pp->next ; )
      pp=pp->next;
    pp->next = (mlist *)(((char *)mp)+size);
    pp->next->next = NULL;
    pp->next->size = cutsize-size;
  }
  else
  {
    free_mem = (mlist *)(((char *)mp)+size);
    free_mem->next = NULL;
    free_mem->size = cutsize-size;
  }

  mp->size = size;

#ifdef SMS_MALLOC_CHECK
  mp->next = used_mem;
  used_mem=mp;
#endif

  hash(mp);
  return mp+1;
}

void free(void *ptr)
/*
 *  Free by (possibly) adjoining the freed chunk into the other parts
 */
{
  register mlist *mp,*pp,*np;

  if(!ptr) return;

  mp = (mlist *)ptr - 1;
  sanity(mp);

#ifdef SMS_MALLOC_CHECK
  if( !used_mem )
  {
    fprintf(stderr,"free:no used mem; address %x = %d (not freed)\n",mp,mp);
    return;
  }
#endif

#ifdef SMS_MALLOC_CHECK
 /*
  *  First remove it from the list of used memory
  */
  if( mp==used_mem )
    used_mem = used_mem->next;
  else
  {
    mlist *up;
    int    i=100000;

    for( pp=used_mem , up=used_mem->next ; --i && up && up != mp ; up=up->next )
      pp=up;

    if( !i )
    {
      static int count;

      if( count++ <10)
        fprintf(stderr,"free:loop detected in free list\n");
      return;
    }

    if(! up)
    {
      fprintf(stderr,"free:illegal address %x = %d (not freed)\n",mp,mp);
dump(stdout,mp,1024);
      abort();
      return;
    }

    pp->next = up->next;
  }
 /*
  * Now mp is floating find the right place for it in the free_list
  */
#endif

  if( !free_mem )                  /* Nothing in the free list */
  {
    mp->next = free_mem;
    free_mem = mp;
    return;
  }

#ifdef SMS_MALLOC_CHECK            /* Check for duplicate free */
  {
    register mlist *fp = free_mem;

    for( ; fp && fp != mp ; fp = fp->next )
      ;

      if( fp )
      {
        fprintf(stderr,"free:duplicate free. aborting...\n");
        abort();
      }
  }
#endif

  if( mp < free_mem )              /* Belong in front of the free list */
  {
    if( ((char*)mp) + mp->size == (char*)free_mem )
    {
      mp->size += free_mem->size;
      mp->next  = free_mem->next;
      free_mem  = mp;
    }
    else
    {
      mp->next = free_mem;
      free_mem = mp;
    }
  }
  else
  {
    for( pp=free_mem , np=free_mem->next ; np && mp>np ; np=np->next )
      pp=np;

    if( ((char*)pp) + pp->size == (char*)mp )
      pp->size += mp->size;
    else
    {
      mp->next = np;
      pp->next = mp;
      pp = mp;
    }
    
    if( ((char*)pp) + pp->size == (char*)np )
    {
      pp->size += np->size;        /* Join with the next */
      pp->next = np->next;
    }
  }
}

void *calloc(register size_t sz, register size_t nm)
{
  void *c;
  int   size = sz;
  int   numelem = nm;

  size *= numelem;

  c = malloc(size);

  if( c != NULL )
    bzero(c,size);

  return c;
}

void *realloc(void *ptr, size_t size)
{
  mlist *mp;
  void  *new_ptr;

  if(size==0)
  {
    free(ptr);
    return malloc(0);
  }

  if(ptr==NULL)
    return malloc(size);

  mp = (mlist *)ptr - 1;

  if( (new_ptr=malloc(size)) )
    bcopy(ptr,new_ptr, (mp->size<size)? mp->size : size );

  free(ptr);
  return new_ptr;
}

static void out(char *s)
{
  int len = strlen(s);

  write(2,s,len);
}

static int not(char *name,int code)
{
  out(name);
  out(" not implemented in this library");
  if(code>0)
    out(" -> abort");
  out("\n");

  if(code>0) 
    abort();
  return 1;
}

int mallopt(int x)                         { not("mallopt" ,0); return 1; }
int mallinfo(void)                          { not("mallinfo",1); return 1; }
void *valloc(size_t size)                    { not("valloc"  ,1); return 0; }
void *memalign(size_t alignment, size_t size) { not("memalign",1); return 0; }

#if 0

#include <unistd.h>        /* For sysconf */

void *valloc(int size)
{
  static int pagesize;

  if(!pagesize)
    pagesize = sysconf(_SC_PAGESIZE);

  return memalign(pagesize,size);
}

#endif


#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif

static void dump_between(FILE *fp, mlist *mp, mlist *prev, int limit)
{
  int   i,j;
  char *s = (char *)(prev+1) + prev->size;

  int   size = (int)((char *)mp - (char *)prev) - prev->size - sizeof(mlist);

  limit = MIN(limit,size);

  for( i=0 ; i<limit ; i += 8 )
  {
    int *k;

    fprintf(fp,"@ %x %d 0x",s,s);
    for( j=0 ; j<8 ; j++,s++ )
    {
      char a = (*s & 0xf0)>>4;
      char b = *s & 0x0f;
      fprintf(fp,"%c%c", tohex(a) , tohex(b) );
    }

    for( j=0,s-=8,k=(int *)s,fprintf(fp," ") ; j<2 ; j++,k++ )
      fprintf(fp,"%010d ", *k);

    for( j=0,fprintf(fp," ") ; j<8 ; j++,s++ )
      fprintf(fp,"%c", (*s<32 || *s>126)? '.' : *s );
    fprintf(fp,"\n");
  }
}

void print_alloc(FILE *fp, int mode, int between_mode)
{
  mlist *mp;
  int    free_size = 0, free_count = 0;
#ifdef SMS_MALLOC_CHECK
  int    used_size = 0, used_count = 0;
#endif

  for( mp=free_mem ; mp ; mp=mp->next , free_count++ )
    free_size += mp->size;
#ifdef SMS_MALLOC_CHECK
  for( mp=used_mem ; mp ; mp=mp->next , used_count++)
    used_size += mp->size;
#endif

#ifdef SANITY_CHECK
  fprintf(fp,"Sanity checks             %10d\n",sanity_count);
  fprintf(fp,"Hash checks               %10d\n",hash_count);
#endif

  fprintf(fp,"Size of sbreak allocation %10d\n",malloc_sbreak);
  fprintf(fp,"Size of free   allocation %10d (%d items)\n",
            free_size,free_count);
#ifdef SMS_MALLOC_CHECK
  fprintf(fp,"Size of used   allocation %10d (%d items)\n",used_size,used_count);
  fprintf(fp,"Size of total  allocation %10d\n",free_size+used_size);
  fprintf(fp,"Size of lost allocation   %10d\n",
         (free_count+used_count)*sizeof(mlist));

  fprintf(fp,"Number of calls to malloc  %9d (%d Mb + %d bytes)\n",
          malloc_calls, malloc_mega_bytes, malloc_bytes);
#endif

  if(mode>=0)
  {
    mlist *prev;

    fprintf(fp,"\nFree space\n");
    for( mp=free_mem, prev=NULL ; mp ; mp=mp->next )
    {
      /* fprintf(fp,"%x %d (%d)\n",mp,mp,mp->size - sizeof(mlist)); */
      fprintf(fp,"%x %d (%d) [%d]\n",mp,mp,mp->size - sizeof(mlist),
              prev? ((char *)mp - (char *)prev) - sizeof(mlist) : (-1) );
      if(mode>0)
        dump(fp,mp,mode);
      if(prev && between_mode>0)
        dump_between(fp,mp,prev,between_mode);
      prev=mp;
    }

#ifdef SMS_MALLOC_CHECK
    fprintf(fp,"\nUsed space\n");
    for( mp=used_mem ; mp ; mp=mp->next )
    {
      fprintf(fp,"%x %d (%d)\n",mp,mp,mp->size - sizeof(mlist));
      if(mode>0) dump(fp,mp,mode);
    }
#endif
  }
  fprintf(fp,"\n");
}

void sms_malloc_signal(int sig)
{
  FILE *fp;
  int   size = 0;
  int   between_size = 0;
  char  buff[MAXNAM] = { 0 };
  char *name = "sms_malloc_output";

  if( (fp=fopen("sms_malloc_control","r")) )
  {
    if( fscanf(fp,"%d %d %s",&size,&between_size,buff)==3 )
      name = buff;

    fclose(fp);
  }

  if( ! (fp=fopen(name,"w")) )
  {
    fprintf(stderr,"sms_malloc_signal: file open error %s\n",STR(name));
    fprintf(stderr,"  using stdout...\n");
    print_alloc(stdout,size,between_size);
  }
  else
  {
    print_alloc(fp,size,between_size);
    fclose(fp);
  }

  signal(sig,sms_malloc_signal);
}

#ifndef STANDALONE

int sms_malloc(int argc, char **argv)
/**************************************************************************
?  Along the line of IOI's memcheck
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   logit;
  static int   size,size_min=(-2),size_def=(-2),size_max=1<20;
  static int   bsize,bsize_min=(-1),bsize_def=(-1),bsize_max=1<20;

  if( called )
  {
    if( dummy )
      ioi_variable_set_int(*--argv,malloc_sbreak);

    if( logit )
      ioi_out(0,IOI_LOG,"malloc: size of the arena %d bytes",malloc_sbreak);

    if( size >= -1 )
      print_alloc(stdout,size,bsize);
    else if( ! dummy )
      ioi_printf(FALSE,"malloc: size of the arena %d bytes\n",malloc_sbreak);

    return TRUE;
  }
  else
  {
    ioi_exe_add("malloc:sms",sms_malloc,
      ioi_exe_link_param(
        ioi_exe_param(
          "-llog",IOI_L_BOOLEAN,ioi_exe_argv(
            "Generate log message into file also.",
            NULL
          ),NULL,1,&logit
        ),
        ioi_exe_param(
          "-bbetween_size",IOI_L_INTEGER,ioi_exe_argv(
            "Output a dump of memory between blocks, size specifies the max lenght",
            "or the dump:",
            " -1==do not print",
            "  0==addresses only",
            " >0==dump all used and free memory, hex int and character",
            NULL
          ),NULL,1,&size,&size_min,NULL,&size_def
        ),
        ioi_exe_param(
          "-ssize",IOI_L_INTEGER,ioi_exe_argv(
            "Output a dump of memory size specifies the max lenght",
            "or the dump:",
            " -2==no dump,",
            " -1==summary only",
            "  0==addresses only",
            " >0==dump all used and free memory, hex int and character",
            NULL
          ),NULL,1,&bsize,&bsize_min,NULL,&bsize_def
        ),
        NULL
      ),
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The possible variable to hold the current value.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Print/store the size of the malloc arena of malloc(SMS).",
        "Used to check the status of the malloc(SMS).",
        "After multiple calls in random order to malloc(SMS) and free(SMS)",
        "the arena can get fragmented.",
        NULL
      )
    );

#ifdef SIGUSR1
    /* printf("reg SIGUSR1\n"); */
    signal(SIGUSR1,sms_malloc_signal);
#endif
  }

  return called = TRUE;
}
#endif  /* STANDALONE */

#else
int sms_malloc(int argc, char **argv) { return 0; }
void sms_malloc_signal(int sig) {}
#endif /* SMS_MALLOC */

#if defined(hpux) || defined(__hpux)
void *_rpc_malloc(int size, ...)
{
  return malloc(size);
}

void _rpc_free(void *p, ...)
{
  free(p);
}
#endif

