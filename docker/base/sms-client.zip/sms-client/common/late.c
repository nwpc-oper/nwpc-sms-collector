/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     LATE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     22-SEP-1995 / 30-AUG-1995 / OP
.VERSION  4.3.10
.LANGUAGE ANSI-C
.FILE     late.c
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     05-JUL-2000 / 07-JUN-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*
*  Node late processing. (See also play.c)
*
*  Currently under test use in the SMS.
*
*  Late concept added into SMS as a long thought after feature.
*  With the flag-processing it was though better to be in SMS rather
*  than in XCdp (this allowes CDP also to show late tasks)
*  This, however, is another deviation from the original KISS principle.
*
************************************o*************************************/

#include "smslib.h"

static void sms_late_set(sms_node *np, int reason)
/**************************************************************************
?  Mark the task being late (if it is not already)
|  Node can be late multiple ways, all different occurences are markt
************************************o*************************************/
{
  if( ! FLAG_ISSET(np,FLAG_LATE) )
  {
    FLAG_SET(np,FLAG_LATE);
    SUITE_CHANGED(np);

    if( ! np->late )
      spit(0,IOI_WAR,"late:%s is late (%s) (from parent)",
        STR(sms_node_full_name(np)),STR(late_name[reason]));
  }
  if( np->late )
  {
    if( ! (np->late->status & (1<<reason)) )
      spit(0,IOI_WAR,"late:%s is late (%s)",
        STR(sms_node_full_name(np)),STR(late_name[reason]));

    np->late->status |= (1<<reason);
  }

}

static char *hh_mm(time_t t)
/**************************************************************************
?  Print time_t in HH:MM format
|  HH can be upto 99 (real clock)
************************************o*************************************/
{
  static char str[6];
  int         h,m;

  if(t<0) return "NONE!";

  h = t / 3600;  if( h>99 ) h=99;
  m = (t / 60) % 60;
  sprintf(str,"%02d:%02d",h,m);
  return str;
}

static void sms_late_check(
    sms_node *np,
    time_t    suite_time,
    time_t    begin_time,
    int       clock,
    time_t    parent_submitted)
/**************************************************************************
?  Check if a task is late.
|  hour[0] == LATE_SUBMITTED
|      [1] == LATE_ACTIVE
|      [2] == LATE_COMPLETE
|      [*] == (-1) not defined
|
|  At the moment "submitted" is not propagated down
************************************o*************************************/
{
  sms_time *lp;
  int       is_late = 0;

  if(!np) return;

  if( np->status == STATUS_UNKNOWN )
    return;

  if( np->status == STATUS_COMPLETE ||
      (np->status == STATUS_SUSPENDED && np->savedstat == STATUS_COMPLETE) )
    return;
 
  if( (lp=np->late) || parent_submitted )
  {
    time_t submitted, active, complete;

    if( lp )
    {
      submitted = (lp->hour[LATE_SUBMITTED]==NIL)?
                   NIL : lp->hour[LATE_SUBMITTED]*3600 + lp->minute[LATE_SUBMITTED]*60;
      active    = (lp->hour[LATE_ACTIVE]==NIL)?
                   NIL : lp->hour[LATE_ACTIVE]*3600 + lp->minute[LATE_ACTIVE]*60;
      complete  = (lp->hour[LATE_COMPLETE]==NIL)?
                   NIL : lp->hour[LATE_COMPLETE]*3600 + lp->minute[LATE_COMPLETE]*60;
    }
    else
       submitted = active = complete = NIL;

    if(submitted == NIL)
      submitted = parent_submitted;

    if( np->type == NODE_FAMILY || np->type == NODE_TASK )
    {
      if(np->status == STATUS_SUBMITTED && submitted != NIL)
        if( (np->stime + submitted) < suite_time )
        {
          sms_late_set(np,LATE_SUBMITTED);
          is_late |= (1<<LATE_SUBMITTED);
        }

      if(np->status != STATUS_ACTIVE && active != NIL)
        if(clock == CLOCK_HYBRID)
        {
          if(suite_time > begin_time+active)
          {
            sms_late_set(np,LATE_ACTIVE);
            is_late |= (1<<LATE_ACTIVE);
          }
        }
        else
        {
          time_t now = suite_time % 86400;

          if( now > active )
          {
            sms_late_set(np,LATE_ACTIVE);
            is_late |= (1<<LATE_ACTIVE);
          }
        }

      if(complete != NIL)
        if(lp->relative)
        {
          if(np->status == STATUS_ACTIVE)
            if( np->stime + complete < suite_time )
            {
              sms_late_set(np,LATE_COMPLETE);
              is_late |= (1<<LATE_COMPLETE);
            }
        }
        else
        {
          if(clock == CLOCK_HYBRID)
          {
            if(suite_time > begin_time+complete)
            {
              sms_late_set(np,LATE_COMPLETE);
              is_late |= (1<<LATE_COMPLETE);
            }
          }
          else
          {
            time_t now = suite_time % 86400;

            if( now > complete )
            {
              sms_late_set(np,LATE_COMPLETE);
              is_late |= (1<<LATE_COMPLETE);
            }
          }
        }

    }

    parent_submitted = submitted;
  }

  if( ! is_late )
    if(FLAG_ISSET(np,FLAG_LATE))
    {
      FLAG_CLEAR(np,FLAG_LATE);
      spit(0,IOI_WAR,"late:%s is not late anymore",STR(sms_node_full_name(np)));
    }

  np = np->kids;
  while(np)
  {
    sms_late_check(np,suite_time,begin_time,clock,parent_submitted);

    np=np->next;
  }
}

void sms_late_process(void)
/**************************************************************************
?  Loop through the suites. Called by SMS main loop, every minute
************************************o*************************************/
{
  sms_node *np;

  for( np = sms_._super->kids ; np ; np = np->next )
    if(np->status != STATUS_UNKNOWN && np->status != STATUS_COMPLETE)
      sms_late_check(np, np->stime, np->btime, np->clock, NIL);
}

char *sms_late_string(sms_node *np, int who)
/**************************************************************************
?  Print a description of a late structure into a string
|  One single line is produced if "r" is not NLLL
|  Used by XCdp, info(cdp) if who==1 or show(play) if who==0
************************************o*************************************/
{
  static char  str[MAXNAM];
  char        *s = str;
  sms_time    *lp = np->late;

  str[0] = '\0';

  if(!np)
    return str;

  lp = np->late;
  if( lp==NULL )
    return str;

  if( who )
  {
    if(lp->hour[0] != (-1))
      sprintf(s,"submitted %02d:%02d ",lp->hour[0],lp->minute[0]);
    s += strlen(s);

    if(lp->hour[1] != (-1))
      sprintf(s,"active %02d:%02d ",lp->hour[1],lp->minute[1]);
    s += strlen(s);

    if(lp->hour[2] != (-1))
      sprintf(s,"complete %s%02d:%02d",
              lp->relative? "+" : "", lp->hour[2],lp->minute[2]);
    s += strlen(s);
    *s = '\0';
  }
  else
  {
    if(lp->hour[0] != (-1))
      sprintf(s," -s %02d:%02d",lp->hour[0],lp->minute[0]);
    s += strlen(s);

    if(lp->hour[1] != (-1))
      sprintf(s," -a %02d:%02d",lp->hour[1],lp->minute[1]);
    s += strlen(s);

    if(lp->hour[2] != (-1))
      sprintf(s," -c %s%02d:%02d",
              lp->relative? "+" : "", lp->hour[2],lp->minute[2]);
    s += strlen(s);
    *s = '\0';
  }

  return str;
}
