/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     DELETE ALL
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     delall.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_delall(ls_gen **root)   /* The address of the start   */
/**************************************************************************
?  Delete all items in the list "root"
=  NULL
************************************o*************************************/
{
  if( root )
    while( *root )
      ls_delete( root,*root );

  return NULL;
}
