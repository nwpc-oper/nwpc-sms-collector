/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     CREATE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     create.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_create(int   type,      /* Loaded into ls_.   */
                  char *name)      /* If given duplicate */
/**************************************************************************
?  Create a new item of "type" and duplicate the "name" if given.
|  No checking is done if the "type" is known by LS.
|  Type 0 (zero) is reserved for ls_gen and is always availabe.
=  New item
|  NULL if the creation routine failed.
************************************o*************************************/
{
  ls_gen *gen;

  if(type && ls_._create[type])
    gen=ls_._create[type](name);
  else
    if( gen=(ls_gen *)calloc(ls_._size[type],1) )
      if(name)
        if( ! (gen->name=(char *)strdup(name)) )
          { free(gen); gen=NULL; }
        else
          ;
      else
        gen->name = NULL;

  if( gen )
  {
    gen->type = type;
    gen->next = NULL;
  }

  return gen;
}
