/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     FANCY (MULTICOLUMN) PRINT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     24-NOV-1993 / 05-SEP-1992 / OP
.VERSION  1.1
.LANGUAGE ANSI-C
.FILE     fancy.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

int
ls_fancy(ls_gen **root,            /* The address of the start */
         FILE    *fp,              /* Where to print           */
         int      width)           /* Width of the output      */
/**************************************************************************
?  Print the list in a multicolumn output if possible
=  Boolean success (FALSE if nothing to print or illegal width)
************************************o*************************************/
{
  int     i,n;
  int     len=0;                   /* Max width */
  ls_gen *tmp;
  char    fmt[10];

  if( !root || !*root ) return 0;

  for( tmp = *root ; tmp ; tmp=tmp->next )
  {
    i = tmp->name? strlen(tmp->name) : 0;
    len = (len>i)?len:i;           /* MAX */
  }

  if(len>width)                    /* Code here the warning if needed */
  ;

  sprintf(fmt,"%%-%ds",len+1);
  n = (width+1)/(len+1);

  for( i=1, tmp = *root ; tmp ; tmp=tmp->next )
  {
    fprintf(fp, (i!=n)?fmt:"%s\n",tmp->name );
    i = (i!=n)? i+1 : 1;
  }

  if(i!=1 && n>1) printf("\n");    /* Was the last line was full? */

  return 1;
}

