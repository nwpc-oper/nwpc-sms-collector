/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     DELETE NAME
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.1
.LANGUAGE ANSI-C
.FILE     delname.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_delname(ls_gen **root,          /* The address of the start   */
           char    *name)          /* The old item to be deleted */
/**************************************************************************
?  Delete an item named "name" from the list "root"
=  Boolean success
************************************o*************************************/
{
  return ls_delete(root,ls_find(root,name));
}
