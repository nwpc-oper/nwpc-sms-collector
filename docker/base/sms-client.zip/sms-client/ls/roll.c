/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     ROLL
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     27-APR-1993 / 05-SEP-1992 / OP
.VERSION  1.1
.LANGUAGE ANSI-C
.FILE     roll.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_roll(ls_gen **root,             /* The address of the start  */
        int      dir)              /* Direction & amount 2 roll */
/**************************************************************************
?  Roll the list 
-EXAMPLES
|  roll [A,B,C,D]  1   =>  [B,C,D,A]     // push
|  roll [A,B,C,D] -1   =>  [D,A,B,C]     // pop
|  roll [A,B,C,D]  0   =>  [A,B,C,D]     // nothing
=  Boolean success
|  FALSE if no elements in the list
|  TRUE otherwise
************************************o*************************************/
{
  ls_gen *start,*end;
  int     len,i;

  if( !root ) return FALSE;

  for( len=0 , start = *root ; start ; start=start->next )
  {
    end = start;
    len++;
  }

  if( (len) < 1 ) return FALSE;
  if( len < 2 || dir==0 ) return TRUE;

  if(dir>0)                        /* push */
  {
    if( (dir %= len) == 0 )
      return TRUE;
  }
  else                             /* pop */
  {
    dir = (-dir);
    if( (dir %= len) == 0 )
      return TRUE;
    dir = len - dir;
  }

  end->next = *root;               /* It is a ring now! */

  start = *root;
  
  for( i=1 ; i<dir ; i++ )
    start = start->next;

  *root = start->next;
  start->next = NULL;

  return TRUE;
}
