/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     PARSE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 05-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     parse.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_parse(ls_gen **root,             /* The address of the start */
        char    *text,             /* The text to be parsed    */
        char     separator)        /* Field separator          */
/**************************************************************************
?  Parse a line of text into tokens
|  Eg text = [aa:bb] with separator==':' ---> [aa] [bb]
=  Number of tokens generated
|  Separator is not part of any of the tokens generated.
************************************o*************************************/
{
  char       *s;                   /* Current string in token */
  char        rem;                 /* Remember this while cutting */
  char       *start = text;        /* The first token starts here */
  int         count;

  while( *text )
  {
    if( *text == separator )
    {
      rem = *text;
      *text = '\0';

      ls_add(root,ls_create(0,start));
      count++;

      *text = rem;
      start = ++text;
    }
    else
      text++;
  }

  if( start != text )
  {
      ls_add(root,ls_create(0,start));
      count++;
  }

  return count;
}
