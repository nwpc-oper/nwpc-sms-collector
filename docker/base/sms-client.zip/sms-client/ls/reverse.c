/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     REVERSE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 05-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     reverse.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_reverse(ls_gen **root)          /* The address of the start         */
/**************************************************************************
?  Reverse the order of the list
=  Boolean success
|  FALSE if no elements in the list or no memory for the internal buffers
************************************o*************************************/
{
  int      len,i;
  ls_gen **array,                  /* Will be 1 more than len */
          *tmp;

  if( (len=ls_len(root)) < 1 ) return FALSE;

  if(len>1)
  {
    if(!(array=(ls_gen **)calloc(len+1,sizeof(ls_gen *))))
      return FALSE;

    for( i=len , tmp=(*root) ; i ; tmp=tmp->next )
      array[--i] = tmp;

    for( i=0 ; i<len ; i++ )
      array[i]->next = array[i+1]; /* The last on will be NULL from calloc */
 
    *root = array[0];
    free(array);
  }

  return TRUE;
}

