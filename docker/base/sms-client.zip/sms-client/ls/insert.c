/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     INSERT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 06-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     insert.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_insert(ls_gen **root,           /* The address of the start */
          ls_gen  *newone)         /* The new item to be added */
/**************************************************************************
?  Add item "newone" into the list "root" in alphabetically right place
|  If the list was empty the original "root" will be updated.
|  The next field of the "newone" will be updated and should not point 
|  anything.
-CALL  Same as add
=  Boolean success
|    FALSE: "newone" was NULL
************************************o*************************************/
{
  if(ls_add_d(root,newone))
    return ls_sort(root,NULL);
  return FALSE;
}
