/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     SORT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 05-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     sort.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

static int alpha_compare(const ls_gen **a, const ls_gen **b)
/**************************************************************************
?  The default comparation routine for the list sort
=  The relation of the names.
************************************o*************************************/
{
  return strcmp((*a)->name,(*b)->name);
}

ls_sort(ls_gen **root,
        int   (* compare)(const ls_gen **, const ls_gen **)
       )
/**************************************************************************
?  Sort the list according the "compare" routine
|  If "compare" is NULL the list will be sorted alphabetically according
|  to the "name" field.
=  Boolean success
|  FALSE if no elements in the list or no memory for the internal buffers
~  qsort(3)
!  It can be an error to order mixed lists, that is lists that contain
|  elements of more then a single type. It all depends what the "compare"
|  does.
************************************o*************************************/
{
  int      len,i;
  ls_gen **array,                  /* Will be 1 more than len */
          *tmp;

  if( (len=ls_len(root)) < 1 ) return FALSE;

  if(len==1) return TRUE;

  if(!(array=(ls_gen **)calloc(len+1,sizeof(ls_gen *))))
    return FALSE;

  for( i=0 , tmp=(*root) ; i<len ; i++ , tmp=tmp->next )
    array[i] = tmp;

  qsort(array,len,sizeof(ls_gen *), compare? compare:alpha_compare);
 
  for( i=0 ; i<len ; i++ )
    array[i]->next = array[i+1];   /* The last on will be NULL from calloc */
 
  *root = array[0];
  free(array);

  return TRUE;
}

