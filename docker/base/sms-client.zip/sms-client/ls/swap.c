/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     SWAP
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     09-NOV-1995 / 09-NOV-1995 / OP
.VERSION  1.3
.LANGUAGE ANSI-C
.FILE     sawp.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_swapf(ls_gen **root,              /* The address of the start     */
         ls_gen  *key)               /* Item to be swapped with next */
/**************************************************************************
?  Swap forward
?  Swap item "key" with the next one in the list "root"
|  Notice that "key" must already be in the list
=  Boolean success
|    FALSE: Only one element in the list
|           Key is the last
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *third;

  if( !key || !start )
    return FALSE;

  if(!key->next)
    return FALSE;

  third = key->next->next;

  if(key==start)
  {
    *root = key->next;
    key->next->next = key;
    key->next = third;
  }
  else
  {
    ls_gen *prev = ls_find_prev(root,key);

    prev->next = key->next;
    key->next->next = key;
    key->next = third;
  }

  return TRUE;
}

ls_swapb(ls_gen **root,            /* The address of the start         */
         ls_gen  *key)             /* Item to be swapped with previous */
/**************************************************************************
?  Swap backward
?  Swap item "key" with the previous one in the list "root"
|  Notice that "key" must already be in the list
=  Boolean success
|    FALSE: Only one element in the list
|           Key is the first
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *third;

  if( !key || !start )
    return FALSE;

  if(key == start)
    return FALSE;

  return ls_swapf(root,ls_find_prev(root,key));
}
