/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     LENGHT 
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     27-APR-1993 / 05-SEP-1992 / OP
.VERSION  1.1
.LANGUAGE ANSI-C
.FILE     len.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_len(ls_gen **root)              /* The address of the start */
/**************************************************************************
?  Compute the number of elements in the list.
=  -1 (NIL) if the root = NULL
|   0       if the *root = NULL
|  >0       the number of elements in the list
************************************o*************************************/
{
  ls_gen *start;
  int     len;

  if( !root ) return NIL;

  for( len=0 , start = *root ; start ; start=start->next )
    len++;

  return len;
}
