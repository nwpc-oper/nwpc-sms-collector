/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     FREE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     free.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_free(ls_gen *gen)       /* The item 2 B deleted */
/**************************************************************************
?  Free the item "gen". Can be called with gen==NULL (overkilling)
=  NULL
************************************o*************************************/
{
  if( !gen ) return NULL;

  if( ls_._delete[gen->type] )
    ls_._delete[gen->type](gen);
  else
  {
    IFFREE(gen->name);
    free(gen);
  }

  return NULL;
}
