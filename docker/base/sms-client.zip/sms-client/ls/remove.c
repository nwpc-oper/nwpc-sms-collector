/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     REMOVE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     remove.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_remove(ls_gen **root,           /* The address of the start   */
          ls_gen  *old)            /* The old item to be removed */
/**************************************************************************
?  Remove the node "old" from the list without deleting it.
|  If found the "old->next" is cleared.
=  BOOLEAN status, was the "old" found from the list.
************************************o*************************************/
{
  ls_gen *start = *root,*last;

  if( !start ) return FALSE;       /* This really shouldn't happed */
  if( !old ) return FALSE;

  if( start == old )
    *root = (*root)->next;
  else
  {
    while( start && start != old ) { last = start; start = start->next; }

    if( start )
      last->next = old->next;
    else
      return FALSE;
  }

  old->next = NULL;
  return TRUE;
}
