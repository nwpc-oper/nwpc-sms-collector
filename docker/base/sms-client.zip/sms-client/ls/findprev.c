/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     FIND-PREVIOUS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-DEC-1995 / 15-MAR-1995 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     find_prev.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_find_prev(ls_gen **root,     /* The address of the start */
                     ls_gen  *key)      /* An element int the list  */
/**************************************************************************
?  Find a previous item by the "key" given.
=  ITEM if found, NULL otherwise.
************************************o*************************************/
{
  ls_gen *start = *root;

  if( !key ) return NULL;
  if( !start ) return NULL;

#if 0
  if(key==start)
    return 0;
#endif

  while( start )
  {
    if( start->next == key )
      return start;
    start = start->next;
  }

  return 0;
}
