/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     ADD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1993 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     add.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_add(ls_gen **root,              /* The address of the start */
       ls_gen  *newone)            /* The new item to be added */
/**************************************************************************
?  Add item "newone" into the list "root"
|  If the list was empty the original "root" will be updated.
|  The next field of the "newone" will be cleared
-CALL:
|  ls_gen *start, *newone;
|  ... in the beginning: start=NULL;
|  newone = (ls_gen*)calloc( ... );
|  list_add( &start , newone );
=  Boolean success
|    FALSE: "newone" was NULL
************************************o*************************************/
{
  ls_gen *start = *root;

  if( !newone ) return FALSE;

  newone->next = NULL;

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = newone;
  }
  else
    *root = newone;

  return TRUE;
}

