/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     ITEM
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 25-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     item.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_item(ls_gen **root,     /* The address of the start  */
                int      key)      /* The item number; 0==first */
/**************************************************************************
?  Find the item by its position number
=  ITEM if found, NULL otherwise.
************************************o*************************************/
{
  ls_gen *start;
  int     i;

  if( !root ) return NULL;
  if( key<0 ) return NULL;

  for( start = *root , i=0 ; start ; start = start->next , i++ )
    if( i==key )
      return start;

  return NULL;
}
