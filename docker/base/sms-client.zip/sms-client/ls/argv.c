/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     ARGV
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 02-MAR-1994 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     argv.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_argv(ls_gen **root,             /* The address of the start */
        int argc, char **argv)     /* The new items to be added */
/**************************************************************************
?  Add items into "root" by creating ls_gen's and allocating new memory
|  for each new element in "argv". That is items created will not point
|  into same memory as the "argv".
=  Boolean success
|    FALSE: No memory for the new. In this case some of the elements
|           might have been added.
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *newone;

  if( argc < 1 ) return FALSE;

  if( ! (newone=ls_create(0,*argv)) )
    return FALSE;

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = newone;
  }
  else
    *root = newone;

  while( --argc )                  /* --x cause we added one already */
  {
    start = newone;

    if( ! (newone=ls_create(0,*++argv)) )          /* ++x same as above */
      return FALSE;

    start->next = newone;
  }

  return TRUE;
}

#if 0
int ls_argcargv(ls_gen *root, int *argc, char ***argv)
/**************************************************************************
?  Make argc argv out of a list pointed by root
|  The "argv" array is allocated by this routine
|  The values in argv do not belong to argv (same pointers as in the root)
=  Boolean success
|    FALSE: No memory for the new array.
************************************o*************************************/
{
  int    ac = 0;
  char **av;

  *argc = 0;

  if(root) return 0;

  *argc = ls_len(&root);
  av = *argv = calloc(sizeof(char *), *argc);
  if( !av ) return 0;

  for( ; root ; root=root->next )
    av[ac++] = root->name ;

  return 1;
}
#endif
