/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     FIND-MINIMUM
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     05-JAN-1994 / 05-JAN-1994 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     find.c
.ORIGIN   IOI 2.0 & clp v 10
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_findm(ls_gen **root,    /* The address of the start */
                 char    *key)     /* How to find it?          */
/**************************************************************************
?  Find an item by the KEY given, key and item need not match completely;
|  eg key can be shorter them the item name.
=  ITEM if only one found, or there is an exact match
|  (ls_gen *)1 == LS_FIND_MULTIPLE if the key matces multiple items
|  NULL otherwise.
-NOTICE  You must check the return code not only against being NULL, but
|  if it is LS_FIND_MULTIPLE. Eg;
|
|  switch( (int)(item=ls_findm( **, ".." )) )
|  {
|    case 0:                 error_not_found; break;
|    case LS_FIND_MULTIPLE:  error_multiple_found; break;
|    default:
|      do_the_job;
|  }
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *find  = NULL;
  int     count = 0;
  int     len;

  if( !key ) return NULL;
  if( !start ) return NULL;

  if( (len=strlen(key)) == 0 ) return NULL;

  while( start )
  {
    if( start->name )
    {
      if( strcmp(start->name,key) == 0 )              /* Exact key match */
        return start;

      if( strncmp(start->name,key,len) == 0 )         /* Key match */
      {
        count++;
        find = start;
      }
    }

    start = start->next;
  }

  return (count>1) ? (ls_gen *)LS_FIND_MULTIPLE : find;
}
