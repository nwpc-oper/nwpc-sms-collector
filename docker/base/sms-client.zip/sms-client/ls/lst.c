/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     TESTER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     27-APR-1993 / 31-AUG-1992 / OP
.VERSION  1.1
.DATE     05-NOV-1993 / 01-NOV-1993 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     lst.c
************************************o*************************************/

#include "ls.h"

typedef struct user {
  int          type;
  char        *name;
  struct user *next;
  char        *addr;
} user_t;

extern char *strdup(const char *);

#ifdef VAX
char *strdup(const char *s)
{
  char *x = (char *)malloc(strlen(s)+1);
  strcpy(x,s);
  return x;
}
#endif

void *create_u(char *name)
{
  user_t *u;

  u = (user_t *)malloc(sizeof(user_t));
  u->name = strdup(name);
  u->addr = strdup("unknown");

  return (ls_gen *)u;
}

int print_u(user_t *u, FILE *fp)
{
  return fprintf(fp,"%-20s %s\n",u->name,u->addr);
}

void *delete_u(user_t *u)
{
  IFFREE(u->name);
  IFFREE(u->addr);
  free(u);
  return NULL;
}

static void find(ls_gen **root, char *key)
{
  ls_gen *f;

  switch( (int)(f=(ls_gen *)ls_findm(root,key)) )
  {
    case 0:                printf("FOUND:(%s):%s\n",key,"<nothing>"); break;
    case LS_FIND_MULTIPLE: printf("FOUND:(%s):%s\n",key,"<many>");    break;
    default:               printf("FOUND:(%s):%s\n",key,f->name);     break;
  }
}

main(int argc, char **argv)
{
  ls_gen *root = NULL;
  ls_gen *join = NULL;
  ls_gen *users = NULL;

  printf("This is a test program for the LIBLS\n\n");

  ls_open();

  printf("Adding own type\n");
  ls_init(1,"user",sizeof(user_t),TRUE,create_u,delete_u,NULL,print_u);

  printf("Testing the basic type:adding three elements and print\n");
  ls_add(&root,ls_create(0,"one"));
  ls_add(&root,ls_create(0,"two"));
  ls_add(&root,ls_create(0,"three"));
  ls_print_all(&root,stdout);

  printf("Testing the find multiple\n");
  find( &root,"t" );
  find( &root,"x" );
  find( &root,"o" );

  printf("Deleting (two)   :: ");
  ls_delname(&root,"two");
  ls_fancy(&root,stdout,80);

  printf("Creating a second list and joining that into the previous\n");
  ls_add(&join,ls_create(0,"j1"));
  ls_add(&join,ls_create(0,"j2"));
  ls_add(&join,ls_create(0,"j3"));
  ls_join(&root,join);
  ls_fancy(&root,stdout,80);

  printf("Creating own types and print\n");
  ls_add((ls_gen **)&users,ls_create(1,"Rex"));
  ls_add(&users,ls_create(1,"Milan"));
  ls_add(&users,ls_create(1,"Freddie"));
  ls_fancy(&users,stdout,80);

  printf("Deleting (Milan) :: ");
  ls_delname(&users,"Milan");
  ls_delname(&users,"NotFound");
  ls_fancy(&users,stdout,80);

  printf("Sort             :: ");
  ls_sort(&root,NULL);
  ls_fancy(&root,stdout,80);

  printf("Reverse          :: ");
  ls_reverse(&root);
  ls_fancy(&root,stdout,80);

  printf("Elements  %3d    :: ",ls_len(&root));
  ls_fancy(&root,stdout,80);

  printf("Index of (one)   :: %d\n",ls_index(&root,"one"));

  printf("Insert (4)(6)    :: ");
  ls_insert(&root,ls_create(0,"four"));
  ls_insert(&root,ls_create(0,"six"));
  ls_fancy(&root,stdout,80);

  printf("Randomize        :: ");
  ls_random(&root);
  ls_fancy(&root,stdout,80);

  printf("Roll  1          :: ");
  ls_roll(&root,1);
  ls_fancy(&root,stdout,80);

  printf("Roll -2          :: ");
  ls_roll(&root,-2);
  ls_fancy(&root,stdout,80);

  printf("Roll 66          :: ");
  ls_roll(&root,66);
  ls_fancy(&root,stdout,80);

  printf("Roll  0          :: ");
  ls_roll(&root,0);
  ls_fancy(&root,stdout,80);

  printf("Element 0 is [%s]\n", ((ls_gen *)ls_item(&root,0))->name );
  printf("Element 3 is [%s]\n", ((ls_gen *)ls_item(&root,3))->name );
}
