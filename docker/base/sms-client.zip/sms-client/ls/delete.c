/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     DELETE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     delete.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_delete(ls_gen **root,           /* The address of the start   */
          ls_gen  *old)            /* The old item to be deleted */
/**************************************************************************
?  Delete an item "old" from the list "root"
=  Boolean success
|    FALSE: Not found.
************************************o*************************************/
{
  ls_gen *start = *root,*last;

  if( !start ) return FALSE;       /* This really shouldn't happed */
  if( !old ) return FALSE;

  if( ! ls_remove(root,old) )
    return FALSE;

  ls_free( old );
  return TRUE;
}
