/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     PRINT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     print.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

void ls_print(ls_gen *gen,         /* The item 2 B printed         */
              FILE   *fp)          /* File to be used for printing */
/**************************************************************************
?  Print a single elements "gen"
|  This is mainly used for debugging, but if the list types loaded into
|  LS produce reasonable prints, this routine can be used as a vehicle
|  for printing.
-NOTICE  This routine does NOT take pointer to pointer argument.
************************************o*************************************/
{
  if(!gen) return;

  if(gen->type==0 || ! ls_._print[gen->type])
    fprintf(fp,"%s\n",gen->name);
  else
    ls_._print[gen->type](gen,fp);
}

void ls_print_all(ls_gen **root,   /* The address of the start     */
                  FILE    *fp)     /* File to be used for printing */
/**************************************************************************
?  Print the whole list by calling ls_print for all the elements in the
|  list. Thus different types can be printed at one go.
************************************o*************************************/
{
  ls_gen *start = *root;

  while(start)
  {
    ls_print(start,fp);
    start = start->next;
  }
}
