/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     RANDOM
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 05-SEP-1992 / OP
.VERSION  1.2
.DATE     11-FEB-1998 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     random.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

static void table(int len, int *number)
/**************************************************************************
?  Randomize a index table
************************************o*************************************/
{
  int i,a,b,t;

  for(i=0 ; i<len ; i++)
    number[i] = i;

  for(i=0 ; i<len ; i++)
  {
    a = rand() % len;
    b = rand() % len;
    t = number[a];
    number[a] = number[b];
    number[b] = t;
  }
}

ls_random(ls_gen **root)           /* The address of the start         */
/**************************************************************************
?  Randomize the order of the list
=  Boolean success
|  FALSE if no elements in the list or no memory for the internal buffers
************************************o*************************************/
{
  int      len,i;
  ls_gen **array,                  /* Will be 1 more than len */
          *tmp;
  int     *number;                 /* Randomized index table */

  if( (len=ls_len(root)) < 1 ) return FALSE;

  if(len>1)
  {
    if(!(array=(ls_gen **)calloc(len+1,sizeof(ls_gen *))))
      return FALSE;
    if(!(number=(int *)calloc(len,sizeof(int))))
    {
      free(array);
      return FALSE;
    }
    table(len,number);
    
    for( i=len , tmp=(*root) ; i ; tmp=tmp->next )
      array[number[--i]] = tmp;

    for( i=0 ; i<len ; i++ )
      array[i]->next = array[i+1]; /* The last on will be NULL from calloc */
 
    *root = array[0];

    free(array);
    free(number);
  }

  return TRUE;
}

