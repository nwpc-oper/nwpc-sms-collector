/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     JOIN
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.DATE     11-FEB-1998 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     join.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_join(ls_gen **root,             /* The address of the start */
        ls_gen  *newone)           /* The newone item to be added */
/**************************************************************************
?  "join" a list "newone" into the list "root".
|  If the list was empty the original "root" will be updated.
|  "newone->next" is not examined nor modified.
-CALL  Like ls_add()
=  Boolean success
|    0: "newone" was NULL
************************************o*************************************/
{
  ls_gen *start = *root;

  if( !newone ) return 0;

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = newone;
  }
  else
    *root = newone;

  return 1;
}
