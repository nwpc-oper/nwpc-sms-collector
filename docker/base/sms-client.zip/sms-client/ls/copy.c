/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     COPY
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 03-MAR-1994 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     copy.c
*NA
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_copy(
    ls_gen **root,                 /* The address of the start */
    ls_gen  *old)                  /* The new items to be added */
/**************************************************************************
?  Add items into "root" by creating ls_gen's and allocating new memory
|  for each new element in list "old". That is items created will not
|  point into same memory as the ones in list "old"
=  Boolean success
|    FALSE: No memory for the new items.
|           In this case some of the elements might have been added.
-NOTICE
|  At the moment works just for type ls_gen
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *newone;

  if( ! old ) return FALSE;

  if( ! (newone=ls_create(0,old->name)) )
    return FALSE;

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = newone;
  }
  else
    *root = newone;

  while( (old=old->next) )         /* Cause we added one already */
  {
    start = newone;

    if( ! (newone=ls_create(0,old->name)) )
      return FALSE;

    start->next = newone;
  }

  return TRUE;
}
