/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     INDEX
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     08-NOV-1995 / 06-SEP-1992 / OP
.VERSION  1.3
.LANGUAGE ANSI-C
.FILE     index.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_index(ls_gen **root,           /* The address of the start */
         char    *key)            /* How to find it?          */
/**************************************************************************
?  Compute the index of "key" in the list "root"
=   -1 (NIL) if the "root" == NULL or if "key" is not found
|  >=0       The index (the first element is number 0!
************************************o*************************************/
{
  ls_gen *start;
  int     len;

  if( !root ) return NIL;

  for( start = *root , len=0 ; start ; start = start->next , len++ )
    if( start->name )
      if( strcmp(start->name,key) == 0 )
        return len;

  return NIL;
}

ls_index_key(ls_gen **root,        /* The address of the start */
             ls_gen *key)          /* How to find it?          */
/**************************************************************************
?  Compute the index of "key" in the list "root"
=   -1 (NIL) if the "root" == NULL or if "key" is not found
|  >=0       The index (the first element is number 0!
************************************o*************************************/
{
  ls_gen *start;
  int     len;

  if( !root ) return NIL;
  if( !key  ) return NIL;

  for( start = *root , len=0 ; start ; start = start->next , len++ )
    if( start == key )
        return len;

  return NIL;
}
