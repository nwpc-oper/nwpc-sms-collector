/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     LAST
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     02-NOV-1995 / 02-NOV-1995 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     last.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_last(ls_gen **root)     /* The address of the start */
/**************************************************************************
?  Find the last element in the list
=  ITEM if found, NULL otherwise.
************************************o*************************************/
{
  ls_gen *start = *root;

  if( !start ) return NULL;

  while( start && start->next )
    start = start->next;

  return( start );
}
