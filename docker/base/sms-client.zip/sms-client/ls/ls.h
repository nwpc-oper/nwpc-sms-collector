/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     LIBLS-HEADER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     04-SEP-1992 / 31-AUG-1992 / OP
.VERSION  1.0
.FILE     ls.c
.LANGUAGE ANSI-C
.DATE     07-AUG-1998 / 01-NOV-1993 / OP
.VERSION  1.2
*         Now with prototypes for library and users
************************************o*************************************/

#ifndef LS_LIBRARY_H
#define LS_LIBRARY_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#ifndef NIL
#  define NIL (-1)
#endif

#ifndef TRUE
#  define TRUE  1
#  define FALSE 0
#endif

#ifndef IFFREE
#  define IFFREE(a) if((a)) { free(a); a=NULL; } else 
#endif

#ifndef LS_GEN
  typedef struct ls_gen {          /* Generic for list routines */
    int                  type;     /* What this structure is?   */
    char                *name;     /* Name of the list item     */
    struct ls_gen       *next;     /* Next item in the list     */
    /* ... */                      /* Rest of the stuff         */
  } ls_gen;                        /* NOTICE! This == ioi_token */

#  define LS_GEN
#endif

/* #define LS_FIND_MULTIPLE ((ls_gen *)1) */
#define LS_FIND_MULTIPLE 1

typedef struct ls_type {           /* Generic for list routines */
  int                  type;       /* What this structure is?   */
  char                *name;       /* Name of the list item     */
  struct ls_type      *next;       /* Next item in the list     */
  int                  size;       /* Size of the item          */
  int                  duplicates; /* Are duplicates allowed    */
  ls_gen           *(* create)();  /* Routine 2 create the type */
  ls_gen           *(* purge)();   /* Routine 2 delete          */
  int               (* xdr)();     /* Routine 2 xdr             */
  int               (* print)();   /* Routine 2 print if any    */
} ls_type;

#ifdef LS_LIBRARY

#  ifndef LS_MAIN_MODULE
     extern
#  endif
     struct {
       ls_type     *_root;         /* List of types defined. Not in 2.0 */
       int          _types;        /* Number of types        */
       char       **_name;         /* Tables for fast access */
       int         *_size;
       int         *_duplicates;
       ls_gen  *(** _create)();
       ls_gen  *(** _delete)();
       int      (** _xdr)()   ;
       int      (** _print)() ;
     } ls_;
#endif

/**************************************************************************
*                   L I B L S   P R O T O T Y P E S  
************************************o*************************************/

#if defined(LS_LIBRARY) || defined(LS_PROTOTYPES)

int     ls_add      (ls_gen **root, ls_gen *newone);
int     ls_add_d    (ls_gen **root, ls_gen *newone);
int     ls_argv     (ls_gen **root, int     argc, char **argv);
int     ls_copy     (ls_gen **root, ls_gen *old);
ls_gen *ls_create   (int      type, char   *name);
ls_gen *ls_delall   (ls_gen **root);
int     ls_delete   (ls_gen **root, ls_gen *old);
int     ls_delname  (ls_gen **root, char   *name);
int     ls_fancy    (ls_gen **root, FILE   *fp,   int width);
ls_gen *ls_find     (ls_gen **root, char   *key);
ls_gen *ls_findm    (ls_gen **root, char   *key);
ls_gen *ls_find_prev(ls_gen **root, ls_gen *key);
ls_gen *ls_free     (ls_gen  *gen);
int     ls_index    (ls_gen **root, char   *key);
int     ls_index_key(ls_gen **root, ls_gen *key);

int     ls_init     (int type, char *name, int size, int duplicates,
                     ls_gen *(* create)(), ls_gen *(* purge)(),
                     int     (* xdr)(),    int     (* print)() );

int     ls_insert   (ls_gen **root, ls_gen *newone);
ls_gen *ls_item     (ls_gen **root, int     key);
int     ls_join     (ls_gen **root, ls_gen *newone);
int     ls_len      (ls_gen **root);
ls_gen *ls_last     (ls_gen **root);
int     ls_open     (void);
int     ls_parse    (ls_gen **root, char   *text, char     separator);
void    ls_print    (ls_gen  *gen,  FILE   *fp);
void    ls_print_all(ls_gen **root, FILE   *fp) ;
int     ls_random   (ls_gen **root);
int     ls_remove   (ls_gen **root, ls_gen *old);
int     ls_reverse  (ls_gen **root);
int     ls_roll     (ls_gen **root, int     dir);
int     ls_sort     (ls_gen **root, int   (*compare)() );
int     ls_swapf    (ls_gen **root, ls_gen *key);
int     ls_swapb    (ls_gen **root, ls_gen *key);

#else

/**************************************************************************
*                   L I B L S   P R O T O T Y P E S  
*                          P u b l i c   u s e
************************************o*************************************/

int     ls_add      (void *root, void *newone);
int     ls_add_d    (void *root, void *newone);
int     ls_argv     (void *root, int     argc, char **argv);
int     ls_copy     (void *root, void *old);
void   *ls_create   (int   type, char   *name);
void   *ls_delall   (void *root);
int     ls_delete   (void *root, void *old);
int     ls_delname  (void *root, char   *name);
int     ls_fancy    (void *root, FILE   *fp,   int width);
void   *ls_find     (void *root, char   *key);
void   *ls_findm    (void *root, char   *key);
void   *ls_find_prev(void *root, void *key);
void   *ls_free     (void *gen);
int     ls_index    (void *root, char   *key);
int     ls_index_key(void *root, void *key);

int     ls_init     (int   type, char *name, int size, int duplicates,
                     void *(* create)(), void *(* purge)(),
                     int     (* xdr)(),    int     (* print)() );

int     ls_insert   (void *root, void *newone);
void   *ls_item     (void *root, int     key);
int     ls_join     (void *root, void *newone);
int     ls_len      (void *root);
void   *ls_last     (void *root);
int     ls_open     (void);
int     ls_parse    (void *root, char   *text, char     separator);
void    ls_print    (void *gen,  FILE   *fp);
void    ls_print_all(void *root, FILE   *fp) ;
int     ls_random   (void *root);
int     ls_remove   (void *root, void *old);
int     ls_reverse  (void *root);
int     ls_roll     (void *root, int     dir);
int     ls_sort     (void *root, int   (*compare)() );
int     ls_swapf    (void *root, void *key);
int     ls_swapb    (void *root, void *key);

#endif /* PROTOTYPES */

#endif /* LS_LIBRARY_H */
