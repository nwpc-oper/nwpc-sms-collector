/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     ADD-DELETE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 06-SEP-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     add_d.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_add_d(ls_gen **root,            /* The address of the start */
         ls_gen  *newone)          /* The newone item to be added */
/**************************************************************************
?  Add item "newone" into the list "root".
|  If the list was empty the original "root" will be updated.
|  The next field of the "newone" will be cleared
|  Multiple elements of same name is controlled by the initialized
|  duplicate value of the type of the "newone".
-CALL  Same as add()
=  Boolean success
|    FALSE: "newone" was NULL
************************************o*************************************/
{
  ls_gen *start = *root;
  ls_gen *die = NULL;

  if( !newone ) return FALSE;

  newone->next = NULL;

  if( newone->name && ! ls_._duplicates[newone->type] )
  {
    if( die=ls_find(root,newone->name) )
      ls_delete(root,die);

    start = *root;                 /* We might have deleted it! */
  }

  if( start )
  {
    while( start->next ) start = start->next;
    start->next = newone;
  }
  else
    *root = newone;

  return TRUE;
}

