/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     INIT
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     06-NOV-1993 / 31-AUG-1992 / OP
.VERSION  1.1
.LANGUAGE ANSI-C
.FILE     init.c
************************************o*************************************/

#define LS_LIBRARY
#define LS_MAIN_MODULE

#include "ls.h"

ls_init(int        type,           /* Type number                  */
        char      *name,           /* Name of the type             */
        int        size,           /* If calloc is create          */
        int        duplicates,     /* Are duplicates allowed?      */
        ls_gen *(* create)(),      /* Routine to create a new item */
        ls_gen *(* purge)(),       /* Routine to free an item      */
        int     (* xdr)(),         /* Routine to serialize an item */
        int     (* print)()        /* Routine to print an item     */
       )
/**************************************************************************
?  Add a new list type. Very high "type" number will cause internal
|  tables to be large. Number zero is reserved for LS.
|  Before adding your own type make sure to call void ls_open(void) 1st!
=  Boolean success
************************************o*************************************/
{
  static   int called;
  ls_type *lt = ls_._root;
  ls_type *newone;
  int      types = ls_._types;
  int      i;

  if( !called )
    if(type!=0)
    {
      fprintf(stderr,"LS-INIT:Not properly initialize\n");
      fprintf(stderr,"LS-INIT:Can not continue!\n");
      exit(1);
    }
    else
    {
      name = "ls_gen";
      size = sizeof(ls_gen);
      duplicates = TRUE;
      create = purge = NULL;
      print = NULL;
      xdr = NULL;

      called = TRUE;
    }

  while( lt )
    if( lt->type == type || !strcmp(lt->name,name) )
      break;
    else
      lt = lt->next;

  if( lt )
  {
    fprintf(stderr,"LS-INIT:Type %s (%d) re-initialized\n",name,type);
    fprintf(stderr,"LS-INIT:Can not continue!\n");
    exit(1);
  }

  if( ! (newone=(ls_type *)calloc(sizeof(ls_type),1)) )
  {
    fprintf(stderr,"LS-INIT:No mem\n");
    fprintf(stderr,"LS-INIT:Can not continue!\n");
    exit(1);
  }

  newone->type = type;
  newone->name = (char *)strdup(name);
  newone->size = size;
  newone->duplicates = duplicates;
  newone->create     = create;
  newone->purge      = purge;
  newone->xdr        = xdr;
  newone->print      = print;

  newone->next = ls_._root;
  ls_._root = newone;

#define RSZ(x,t) if( ! (x=(t)realloc(x,sizeof(void *)*(types+1))) ) {\
                   fprintf(stderr,"LS-INIT:%s (%d):No mem (re)\n",name,type);\
                   exit(1);}
#define ISZ(x,t) if( ! (x=(t)calloc(sizeof(void *),(types+1))) ) {\
                   fprintf(stderr,"LS-INIT:%s (%d):No mem (i)\n",name,type);\
                   exit(1);}

  if(types)
  {
    types = types>type?types:type;
    RSZ(ls_._name       , char  **       );
    RSZ(ls_._size       , int    *       );
    RSZ(ls_._duplicates , int    *       );
    RSZ(ls_._create     , ls_gen *(**)() );
    RSZ(ls_._delete     , ls_gen *(**)() );
    RSZ(ls_._xdr        , int     (**)() );
    RSZ(ls_._print      , int     (**)() );
  }
  else
  {
    types = types>type?types:type;
    ISZ(ls_._name       , char  **       );
    ISZ(ls_._size       , int    *       );
    ISZ(ls_._duplicates , int    *       );
    ISZ(ls_._create     , ls_gen *(**)() );
    ISZ(ls_._delete     , ls_gen *(**)() );
    ISZ(ls_._xdr        , int     (**)() );
    ISZ(ls_._print      , int     (**)() );
  }

  ls_._name[type]       = (char *)strdup(name);
  ls_._size[type]       = size;
  ls_._duplicates[type] = duplicates;
  ls_._create[type]     = create;
  ls_._delete[type]     = purge;
  ls_._xdr[type]        = xdr;
  ls_._print[type]      = print;

  ls_._types = types+1;

  return TRUE;
} 

ls_open(void)
/**************************************************************************
?  Initialize the LIBLS properly. This must be the first libls call if
|  routines needing INITIALIZATION are to be called.
************************************o*************************************/
{
  return ls_init(0,NULL,0,0,NULL,NULL,NULL,NULL);
}

