/**************************************************************************
.TITLE    LIST PROCESSING LIBRARY
.NAME     FIND
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1994 / 31-AUG-1992 / OP
.VERSION  1.2
.LANGUAGE ANSI-C
.FILE     find.c
************************************o*************************************/

#define LS_LIBRARY
#include "ls.h"

ls_gen *ls_find(ls_gen **root,     /* The address of the start */
                char    *key)      /* How to find it?          */
/**************************************************************************
?  Find an item by the "key" given.
=  ITEM if found, NULL otherwise.
************************************o*************************************/
{
  ls_gen *start = *root;

  if( !key ) return NULL;
  if( !start ) return NULL;

  while( start )
  {
    if( start->name )
      if( strcmp(start->name,key) == 0 )
        break;

    start = start->next;
  }

  return( start );
}
