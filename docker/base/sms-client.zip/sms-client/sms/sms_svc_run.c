/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMS-SVC-RUN
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     17-MAR-1992 / 09-AUG-1991 / OP
.VERSION  4.0
.FILE     sms_svc_run.c
*
.DATE     23-APR-1993 / 23-APR-1993 / OP
.VERSION  4.2
.DATE     25-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
.DATE     20-APR-1998 / 20-APR-1998 / OP
.VERSION  4.3.18
*         TCP buffer size
.DATE     10-JUN-1998 / 15-JUN-1998 / OP
.VERSION  4.3.19
*         Server timeout
.DATE     30-JUL-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up + prototypes
.DATE     16-NOV-2000 / 14-NOV-2000
.VERSION  4.4.4
*         (*)printf and macro STR
*         Bug fix for play/replace
*
*  This is the sms-servers RPC client call handled.
*
************************************o*************************************/

#include "smslib.h"
#include <rpc/rpc.h>

#include <sys/errno.h>
#include <sys/socket.h>

#if defined(__uxppx__)
#include <netinet/in.h>
#endif

int sms_svc_run(void)
/**************************************************************************
?  This is the C-SMS! (with RPC)
************************************o*************************************/
{
  int        i;
#ifdef FD_SETSIZE
  fd_set     readfds;
#else
  int        readfds;
#endif

  struct timeval timeout;

  timeout.tv_sec  = SMS_CYCLE_TIME +0;
  timeout.tv_usec = 10000;         /* 0.01 sec! */

  for( i=0 ; i<1 ; i++ )           /* Let's do it only once and get back */
  {

#ifdef FD_SETSIZE
    readfds = svc_fdset;

    switch( select(sms_getsize(),&readfds,(fd_set *)0,(fd_set *)0,&timeout) )
#else
    readfds = svc_fds;

    switch( select(sms_getsize(),&readfds,(int *)0,(int *)0,&timeout) )
#endif
    {
      case -1:
        if (errno == EINTR)
          continue;
        return ioi_perror("SMS-SVC-RUN/select",0);
      case 0:
        continue;
      default:
        svc_getreqset(&readfds);
    }
  }
  return TRUE;
}

int sms_svc_quit(void)
/**************************************************************************
?  Tell the portmapper that we are going away
************************************o*************************************/
{
  (void) pmap_unset(sms_._prog, sms_._vers);
  return 0;
}

/**************************************************************************
?  Copied from the sms_svc.c, which is in turn NOT used
************************************o*************************************/

#define xdr_sms_login  sms_xdr_login
#define xdr_sms_list   sms_xdr_list
#define xdr_sms_status sms_xdr_status
#define xdr_sms_node   sms_xdr_node
#define xdr_sms_reply  sms_xdr_reply
#define xdr_sms_handle sms_xdr_handle

#include <setjmp.h>

static void sms_prog_1(struct svc_req *rqstp, register SVCXPRT *transp)
{
	union {
		sms_login sms_login_1_arg;
		int sms_news_1_arg;
		int sms_history_1_arg;
		int sms_status_1_arg;
		sms_node sms_play_1_arg;
		sms_reply sms_cmd_1_arg;
		char *sms_cmd_old_1_arg;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

#include "cred.c"

	switch (rqstp->rq_proc) {
	case NULLPROC:
		(void) svc_sendreply(transp, xdr_void, (char *)NULL);
		return;

	case SMS_LOGIN:
		xdr_argument = xdr_sms_login;
		xdr_result = xdr_sms_handle;
		local = (char *(*)()) sms_login_1;
		break;

	case SMS_LOGOUT:
		xdr_argument = xdr_void;
		xdr_result = xdr_int;
		local = (char *(*)()) sms_logout_1;
		break;

	case SMS_NEWS:
		xdr_argument = xdr_int;
		xdr_result = xdr_int;
		local = (char *(*)()) sms_news_1;
		break;

	case SMS_HISTORY:
		xdr_argument = xdr_int;
		xdr_result = xdr_sms_list;
		local = (char *(*)()) sms_history_1;
		break;

	case SMS_STATUS:
		xdr_argument = xdr_int;
		xdr_result = xdr_sms_status;
		local = (char *(*)()) sms_status_1;
		break;

	case SMS_PLAY:
		xdr_argument = xdr_sms_node;
		xdr_result = xdr_int;
		local = (char *(*)()) sms_play_1;
		break;

	case SMS_CMD:
		xdr_argument = xdr_sms_reply;
		xdr_result = xdr_sms_reply;
		local = (char *(*)()) sms_cmd_1;
		break;

	case SMS_CMD_OLD:
		xdr_argument = xdr_wrapstring;
		xdr_result = xdr_int;
		local = (char *(*)()) sms_cmd_old_1;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}

        /* sms_xdr_arm(); */

	bzero((char *)&argument, sizeof(argument));
	if (!svc_getargs(transp, xdr_argument, (char *)&argument)) {
		svcerr_decode(transp);
                sms_xdr_release();
		return;
	}

sms_xdrtimer_start();

	result = (*local)(&argument, rqstp);

	recover_jump = 1;

        if(setjmp(sms_jump_station)==0)
{
        sms_xdr_arm();

	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
}
else
{
  printf("got interrupted\n");
}
        sms_xdr_release();
	recover_jump = 0;

if( rqstp->rq_proc == SMS_CMD )
{
#include "child.h"

  sms_reply *command = (sms_reply *)(&argument);
  sms_list  *cmd     = command->lines;
  char      *name;
  int        code;

  if( cmd && cmd->name )
  {
    name = cmd->name;
    if( *name == '/' )
      name++;

    code = ioi_user_cmdf(name,sms_cmds,NULL,nsms_cmds);

    if(code >= 0 && code < nsms_cmds )
      sms_xdrtimer_stop( sms_cmds[ code ] );
  }
}
else
  sms_xdrtimer_stop( sms_command_name[rqstp->rq_proc] );

	if (!svc_freeargs(transp, xdr_argument, (char *)&argument)) {
		fprintf(stderr, "unable to free arguments");
		exit(1);
	}

#include "timer.c"

	return;
}





void svc_main(void)
/**************************************************************************
?  Create the transports and register them to the portmapper.
|
|  This differs from the rpcgen'erated that the firts one created is the
|  tcp transport and then the udp and that SMS will remember the ports.
|
|  The other major difference is that a dedicated port number is tried 
|  first. If that fails any port will do.
|
|  If the transport creation fails for the udp we don't care so much.
|
|  The reason for trying a dedicated port number is to be able to use the
|  SMS system under operating systems that do not allow portmapper or
|  wide are networks that filters the traffic for some protocols like 
|  portmap(tcp/udp in port 111).
************************************o*************************************/
{
  SVCXPRT *transp;
  int      sock;                   /* We don't need it later on */

  (void) pmap_unset(sms_._prog,sms_._vers);

  if( (sock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP)) != NIL )
  {
    struct sockaddr_in addr;

    bzero(&addr,sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(SMSSOCKET);
    addr.sin_addr.s_addr = INADDR_ANY;      /* Necessary? Donno, do ya? */

    bind(sock,(struct sockaddr *)&addr,sizeof(addr));

#if defined(SMS_TCPSIZE)
    if( ! (transp=svctcp_create(sock,SMS_TCPSIZE,SMS_TCPSIZE)) )
#else
    if( ! (transp=svctcp_create(sock,0,0)) )
#endif
      (void) close(sock);
  }

  if( ! transp )
#if defined(SMS_TCPSIZE)
    if( ! (transp=svctcp_create(RPC_ANYSOCK,SMS_TCPSIZE,SMS_TCPSIZE)) )
#else
    if( ! (transp=svctcp_create(RPC_ANYSOCK,0,0)) )
#endif
      exit( spit(1,IOI_ERR,"sms:cannot create tcp service") );

  if (!svc_register(transp,sms_._prog,sms_._vers,sms_prog_1,IPPROTO_TCP))
    exit( spit(0,IOI_ERR,"sms:unable to register %d %d for tcp",
          sms_._prog,sms_._vers) );

  spit(0,IOI_MSG,"sms:tcp transport on port %d",
       sms_._tcp_port = transp->xp_port);

  if( ! (transp=svcudp_create(RPC_ANYSOCK)) )
    spit(0,IOI_ERR,"sms:cannot create udp service");
  else
    if (!svc_register(transp,sms_._prog,sms_._vers,sms_prog_1,IPPROTO_UDP))
      spit(0,IOI_ERR,"sms:unable to register %d %d for udp",
           sms_._prog,sms_._vers);
    else
      spit(0,IOI_MSG,"sms:udp transport on port %d",
           sms_._udp_port = transp->xp_port);
}
