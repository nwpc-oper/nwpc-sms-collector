/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMS
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     sms.c
.DATE     14-JUL-1992 / 09-AUG-1991 / OP
.VERSION  4.0
.DATE     27-APR-1993 / 27-APR-1993 / OP
.VERSION  4.1
.DATE     18-AUG-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.DATE     25-AUG-1994 / 18-AUG-1994 / OP
.VERSION  4.3.1
*         Memory manager now optional part
.DATE     09-MAR-1995 / 09-MAR-1995 / OP
.VERSION  4.3.5
*         Added default checkpointing and recovery
.DATE     20-SEP-1995 / 20-SEP-1995 / OP
.VERSION  4.3.10
*         Added late concept
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
.DATE     21-APR-1998 / 21-APR-1998 / OP
.VERSION  4.3.18
*         YP-cacheing
.DATE     11-JUN-1998 /11-JUN-1998 / OP
.VERSION  4.3.19
*         Server timeout
.DATE     07-AUG-1998 / 23-JUL-1998 / OP
.VERSION  4.3.21
*         Running job limit
*         Cleaning up + prototypes
.DATE     19-JAN-1999 / 12-OCT-1998 / OP
.VERSION  4.4
*         Zombie passwords
.DATE     22-MAR-1999 / 19-MAR--1999 / OP
.VERSION  4.4.2
*         Limit reset automatically on suite modification
*         SMSMICRO an edit variable now
.DATE     28-JUN-2001 / 12-FEB-2001 / OP
.VERSION  4.4.5 ABT(c)
*
*  This is the main part of the SMS.
*
************************************o*************************************/

#define IOI_MODULE

#include "smslib.h"

#ifndef TODAY
#  define TODAY "date unknown"
#endif

static int count;                  /* Pipes broken */
static int last_time = 0;          /* I checked the time-date dependents */
static int exhausted = FALSE;      /* Still to read from the stdin */
static int last_modno = 0;

int cdp_status(int argc, char **argv) {return 0;}  /* To make the ld happier */

static void catch_pipe(int sig)
/**************************************************************************
?  Catch the broken pipes and count them.
************************************o*************************************/
{ 
  spit(0,IOI_ERR,"SIG-PIPE:%d",++count);

  signal(sig,catch_pipe);          /* Doesn't stay in all the OS's */
}

static void catch_hup(int sig)
/**************************************************************************
?  Catch the hang-up signal
|  Start reading the keyboard from the emergency input file.
|  Typically this file would be a pipe:
-EXAMPLE
|  % mknod keyboard p
|  % [win1] cat > keyboard
|  % [win2] kill -HUP SMS-PID
|  % [win2] tail -f log-file
************************************o*************************************/
{
  FILE *fp = 0;

  spit(0,IOI_WAR,"catch-hup:input was %s",exhausted?"exhausted":"normal");

  if(exhausted)
    if( (fp=freopen("keyboard","r",stdin)) != NULL )
    {
      spit(0,IOI_WAR,"catch-hup:input now on keyboard");
      exhausted = FALSE;
    }
    else
      spit(0,IOI_ERR,"catch-hup:open failed for keyboard");

  signal(sig,catch_hup);           /* Doesn't stay in all the OS's */
}

static void catch_check(int sig)
/**************************************************************************
?  Catch the signal(s) allocated for generating a checkpoint file
************************************o*************************************/
{
  spit(0,IOI_WAR,"catch-check:[%d] prepearing emergency checkpoint",sig);

  ioi_file_input("check emergency");

  signal(sig,catch_check);         /* Doesn't stay in all the OS's */
}

get_input(char *buff, int buffsize, int depth)
/**************************************************************************
?  The test version is able to execute direct commands.
|  This is the parking point for the IOI.
************************************o*************************************/
{
  sms_node       *suite;           /* Loop suites to check jobs undone */
  int             busy;            /* If true there were thing to do   */
  fd_set          readfds;
  struct timeval  timeout;
  static int      action_number;

  timeout.tv_sec  = 0;             /* Just check the files */
  timeout.tv_usec = 0;             /* 0.0 sec! */

  ioi_file_prompt(depth);

  if(sms_._check_mode == CHECK_ALWAYS && action_number < sms_._action_number)
  { 
    sms_node_check();
    action_number = sms_._action_number;
  }

  while( TRUE )
  {
    FD_ZERO(&readfds);
    FD_SET(fileno(stdin),&readfds);

    busy = FALSE;

    if( !exhausted )
    {
#ifdef FD_SETSIZE
      switch( select( FD_SETSIZE,&readfds,NULL,NULL,&timeout) )
#else
      switch( select( 8*sizeof(readfds),&readfds,NULL,NULL,&timeout) )
#endif
      {
        case -1:
          spit(0,IOI_ERR,"GET-INPUT:Select problem.");
          exhausted = TRUE;
          break;
        case  0:
          if( ioi_._usrinput )
          {
            strncpy(buff,ioi_._usrinput->text,buffsize);
            ioi_._usrinput=ioi_token_delete(ioi_._usrinput,FALSE);
            return 1;
          }
          break;
        case  1:
          if( fgets(buff,buffsize,stdin) )
            return TRUE;

          exhausted = TRUE;        /* We'll stay in this routine */
          break;
      }
      if( exhausted )
        spit(0,IOI_MSG,"sms:EOF in stdin, removing keyboard access");
    }
    else
      if( ioi_._usrinput )
      {
        strncpy(buff,ioi_._usrinput->text,buffsize);
        ioi_._usrinput=ioi_token_delete(ioi_._usrinput,FALSE);
        return 1;
      }
#ifdef IMPOSSIBLE
  check tis 1 later on  ^^^
#endif

    if( IS_RUNNING )
    {
      busy = TRUE;

      if( !last_time || (sms_time_t(NULL)-last_time > sms_._interval) )
      {
        last_time = sms_time_t(NULL);
        sms_time_waiting(sms_._super->kids);
        sms_time_out();
        sms_cancel_auto(sms_._super);
        sms_migrate_auto(sms_._super);
        sms_late_process();
        sms_passwd_process(last_time);
      }

      sms_limit_count(sms_._super);
      if(last_modno < sms_._modify_number)
      {
        sms_limit_reset(sms_._super);
        last_modno = sms_._modify_number;
      }

      while( busy )                /* Process all the changes */
      {
        suite = sms_._super->kids;
        busy  = FALSE;
  
        while( suite )
        {
          if( suite->modified )
          {
            busy = TRUE;
            sms_status_process( suite );
          }
          suite = suite->next;
        }
      }
    }                              /* running */

    switch( sms_._check_mode )
    {
      case CHECK_ALWAYS:
        if(action_number < sms_._action_number)
        {
          sms_node_check();
          action_number = sms_._action_number;
        }
        break;
      case CHECK_ON_TIME:
        if( sms_time_t(NULL)-sms_._check_last >= sms_._check_time )
          if(action_number < sms_._action_number)
          {
            sms_node_check();
            action_number = sms_._action_number;
          }
        break;
      case CHECK_NONE:             /* Only by initially */
      case CHECK_NEVER:
        break;
    }

    if( IS_DYING )                 /* Let the IOI handle exiting */
    { 
      spit(0,IOI_MSG,"sms:exiting");
      strncpy(buff,"exit",buffsize);
      return 1;
    }

    /* TIME/DATE dependencies to be checkd every minute on the minute */

    if( !busy )                    /* If I'm not busy then I'll serve */
    {
      sms_._xdr_privs   = XDR_NONE;

      sms_svc_run();

      sms_._xdr_privs    = XDR_SERVER;
      sms_._current_con  = NULL;
      sms_._xdr_version  = SMS_REVISION * 1000 + SMS_MODIFICATION;
    }

#ifdef SMS_CYCLE_TIME
    if(SMS_CYCLE_TIME==0)
      sms_nap(100000);               /* 0.1 sec */
#else
    sms_nap(100000);               /* 0.1 sec */
#endif

#ifdef SMS_MULTI_PROCESS
    sms_process_child();
#endif

  }                                /* forever ... */
}

static void ping(void )
/**************************************************************************
?  Check that there isn't other SMS already running!
************************************o*************************************/
{
  if( sms_client_ping(sms_._host,TRUE, 0) )
  {
    fprintf(stderr,"Other SMS is alive on this machine [%s]\n",STR(sms_._host));
    fprintf(stderr,"Can't continue execution.\n");
    exit(1);
  }
}

static void myself(void )
/**************************************************************************
?  Create myself
************************************o*************************************/
{
  sms_connect *con;

  con = sms_alloc(NODE_CONNECTION);
  
  con->name = strdup("SMS");
  con->host = strdup(sms_._host);
  con->uid  = getuid();
  con->gid  = getgid();

  con->passok = PR_ALL;
  con->handle = (-1);              /* No need to crypt */
  con->login  =
  con->idle   = sms_time_t(NULL);

  sms_list_add( &sms_._connect,con );
}

#ifdef CRAY                        /* Enter into real-time mode */

#include <sys/param.h>
#include <stdio.h>
#include <sys/cpu.h>
#include <sys/category.h>
#include <sys/signal.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <nlist.h>

#define ANYCPU  "/dev/cpu/any"

static struct nlist nlistarg[] = { {"ixp",0}, {0,0}, };
struct cpudev cpuctl;

static void docprealt( void )
/**************************************************************************
?  Set the process to be a real-time process in the CRAY.
************************************o*************************************/
{
  int fd;
  int ret;
  int big;

  big=(int)malloc(1024*1024*1);
  if(!big)
  {
    sms_error(SMS_E_MEMORY,"docprealt:malloc failed");
    exit(1);
  }
  free(big);

  if((fd = open(ANYCPU,0)) < 0)
  {
    sms_error(SMS_E_NOTFOUND,"docprealt:cannot open %s",STR(ANYCPU));
    exit(1);
  }
  cpuctl.cat = C_PROC;
  cpuctl.id = 0;
  cpuctl.word = 0;
  if((ret = ioctl(fd,CPU_SETRT,&cpuctl)) < 0)
  {
    sms_error(SMS_E_UNIX,"docprealt:cannot make realtime",NULL);
    exit(1);
  }
  close(fd);
}

static isrealtime(void)
/**************************************************************************
?  Check if the CRAY is running in the RT mode.
************************************o*************************************/
{
  if(nlist("/unicos",nlistarg) < 0)
  {
    spit(0,IOI_WAR,"isrealtime:No /unicos, assuming not running as GOS");
  }
  else if(nlistarg[0].n_value != 0)
  {
    sms_error(SMS_E_UNIX,"isrealtime:UNICOS in GOS mode; No RT features");
    exit(1);
  }
}

#endif /* CRAY */

static void drop(int argc, char **argv)
/**************************************************************************
?  Drop the users specified
************************************o*************************************/
{
  while( argc-- )
  {
    sms_connect *con = ls_find(&sms_._connect,*argv);

    if(con)
      sms_list_delete(&sms_._connect,con);
    else
      spit(0,IOI_WAR,"DROP:no such user %s",STR(*argv));

    argv++;
  }
}

#if 0
static genvar(int argc, char **argv)
/**************************************************************************
?  List the variables in the node
   -> cmds
    "genvar",
   -> helps
    "print the generated variables",
   -> params
    1,
************************************o*************************************/
{
  while( argc-- )
  {
    sms_node *np = sms_node_find_full(*argv);

    sms_variable *vp;

    if( ! np )
      printf("NODE: %s not found???\n",STR(*argv));
    else
    {
      printf("NODE: %s\n",STR(*argv));

      for( vp = np->variable; vp ; vp=vp->next )
        printf("%20s %s\n",STR(vp->name),STR(vp->value));

      for( vp = np->genvars; vp ; vp=vp->next )
        printf("[%20s] %s\n",STR(vp->name),STR(vp->value));
    }
    argv++;
  }
}
#endif

main(int argc, char **argv)
/**************************************************************************
?  This is the C-SMS! (with RPC)
************************************o*************************************/
{
  static char  *cmds[] = {
    "users",
    "quit",
    "suite",
    "action",

    "Mallocmap",
    "globals",
    "passwd",

    "smsuser",

    "check",

    "drop",
    "timer",

    "readlists",
    "writelists",
    "ypdump",

    "clienttimeout",
  };

  static char *helps[] = {
    "list users logged in",
    "terminate sms",
    "list the suite(s)",
    "print the action numbers",

    "print the mallocmap on stdout",
    "print the generated variables on stdout",
    "print the contents of the (internal) passwd file",

    "test who is the current sms-user",

    "checkpoint the SMS in file given",

    "drop user(s) named",
    "set timer message limit, 0 = none",

    "read listed users",
    "write listed users",
    "dump cached YP stuff into a file",

    "timeout for client reply",
  };

  static int params[] = {
    0,  0,  0,  0,
    0,  0,  0,
    0,
    1,
    1, 1,
    0, 1, 1,
    1,
  };

  static int lengths[ sizeof(cmds) / sizeof(char *) ];
  int        maxcmd = sizeof(cmds) / sizeof(char *);

  char *my_name = strdup(*argv);

  int   go_on = TRUE;
  int   rc;

  char  temp[MAXLEN];

  gethostname(temp,MAXLEN);        /* Need the name in the ping */

  sms_._host      = strdup(temp);
  sms_._is_server = TRUE;
  sms_._status    = SMS_HALTED;

  if(argc>1)
    if(strcmp(argv[1],"-b")==0)
    {
#if defined(unix) || defined(__unix) /* That is fork exists */
      int pid;

      if((pid=fork()) != 0)        /* NOT the child */
      {
        if(pid== -1)
        {
          fprintf(stderr,"%s:fork failed???\n",STR(*argv));
          exit(1);
        }
        exit(0);                   /* Ok the parent can quit! */
      }
#else
      fprintf(stderr,"%s:no fork in this OS:-b ignored\n");
#endif
    }

  printf("Welcome to SMS version %d.%d.%d compiled on %s\n",
          SMS_VERSION,SMS_REVISION,SMS_MODIFICATION,STR(TODAY));

  ls_open();
  ioi_open(argc,argv,"SMSRC");
  ioi_try_name("IOIRC");

#ifdef CRAY
  if(argc>2)
    if(strcmp(argv[2],"-r")==0)
    {
      isrealtime();

      sms_system_start_kid();

      docprealt();
    }
#endif

  ioi_variable_set("prompt","SMS"); /* For the test-sms there is input */
  ioi_variable_set("logging","on");

  ioi_user_fmcl(cmds,lengths,maxcmd);

  ioi_user_input(get_input);
  ioi_user_exit(sms_svc_quit);     /* Does actually return */

  sms_init();
  svc_main();                      /* Let's get registered to the portmap */

  signal(SIGPIPE,catch_pipe);      /* RPC-client may die in between!      */
  signal(SIGHUP,catch_hup);
  signal(SIGTERM,catch_check);
#ifdef SIGCPULIM
  signal(SIGCPULIM,catch_check);
#endif
  sms_xdr_signal(SMS_SERVER_TIMEOUT);

  spit(0,IOI_LOG,"SMS:Running in host %s [RPC %d/%d]",
       STR(sms_._host),sms_._prog,sms_._vers);
  spit(0,IOI_MSG,"SMS:Currently %s",
       STR(status_name[sms_._super? sms_._super->status : STATUS_UNKNOWN]));

#ifdef SMSAUTORECOVER
  sms_cmd_auto_recover();
#endif

  while( go_on )
    switch( rc=ioi_user_menu("SMS",&argc,&argv,
                             cmds,helps,lengths,params,maxcmd))
    {
      case  0:
        sms_list_print(&sms_._connect,stdout);
        break;
      case  1: 
        go_on = FALSE;
        break;
      case  2:
        sms_play_show(argc>1? TRUE:FALSE, TRUE, 0);
        break;
      case  3:
        printf("Current action number: %d\n",sms_._action_number);
        printf("Current modify number: %d\n",sms_._modify_number);
        break;
      case  4:
#ifdef MALLOCMAP
        mallocmap();
#else
        spit(0,IOI_ERR,"mallocmap: not linked with this SMS");
#endif
        break;
      case  5:
        {
          sms_node *np = sms_._super->kids;

          printf("GLOBAL:\n");
          sms_list_print(&sms_._super->variable,stdout);

          while( np )
          {
            printf("\n");
            printf("suite: %s\n",STR(np->name));
            sms_list_print(&np->genvars,stdout);
            np = np->next;
          }
        }
        break;
      case  6:
        sms_passwd_list(TRUE);
        break;
      case  7:
        printf("SMS_USER: %s\n",STR(SMS_USER));
        break;

      case  8:
        sms_node_write(sms_._super,argv[1]);
        break;

      case  9:
        drop(--argc,++argv);
        break;

      case 10:
        /* sms_xdrtimer_setup(ioi_variable_flag(argv[1])); */
        sms_xdrtimer_setup(atof(argv[1]));
        break;

      case 11:
        sms_passwd_list_read(argc>1? argv[1] : 0);
        break;

      case 12:
        sms_passwd_list_write(argc>1? argv[1] : 0);
        break;

      case 13:
        sms_yp_dump(argv[1]);
        break;

      case 14:
        sms_xdr_signal(atoi(argv[1]));
        break;

      default:
        /* go_on = FALSE; */
        spit(0,IOI_WAR,"mail:command code %d ???",rc);
        break;
    }

  sms_svc_quit();

  ioi_close();
}

sms_init(void)
/**************************************************************************
?  Init the SMS system.
|  Create the initial super-node.
|  Get the environment and create the globals needed to run the SMS
|  CD to the SMSHOME (must have read & write access)
|  Read the password file, if possible
|  Start the log file
************************************o*************************************/
{
  char        *tmp;
  char         temp[MAXLEN];

  if( !(sms_._super=sms_alloc(NODE_SUPER)))
    exit( spit(1,IOI_ERR,"SMS-INIT:No mem.") );

  sms_._super->name   = strdup("/");

  sprintf(temp,"%d",SMSDEFTRIES);
  sms_variable_makesms("SMSTRIES",temp);

  sms_._super->status = STATUS_HALTED;

  sms_._check_mode = SMSCHECKMODE;
  sms_._check_time = SMSCHECKINTERVAL;
  sms_._hist_max   = SMSHISTORYLEN;
  sms_._interval   = SMSINTERVAL;
  sms_._xdr_privs  = XDR_SERVER;

  sms_._action_number = 1;
  sms_._modify_number = 1;

  sms_._prog = (getenv("SMS_PROG"))? atoi(getenv("SMS_PROG")) : SMS_PROG;
  sprintf(temp,"%d",sms_._prog);
  sms_variable_makesms( "SMS_PROG",temp);

  sms_._vers = (getenv("SMS_VERS"))? atoi(getenv("SMS_VERS")) : SMS_VERS;
  sprintf(temp,"%d",sms_._vers);
  sms_variable_makesms( "SMS_VERS",temp);

  sms_variable_makesms( "SMSNODE"      , SMSNODE      );
  sms_variable_makesms( "SMSHOME"      , SMSHOME      );

  ping();

#ifdef unix
  if( strcmp(SMSHOME,".") == 0 )
    if( (tmp=ioi_variable_get("cwd")) != NULL )
    {
#  ifdef SMS_AUTOMOUNT
      int len = strlen(SMS_AUTOMOUNT);

      if( strncmp(tmp,SMS_AUTOMOUNT,len) == 0 )
        if( strlen(tmp) > len )
          tmp += len;
#  endif
      sms_variable_makesms( "SMSHOME", tmp );
    }
#else
#endif

  sms_variable_makesms( "SMSCMD"       , SMSCMD       );
  sms_variable_makesms( "SMSPASSWD"    , SMSPASSWD    );
  sms_variable_makesms( "SMSLISTS"     , SMSLISTS     );
  sms_variable_makesms( "SMSWEBACCESS" , SMSWEBACCESS );
  sms_variable_makesms( "SMSPASS"      , SMSPASS      );
  sms_variable_makesms( "SMSLOG"       , SMSLOG       );
  sms_variable_makesms( "SMSCHECK"     , SMSCHECK     );
  sms_variable_makesms( "SMSCHECKOLD"  , SMSCHECKOLD  );
  sms_variable_makesms( "SMSMICRO"     , SMSMICRODEF  );

  if( chdir(tmp=sms_variable_get("SMSHOME",NULL)) == NIL )
    exit( spit(1,IOI_ERR,"SMS:can't chdir to SMSHOME %s",STR(tmp)) );

#ifdef unix
  if( access(tmp , X_OK|R_OK|W_OK) == NIL )
    exit(spit(1,IOI_ERR,"SMS:access restriction on SMSHOME %s",STR(tmp)));
#else
  /*
   *  VAXC the access only applies to the files, directories are different
   *  Under UNIX the directories are actually files!
   *  So currently not checking the accessability of the directory
   */
#endif

  if( access(SMSPASSWD , R_OK) == 0 )
    sms_passwd_read(0);
  spit(0,IOI_MSG,"passwd:running in %s mode",sms_._passwd?"secure":"open");

  if( access(SMSLISTS , R_OK) == 0 )
    sms_passwd_list_read(0);
  if(sms_._whitelist) spit(0,IOI_MSG,"passwd:running with white listed users");
  if(sms_._blacklist) spit(0,IOI_MSG,"passwd:running with black listed users");

/* BR -- webcdp support */
  if( access(SMSWEBACCESS , R_OK) == 0 )
	sms_webaccess_read(0);
  if(sms_._web_callable)
	spit(0,IOI_MSG,"passwd:running with webacess enabled");

/* BR -- end */


  if( (tmp=sms_variable_get("SMSLOG",NULL)) )
  {
    if( access(tmp , F_OK) != NIL )
    if( access(tmp , R_OK|W_OK) == NIL )
      exit(spit(1,IOI_ERR,"SMS:access restriction on SMSLOG %s",STR(tmp)));

    sprintf(temp,">> %s",STR(tmp));
    ioi_file_input(temp);
  }

  sms_._start_up = sms_time_t(NULL);

  sms_malloc(0,NULL);
#ifdef SMS_MULTI_PROCESS
  sms_system_block();
#endif

  return 0;
}
