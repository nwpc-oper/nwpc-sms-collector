/**************************************************************************
.TITLE    C-SMS-CDP
.NAME     SMS_PROC
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-JUL-1992 / 12-AUG-1991 / OP
.VERSION  4.0
.DATE     26-APR-1993 / 23-APR-1993 / OP
.VERSION  4.2
.FILE     sms_proc.c
*
.DATE     28-FEB-1994 / 25-FEB-1994 / OP
.LANGUAGE ANSI-C
.VERSION  4.3
.DATE     09-MAR-1995 / 31-AUG-1994 / OP
.VERSION  4.3.2-5
*         Bug fix for the play (add)
*         Suite registering logic changed
.DATE     05-OCT-1995 / 05-OCT-1995 / OP
.VERSION  4.3.11
*         Added per node logging
.DATE     21-NOV-1996 / 21-NOV-1996 / OP
.VERSION  4.3.14
*         Added per xdr-command logging for debugging
.DATE     09-FEB-1998 / OP
.VERSION  4.3.16
*         Handle re-playing of migrated nodes correctly
.DATE     04-MAR-1998 / 26-FEB-1998 / OP
.VERSION  4.3.17
*         Passwords modified to have white and black list
.DATE     23-APR-1998 / 21-APR-1998 / OP
.VERSION  4.3.18
*         YP-caching
*         repeat and label init
.DATE     25-JUN-1998 / 25-JUN-1998 / OP
.VERSION  4.3.20
*         Passwords blacklist modified. No entry by default anymore
.DATE     07-AUG-1998 / 30-JUL-1998 / OP
.VERSION  4.3.21
*         Cleaning up
.DATE     11-DEC-SEP-1998 / 18-SEP-1998 / OP
.VERSION  4.4
*         play -r for repeat
*         Zombie passwords
*         Primitive talk
*         User and zombie requests
*         MOT
*
*         This is the server side of the RPC.
*
************************************o*************************************/

#define SERVER_SIDE

#include "smslib.h"
#include <pwd.h>

#if defined(CACHE_YP)
extern struct passwd *sms_getpwuid(int uid);
extern void sms_endpwent();
#endif

sms_handle *sms_login_1(sms_login *who)
/**************************************************************************
?  Log the user in.
=  HANDLE, a NULL means that permission was denied.
|  Upon successfull login the client is given a non-NULL handle which must
|  be presented by the client every time it communicates with the SMS.
|
|  The SMS-CLIENT-routines provide the necessary authentication.
|
|  Currently the handle is just a running number, but will later on be a
|  crypted indentification.
************************************o*************************************/
{
  static sms_handle rc;
  static int        handle;

  sms_connect      *con = NULL;
  char              name[MAXLEN];
  sms_passwd       *pw = NULL;
  int               is_zombie = 0;
  int               fail      = 0; /* Ask the zombie to exit */

  handle = 0;                      /* So far, I don't know 'em */

  rc.type     = NODE_HANDLE;
  rc.vers     = SMS_VERSION;
  rc.rev      = SMS_REVISION;
  rc.mod      = SMS_MODIFICATION;
  rc.security = sms_._passwd ? TRUE : FALSE;
  rc.rights   = PR_NONE;
  rc.handle   = 0;
  rc.lines    = NULL;

  if( ! who->name || ! *(who->name) )
  {
#ifdef SMS_STATISTICS
    smss_._anonymous_logins++;
#endif

    spit(0,IOI_WAR,"login:anonymous connection from %s",STR(sms_._machine));
    return 0;
  }

  if( rc.vers != who->vers )
  {
    spit(0,IOI_ERR,"login:%s form %s:version mismatch:mine %d yours %d",
         STR(who->name),STR(sms_._machine),who->vers,SMS_VERSION);
    return &rc;
  }

  if( who->passwd )                /* Ok this is for real */
  {
    if(who->name[0] == '/')        /* It's a task! */
    {
      if( sms_passwd_task_ok(who) )
        handle = ++(sms_._handle);
      else if( sms_passwd_is_zombie(who,&fail) )
        is_zombie = 1;
      else
        ;
    }
    else                           /* It's a user! */
	{
      /* Check for web access */
	  if( sms_._web_callable )
	  {
		if(ls_find(&sms_._web_hosts,sms_._machine))
		{
            struct passwd *p;
			spit(0,IOI_MSG,"login: web access from %s",sms_._machine);
			if(who->uid != sms_._web_uid || who->gid != sms_._web_gid)
			{
				spit(0,IOI_MSG,"login: web access uid/gid mismatch %d/%d and %d/%d",who->uid,who->gid,
					sms_._web_uid,sms_._web_gid);


				rc.code = SMS_E_FAIL;
				return &rc;
			}

			/* Check browse only */
			p = SMS_GETPWUID(who->uid);
			if( !p )
			{
				spit(0,IOI_ERR,"login:user id %d not known",who->uid);
				rc.code = SMS_E_FAIL;
				return &rc;
			}

			if( strcmp(p->pw_name , who->name ) == 0 )
			{
				spit(0,IOI_MSG,"login: %s is main webcdp user",who->name);
				/* this webcdp the user itslef logging in */
				/* the next line should be ok to limit to browse only */
				who->passwd[0] = 0;
				if(ls_find(&sms_._whitelist, who->name) )
					spit(0,IOI_ERR,"login:user %s who->name should not be white listed",who->name);

				if(ls_find(&sms_._blacklist, who->name) )
					spit(0,IOI_ERR,"login:user %s who->name should be black listed",who->name);
			}
			else
			{
				spit(0,IOI_MSG,"login: %s is guest webcdp user",who->name);

			/* Check token */
				if(!sms_check_webaccess(who->name,who->passwd))
				{
					spit(0,IOI_ERR,"login: failed to validate %s %s",who->name,who->passwd);
					rc.code = SMS_E_FAIL;
					return &rc;
				}
			}

			spit(0,IOI_MSG,"login: web access for %s", who->name);
		}
	  }

	  if( !sms_._passwd )
      {
        spit(0,IOI_DBG,"login:Password checking disabled");

        if( sms_._whitelist &&
            ( ! ls_find(&sms_._whitelist, who->name) &&
              ! ls_find(&sms_._blacklist, who->name) ) )
        {
          spit(0,IOI_WAR,"login:user %s is not listed",STR(who->name));
          handle = 0;
        }
        else
        {
          struct passwd *p;

          handle = ++(sms_._handle);

          if(sms_._whitelist)
            if(ls_find(&sms_._whitelist, who->name) )
            {
              p = SMS_GETPWUID(who->uid);

              if( !p )
              {
                handle = 0;
                spit(0,IOI_ERR,"login:user id %d not known",who->uid);
              }
              else if( strcmp( p->pw_name , who->name ) == 0 )
                spit(0,IOI_DBG,"login:user %s white listed",STR(who->name));
              else if(ls_find(&sms_._whitelist, p->pw_name))
                spit(0,IOI_MSG,"login:user %s white listed (su from %s)",
                     STR(who->name), STR(p->pw_name));
              else
              {
                handle = 0;
                spit(0,IOI_WAR,"login:user %s not white listed",STR(p->pw_name));
              }

              SMS_ENDPWENT();
            }
            else
            {
              who->passwd[0] = 0;
              spit(0,IOI_WAR,"login:user %s not white listed",STR(who->name));
              spit(0,IOI_WAR,"login:user %s password ignored",STR(who->name));
            }
        }
      }

      else
        if( pw=ls_find(&sms_._passwd,who->name) )
          if( sms_passwd_ok(who->name,who->passwd) )
            if( who->uid != pw->uid  ||  who->gid != pw->gid )
            {
#ifndef SMS_IN_SECURE_MODE
              spit(0,IOI_WAR,"login:user %s is not [%d,%d]",
                   STR(who->name),who->uid,who->gid);
          
              handle = ++(sms_._handle);
#endif
            }
            else
              handle = ++(sms_._handle);
	  }
  }
  else                             /* Just monitorin' */
  {
    if( !sms_._whitelist || 
        ls_find(&sms_._whitelist, who->name) ||
        ls_find(&sms_._blacklist, who->name) )
      handle = ++(sms_._handle);   /* The first time == 1 */
    else
    {
      spit(0,IOI_WAR,"login:user %s is not listed",STR(who->name));
      handle = 0;
    }
  }

  sprintf(sms_._timer_txt,"%s form %s", STR(who->name) , STR(sms_._machine));

  if( handle )
  {
    con = sms_alloc(NODE_CONNECTION);

    sprintf(name,"%s@%d", STR(who->name),handle);

    con->name   = strdup(name);
    con->host   = strdup( sms_._machine?sms_._machine:"unknown");
    con->uid    = who->uid;
    con->gid    = who->gid;

    /* Change to the PASSWD-BITMASK */
    rc.rights   = 
    con->passok = (who->passwd && who->passwd[0] ) ? 
      (pw?pw->rights : PR_ALL) : FALSE;

    con->handle = handle;          /* Crypt the handle */

    con->login  = 
    con->idle   = sms_time_t(NULL);

    con->vers  = who->vers;
    con->rev   = who->rev;
    con->mod   = who->mod;

    con->newsuites = TRUE;

    sms_list_add(&sms_._connect,con);
    sms_connect_login(con);

    NODE_FREE(sms_._reply,sms_list);

    if( con->name[0] == '/' )
      spit(0,IOI_DBG,"login:Task %s from %s", STR(con->name) , STR(sms_._machine));
    else
      spit(0,IOI_MSG,"login:User %s with%s password from %s",
           STR(con->name) , con->passok ? "" : "out" , STR(sms_._machine));
  }
  else
  {
    spit(0,(who->name[0] == '/')?IOI_DBG:IOI_WAR,
         "login:Denied %s [%d,%d] form %s",
         STR(who->name),who->uid,who->gid,STR(sms_._machine));
    strcat(sms_._timer_txt," (denied)");
  }

#ifdef SMS_STATISTICS
  if(handle)
    if( who->name[0] == '/' ) smss_._task_logins++;
    else
      if(con->passok)         smss_._priv_logins++;
      else                    smss_._user_logins++;
  else
  {
    if( is_zombie )           smss_._tasks_zombie++;
    else
    if( who->name[0] == '/' ) smss_._tasks_denied++;
    else                      smss_._users_denied++;
  }
#endif

  if( rc.rev != who->rev && handle )
    spit(0,IOI_WAR,"login:%s from %s:revision %d is not same as SMS %d",
         STR(who->name),STR(sms_._machine),who->rev,SMS_REVISION);

  rc.handle = handle;

  if(handle && who->lines)
  {
    NODE_FREE(sms_._reply,sms_list);
    sms_._answer = TRUE;           /* Copy the output to the reply */

    sms_._current_con = con;

    spit(0,IOI_DBG,"%s:by %s",STR(who->lines->name),STR(who->name));

    rc.code     = sms_cmd(0,who->lines);
    rc.lines    = sms_._reply;

    sms_._answer = FALSE;

    spit(0,IOI_DBG,"express-logout:Task %s",STR(con->name));

    sms_list_delete(&sms_._connect,con);
  }
  else
    sms_mail_init(con);

#if 0
  if(handle && who->name[0] != '/')/* Help XCdp */
    sms_._super->act_no = ++sms_._action_number; 
#endif

  if(is_zombie)                    /* 4.4.0 */
  {
    NODE_FREE(sms_._reply,sms_list);
    sms_._answer = TRUE;           /* Copy the output to the reply */
    spit(0,IOI_WAR,"zombie:%s from %s for %s",STR(who->lines->name),
         sms_._machine?sms_._machine:"unknown" , STR(who->name));
    rc.lines    = sms_._reply;
    rc.handle   = 1;               /* Client will exit */
    sms_._answer = FALSE;

    rc.code = fail? SMS_E_FAIL : SMS_E_OK;
  }

  return &rc;
}

int *sms_logout_1(void)
/**************************************************************************
?  Remove the user from the connection list.
=  TRUE if the user was actually logged in else FALSE.
************************************o*************************************/
{
  static int   res = TRUE;         /* Yeps! This is allways OK! */
  sms_connect *con = sms_._current_con;

  if( con->name[0] == '/' )
    spit(0,IOI_DBG,"logout:Task %s",STR(con->name));
  else
    spit(0,IOI_MSG,"logout:User %s",STR(con->name));

  sms_list_delete(&sms_._connect,con);

  return &res;
}

int *sms_news_1(int *handle)
/**************************************************************************
?  Client query if there is something new happened after the client
|  heard last time of the SMS
=  TRUE if the "handle" is older than the current action_number.
************************************o*************************************/
{
  static int res;

  res = ( *handle < sms_._action_number )? SMS_E_OK : SMS_E_NONEWS;

  return &res;
}

sms_list *sms_history_1(int *last)
/**************************************************************************
?  Get the last lines of the history file.
************************************o*************************************/
{
  static sms_list l;
  static char     numbers[MAXLEN];
  sms_list       *lp;
  int             skip;            /* # lines to skip, client have them */
  int             first;           /* First line number that I have     */

  /* xdr_free( xdr_sms_list,&l ); */  /* No need to free, static! */

  l.type = NODE_LIST;
  l.name = numbers;

  first = sms_._hist_num - sms_._hist_len + 1;

  skip = *last - first + 1;

  for( lp = sms_._history ; lp && skip>0 ; skip-- , first++ )
    lp = lp->next;
  l.next = lp;

  sprintf(numbers,"%d %d",first,sms_._hist_num);

  return &l;
}

sms_status *sms_status_1(int *all)
/**************************************************************************
?  Return the full tree of the current structure to the client.
=  You always get something, even if there is no suites defined.
************************************o*************************************/
{
  static sms_status  res;
  static sms_node   *old   = 0;
         sms_node   *reply = NULL;
 
  if( *all != 0 )
  {
    sms_node_before_send(sms_._super);           /* Strip passwords! */
                                                 /* Done in XDR_xxx  */
    if( *all < 0 || (*all <= sms_._action_on_mod) )
    {
#ifdef VERSION4_4
      if(SUPPORTED(4,4,0))                      /* Protocol changed */
#else
      if( 1 )
#endif
        reply = sms_._super;
      else
      {
        if(!old)
        {
          old = sms_alloc(NODE_SUPER);
          if(old)
            old->name = strdup("Wrong-version-number");
        }
        reply = old;
      }
    }
    else
      reply = (sms_node *)sms_nid_build(sms_._super,*all);
  }

  res.type     = NODE_STATUS;
  res.action_n = sms_._action_number;
  res.modify_n = sms_._modify_number;
  res.status   = sms_._status;
  res.node     = reply;

  return &res;
}

int *sms_play_1(sms_node *play)
/**************************************************************************
?  Define a suite.
|  Only one suite at the time!
=  SMS-RETURN-CODE
************************************o*************************************/
{
  static int   res;
  sms_node    *np  = NULL;
  sms_node    *tmp;                /* Allocated later on ... */
  char        *replace = NULL;

  if( ! PRIVILEGE(PR_PLAY) )
  {
    res=SMS_E_PRIVILEGE;
    spit(0,IOI_ERR,"play:user %s:no privilege",STR(SMS_USER));
    return &res;
  }

  if( play->type==NODE_SUPER )     /* Replace mode */
  {
    replace = play->name;
    tmp  = play->kids;
    play->kids = 0;
    play = tmp;
  }

  if( play->next )
  {
    res=SMS_E_PROTOCOL;
    spit(0,IOI_ERR,"play:user %s:protocol error!",STR(SMS_USER));
    return &res;
  }

  if( replace )
  {
    sms_node *np;
    int       validate = FALSE;

    if( play->type==NODE_EVENT || play->type==NODE_METER ||
        play->type==NODE_LABEL || play->type==NODE_REPEAT )
    {
      res=SMS_E_PRIVILEGE;
      spit(0,IOI_ERR,"play:can't replace events/meters/labels/repeat (use alter):%s", STR(SMS_USER));
      return &res;
    }

    if( IS_ROOT(replace) )
    {
      res=SMS_E_PRIVILEGE;
      spit(0,IOI_ERR,"play:can't remove super-node:user %s:",STR(SMS_USER));
      return &res;
    }

    if( (np=sms_node_find_full(replace)) )
    {
      sms_node temp;               /* Jeps! Need space to swap */
      sms_node *parent,*next;

      if( sms_cancellable(np) != 0 )
      {
#ifdef SMS_CROSS_SUITE
        spit(0,IOI_WAR,"play:replace:forced cancel on %s",STR(replace));
#else
        res=SMS_E_NOTFREE;
        spit(0,IOI_ERR,"play:replace:not free:%s",STR(replace));
        return &res;
#endif
      }

      if( ! (tmp=sms_alloc(NODE_SUITE)) )
      {
        res=SMS_E_MEMORY;
        spit(0,IOI_ERR,"play:replace:user %s:no mem",STR(SMS_USER));
        return &res;
      }

      validate = (np->status != STATUS_UNKNOWN);

      parent = np->parent;         /* 2 B in the same order as original */
      next   = np->next;

      sms_passwd_zombie(np);

      memcpy(   tmp ,    np , sizeof(sms_node) );
      memcpy(    np ,  play , sizeof(sms_node) );
/*
      memcpy(  play ,   tmp , sizeof(sms_node) );
*/

      np->parent = parent;
      np->next   = 0;

      play->next = NULL;           /* Parent is wrong but ! needed in free */

      tmp->next = 0;
      sms_node_free(tmp);

      memset(play,0,sizeof(sms_node));

      np->parent = parent;
      sms_node_after_receive( np );
      np->next   = next;

      if(validate)
      {
        sms_status_default(np);

        if(np->type == NODE_SUITE) sms_time_suite(np,TRUE,NULL,NULL);
        else                       sms_time_load(np);

        sms_time_mark(np);
        sms_time_waiting(np);
        sms_time_autocm_init(np);
        sms_repeat_init(np);
      }

      SUITE_MODIFIED(np);
      GET_TRIGGERS;

      if( FLAG_ISSET(np,FLAG_MIGRATED) )
        spit(0,IOI_WAR,"play:replace: node was migrated :%s",STR(replace));
      FLAG_CLEAR(np,FLAG_MIGRATED);

      sms_status_change(np->parent,sms_status_max(np->parent->kids),
                        FALSE,FALSE);

      LOGGING(np);
      spit(0,IOI_MSG,"play:replace:user %s:%s",STR(SMS_USER),STR(replace));
      LOGGING(0);
    }
    else                           /* Add a new stuff */
    {
      if((np=sms_node_find_full(sms_cd_to(replace,"..")))==NULL)
      {
        res=SMS_E_NOTFOUND;
        spit(0,IOI_ERR,"play:add not found:%s",STR(replace));
        return &res;
      }

      if( ! (tmp=sms_alloc(NODE_SUITE)) )
      {
        res=SMS_E_MEMORY;
        spit(0,IOI_ERR,"play:add:user %s:no mem",STR(SMS_USER));
        return &res;
      }

      validate = (np->status != STATUS_UNKNOWN);

      memcpy(tmp,play,sizeof(sms_node));  /* Let's steel it from the RPC */
      memset(play,0,sizeof(sms_node));

      tmp->parent = np;
      sms_list_add(&np->kids,(sms_list*)tmp);
      sms_node_after_receive( tmp );
      SUITE_MODIFIED(tmp);  /* MOD 4.3.13 was (np) */
      GET_TRIGGERS;

      LOGGING(tmp);
      spit(0,IOI_MSG,"play:add:user %s:%s",STR(SMS_USER),STR(replace));

      if(validate)
      {
        sms_status_default(tmp);

        /* Use tmp not np */

        if(tmp->type == NODE_SUITE) sms_time_suite(tmp,TRUE,NULL,NULL);
        else                        sms_time_load(tmp);

        sms_time_mark(tmp);
        sms_time_waiting(tmp);
        sms_time_autocm_init(tmp);
        sms_repeat_init(tmp);
      }

      LOGGING(0);
      sms_status_change(tmp->parent,sms_status_max(tmp->parent->kids),
                        FALSE,FALSE);
    }

    res = SMS_E_OK;
    return &res;
  }
  else
    if( sms_list_find(&sms_._super->kids,play->name) )
    {
      res=SMS_E_EXISTS;
      spit(0,IOI_ERR,"play:user %s:suite %s already exists",STR(SMS_USER),STR(play->name));
      return &res;
    }

  if( ! (tmp=sms_alloc(NODE_SUITE)) )
  {
    res=SMS_E_MEMORY;
    spit(0,IOI_ERR,"play:user %s:no mem",STR(SMS_USER));
    return &res;
  }

  memcpy(tmp,play,sizeof(sms_node));   /* Let's steel it from the RPC */
  memset(play,0,sizeof(sms_node));

  sms_node_after_receive( tmp );   /* Should be ok now! */
  tmp->parent = sms_._super;
  sms_list_add(&sms_._super->kids,(sms_list*)tmp);
  SUITE_MODIFIED(tmp);
  GET_TRIGGERS;

  sms_connect_check(tmp->name);

  spit(0,IOI_MSG,"play:user %s:suite %s defined",STR(SMS_USER),STR(tmp->name));

  res = SMS_E_OK;
  return &res;
}

sms_reply *sms_cmd_1(sms_reply *cmd)
/**************************************************************************
?  Execute a command.
=  CODE == 0 (==SMS_E_OK) upon successfull execution, otherwise (C-true)
|  the CODE indicates a valid SMS-ERROR-code.
************************************o*************************************/
{
  static sms_reply res;

  res.code  = SMS_E_OK;

  NODE_FREE(sms_._reply,sms_list); /* Empty the previous client reply */
  sms_._staticlist = NULL;         /* Clear previous list, NO DELETE! */

  spit(0,IOI_DBG,"%s:by %s",STR(cmd->lines->name),STR(SMS_USER));

  sms_._answer = TRUE;             /* Copy the output to the reply */

  res.type     = NODE_REPLY;
  res.code     = sms_cmd(cmd->code,cmd->lines);

  if(res.code == SMS_E_OK && sms_._staticlist)
    res.lines = sms_._staticlist;
  else
    res.lines = sms_._reply;

  sms_._answer = FALSE;

  return &res;
}

int *sms_cmd_old_1(char **s)
/**************************************************************************
?  Execute a command. OLD one.
|  This always returns TRUE!
|  This will be removed.
************************************o*************************************/
{
  static int res;

  if( res = PRIVILEGE(PR_SYSTEM) )
    ioi_file_input(*s);
  else
    spit(0,IOI_ERR,"old:%s rejected for:%s",STR(SMS_USER),STR(sms_no_newline(*s)));

  return &res;
}

