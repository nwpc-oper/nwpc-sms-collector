#!/bin/ksh

set -e

cd `dirname $0`

echo "Select one of the following files to be used as the compilation flags"

ls -1 flags
