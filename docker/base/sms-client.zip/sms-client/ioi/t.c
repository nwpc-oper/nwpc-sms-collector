/**************************************************************************
.TITLE    Input Output Interface
.NAME     EDITOR
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     t.c
.LANGUAGE ANSI-C
.DATE     02-AUG-1995 / xx-MAY-1995 / OP
.VERSION  3.3
*
*  Termio based line-editing added
*  Only for ANSI (VT100/xterm) like terminals
*  The reason for writing my own, istead of using the curses lib,
*  is that you can not easily have two applications using curses
*  at the same time. Eg routines like filter(CURSES) change this
*  permanently.
*
*  This module is called to read a line at the time. While reading that
*  line, the terminal parameters might be edited for line control.
*  The module restores terminal settings before returning.
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#if 0
#include <curses.h>
#include <term.h>
#endif

#include <termio.h>
#include <sys/ioctl.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>

/**************************************************************************
*  Definitions that are borrowed from curses
************************************o*************************************/

#ifndef KEY_DOWN                   /* if curses.h not included */
#  define KEY_DOWN        0402     /* Sent by terminal down arrow key */
#  define KEY_UP          0403     /* Sent by terminal up arrow key */
#  define KEY_LEFT        0404     /* Sent by terminal left arrow key */
#  define KEY_RIGHT       0405     /* Sent by terminal right arrow key */
#  define KEY_HOME        0406     /* Sent by home key. */
#  define KEY_BACKSPACE   0407     /* Sent by backspace key */
#endif

/**************************************************************************
*  Own definitions
************************************o*************************************/

#define ESC 27
#define ERR (-1)
#define BACKSPACE 8
#define CONTROL(x) ((x)-64)

typedef struct {
  char *_sends;
  int   _keyval;
} key_map;

/**************************************************************************
*  Globals for this module
************************************o*************************************/

static key_map keys[] = {
  { "[A" , KEY_UP },
  { "[B" , KEY_DOWN },
  { "[C" , KEY_RIGHT },
  { "[D" , KEY_LEFT },
};
static num_keys = sizeof(keys) / sizeof(key_map);

static struct {
  FILE             *_of;           /* Output file pointer */
  FILE             *_if;           /* Input file pointer */
  struct termio     _iprog;        /* Input setting in program mode */
  struct termio     _ishell;       /* Input setting in shell mode */
  struct termio     _oprog;        /* Output setting in program mode */
  struct termio     _oshell;       /* Output setting in shell mode */
} ed_;

static int in_program_mode;
static int current_pos;

static char buff[MAXLEN];

static void history(int line)
/**************************************************************************
?  Fill the line buffer with the history line
************************************o*************************************/
{
  ioi_history *history = (ioi_history *)ls_item(&ioi_._history,line);
  int    i;
  int    len = 0;
  char  *s;
  char **argv;
  char  *bp = buff;

  if( history )
    for( i=history->argc , argv=history->argv ; i ; i--)
    {
      s = *argv++;
      while( len < MAXLEN && *s )
      {
        *bp++ = *s++;
        len++;
      }
      if( i>1 && len<MAXLEN )
      {
        *bp++ = ' ';
        len++;
      }
    }

  *bp = '\0';
}

static void enter_program_mode(void)
/**************************************************************************
?  Set the termio parameters for line-editing mode
************************************o*************************************/
{
  if(in_program_mode) return;

  (void) ioctl(fileno(ed_._if), TCSETAF, &ed_._iprog);
  in_program_mode = TRUE;
}

static void exit_program_mode(void)
/**************************************************************************
?  Set the termio parameters for normal (line-by-line) mode
************************************o*************************************/
{
  if( in_program_mode )
    (void) ioctl(fileno(ed_._if), TCSETA , &ed_._ishell);
  in_program_mode = FALSE;
}

void ioi_ed_init(FILE *in, FILE *out)
/**************************************************************************
?  Set the termio parameters for the very first time
************************************o*************************************/
{
  if( ed_._if ) return;

  ed_._if = in;
  ed_._of = out;

/*
  setbuf(ed_._of,0);
  setbuf(ed_._if,0);
*/

  ioctl(fileno(ed_._if), TCGETA, &ed_._ishell);
  memcpy(&ed_._iprog,&ed_._ishell,sizeof(struct termio));

  ed_._iprog.c_cc[VEOF] = 1;
  ed_._iprog.c_cc[VEOL] = 1;

  ed_._iprog.c_lflag &= ~(ECHO | ECHOE | ECHOK | ECHONL);
  ed_._iprog.c_lflag &= ~(ICANON);

  return;
}

static void ed_beep(void)    { fprintf(ed_._of,"%c",CONTROL('G')); }
static void ed_bold(void)    { fprintf(ed_._of,"%c[1m",ESC); }
static void ed_normal(void)  { fprintf(ed_._of,"%c[m",ESC); }
static void ed_reverse(void) { fprintf(ed_._of,"%c[7m",ESC); }

static void ed_home(void)
{
  fprintf(ed_._of,"\r");
  current_pos = 0;
}

static void ed_cursor_left(void)
{
  if( current_pos > 0 )
  {
    fprintf(ed_._of,"%c",BACKSPACE);
    current_pos--;
  }
}

static void ed_cursor_right(void)
{
  fprintf(ed_._of,"%c[C",ESC);
  current_pos++;
}

static void ed_move_left(int num)
{
  if( current_pos > num )
    num = current_pos;

  fprintf(ed_._of,"%c[%dD",num);
  current_pos -= num;
}

static void ed_move_right(int num)
{
  fprintf(ed_._of,"%c[%dC",num);
  current_pos += num;
}

static void ed_clear_eol(void)
{
  fprintf(ed_._of,"%c[K",ESC);
}

static void ed_delete_chars(int x)
{

}

static ed_addch(int ch)
{
  fprintf(ed_._of,"%c",ch);
  current_pos++;
}

static ed_addstr(char *s)
{
  for( ; *s ; s++ )
    if( isprint( *s ) )
      ed_addch( *s );
}

static void ed_insch(int ch)
{
  fprintf(ed_._of,"%c[@",ESC);
  ed_addch(ch);
}

static void ed_move(int pos)
{

}

static void dump(char *line, int len)
{
  while(len-- > 0)
    addch(*line++);
}

static void ioi_ed_output(int type, char *line, int len)
{
  static char *bold,*normal,*reverse;

  if(type==IOI_RAW)
    dump(line,len);
  else if(type==IOI_ERR)
  {
    ed_reverse();
    dump(line,strlen(line));
    ed_normal();
  }
  else if(type==IOI_WAR)
  {
    ed_bold();
    dump(line,strlen(line));
    ed_normal();
  }
  else
    dump(line,strlen(line));
}

static int in_wait(int fd, int wait_usec)
/**************************************************************************
?  Read a character form file "fd" with delay specified as "wait_usec"
|  in micro-seconds ( -1 as wait_usec blocks indefinetely)
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
  int             c = ERR;
  char            ch;
  fd_set          readfds;
  struct timeval  timeout;

  timeout.tv_sec  = 0;
  timeout.tv_usec = wait_usec;

  FD_ZERO(&readfds);
  FD_SET(fd,&readfds);

#ifdef FD_SETSIZE
  switch( select(FD_SETSIZE,&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#else
  switch( select(8*sizeof(readfds),&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#endif
  {
    case -1:
      break;

    case 0:
      break;

    case 1:
      if( read(fd, &ch, 1) == 1 )
        c = ch; 
      break;

    default: /* hymm... donno, must be some sort of an error */
      break;
  }

  return c;
}

static int in(int fd)
/**************************************************************************
?  Read a character form file "fd" 
|  If an escape is pressed and more characters apper withing a timeout
|  a function key value may be returned
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
#define MAX_TYPE_AHEAD 10

  int c;
  static char type_ahead[MAX_TYPE_AHEAD];  /* If we read for function keys */
  static int  type_ahead_len;              /* but there is no match        */
  key_map    *kp;
  int         num_matches = 1;

  if( type_ahead_len )
  {
    c = type_ahead[0];
    memmove(type_ahead,type_ahead+1,--type_ahead_len);
    return c;
  }

  if( (c=in_wait(fd, -1)) == -1 )
    return -1;

  type_ahead[type_ahead_len++] = c;

  while( type_ahead_len < MAX_TYPE_AHEAD && num_matches )
  {
    int i;
    num_matches = 0;

    for( i=0, kp = &keys[i]; i<num_keys ; kp = &keys[++i] )
    {
      if( strncmp( kp->_sends , type_ahead , type_ahead_len ) == 0 )
      {
        num_matches++;
        if( strlen( kp->_sends ) == type_ahead_len )
        {
          type_ahead_len = 0;
          return kp->_keyval;
        }
      }
    }

    if( num_matches )              /* Beginning macthes but not completely */
    {                              /* Get more, with small delay           */
      if( (c=in_wait(fd, 100000)) == -1 )
      {
        c = type_ahead[0];
        memmove(type_ahead,type_ahead+1,--type_ahead_len);

        return c;
      }

      type_ahead[type_ahead_len++] = c;
    }
  }

  /* No match, buffer full => return the first */

  c = type_ahead[0];
  memmove(type_ahead,type_ahead+1,--type_ahead_len);

  return c;
}

static int ioi_ed_input(char *line, int maxlen, int depth)
/**************************************************************************
?  Read a line of characters, with line editing and history processing
|  If a whole line is ready in the input queue read it and return.
|  Otherwise enter line-editing mode and process the keystorkes.
|  Always leave the terminal in the normal mode (commands that read
|  stdin, will not have line editing on)
=  -1 
************************************o*************************************/
{
  int len=0;                       /* Current length of the input  */
  int pos=0;                       /* Current position on the line */
  int rch;                         /* Character-code just read     */
  int prompt_len;                  /* Lenght of the prompt         */

  int history_lines = ls_len(&ioi_._history);
  int current_line  = history_lines;

  int i;
  char prompt[MAXNAM];

  if( depth > 0 )                  /* Distinguist between the prompts */
  {
    for( i=0 ; i<depth ; i++ )
      prompt[i]='>';               /* Prompt size reflects the depth */
      prompt[i++] = ' ';           /* Much clearer */
      prompt[i++] = '\0';
  }
  else
    if( *ioi_._prompt )
      sprintf(prompt,"%s> ",(depth)? "":ioi_._prompt);

  prompt_len = strlen(prompt);

  ed_home();
  ed_addstr(prompt);
  ed_clear_eol();

  while( (rch=in_wait(fileno(ed_._if), 1)) != ERR )
    if( rch=='\r' || rch == '\n' )
    {
      len = MIN(maxlen,len);
      buff[len] = '\0';
      strcpy(line,buff);
      return len;
    }
    else
    {
      buff[len++] = rch;
      if( len >= MAXLEN || len >= maxlen )
        len--;                     /* Ignore last char */
    }

  enter_program_mode();

  while( (rch=in(fileno(ed_._if))) != ERR )
  {
    if( rch == '\r' || rch == '\n' )
    {
      len = MIN(maxlen,len);
      buff[len] = '\0';
      strcpy(line,buff);
      exit_program_mode();
      printf("\n");
      return len;
    }
  
    switch (rch)
    {

      default:
        if( rch <= 0xff &&
            (isalnum(rch) || rch==' ' || rch=='_' || ispunct(rch)) )
        {
          if( len<MAXLEN )
          {
            if( pos == len )
            {
              ed_addch(rch);
              buff[len++] = rch;
              pos++;
            }
            else
            {
              memmove(buff+pos+1,buff+pos,len-pos);
              buff[pos++] = rch;
              len++;
              ed_insch(rch);
              ed_move(prompt_len + pos);
            }
          }
          else
            ed_beep();
        }
        else                       /* Fix this if needed */
          ed_beep();

    }  /* switch(rch) */

  }

  exit_program_mode();

  return -1;
}

void ioi_ed_exit(void)
/**************************************************************************
?  Really a dummy routine, will only be called once at the end of an
|  IOI-application
************************************o*************************************/
{
  ed_._if = ed_._of = NULL;

  ioi_._output = NULL;
}

void ioi_ed(int truth)
{
  ioi_user_input( truth? ioi_ed_input : NULL );
/*
  ioi_user_output( truth? ioi_ed_output : NULL );
*/

  if( ! truth )
    ed_._if = ed_._of = NULL;
}
