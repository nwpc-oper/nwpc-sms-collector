/**************************************************************************
.TITLE   Input Output Interface
.NAME    IOI
.SECTION LIB
.AUTHOR  Otto Pesonen
.DATE    18-MAR-1993 / 07-MAY-1990 / OP
.VERSION 2.3
.DATE    10-APR-1994 / 26-OCT-1993 / OP
.VERSION 3.0
.DATE    29-JUN-1994 / 16-JUN-1994 / OP
.VERSION 3.0
.DATE    25-AUG-1994 / 14-JUL-1994 / OP
.VERSION 3.1
.FILE    ioi.h
.DATE    27-MAR-1995 / 27-MAR-1995 / OP
.VERSION 3.2
*        Dynamic linking added
.DATE    07-AUG-1998 / 07-AUG-1998 / OP
.VERSION 3.3
*        Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#ifndef IOI_H
#define IOI_H

#if defined(__uxppx__) && ! defined(FUJITSU)
#  define FUJITSU
#endif

#ifdef VMS
#  undef UNIX
#endif

#ifdef ultrix
#  define CLK_TCK 60
#endif

#ifdef _CONVEX_SOURCE              /* Would convex define these, please! */
#  define MAXDOUBLE       1.79769313486231470e+308
#  define MINDOUBLE       4.94065645841246544e-324
#else
#  ifdef VMS
#    include <float.h>
#    define MAXDOUBLE DBL_MAX
#    define MINDOUBLE DBL_MIN
#  else
#    include <values.h>
#  endif
#endif

#include "ls.h"
#include <ctype.h>

#if ! defined(mips) || defined(sgi)
#if 0
#  include <math.h>
#endif
#endif

#if defined(__STDC__) || defined(__alpha)
#  include <stdarg.h>
#else
#  include <varargs.h> 
#endif

#include <limits.h>
#include <time.h>
#include <signal.h>
#include <setjmp.h>
#include <errno.h>

#if defined(SIGCLD) && !defined(SIGCHLD)
#define SIGCHLD SIGCLD  /* 4.3BSD's name */
#endif

#ifdef VMS
#  include <perror.h>
#else
#ifndef linux
   extern int errno, sys_nerr;
   extern char *sys_errlist[];
#endif
#endif

#ifdef VMS
#  include <types.h>
#  define tms tbuffer
#  define tms_utime  proc_user_time
#  define tms_stime  proc_system_time
#  define tms_cutime child_user_time
#  define tms_cstime child_system_time
#  define gmtime localtime         /* VMS does not now GMT */
#else
#  include <sys/types.h>
#  include <sys/times.h>
#endif

#ifdef CRAY                        /* When will cray got these right? */
#  include <sys/machd.h>           /* Just to catch the HZ for cmd.c! */
#else
#  if !defined(VMS) && !defined(sun)
#    include <sys/param.h>
#  endif
#endif

#ifndef HZ
#  ifdef CLK_TCK                   /* Convex, again (argh!) */
#    define HZ CLK_TCK
#  endif
#endif


#if 0
#if defined(sgi) || defined(_sgi)
#  include <strings.h>
#else
  extern char * strdup();
#endif
#endif

#include <string.h>
#include <strings.h>

/**************************************************************************
*  The standard stuff ...
************************************o*************************************/

#ifndef TRUE
#  define TRUE  1
#  define FALSE 0
#endif

#ifndef YES
#  define YES   1
#  define NO    0
#endif

#ifndef NIL
#  define NIL (-1)
#endif

#ifndef MAX
#  define MAX(a,b) ((a)> (b)?(a):(b))
#  define MIN(a,b) ((a)<=(b)?(a):(b))
#endif

/**************************************************************************
*  Max & Min for the current input buffer size and for command stack.
************************************o*************************************/

#define MAXLEN      32768          /* For input and output buffers   */
#define MAXARG       4024          /* Arguments for a single command */

#define MINLEN        256          /* Let`s be reasonable! */
#define MINARG         32

#define MAXNAM        256          /* For file names */

#if defined(MAX_PATH) && !defined(MAXPATHLEN)
#  define MAXPATHLEN MAX_PATH
#endif

#ifndef MAXPATHLEN
#  define MAXPATHLEN MAXLEN
#endif

/**************************************************************************
*  Different output types for filtering purposes.
************************************o*************************************/

#define IOI_ECHO        0          /* == FALSE */
#define IOI_ERR         1          /* == TRUE  */
#define IOI_WAR         2
#define IOI_MSG         3
#define IOI_LOG         4
#define IOI_DBG         5
#define IOI_LOGS        6          /* Number of different loggings */
#define IOI_RAW         6          /* Only for raw output          */

/**************************************************************************
*  Different math types. In the order of the precedence.
*  Check the local tables in math.c if you change these.
************************************o*************************************/

#define M_NIL    0                 /* Got to be ZERO */
#define M_OR     1
#define M_AND    2
#define M_EQ     3
#define M_NE     4
#define M_LT     5
#define M_LE     6
#define M_GT     7
#define M_GE     8
#define M_ADD    9
#define M_SUB   10
#define M_MUL   11
#define M_DIV   12
#define M_MOD   13
#define M_POW   14
#define M_NOT   15                 /* Only one branch!     */
#define M_UNARY 16                 /*       - " -          */
#define M_OPEN  17                 /* Opening paranthesis  */
#define M_CLOSE 18                 /* Closing paranthesis  */
#define M_NAME  19                 /* Must be the last one */

#define M_PRECEDENCE 9             /* Precedence for the name */

/**************************************************************************
*  Default characters for syntax checking.
*  Currently you cann't change these.
*  The macros IS_xxx are for future if different character sets are needed
************************************o*************************************/

#define IOI_IOI        '.'         /* Internal command introducer */
#define IOI_COMMAND    ';'         /* Command separator (+ eol)    */
#define IOI_COMMENT    '#'         /* The rest discarded, (ex join) */
#define IOI_SHELL      '$'         /* Operating system command/shell */
#define IOI_CSHELL     '%'         /* C-shell command/shell           */
#define IOI_HISTORY    '!'         /* History substitution introducer  */
#define IOI_JOIN      '\\'         /* Continues line, join next line    */
#define IOI_ESCAPE    '\\'         /* Remove speciality of the next one */
#define IOI_BACKUP     '/'         /* For compatibility for V.10 clp/ux */
#define IOI_COMMA     '\0'         /* Secondary break if set (space)    */
#define IOI_VARIABLE   '$'         /* Variable reference introducer    */
#define IOI_HELP       '?'         /* In menu mode: help request      */
#define IOI_MATH       '@'         /* Invoke the internal calculator */

#define IOI_GROUP_IN   '('         /* Start command grouping       */
#define IOI_GROUP_OUT  ')'         /* End command grouping         */

#define IOI_INPUT      '<'         /* File redirection and include */
#define IOI_OUTPUT     '>'         /*     - " -        and logging */
#define IOI_ERROR      '&'
#define IOI_PIPE       '|'
#define IOI_COMPRESS   '='         /* in/output and strip for here */

#define IOI_OPTION     '-'         /* Exe option introducer */

#define IS_COMMENT(c)   ((c)==IOI_COMMENT)
#define IS_HISTORY(c)   ((c)==IOI_HISTORY)
#define IS_SHELL(c)     ((c)==IOI_SHELL)
#define IS_CSHELL(c)    ((c)==IOI_CSHELL)
#define IS_ESCAPE(c)    ((c)==IOI_ESCAPE)
#define IS_VARIABLE(c)  ((c)==IOI_VARIABLE)
#define IS_IOI(c)       ((c)==IOI_IOI)
#define IS_COMMAND(c)   ((c)==IOI_COMMAND)
#define IS_JOIN(c)      ((c)==IOI_JOIN)
#define IS_HELP(c)      ((c)==IOI_HELP)
#define IS_MATH(c)      ((c)==IOI_MATH)

#define IS_GROUP_IN(c)  ((c)==IOI_GROUP_IN)
#define IS_GROUP_OUT(c) ((c)==IOI_GROUP_OUT)

#define IS_INPUT(c)     ((c)==IOI_INPUT)
#define IS_OUTPUT(c)    ((c)==IOI_OUTPUT)
#define IS_ERROR(c)     ((c)==IOI_ERROR)
#define IS_PIPE(c)      ((c)==IOI_PIPE)
#define IS_COMPRESS(c)  ((c)==IOI_COMPRESS)

#define IS_OPTION(c)    ((c)==IOI_OPTION)

#define IS_(c) ((c)==IOI_)

/*
#define IS_COMMENT(c)  ((c)==ioi_._comment)
...
*/

#define IS_SPACE(c)    ((c)==' ' || (c)=='\t' || (c)=='\n')

/**************************************************************************
*  Different list types for list handling module.
************************************o*************************************/

#define IOI_L_ALIAS       0
#define IOI_L_HISTORY     1
#define IOI_L_VARIABLE    2
#define IOI_L_FUNCTION    3
#define IOI_L_CALL        4
#define IOI_L_FILE        5
#define IOI_L_TOKEN       6
#define IOI_L_MATH        7

#define IOI_L_REDIR       8        /* File IOI redirection, new 09-JUL-91 */

#define IOI_L_CASE        9        /* These must be in alphabetical orded */
#define IOI_L_FOR        10        /* and the case to be the first one    */
#define IOI_L_IF         11
#define IOI_L_LOOP       12 
#define IOI_L_WHILE      13
#define IOI_L_REPEAT     14        /* Currently unused */
#define IOI_L_CASEIN     15        /* Case command in branch */

#define IOI_L_CMD        16        /* Any of the control ones     */
#define IOI_L_EXE        17        /* Compiled & defined function */
#define IOI_L_PARAM      18

#define IOI_L_BOOLEAN    19        /* Different parameter types           */
#define IOI_L_INTEGER    20        /* These must be in alphabetical orded */
#define IOI_L_DOUBLE     21        /* and the boolean to be the first one */
#define IOI_L_CHARACTER  22
#define IOI_L_STRING     23
#define IOI_L_ENUM       24
#define IOI_L_PATH       25

#define IOI_L_TYPES      26

#define EXE_PARAM FALSE            /* Used in exe-creation calls */
#define EXE_OPTION TRUE            /*           -  "  -          */

#define IS_CONTROL(c) \
 ( (c)==IOI_L_CASE   || (c)==IOI_L_FOR    || (c)==IOI_L_IF    || \
   (c)==IOI_L_LOOP   || (c)==IOI_L_REPEAT || (c)==IOI_L_WHILE )

#define CASE_CONTROL \
   case IOI_L_CASE:   case IOI_L_FOR:    case IOI_L_IF: \
   case IOI_L_LOOP:   case IOI_L_REPEAT: case IOI_L_WHILE  /* LAST without : */

/**************************************************************************
*  Some generally useful macros.
************************************o*************************************/

#define FCLOSE(a) if((a)) { fclose((a)); (a)=NULL; }
#define MANLEN(x) (sizeof(x)/sizeof(char *))

#define SALLOC(x) (x *)calloc(1,sizeof(x))
#define  ALLOC(x) calloc(1,x)

/**************************************************************************
*  IOI-TYPE-DEFINITION (currently struct introductions only.)
*  NOTICE! The type ioi_gen is used in module list.
************************************o*************************************/

typedef struct _ioi_gen {          /* Generic for list routines */
  int                  type;       /* What this structure is? */
  char                *name;       /* Name of the list item    */
  struct _ioi_gen     *next;       /* Next item in the list     */
  /* ... */                        /* Rest of the stuff      */
} ioi_gen;

typedef struct _ioi_token {
  int                   type;       /* === GEN === */
  char                 *text;       /* !see above! */
  struct _ioi_token    *next;       /* !see above! */
} ioi_token;

typedef struct _ioi_node {
  int                  type;       /* === GEN === */
  char                *name;       /* Variable or constant name */
  struct _ioi_node    *left,*right;/* NOT REALLY A GEN */
  int                  mtype;      /* Math type */
  int                  level;      /* Precedence level */
  int                  dummy;      /* For the XDR!     */ /* See sms */
} ioi_node;

typedef struct _ioi_alias {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _ioi_alias   *next;       /* !see above! */
  int                  argc;       /* Actual number of tokens */
  char               **argv;       /* The tokens */
  int                  hit;        /* Hit against recursion */
} ioi_alias;

typedef struct _ioi_history {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _ioi_history *next;       /* !see above! */
  int                  argc;       /* Actual number of tokens */
  char               **argv;       /* The tokens */
  int                  num;        /* History line number */
} ioi_history;
  
typedef struct _ioi_variable {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _ioi_variable *next;      /* !see above! */
  char                *definition; /* Currently only strings */
/*int                  vtype; */   /* Currently unused */

} ioi_variable;

typedef struct _ioi_file {         /* Include file stack   */
  int                  type;       /* !see above!           */
  char                *name;       /* Remembered for logging */
  ioi_gen             *next;       /* Next (previuos) file    */
  ioi_variable        *local;      /* SAME OFFSET THAN IN CALL */
  FILE                *fp;         /* File to read              */
  ioi_token           *stack;      /* Arguments left after <     */
} ioi_file;

typedef struct _ioi_function {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _ioi_function *next;      /* !see above! */
  int                  in_use;     /* A counter, not changeable? */
  ioi_token           *lines;      /* The text to be executed    */
} ioi_function;

typedef struct _ioi_call {         /* A function call      */
  int                  type;       /* !see above!           */
  char                *name;       /* CURRENTLY UNUSED       */
  ioi_gen             *next;       /* Next (previuos) file    */
  ioi_variable        *local;      /* SAME OFFSET THAN IN FILE */
  ioi_token           *stack;      /* Tokens left after call    */
  ioi_token           *ifile;      /* Pointer in the function    */
  ioi_function        *function;   /* To reduce in-use count      */
  ioi_token           *params;     /* Parameters to the function   */
} ioi_call;

typedef struct _ioi_redir {         /* A file IOI redirection */
  int                   type;       /* === GEN === */
  char /* UNUSED */    *name;       /* !see above! */
  struct _ioi_redir    *next;       /* !see above! */
  FILE             *in,*out,*err;   /* Stdin, stdout & stderr saved */
  char            *cin,*cout,*cerr; /* Names saved for debugging    */
  int                   pipe;       /* In UNIX stdout is pipe? */
} ioi_redir;

typedef struct _ioi_command {
  int                  type;       /* === GEN === */
  char /* UNUSED */   *name;       /* !see above! */
  struct _ioi_command *next;       /* !see above! */
  ioi_token           *cmd;        /* Current command parsed into tokens */
} ioi_command;

typedef struct _ioi_control {
  int                  type;       /* === GEN === */
  char /* UNUSED */   *name;       /* !see above! */
  ioi_gen             *next;       /* !see above! */
  ioi_command         *cmd;        /* Current command       */
  ioi_token           *item;       /* Current item in list   */
  ioi_command         *command;    /* The body of commands    */
  ioi_command         *other;      /* IF statement only        */
  ioi_node            *expression; /* IF & WHILE statements     */
  ioi_token           *in_list;    /* LOOP statement only        */
  ioi_command         *casecmd;    /* Current cmd in case branch  */
  char                *variable;   /* CASE/FOR/LOOP statements     */
  double               value;      /* FOR statement (value=current) */
  ioi_node            *start,*end,*step; /* Expressions for the FOR */
} ioi_control;

typedef struct _IOI_param {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _IOI_param   *next;       /* !see above! */
  char                *oname;      /* Character name of the option       */
  char                *value;      /* Pointer to the value(s) (type def!) */
  char                *def;        /* Default value(s) (address('s))       */
  char                *min,*max;   /* Limits for the value(s) if applicable */
  int                  dim;        /* Number of values in this parameter     */
  int                  must;       /* Is't necessary for this param to exist */
  int                  eargc;      /* Number of enumbered items              */
  char               **eargv;      /* Char representation of enums           */
  int                 *elens;      /* Minimum lenghts for the enums         */
  int                  margc;      /* Length of the manual in lines        */
  char               **margv;      /* The first line is the short help    */
  char                *coupled;    /* Parameter is coupled with variable */
} ioi_param;

typedef struct _ioi_exe {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _ioi_exe     *next;       /* !see above! */
  char                *section;    /* Manual section */
  int               (* call)();    /* Function to call with params */
  ioi_param           *options;    /* If any (use one letter ones)  */
  ioi_param           *parameters; /* If any (extra can be supplied) */
  int                  margc;      /* Length of the manual in lines   */
  char               **margv;      /* The first line is the short help */
  void                *library;    /* Dynamically loaded library        */
} ioi_exe;

/**************************************************************************
*  The variable structure ioi_ is only 'visible' for the ioi-module.
*  DON'T TRY TO MODIFY IT DIRECTLY OUTSIDE THE MODULE, USE FUNCTIONS!
************************************o*************************************/

#ifdef IOI_MODULE

#ifdef IOI_MAIN_MODULE
#  define EXT
#else
#  define EXT extern
#endif

EXT struct {
  int              _log[IOI_LOGS]; /* Flags to log messages          */
  int              _msg[IOI_LOGS]; /* Flags to show messages         */
  int                  _brief;     /* Brief messages                 */
  FILE                *_logfile;   /* Current logfile                */
  char                *_logname;   /* It's nice to remember          */
  FILE           *_in,*_out,*_err; /* Stdin, stdout & stderr saved   */
  char         *_cin,*_cout,*_cerr;/* Names saved for debugging      */
  int                  _pipe;      /* In UNIX stdout is pipe?        */
  int                  _lsize;     /* Max size of the line           */
  char                *_line;      /* Current input line             */
  char                *_work;      /* Temp for expansion             */
  char                *_logmsg;    /* Last log message               */
  ioi_token           *_usrinput;  /* From the _file_input()         */
  int                (*_input)();  /* User input routine             */
  int                (*_output)(); /* User output routine            */
  int                (*_exit)();   /* User exit routine              */
  int                (*_event)();  /* User event routine             */
  int                  _disabled;  /* Language module disabled, eg X */
  ioi_token           *_token;     /* Current command to be executed */
  ioi_token           *_stack;     /* Tokens for next commands       */
  ioi_gen             *_action;    /* Action stack files             */
  ioi_history         *_history;   /* List of history lines          */
  int                  _hist_num;  /* Current line number            */
  int                  _hist_len;  /* # of lines to remember         */
  ioi_alias           *_alias;     /* Alias pairs                    */
  ioi_variable        *_variable;  /* Variables set                  */
  ioi_function        *_function;  /* Functions defined              */
  ioi_exe             *_exe;       /* Executables defined            */
  ioi_exe             *_man;       /* Manual pages defined (! run)   */
  char           _usedopt[MAXNAM]; /* Options used by the user       */
  int                  _asize;     /* Size of the _argv buffer       */
  int                  _argc;      /* Current _argv usage            */
  char               **_argv;      /* Current command                */
  int                  _in_def;    /* Inside function definition?    */
  int                  _sensitive; /* Is the ioi case sensitive?     */
  int                  _automenu;  /* Automatic menu display?        */
  int                  _autopath;  /* Automatic path update?         */
  char                 _ioi;       /* IOI command                    */
  char                 _comment;   /* Comment character              */
  char                 _shell;     /* Shell escape character         */
  char                 _cshell;    /* C-Shell escape character       */
  char                 _command;   /* Command separator character    */
  char                 _join;      /* Join next input line           */
  char                 _backup;    /* Return backup signal           */
  char                 _escape;    /* Prervent special char meaning  */
  char                 _comma;     /* Number separation              */
  char                 _math;      /* Calculator invoker             */
  char            _prompt[MAXNAM]; /* The current prompt for input   */
  int                  _stime;     /* Starting time of the module    */
  jmp_buf              _jmpenv;    /* For setjmp() / longjmp()       */
  char                *_myname;    /* Name of the original command   */
} ioi_;

#define D(x)    fprintf(stderr,"TRAP %d\n",(x))

#endif  /* IOI_MODULE */

#include <ioiproto.h>

#endif  /* IOI_H */
