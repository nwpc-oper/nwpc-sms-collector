"Remove the definition of the variable named.",
"The definition of the variable named is removed.",
"",
"Notice! It's not an error to remove a variable even if it doesn't exist.",
"        Some of the internal variables will appear again automatically.",
"",
NULL
