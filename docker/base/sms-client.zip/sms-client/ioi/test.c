/**************************************************************************
.TITLE   Input Output Interface
.NAME    TEST
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    20-OCT-1992 / 20-OCT-1992 / OP
.VERSION 2.1
.FILE    test.c
*
*  Code for the command test(ioi)
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#include <sys/stat.h>

ioi_test(argc,argv) int argc; char **argv;
/**************************************************************************
?  Test a file
=  TRUE if ok.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   f_ ;

  if( called )
  {
    struct stat st;

    if( stat(dummy,&st) == NIL )
      return ioi_perror("IOI-TEST:",dummy);

    if(f_
  }
  else
    ioi_exe_add("test:ioi",ioi_test,
      ioi_exe_link_param(
        ioi_exe_param("-ffile",IOI_L_BOOLEAN,ioi_exe_argv(
            "Test if filename exists and is a regular file.",
            NULL
          ),NULL,1,&f_
        ),
        NULL
      ),
      ioi_exe_param("filename",IOI_L_PATH,ioi_exe_argv(
          "The file name to be tested.",
          NULL
        ),NULL,-1,&dummy
      ),

      ioi_exe_argv(
        "Test the files.",
        "The status is $rc.",
        "Currently under costruction.",
        NULL
      )
    );

  return called=TRUE;
}
