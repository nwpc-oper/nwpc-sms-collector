int sbs(int argc, char **argv)
{
  printf("New version\n");
  while(argc--)
    printf("FOO: %s\n",*argv++);

  return 1;
}

