
#define IOI_MEMORY

#include "ioi.h"

main()
{
  int i;
  char *x[100];

  ioi_memory(1000);
/*
  ioi_open(0,NULL,NULL);
*/

  srand(time(NULL)+getpid());

  for( i=0 ; i<5 ; i++ )
  {
    x[i] = (char *)malloc(20);
    dump();
  }

  for( i=2 ; i<5 ; i++ )
  {
    free(x[i]);
    dump();
  }

  for( i=0 ; i<7 ; i++ )
  {
    x[i] = (char *)malloc(20);
    dump();
  }
}
