/**************************************************************************
.TITLE    Input Output Interface
.NAME     IOI
.SECTION  LIB
.AUTHOR   Otto Pesonen
.DATE     08-OCT-1992 / 07-MAY-1990 / OP
.VERSION  2.0
.FILE     ioi.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     25-AUG-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*   Based on: clp, cmdf, unix & cmdop (v 10)
*   Totally rewritten for IOI by OP
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#define IOI_MAIN_MODULE
#include "ioi.h"

int ioi_try_name(char *name)
/**************************************************************************
?  Include the file named/digged from environment into the input stream.
|
|  The name given is expected to be an environment variable, in most cases
|  this is in UPPER case.
|
|  Nothing is done, if no name is given (name is NULL or string is empty).
|
|  If the environment variable pointed by the NAME can be found and points
|  to a readable file, the file is included.
|
|  Otherwise the NAME is converted to lowercase and a dot (.) is added
|  into the beginning. Then if a file with the converted name in the
|  current directory is readable, it is included.
|
|  Otherwise if a file with the converted name in users HOME directory is
|  readable, it is included.
=  BOOLEAN status was the file included?
+  ioi_try_name("IOIRC");
|    1.  environment variable $IOIRC
|    2.  ./.ioirc
|    3.  ~/.ioirc   (or ${HOME}/.ioirc
************************************o*************************************/
{
  extern char *getenv();

  char  lower[MAXNAM];             /* The name in lower case + a dot */
  char *s;

  if( !name ) return FALSE;        /* Not loaded! */

  if((s=getenv(name)))             /* First the environment */
    if( access(s,4) )
      ioi_out(0,IOI_ERR,"IOI-OPEN:Cann't access %s (env %s)",s,name);
    else
    {
      ioi_file_include(s);
      return TRUE;
    }

  for( s = lower , *s++ = '.' ; *name ; name++ )
    *s++ = tolower(*name);
  *s = '\0';

  if( !access(lower,4) )           /* Then the current directory */
  {
    ioi_file_include(lower);
    return TRUE;
  }

  if((s=getenv("HOME")))           /* Then the HOME-directory */
  {
    char work[MAXLEN];

#if defined(UNIX) || defined(unix)

    sprintf(work,"%s/%s",s,lower);

#else
#  if defined(VMS)

    sprintf(work,"%s%s",s,lower);

#  else

    work[0]='\0';                  /* Nothin' @ all */

#  endif
#endif

    if( !access(work,4) )
    {
      ioi_file_include(work);
      return TRUE;
    }
  }

  return FALSE;
}

int ioi_open(int argc, char **argv, char *name)
/**************************************************************************
?  Called to initialize the IOI-system.
|  This loads the defaults and allocates memory for the internal buffers.
|  The size of the buffers can be increased.
|
|  The name determines the initialization file:
|  if NULL use the default (IOIRC)
|  if empty don't use anything
|  if (otherwise) use name pointed
-EXIT  If this routine fails the program is terminated by the exit system
|  call with exitcode 1.
*NOTICE  At the startup the default setting of the charactes and variables
*  may be modified by the inirc-file.
************************************o*************************************/
{
  ioi_._logfile      = NULL;

  ioi_._in           = NULL;
  ioi_._out          = NULL;
  ioi_._err          = NULL;
  ioi_._pipe         = FALSE;

  ioi_._token        = NULL;
  ioi_._stack        = NULL;
  ioi_._action       = NULL;

  ioi_._history      = NULL;
  ioi_._hist_num     = 0;
  ioi_._hist_len     = 0;

  ioi_._alias        = NULL;
  ioi_._variable     = NULL;
  ioi_._function     = NULL;

  ioi_._automenu     = FALSE;
  ioi_._autopath     = FALSE;
  ioi_._sensitive    = FALSE;

  ioi_._ioi          = IOI_IOI;
  ioi_._comment      = IOI_COMMENT;
  ioi_._shell        = IOI_SHELL;
  ioi_._command      = IOI_COMMAND;
  ioi_._join         = IOI_JOIN;
  ioi_._backup       = IOI_BACKUP;
  ioi_._escape       = IOI_ESCAPE;
  ioi_._comma        = IOI_COMMA;
  ioi_._math         = IOI_MATH;

  ioi_._argc         = 0;

  ioi_._logmsg       = (char *)ALLOC(1024);   /* Should be big enough */

  ioi_set_line_size(MAXLEN);
  ioi_set_stack_size(MAXARG);

  ioi_variable_init();

  if( !ioi_._line || !ioi_._work || !ioi_._argv || !ioi_._logmsg )
  {
    ioi_out(0,IOI_ERR,"IOI-OPEN:Internal buffer allocation error.");
    exit(1);
  }

  ioi_._line[0]      = '\0';

  if(!name) 
    ioi_try_name("IOIRC");
  else
    if(*name)
      ioi_try_name(name);

  ioi_man_manload(0,NULL);

  ioi_._stime = time(NULL);

  return 0;
}

int ioi_set_stack_size(int newsize)
/**************************************************************************
?  Modify the maximum size of the current command buffer.
|  The new size must be at least MINARG (originally 32).
|  The contents of the internal argv-buffer is copied into the new one.
=  TRUE if ok
|  FALSE if too small size or the requested size couldn't be allocated.
************************************o*************************************/
{
  char **argv;                     /* Temp to make sure this works out */

  if(newsize == ioi_._asize) return(TRUE);

  if(newsize < MINARG)
    return ioi_out(0,IOI_ERR,"IOI-SET-STACK-SIZE:Too small(%d).",newsize);

  if( !(argv = (char **)ALLOC(sizeof(char *)*(newsize+1))) )
    return ioi_out(0,IOI_ERR,"IOI-SET-STACK-SIZE:No mem (%d).",newsize);

  memcpy(argv,ioi_._argv,ioi_._asize*sizeof(char **));
  IFFREE(ioi_._argv);
  ioi_._argv = argv;

  ioi_._asize = newsize;

  return TRUE;
}

int ioi_set_line_size(int newsize)
/**************************************************************************
?  Modify the maximum size of the current input line buffer.
|  The temporarily work space is also modified.
|  The new size must be at least MINLEN (originally 256).
|  The contents of the internal line-buffers are copied into the new ones.
=  TRUE if ok
|  FALSE if too small size or the requested size couldn't be allocated.
************************************o*************************************/
{
  char *line1,*line2;              /* Temp to make sure this works out */

  if(newsize == ioi_._lsize) return(TRUE);

  if(newsize < MINLEN)
    return ioi_out(0,IOI_ERR,"IOI-SET-LINE-SIZE:Too small (%d).",newsize);

  if( !(line1 = (char *)ALLOC(newsize+1)) )
    return ioi_out(0,IOI_ERR,"IOI-SET-LINE-SIZE-1:No mem (%d).",newsize);

  if( !(line2 = (char *)ALLOC(newsize+1)) )
  {
    free(line1);
    return ioi_out(0,IOI_ERR,"IOI-SET-LINE-SIZE-2:No mem (%d).",newsize);
  }

  if(ioi_._line) memcpy(line1,ioi_._line,ioi_._lsize*sizeof(char));
  if(ioi_._work) memcpy(line2,ioi_._work,ioi_._lsize*sizeof(char));

  /* line1[newsize] = line2[newsize] = '\0'; */

  IFFREE(ioi_._line);
  ioi_._line = line1; 

  IFFREE(ioi_._work);
  ioi_._work = line2; 

  ioi_._lsize = newsize;

  return TRUE;
}

void ioi_close(void)
/**************************************************************************
?  Terminate the IOI system.
|  The memory used by the IOI-system is released.
|  All assosiated files are closed.
|  The system cann't be used again without calling the ioi_open routine.
************************************o*************************************/
{
  ioi_file_restore();
  ioi_out(0,IOI_LOG,"IOI-CLOSE:Closing down the IOI.");

  if( ioi_._action )
    ioi_action_handler(-1);

  ioi_file_log(NULL,FALSE);

  /* Remove dynamic variables */

  ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,TRUE);

  ioi_list_delete_all(IOI_L_ALIAS);
  ioi_list_delete_all(IOI_L_FUNCTION);
  ioi_list_delete_all(IOI_L_VARIABLE);
  ioi_history_set(0);

  IFFREE(ioi_._argv); ioi_._asize=0;
  IFFREE(ioi_._line); IFFREE(ioi_._work); ioi_._lsize=0;
  IFFREE(ioi_._logmsg);
}

int ioi_check_internal(void)
/**************************************************************************
?  Check to see if this is an internal command
=  TRUE if this is an internal command.
|  FALSE if not or ioi is in internal menu.
************************************o*************************************/
{
  char   c;
  char **argv = ioi_._argv;
  int    argc = ioi_._argc;
  int    cmd;

  if(argc==0) return FALSE;

  c = argv[0][0];

  if( IS_HELP(c) || IS_SHELL(c) || IS_CSHELL(c) || c=='<' || c=='>' )
    return TRUE;
  else                 /* NEW PATCH */
    return FALSE;
}

int ioi_internal_help(void)
/**************************************************************************
?  Print internal help 
************************************o*************************************/
{
  ioi_printf(FALSE,"Or one of the following\n\n");

  ioi_printf(FALSE,"< filename     to include an external file (<< is the same)\n");
  ioi_printf(FALSE,"> logname      to start (a new) logfile (use >> to append)\n");
  ioi_printf(FALSE,"$ cmd [arg(s)] to execute operating system command\n");
  ioi_printf(FALSE,"$              to escape into shell (env SHELL, def /bin/sh)\n");
  ioi_printf(FALSE,"%% cmd [arg(s)] to execute operating system command in csh\n");
  ioi_printf(FALSE,"%%              to escape into C-shell\n");
  ioi_printf(FALSE,"\n");

  return( TRUE );
}

int ioi_internal(int help_return)
/**************************************************************************
?  Execute internal command.
|  The command is in the "current command" (argc & argv) all piping
|  and so fort is done before this routine
=  TRUE if ok, FALSE if syntax or any other error.
************************************o*************************************/
{
  char   c;
  int    argc = ioi_._argc;
  char **argv = ioi_._argv;
  int    append;

  c = argv[0][0];
  append = ( IS_OUTPUT(argv[0][1]) );

  if( IS_SHELL(c) ) return( ioi_shell_system(TRUE,argc,argv) );

  if( IS_CSHELL(c) ) return( ioi_shell_system(FALSE,argc,argv) );

  if( IS_INPUT(c) ) return( ioi_file_include( (argc>1)? (*++argv):NULL) );

  if( IS_OUTPUT(c) ) return( ioi_file_log( (argc>1)? (*++argv):NULL,append) );

  if( IS_HELP(c) && !help_return )
    return ioi_internal_help();

  return TRUE;
}

int ioi_cmd(int help_return)
/**************************************************************************
|  Form a next command in to the argc-argv of the ioi_.
|  REDIRECT STDS BACK, restore stdio/out/err/pipe
|  REMOVE OLD COMMAND
|  IF NO TOKENS LEFT ==>
|    READ A NEXT LOGICAL LINE
|    CHECK HISTORY SUBSTITUTION (error break)
|    PARSE INTO TOKENS (null break) (leave escapes and quotes)
|    STORE HISTORY 
|  BUILD A COOMAND:
|    ALIAS FIRST TOKEN (loop protect)
|    SUBSTITUTE VARIABLES (no null break)
|    EXECUTE SHELLS AND PARSE INTO TOKENS (process-break)
|    REDIRECT OUTPUT (error break)
|    CUT THE COMMAND FROM TOKEN-STREAM (remove escapes and quotes)
|
|  This routine only returns when there is a syntactically valid command
|  for the calling program to be executed. Internal commands are executed
|  without the caller to know about them. Variables, history substitution
|  and input/output redirection doesn't show to the caller.
=  TRUE if command exists, that means there is at least one character.
|  FALSE if the module has been advised to exit of if EOF in stdin is
|  reached.
************************************o*************************************/
{
  static int syntax_error = FALSE;

  while( TRUE )
  {
    if( setjmp(ioi_._jmpenv) )
      /* From the longjmp() */
      ;
    else
      /* After the setjmp() */
      ;

    ioi_file_restore();

    ioi_token_delete_command();

    if( syntax_error )
    {
      ioi_._stack = (ioi_token *)ioi_token_delete(ioi_._stack,TRUE);
      syntax_error = FALSE;
      /* EMERGENCY BREAK! */
    }

    if( ! ioi_token_stack(FALSE) )
      return( FALSE );

    /* Generate a command out of the tokens */

    if( ioi_math_is_set() )
      if( ioi_math_is_calc() )
      {
        syntax_error = TRUE;
        if( ioi_language_substitute() )
          if( !ioi_._token )
            syntax_error = FALSE;
          else
            if( ioi_alias_substitute() )
              if( ioi_variable_substitute() )
                if( ioi_shell_substitute() )
                  if( ioi_file_redirect() )
                    if( ioi_load_command() )
                      if( ioi_function_substitute() )
                        syntax_error = FALSE;
                      else
                        if( !ioi_exe_substitute(NULL,0,NULL) )
                          syntax_error = FALSE;
                        else
                          if( ioi_check_internal() )
                            if( ioi_internal(help_return) )
                              if( ioi_._token && IS_HELP(ioi_._token->text[0])
                                  && help_return )
                                return( TRUE );
                              else
                                syntax_error = FALSE;
                            else
                              ;
                          else
                            return( TRUE );
      }
  }
}

int ioi_load_command(void)
/**************************************************************************
?  Load the command into the argc-argv of the ioi_.
*  Process tokens up to the IOI_COMMAND. (Done by the ioi_token_stack!)
|  Pipe introducer is already processed before this.
|  Strip the quotation marks and escaped characters from the strings.
************************************o*************************************/
{
  ioi_token *token = ioi_._token;
  int        argc  = 0;
  int        asize = ioi_._asize;
  char     **argv  = ioi_._argv;

  char       *w;                   /* Work space ( == same)   */
  char       *s;                   /* Current string in token */
  char        inside   = '\0';     /* Inside quotes?  ' or "  */

  ioi_token_remove_empty();

  token = ioi_._token;

  while( token )
  {
    *argv    = token->text;
    token    = token->next;

    inside   = '\0';
    s        = *argv;
    w        = *argv++;

    while( *s )                    /* Remove the quotation & specials! */
    {
      if( inside )
        if( inside == *s )
          inside = '\0';
        else
        {
          if( inside == '\'' )
            *w++ = *s;
          else
            if(IS_ESCAPE(*s) && s[1]) /* && !(isalnum(s[1] || s[1]=='_') */
              *w++ = *++s;
            else
              *w++ = *s;
        }
      else
        if(IS_ESCAPE(*s) && s[1])  /* Special last char! */
          *w++ = *++s;
        else
          if( *s=='\'' || *s=='"')
            inside = *s;
          else
            *w++ = *s;

      s++;
    }
    *w = '\0';                     /* Terminate the stripped string */

    if( ++argc >= asize )
    {
      ioi_token_delete_command();

      return
        ioi_out(0,IOI_ERR,"IOI-LOAD-COMMAND:Too many arguments %d",asize);
    }
  }

  ioi_._argc = argc;

  return( TRUE );
}

int ioi_parse_args(int *ac, char ***av, char c)
/**************************************************************************
?  Further parse args by splitting them by the char C.
|  Eg  [aa:bb] with C==':' ---> [aa] [:] [bb]
=  In argc and argv
!  The argc and argv are generated from the tokens again, user can't
|  give it's one argc/argv arrays!
-NOTICE Use ls_parse()
************************************o*************************************/
{
  ioi_token *token = ioi_._token;
  int        argc  = 0;
  int        asize = ioi_._asize;
  char     **argv  = ioi_._argv;

  char       *s;                   /* Current string in token */
  char        cmd[2];              /* To generate new tokens  */

  cmd[0] = c; cmd[1] = '\0';

  while( token )
  {
    s = token->text;

    while( *s )
    {
      if( *s == c )
      {
        ioi_token *temp = token->next;

        if( s != token->text )
        {
          *s = '\0';
          token->next = (ioi_token *)ioi_token_create(cmd);
          if( ! (token = token->next) ) goto error;
        }
        if( *++s )
        {
          token->next = (ioi_token *)ioi_token_create(s);
          if( ! (token = token->next) ) goto error;
        }
        token->next = temp;
        s = token->text;
      }
      else
        s++;
    }
    token = token->next;
  }

  token = ioi_._token;

  while( token )
  {
    *argv++ = token->text;
    if( ++argc >= asize ) 
    {
      ioi_token_delete_command();

      return
        ioi_out(0,IOI_ERR,"IOI-PARSE-ARGS:Too many arguments %d",asize);
    }
    token   = token->next;
  }

  *ac = ioi_._argc = argc;
  *av = ioi_._argv;

  return( TRUE );

  error:

  ioi_token_delete_command();
  return ioi_out(0,IOI_ERR,"IOI-PARSE-ARGS:No mem.");
}
