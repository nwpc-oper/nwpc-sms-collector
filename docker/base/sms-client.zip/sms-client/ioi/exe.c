/**************************************************************************
.TITLE    Input Output Interface
.NAME     EXE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     09-FEB-1993 / 27-JAN-1991 / OP
.VERSION  2.0
.FILE     exe.c
.DATE     05-NOV-1993 / 27-JAN-1991 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-SEP-1994 / 05-JAN-1994 / OP
.VERSION  3.1
.DATE     27-MAR-1995 / 27-MAR-1995 / OP
.VERSION  3.2
*         Dynamic loading added
*         Command and manual shortening.
.DATE     07-AUG-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

extern double atof();

/**************************************************************************
*
*           D E F I N I T I O N S   F O R   C L A R I T Y
*
************************************o*************************************/

#define UP(x) if((x)) (x)++

char **ioi_exe_argv(char *first, ...)
/**************************************************************************
?  Create a copy of the strings given and form a argv-type array.
|  This is normally used for the manual pages of the exe-system.
|  Look at the example later on.
-NOTICE  At the moment only the reference to the original strings are 
|  created.
=  The pointer to the array or NULL if out of memory.
$  char **argv = ioi_exe_argv("first","second","third...",NULL);
~  The number of items in the array can be calculated by ioi_exe_argc()
************************************o*************************************/
{
  va_list ap;
  char  **argv;
  char   *s;
  int     argc = 1;

  va_start(ap,first);
  while( (s=va_arg(ap, char *)) ) argc++;
  va_end(ap);

  if( !(argv=(char **)calloc(argc+1,sizeof(char *))) )
    return(char **)ioi_out(0,IOI_ERR,"IOI-EXE-ARGV:No mem (1).");

  argc = 0;
  va_start(ap,first);

#ifdef PRIVATE_COPY                /* Make a private copy */

  argv[argc++] = strdup(first);

  while( (s=va_arg(ap, char *)) )
    if( !( argv[argc]=strdup(s) ) )
      return(char **)ioi_out(0,IOI_ERR,"IOI-EXE-ARGV:No mem (2).");
    else
      argc++;

#else                              /* Just link the reference */

  argv[argc++] = first;
  while( ( argv[argc]=va_arg(ap, char *)) )
    argc++;

#endif

  va_end(ap);

  argv[argc] = NULL;

  return argv;
}

int ioi_exe_delete_argv(int argc, char **argv)
/**************************************************************************
?  Remove the argv table
=  BOOLEAN success
************************************o*************************************/
{
  if(!argv) return FALSE;

#ifdef PRIVATE_COPY                /* Remove the private copy */
  while( argc )
    if(argv[--argc]) free(argv[argc]);
#else
  /* nothing! */
#endif

  free(argv);

  return TRUE;
}

int ioi_exe_argc(char **argv)
/**************************************************************************
?  Count the number of items in the argv, where the last must be NULL.
=  The number of args found in the argv
************************************o*************************************/
{
  int argc=0;

  if(argv)
    while(*argv++)
      argc++;

  return argc;
}

ioi_param *ioi_exe_param(char *pname, ...)
/**************************************************************************
?  Create and fill in the parameter structure for a parameter or an option.
-CALLED  name,type,margv,coupled,dim,valueaddr [,defloc(s)]
|
|  NAME        If the NAME starts with the letter minus (-) this is assumed
|              to be an option and the second letter to be the option
|              character and the rest of the name to be the explanation for
|              the option (to be displayed in man.)
|
|  TYPE        Defines the actions for the creation and the contents of the
|              DEF(S). The parameter is unlimited in either direction if the
|              min/max-pointer is NULL.
|
|              TYPE      |  DEFLOC(S)
|              ----------+-------------------------------------
|              BOOLEAN   |  can be omitted, is FALSE by default
|              INTEGER   |  integers: minimum maximum default
|              DOUBLE    |  doubles:  minimum maximum default
|              CHARACTER |  can be omitted. NOTE DIM = len.
|              STRING    |  can be omitted. NOTE sign of DIM
|              ENUM      |  eargv default
|              FILE      |  == STRING
|
|
|  MARGV       Is a NULL terminated string array, eg created by the 
|              ioi_exe_argv(IOI). If it's NULL, there isn't manual for this
|              parameter.
|
|  COUPLED     Is a string (can be a NULL) into which the option/parameter
|              is 'coupled to' when the parameter is executed but not given
|              by the user. Command line usage overrides the coupled usage.
|
|  DIM         Tell's how big the arrays holding the values and defaults are.
|              If the DIM is negative, the parameter must be given. This
|              means that there can be extra parameters in the command which
|              are not compulsory but if given, will be checked by the IOI.
|
|              For the CHARACTER this is the length of the space allocated
|              in bytes. So it's an array of characters!
|
|              For the STRING only the sign counts.
|              NOTICE  The users variable will point to the string that is
|                      "alive" only during the execution of the users
|                      routine. If needed later it has to be duplicated.
|
|  VALUEADDR   Is an address of items defined by the TYPE. At least DIM
|              number of items must be available. The result(s) of default(s)
|              coupled argument(s) are stored here.
|
|  DEFLOC(S)   TYPE dependent. See above.
|
-NOTICE  It's an error to create parameters default value to be out of the
|  limits given.
+  ioi_exe_param("-ccolormap",IOI_L_BOOLEAN,man,NULL,1,&static_cmap)
|  ioi_exe_param("output",IOI_L_STRING,man,"my_output",80,mychars)
|  ioi_exe_param("scale",IOI_L_DOUBLE,man,"scale",1,&scale,NULL,NULL,&def)
************************************o*************************************/
{
  ioi_param *param = NULL;
  va_list   ap;

  char      *name;
  int        emus_shortening = TRUE;

  if( ! (param= SALLOC(ioi_param)) )
    return(ioi_param *)ioi_out(0,IOI_ERR,"IOI-EXE-PARAMETER:No mem.");

  va_start(ap,pname);

  /* name           = va_arg(ap, char *); */

  name           = pname;
  param->type    = va_arg(ap, int);        /* Type of the new parameter */
  param->margv   = va_arg(ap, char **);    /* Manual page for the param */
  param->margc   = ioi_exe_argc( param->margv );
  param->coupled = va_arg(ap, char *);     /* Default variable to look  */
  param->dim     = va_arg(ap, int);        /* Dimensions of the arrays   */
  param->value   = va_arg(ap, char *);     /* Values will be strored here */

  if(param->type == -(IOI_L_ENUM))
  {
    param->type = IOI_L_ENUM;
    emus_shortening = FALSE;
  }

  if( param->dim<0 )               /* Mark the param to compulsory */
  {
    param->must = TRUE;
    param->dim = (-param->dim);
  }

  if( *name=='-' )                 /* An option! */
  {
    param->must = FALSE;
    if( name[2] )
      param->oname = strdup(&name[2]);

    param->name = strdup("-");     /* Space for two bytes! */
    param->name[0] = name[1];      /* Option letter */
  }
  else
    param->name = strdup(name);

  switch( param->type )
  {
    case IOI_L_BOOLEAN:
    case IOI_L_STRING:
    case IOI_L_PATH:               /* Nothin' else! */
      break;
    case IOI_L_CHARACTER:
      param->dim--;                /* Let's save space for the \0 */
      break;
    case IOI_L_DOUBLE:
    case IOI_L_INTEGER:
      param->min = va_arg(ap, char *); /* Default(s) and limit(s) arrays */
      param->max = va_arg(ap, char *);
      param->def = va_arg(ap, char *);
      break;
    case IOI_L_ENUM:
      param->eargv = va_arg(ap, char **);
      param->eargc = ioi_exe_argc( param->eargv );
      param->def   = va_arg(ap, char *);
      if( emus_shortening )
      {
        param->elens = (int *)malloc(sizeof(int)*param->eargc);
        ioi_user_fmcl(param->eargv,param->elens,param->eargc);
      }
      break;
    default:
      ioi_out(0,IOI_ERR,"IOI-EXE-PARAMETER:User error!");
      break;
  }

  va_end(ap);

  return param;
}

ioi_param *ioi_exe_link_param(ioi_param *first, ...)
/**************************************************************************
?  Link the parameters given.
$  ioi_parameter *param = ioi_exe_link_param(first,second,third,NULL);
-NOTICE  The parameters given must be unlinked!
=  Pointer to the first parameter given.
************************************o*************************************/
{
  va_list ap;
  ioi_param *start=NULL,*last=NULL,*next=NULL;

  start = last = first;

  if(!start) return start;

  va_start(ap,first);

  while( (next=va_arg(ap, ioi_param *)) )
  {
    last->next = next;
    last = next;
  }
  
  va_end(ap);

  return start;
}

void ioi_exe_param_list(ioi_param *param)
/*
 *  This function is moving to man.c
 */
/**************************************************************************
?  List the parameters (options) in for the manual page.
************************************o*************************************/
{
  static char *types[] = {
    "boolean",  "integer",  "double",  "character",  "string",
    "enum"   ,  "file",
  };

  int     i,dim;
  int    *imin,*imax,*idef;
  double *dmin,*dmax,*ddef;

  while(param)
  {
    ioi_printf(0,"    ");

#if 0
    if( !param->name[1] )          /* Simple temporarily solution! */
      ioi_printf(0,"-%s",param->name);
    else
      ioi_printf(0,"%s",param->name);
#endif

    if( param->oname ) ioi_printf(0,"-");
    ioi_printf(0,"%s",param->name);

    if( param->oname )
      ioi_printf(0," [%s]",param->oname);

    ioi_printf(0," (%s)",types[param->type-IOI_L_BOOLEAN]);

    if( param->coupled ) ioi_printf(0," {%s}",param->coupled);

    if( (dim=param->dim) >1 )
      if( param->type==IOI_L_INTEGER || param->type==IOI_L_DOUBLE )
        ioi_printf(0," [x%d]",dim);

    switch( param->type )
    {
      case IOI_L_BOOLEAN:
        break;
      case IOI_L_INTEGER:
        imin = (int *)param->min;
        imax = (int *)param->max;
        idef = (int *)param->def;
        for( i=0 ; i<dim ; i++ )
        {
          if( ! imin && ! imax )
            ioi_printf(0," nolimits");
          else
          {
            if( imin )         ioi_printf(0," %d",*imin);
            else               ioi_printf(0," -inf");
                               ioi_printf(0," -");
            if( imax )         ioi_printf(0," %d",*imax);
            else               ioi_printf(0," inf");

            if( idef )         ioi_printf(0," def=%d",*idef);
            if( ++i != dim )   ioi_printf(0," , ");
          }

          UP(imin); UP(imax); UP(idef);
        }
        break;
      case IOI_L_DOUBLE:
        dmin = (double *)param->min;
        dmax = (double *)param->max;
        ddef = (double *)param->def;
        for( i=0 ; i<dim ; i++ )
        {
          if( ! dmin && ! dmax )
            ioi_printf(0," nolimits");
          else
          {
            if( dmin )         ioi_printf(0," %g",*dmin);
            else               ioi_printf(0," -inf");
                               ioi_printf(0," -");
            if( dmax )         ioi_printf(0," %g",*dmax);
            else               ioi_printf(0," inf");

            if( ddef )         ioi_printf(0," def=%g",*ddef);
            if( ++i != dim ) ioi_printf(0," , ");
          }

          UP(dmin); UP(dmax); UP(ddef);
        }
        break;
      case IOI_L_CHARACTER:
        ioi_printf(0," maxlen=%d",dim);
        break;
      case IOI_L_STRING:
      case IOI_L_PATH:
        break;
      case IOI_L_ENUM:
        idef = (int *)param->def;

        ioi_printf(0,"\n\n       <");

        for( i=0 ; i<param->eargc ; i++ )
          ioi_printf(0,"%s%s",param->eargv[i],(i==param->eargc-1)?">":",");

        if( !param->must )
          ioi_printf(0," (%s)",param->eargv[idef?*idef:0]);
        break;
      default:
        ioi_printf(0,"\n");
        ioi_out(0,IOI_ERR,"IOI-PARAM-LIST:Internal trap");
        return;
    }

    if( param->must ) ioi_printf(0," [compulsory]");

    ioi_printf(0,"\n");

    if(param->margv)
    {
      ioi_printf(0,"\n");
      for( i=0 ; i<param->margc ; i++ )
        if( param->margv[i][0] )
          ioi_printf(0,"        %s\n",param->margv[i]);
        else
          ioi_printf(0,"\n");
      ioi_printf(0,"\n");
    }

    param = param->next;
  }
  ioi_printf(0,"\n");
}

int ioi_exe_list(
    char  *name,
    int    level,
    char  *section)                /* If defined, process only these */
/*
 *  This function is moving to man.c
 */
/**************************************************************************
?  Print the help information of the current manual system.
|  Different request formats available.
|
|  0: Print all known commands, just the names.
|  1: Print one liner of the command named
|  2: Print one liner of all known commands
|  3: Print the full manual page out of the named command.
|  4: Print the full manual page out of the all commands.
|  5: Print all known commands, different sections separately
|
|  Introduced in command line as follows:
|  ?           Just all the command names
|  ? name      One liner of the name
|  ??          One liner of all the commands
|  ?? name     Manual page of the name
|  ???         Manual page of all the commands
|  Only through the man command
=  TRUE if the action was completed, FALSE otherwise
************************************o*************************************/
{
  static ioi_gen *sec;             /* List of sections */

  ioi_exe *exe  = ioi_._exe;
  int      mlen = 0;               /* Max length if many commands req. */
  int      slen = 0;               /* Max length of the sections -"-  */
  int      len  = 0;
  int      cmds = 0, mans = 0;     /* Count the commands & man-pages */
  int      i;
  char     mfmt[MAXNAM];           /* Manual format string          */
  char     sfmt[MAXNAM];           /* Sections format string       */
  char    *title;                  /* To place in top of the page */
  char   **man;

/* Use this code if quick option is not allowed for the extra manual pages
  if( level==1 )
  {
    exe = ls_findm( &ioi_._exe , name );

    if( exe == LS_FIND_MULTIPLE ) exe = NULL;
    if( exe && ! exe->call ) level=3;
  }
*/

  sec = (ioi_gen *)ioi_token_delete((ioi_token *)sec,TRUE);

  while(exe)                       /* Calculate the maximum command length */
  {
    /* if( level != 2 || exe->call ) */
    if( 1 )
    {
      len = strlen(exe->name);
      mlen = (len>mlen)?len:mlen;
      len = exe->section? strlen(exe->section) : 0;
      slen = (len>slen)?len:slen;
    }

    if( exe->call ) cmds++;
    else            mans++;

    exe = exe->next;
  }

  exe = ioi_._exe;

  if( level==1 || level==3 )
  {
    exe = ls_findm( &ioi_._exe , name );

    if( (int)exe == LS_FIND_MULTIPLE )
      return ioi_out(FALSE,IOI_ERR,"IOI-EXE-LIST:multiple matches for %s",name);
    if( ! exe )
      return ioi_out(0,IOI_WAR,"IOI-EXE-LIST:[%s] not found!",name);

    mlen = !strlen(name);
  }

  mlen += 1;

  if( ( level==0 || level==2 ) && cmds )
    ioi_printf(0,"COMMANDS\n\n");

  sprintf(mfmt,"%%-%ds",mlen);

  if( level==0 )                   /* Only the command names */
  {
    int j=0;

    while( exe )
    {
      if( exe->call )              /* Let's print the commnads first */
        if( !section || (exe->section && !strcmp(section,exe->section)) )
        {
          ioi_printf(0,mfmt,exe->name);
          j += mlen;
          if( j+mlen>80 )          /* 80 really should be a variable! */
            ioi_printf(0,"\n") , j=0;
        }
      exe = exe->next;
    }
    if(j) ioi_printf(0,"\n");
    ioi_printf(0,"\n");

    if( mans )
    {
      exe = ioi_._exe;
      ioi_printf(0,"MANUALS\n\n");

      j=0;
      while( exe )
      {
        if( !exe->call )           /* And now only the manual pages */
          if( !section || (exe->section && !strcmp(section,exe->section)) )
          {
            ioi_printf(0,mfmt,exe->name);
            j += mlen;
            if( j+mlen>80 )        /* 80 really should be a variable! */
              ioi_printf(0,"\n") , j=0;
          }
        exe = exe->next;
      }
      if(j) ioi_printf(0,"\n");
      ioi_printf(0,"\n");
    }
    return( TRUE );
  }

  if( level==1 )                   /* One-liner of a single command */
  {
    ioi_printf(0,"%s",exe->name);
    if(exe->section)
      ioi_printf(0,"(%s)",exe->section);
    ioi_printf(0," %s\n",(exe->margv)? exe->margv[0] : "");
 
    return( TRUE );
  }

  if( level==2 )                   /* One-liner of all the commands */
  {
    char tmp[MAXNAM];              /* To form the name here first */

    /* Build a format string to have all printed equally wide */

    if(slen) slen += 2;
    sprintf(sfmt,"%%-%ds",slen);

    while( exe )
    {
      if(exe->call)
        if( section )
          if( exe->section && !strcmp(section,exe->section) )
          {
            ioi_printf(0,mfmt,exe->name);
            ioi_printf(0,"%s\n", (exe->margv)? exe->margv[0] : "");
          }
          else
            ;
        else
        {
          ioi_printf(0,mfmt,exe->name);
          ioi_printf(0,sfmt,(exe->section)? exe->section : "");
          ioi_printf(0,"%s\n", (exe->margv)? exe->margv[0] : "");
        }

      exe = (level==2)? exe->next : NULL;
    }

    if( mans )
    {
      exe = ioi_._exe;
      ioi_printf(0,"\nMANUALS\n\n");

      while( exe )
      {
        if( !exe->call )           /* And now only the manual pages */
          if( section )
            if( exe->section && !strcmp(section,exe->section) )
            {
              ioi_printf(0,mfmt,exe->name);
              ioi_printf(0,"%s\n", (exe->margv)? exe->margv[0] : "");
            }
            else
              ;
          else
          {
            ioi_printf(0,mfmt,exe->name);
            ioi_printf(0,sfmt,(exe->section)? exe->section : "");
            ioi_printf(0,"%s\n", (exe->margv)? exe->margv[0] : "");
          }
          exe = exe->next;
      }
    }

    return( TRUE );
  }

  while(exe)                       /* A full manual page */
  {
    char buff[MAXLEN];

    ioi_printf(0,"%s\n\n",ioi_man_title(buff,75,exe));

    if( FALSE )                    /* TEMP disable */
    {
      ioi_param *param = exe->options;

      while(param)                 /* Print short synopsis */
      {
        ioi_printf(0," -%s",param->name);
        param = param->next;
      }

      param = exe->parameters;

      while(param)
      {
        ioi_printf(0," %s",param->name);
        param = param->next;
      }
      ioi_printf(0,"\n");
    }
    else
    {
      if( exe->call )
      {
        ioi_printf(0,"    %s\n\n",exe->margv? exe->margv[0] : "");

        if(exe->options)
        {
          ioi_printf(0,"OPTIONS\n\n");
          ioi_exe_param_list(exe->options);
        }

        if(exe->parameters)
        {
          ioi_printf(0,"PARAMETERS\n\n");
          ioi_exe_param_list(exe->parameters);
        }

        if(exe->margv)
        {
          man = exe->margv;
          ioi_printf(0,"DESCRIPTION\n\n");
          for( i=1 ; i<exe->margc ; i++ )
            ioi_printf(0,"    %s\n",*++man);
        }
      }
      else
        for( man=exe->margv ; *man ; man++ )
          ioi_printf(0,"  %s\n",*man);
    }
    ioi_printf(0,"\n");

    exe = (level==4)? exe->next : NULL;
  }
  return( TRUE );
}

ioi_exe *ioi_exe_create(char *name, int (* call)(int, char**),
                        ioi_param *options, ioi_param *parameters, char **man)
/**************************************************************************
?  Create a new exe without adding it into the IOI.
*  CALL  rc = exe->call(argc,argv);
=  The new one created if successfull, NULL if not.
************************************o*************************************/
{
  ioi_exe *exe;
  char     tmp[MAXNAM];            /* Build the copies here */
  char    *s = tmp;                /* To catch the section */
  int      section = FALSE;

  strncpy(tmp,name,MAXNAM);
  tmp[MAXNAM-1]='\0';

  while( *s && ( *s != ':' ) ) s++;

  if( *s )                         /* Section found! */
  {
    *s++ = '\0';
    section = TRUE;
  }

  if( ! (exe=SALLOC(ioi_exe)) )
  {
    ioi_out(0,IOI_ERR,"IOI-EXE-ADD:No mem.");
    return 0;
  }

  exe->name     = strdup(tmp);
  if( section ) exe->section  = strdup(s);

  exe->call       = call;          /* If empty, don't care! */
  exe->options    = options;
  exe->parameters = parameters;
  exe->type       = IOI_L_EXE;
  exe->margv      = man;
  exe->margc      = ioi_exe_argc(man);

  return exe;
}

ioi_exe *ioi_exe_add(char *name, int (* call)(int, char**),
                     ioi_param *options, ioi_param  *parameters, char **man)
/**************************************************************************
?  Add a new exe into the IOI.
*  CALL  rc = exe->call(argc,argv);
=  The new one created if successfull, NULL if not.
************************************o*************************************/
{
  ioi_exe *exe;

  if( ! (exe=ioi_exe_create(name,call,options,parameters,man)) )
    return 0;

  if( ioi_list_get(IOI_L_EXE,exe->name,FALSE) )
  {
    ioi_out(0,IOI_ERR,"IOI-EXE-ADD:Multiple adds for %s",name);
    return 0;
  }

  ioi_list_add(exe->type,(ioi_gen*)exe);

  return exe;
}

int ioi_exe_delete(ioi_exe *exe)
/**************************************************************************
?  Remove the exe given. ( Called by ioi_list_delete() )
|  Empty the memory area.
*NA (under testin')
************************************o*************************************/
{
  int        i;

  IFFREE(exe->name);
  IFFREE(exe->section);

  for(i=0;i<2;i++)
  {
    ioi_param *param;

    param = i? exe->options : exe->parameters;
    while(param)
    {
      ioi_param *next = param->next;

      IFFREE( param->name );
      IFFREE( param->oname );
      ioi_exe_delete_argv(param->eargc,param->eargv);
      ioi_exe_delete_argv(param->margc,param->margv);

      free(param);
      param = next;
    }
  }

  ioi_exe_delete_argv(exe->margc,exe->margv);

/*
  ioi_out(0,IOI_ERR,"IOI-EXE-DELETE:Not implemented yet! %s",exe->name);
*/
  return FALSE;
}

void ioi_exe_def_param(ioi_param *param)
/**************************************************************************
?  Fill in the default value(s) for the parameter.
|  The default value can come from the address specified at the exe load
|  or from coupled variable if the variable has been set up.
************************************o*************************************/
{
  char *variable    = NULL;
  char *destination = (char *)param->value;
  char *source      = NULL;
  int   increment   = FALSE;       /* The source pointer? */
  int   dim         = param->dim;
  int   sz;

  int    i_source = FALSE;
  double d_source = 0.0;
  char  *s_source = NULL;
  char   c_source = '\0';

  switch(param->type)              /* Find out default source */
  {
    case IOI_L_BOOLEAN:
      sz = sizeof(int);
      source=(char *)(&i_source);
      break;
    case IOI_L_INTEGER:
      sz = sizeof(int);
      source=(char *)param->def;
      increment=TRUE;
      break;
    case IOI_L_ENUM:               /* Dim gotta be 1 */
      sz = sizeof(int);
      source=(param->def)?(char *)param->def : (char *)(&i_source);
      break;
    case IOI_L_DOUBLE:
      sz = sizeof(double);
      source=(char *)param->def;
      increment=TRUE;
      break;
    case IOI_L_STRING:
    case IOI_L_PATH:
      sz = sizeof(char *);
      source = (char *)(&s_source);
      break;
    case IOI_L_CHARACTER:
      dim=0;
      *destination = '\0';         /* Clear the string */
      break;
  }

  if( (variable=(char *)           /* Fill in the coupled value if found */
      ioi_variable_get(param->coupled)) )
    switch(param->type)
    {
      case IOI_L_BOOLEAN:
        i_source = atoi( variable );
        break;
      case IOI_L_INTEGER:
        i_source = atoi( variable );
        source=(char *)(&i_source);
        increment=FALSE;
        break;
      case IOI_L_ENUM:
        i_source = ioi_user_cmdf( variable,param->eargv,
                                  param->elens,param->eargc );
        if( i_source == (-1) ) i_source = 0; /* IOI_WAR? */
        source=(char *)(&i_source);
        break;
      case IOI_L_DOUBLE:
        d_source = atof(variable);
        source = (char *)(&d_source);
        increment = FALSE;
        break;
      case IOI_L_STRING:
      case IOI_L_PATH:
        /* memcpy( destination , &variable , sz ); */
        s_source = variable;
        break;
      case IOI_L_CHARACTER:
        strncpy( destination,variable,param->dim );
        break;
    }

  if( source )
    for( ; dim ; dim-- , destination += sz )
    {
      memcpy( destination , source , sz );
      if( increment ) source += sz;
    }
}

int ioi_exe_check_param(ioi_param *param)
/**************************************************************************
?  Check to see if the argument(s) already filled are valid for the
|  parameter.
=  TRUE if the values were ok, FALSE otherwise.
************************************o*************************************/
{
  int        dim     = param->dim;
  int       *i_value, *i_min, *i_max;
  double    *d_value, *d_min, *d_max;
  char     **path;

  if( !param ) return(0);

  i_value = (int *)param->value;
  d_value = (double *)param->value;

  i_min   = (int *)param->min;
  i_max   = (int *)param->max;

  d_min   = (double *)param->min;
  d_max   = (double *)param->max;

  path    = (char  **)param->value;

  switch( param->type )
  {
      case IOI_L_BOOLEAN:          /* Boolean are always OK! */
        break;
      case IOI_L_INTEGER:
        for( ; dim ; dim-- )
        {
          if( i_min && ( *i_value < *i_min ) )
            goto i_error;
          if( i_max && ( *i_value > *i_max ) )
            goto i_error;

          UP(i_min); UP(i_max); UP(i_value);
        }
        break;
      case IOI_L_ENUM:             /* Enum is checked at assignment */
        break;
      case IOI_L_DOUBLE:
        for( ; dim ; dim-- )
        {
          if( d_min && ( *d_value < *d_min ) )
            goto d_error;
          if( d_max && ( *d_value > *d_max ) )
            goto d_error;

          UP(d_min); UP(d_max); UP(d_value);
        }
        break;
      case IOI_L_CHARACTER:	   /* Strings are always OK! */
        break;
      case IOI_L_STRING:           /* Strings are always OK! */
        break;
      case IOI_L_PATH:
        if( !(*path = (char *)ioi_file_substitute(*path)) )
          if( param->must )
            return FALSE;
        break;
  }

  return(TRUE);

  i_error:
     return ioi_out(FALSE,IOI_ERR,
       "SYNTAX:Parameter (%s) out of range: (%d - %d) given %d ",
       param->name,i_min?*i_min:INT_MIN,i_max?*i_max:INT_MAX,*i_value);

  d_error:
     return ioi_out(FALSE,IOI_ERR,
       "SYNTAX:Parameter (%s) out of range: (%g - %g) given %g ",
       param->name,d_min?*d_min:-MINDOUBLE,d_max?*d_max:MAXDOUBLE,*d_value);
}

int ioi_exe_substitute(
    ioi_exe  *prg,                 /* If not NULL use this exe   */
    int       ac,                  /* With this number of params */
    char    **av)                  /* which are stored here      */
/**************************************************************************
?  Execute a IOI loaded program.
|
|  If the prg == NULL: (the AC and AV are ignored and can be omitted)
|
|  Check to see if the current command is in the exe-table.
|  If found:
|    The default values are updated.
|    The possible options are checked, an illegal option        => error.
|    The parameters are checked, a missing or a wrong parameter => error.
|    The procedure is executed.
|    FALSE is returned to indicate ioi.c to stop searching.
|  Otherwise a TRUE is returned. (And search in ioi.c continues!)
|
|  If the prg != NULL:
|
|  Just execute the prg given, unless there is a help request or an error
|  is detected.
=  TRUE if there was nothing to do. It wasn't for this module.
|  FALSE if the command was in the exe-table, even if it was never executed.
************************************o*************************************/
{
  char     **argv  = (prg)? av   :     ioi_._argv;
  int        argc  = (prg)? ac    :    ioi_._argc;
  ioi_exe   *exe   = (prg)? prg    :   ioi_._exe;
  int        found = (prg)? TRUE    :  FALSE;
  char      *name  = (prg)? argv[-1] : argv[0];

  ioi_param *param = NULL;         /* In scanning the options/parameters */

  char      *s;                    /* Current option character */
  int        options=TRUE;
  int        i;
  int        dim;
  int        must  = TRUE;         /* When looping the parameters */
  int       *i_value;
  double    *d_value;

  if( *name == '?' || (prg && argc && **argv == '?') )
  {
    int level=0;                   /* First number of '?'s */

    s = *argv++;
/*
 *  Maybe a man-command will be in order?
 *
 *  ?
 *  ? name     ?name
 *  ??         ? ?
 *  ?? name    ??name    ? ?name   ? ? name
 *  ???        ? ??      ?? ?      ? ? ?
 */

    if( prg )
      return ioi_exe_list(prg->name,3,NULL);

    while( *s == '?' && argc )
    {
      level++;
      s++;

      if( ! *s  )
        if( argc>1 )
        { argc--; s = *argv++; }
    }

   ioi_out(0,IOI_WAR,"syntax is changing, ? will be replaced by the man cmd");

   if( ! *s )
     if( argc>1 )
       s = *argv++;

    level--;

    if( level==0 )                 /* Very clear, eh? */
      if( *s )
        level=1;
        else ;
    else
      if(level==1) 
        level=(*s)?3:2;
       else level=4;
  
    ioi_variable_set_int("rc",ioi_exe_list(s,level,NULL));

    if( level ) return( FALSE );

    return level?FALSE:TRUE;
  }                                /* END OF MAN! */

  if( ! found )                    /* Exe's not added can be executed! */
  {                                /* even without the call-back       */
    if( *name == '/' )             /* Alias/function escape            */
      name++;

    /* exe = (ioi_exe *)ioi_list_get(IOI_L_EXE,name,FALSE); */
    exe = ls_findm( &ioi_._exe , name );

    if( (int)exe == LS_FIND_MULTIPLE )
      return ioi_out(FALSE,IOI_ERR,"SYNTAX:multiple matches for %s",name);

    if( !exe || !exe->call )       /* Jush a man page? */
      return( TRUE );              /* Not an exe, ioi.c goon! */

    argv++; argc--;                /* With prg the av[0] == 1.st param */
  }

  for( i=0 ; i<2 ; i++ )
    for(param=(i)? exe->parameters : exe->options ; param ; param=param->next)
      ioi_exe_def_param(param);

  if( exe->options && argc )
  {
    /* We like to give the options at least in the following ways:
     *
     * -x -y -z 10 -Z 10 20
     * -xy -z10 -Z10 20
     * -xyz10 -Z10 20
     *
     * So a boolean option may be followed by an other option
     * If an option has a param(s) first can be concatenated to the option
     */

    int opt_count = 0;

    ioi_._usedopt[0] = '\0';

    while(argc>0 && options && IS_OPTION(argv[0][0]) && !isdigit(argv[0][1]) )
    {
      s=argv[0]+1;                 /* The first option letter */

      if( ! *s )
        options = FALSE;
      else
        for( ; *s ; s++)           /* Well, option can be nested */
        {
          ioi_._usedopt[opt_count++] = *s;   /* Rem the options used so that */
          ioi_._usedopt[opt_count] = '\0';   /* the program can ask for them */

          param=exe->options;

          while( param && param->name[0] != *s )
             param=param->next;

          if( !param )
            return
              ioi_out(FALSE,IOI_ERR,
                      "SYNTAX:Illegal option: %c for %s",*s ,name);

          dim     = param->dim;
          i_value = (int *)param->value;
          d_value = (double *)param->value;
        
          if( param->type != IOI_L_BOOLEAN )
            if( ! s[1] )
              if( argc==1 )
                goto opt_missing;
              else
              { argc--; argv++; s=argv[0]; }
            else
              s++;
            
          switch( param->type )
          {
            case IOI_L_BOOLEAN:
              *i_value = TRUE;
              break;
            case IOI_L_INTEGER:
              for( ; dim ; dim--,argc--, s = *++argv )
                if( !argc ) goto opt_missing;
                else *i_value++ = atoi(s);
              break;
            case IOI_L_ENUM:
              *i_value=ioi_user_cmdf(s,param->eargv,param->elens,param->eargc);
              if( *i_value == (-1) )
                return
                  ioi_out(FALSE,IOI_ERR,
                          "SYNTAX:Illegal enum value: %s cmd %s optio %s",
                          s,name,param->name);
              break;
            case IOI_L_DOUBLE:
              for( ; dim ; dim--,argc--, s = *++argv )
                if( !argc ) goto opt_missing;
                else *d_value++ = atof(s);
              break;
            case IOI_L_CHARACTER:
              strncpy( param->value,s,dim );
              break;
            case IOI_L_STRING:
            case IOI_L_PATH:
              memcpy( param->value,&s,sizeof(char *) );
              break;
          }

          if( param->type != IOI_L_BOOLEAN )
            if( param->type==IOI_L_INTEGER || param->type==IOI_L_DOUBLE )
            {
              argc++; argv--; break; /* We updated them on too may */
            }
            else
              break;               /* Let's get out of the for(s.. */
        }

      argc--; argv++;              /* See above the update message! */
    }
  }                                /* End of option parsing */

  param = exe->parameters;

  while( param )
  {
    dim     = param->dim;
    if( param->type == IOI_L_CHARACTER ) dim=1;

    i_value = (int *)param->value;
    d_value = (double *)param->value;

    if( param->type==IOI_L_STRING  || param->type==IOI_L_PATH ) dim=1;

    if( param->must && argc<dim )
      return ioi_out(FALSE,IOI_ERR,
        "SYNTAX:Parameter %s missing for the command %s",param->name,name);

    if( dim<=argc )                 /* Otherwise they are not processed */
      switch( param->type )
      {
        case IOI_L_BOOLEAN:
          if( argc )
          {
            if( (*i_value=ioi_variable_flag(*argv++)) == NIL )
            return
                ioi_out(FALSE,IOI_ERR,
                        "SYNTAX:Illegal boolean value: %s cmd %s param %s",
                        *--argv,name,param->name);
            argc--;
          }
          break;
        case IOI_L_INTEGER:
          for( ; dim && argc ; dim--,argc-- )
            *i_value++ = atoi( *argv++ );
          break;
        case IOI_L_ENUM:
          if( argc )
          {
            *i_value = ioi_user_cmdf(*argv++,param->eargv,
                                     param->elens,param->eargc);
            if( *i_value == (-1) )
              return 
                ioi_out(FALSE,IOI_ERR,
                        "SYNTAX:Illegal enum value: %s cmd %s param %s",
                        *--argv,name,param->name);
            argc--;
          }
          break;
        case IOI_L_DOUBLE:
          for( ; dim && argc ; dim--,argc-- )
            *d_value++ = atof( *argv++ );
          break;
        case IOI_L_CHARACTER:
          if( argc )
          {
            strncpy( param->value,*argv++,param->dim );
            argc--;
          }
          break;
        case IOI_L_STRING:
        case IOI_L_PATH:
          if( argc ) 
          {
            memcpy( param->value,argv++,sizeof(char *) );
            argc--;
          }
          break;
      }
    param = param->next;
  }

  for( i=0 ; i<2 ; i++ )
    for(param=(i)? exe->parameters : exe->options ; param ; param=param->next)
      if( ! ioi_exe_check_param(param) )
        return( FALSE );

  if(exe->call) 
  {
    i = exe->call(argc,argv);
    ioi_variable_set_int("rc",i);
  }

  return( FALSE );

  opt_missing:
    return
      ioi_out(FALSE,IOI_ERR,"SYNTAX:Optarg missing: %c for %s",*s ,name);
}

char *ioi_exe_options(char *s)
/**************************************************************************
?  Return the options used as a character array. If "s" is NULL it is not
|  used, otherwise it is assumed to be long enough to hold the options
|  The max size is MAXNAM.
=  ioi_._usedopt or the users array if given.
************************************o*************************************/
{
  if( !s ) return ioi_._usedopt;

  strcpy(s,ioi_._usedopt);
  return s;
}

void ioi_execute(void)
/**************************************************************************
?  To permanently give the control to the IOI.
=  THIS NEVER RETURNS!
************************************o*************************************/
{
  int argc; char **argv;

  while( ioi_user_cmd(&argc,&argv) )
    if(argc)
      ioi_out(0,IOI_ERR,"SYNTAX:unknown command %s, (ignored)",*argv);

  if( ioi_._exit ) ioi_._exit( -1 );
  exit( 0 );
}
