/**************************************************************************
.TITLE    Input Output Interface
.NAME     MAN
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1992 / 27-MAR-1991 / OP
.VERSION  2.0
.FILE     man.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
*         You can place manual pages into the EXE module by defining
*         commands that have NULL as a function pointer.
*         Normally (but not necessarily) this also means that the options
*         and parameters are also NULL. If given, the actual values are
*         still never consulted, so it is possible to give a NULL as
*         an address.
.DATE     27-MAR-1995 / 27-MAR-1995 / OP
.VERSION  3.2
*         Dynamic linking added
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

char *ioi_man_title(char *buff, int len, ioi_exe *exe)
/**************************************************************************
?  Generate the title line for the manual page in the buffer given.
|  The format is  NAME(SECTION)  TITLE  NAME(SECTION).
|  If the section is defined and it fits into the line it is printed.
|  If the title fits into the line it is printed and the command name
|  is printed before and after the title. The title is center adjusted.
=  The buffer given.
************************************o*************************************/
{
  char *title;
  int   name_len, title_len, section_len;
  int   i;

  if( ! (title = (char *)ioi_variable_get("ioi_title")) )
    title = "Input Output Interface";

  name_len    = strlen(exe->name);
  title_len   = strlen(title);
  section_len = (exe->section)? strlen(exe->section)+2 : 0;

  if( 2*(name_len+section_len)+title_len+2 > len)
    section_len = 0;

  if( 2*(name_len+section_len)+title_len+2 <= len)
  {
    len -= 2*(name_len+section_len)+title_len;

    strcpy(buff,exe->name);
    if( section_len )
    {
      strcat(buff,"(");
      strcat(buff,exe->section);
      strcat(buff,")");
    }

    for(i=0 ; i<len/2 ; i++) strcat(buff," ");
    strcat(buff,title);
    for(i=0 ; i<(len+1)/2 ; i++) strcat(buff," ");

    strcat(buff,exe->name);
    if( section_len )
    {
      strcat(buff,"(");
      strcat(buff,exe->section);
      strcat(buff,")");
    }
  }
  else
    if(2*name_len < len)
    {
      len -= 2*name_len;

      strcpy(buff,exe->name);
      for(i=0 ; i<len ; i++) strcat(buff," ");
      strcat(buff,exe->name);
    }
    else
    {
      strncpy(buff,exe->name,len);
      buff[len-1] = '\0';
    }

  return buff;
}

int ioi_man_cmd(int argc, char **argv)
/**************************************************************************
?  The man command itself.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   all;
  static int   quick;
  static char *section;

  if( called )
  {
    if( dummy ) argc++,argv--;

    if( argc )
      while( argc-- )
        ioi_exe_list(*argv++,quick?1:3,NULL);
    else
      if( all && !quick && !section )
        ioi_exe_list(NULL,4,NULL);
      else
        ioi_exe_list(NULL,quick?2:0,section);
  }
  else
    ioi_exe_add("man:ioi",ioi_man_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "Process all the manual pages. This option is void if page",
            "names are given.",
            "If only the this option is given the full page of all the",
            "manual pages are given. (Lots of text!)",
            NULL
          ),NULL,1,&all
        ),
        ioi_exe_param(
          "-qquick",IOI_L_BOOLEAN,ioi_exe_argv(
            "Produce only a oneliner of the manual pages requested.",
            "If all is requested, only the commands are processed.",
            NULL
          ),NULL,1,&quick
        ),
        ioi_exe_param(
          "-ssection",IOI_L_STRING,ioi_exe_argv(
            "Give manual pages belonging to the section specified. This",
            "option works with the quick and all options but is void if",
            "page names are given.",
            NULL
          ),NULL,1,&section
        ),
        NULL
      ),
      ioi_exe_param(
        "pages",IOI_L_STRING,ioi_exe_argv(
          "The manual page names to be printed, if any. If names are given",
          "they override the all (a) and section (s) options",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
#include "man.h"
      )
    );

  return called = TRUE;
}

int ioi_man_manload(int argc, char **argv)
/**************************************************************************
?  Load the manual pages.
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    if( dummy ) { argc++,argv--; } /* Compulsory parameter! */

    if( !argc )
      if( ! ioi_man_read(NULL) )
        return FALSE;
      else ;
    else
      while( argc-- )
        if( ! (*argv = (char *)ioi_file_substitute(*argv)) )
          return FALSE;
        else
          if( ! ioi_man_read(*argv++) )
            return FALSE;

    return TRUE;                   /* This branch must end!!! */
  }
  else
  {
    ioi_exe_add("manload:ioi",ioi_man_manload,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_PATH,ioi_exe_argv(
            "The name(s) of the files containing manual page(s). If omitted",
            "stdin is read unless it's the control terminal.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Load a IOI-manual page into the system.",
        "Load will try to open the file name and interpret its contents",
        "to dynamically load manual pages into the IOI.",
        "",
        "In the startup of the IOI a default file is been loaded",
        "","EXAMPLE","",
        "IOI> manload << EOF",
        "> Pagename:local",
        ">   The onliner for the quick manpages.",
        ">   The rest of the text ...",
        "> EOF",
        "IOI> ",
        NULL
      )
    );

    ioi_alias_create(0,NULL);
    ioi_alias_delete(0,NULL);

    ioi_cmd_setenv(0,NULL);
    ioi_cmd_args(0,NULL);
    ioi_cmd_cat(0,NULL);
    ioi_cmd_cd(0,NULL);
    ioi_cmd_date(0,NULL);
    ioi_cmd_echo(0,NULL);
    ioi_cmd_exit(0,NULL);
    ioi_cmd_input(0,NULL);
    ioi_cmd_ioi(0,NULL);
    ioi_cmd_local(0,NULL);
    ioi_cmd_memcheck(0,NULL);
    ioi_cmd_sleep(0,NULL);
    ioi_cmd_time(0,NULL);

    ioi_file_close(0,NULL);

    ioi_function_create(0,NULL);
    ioi_function_delete(0,NULL);
    ioi_function_return(0,NULL);

    ioi_history_cmd(0,NULL);

    ioi_language_break(0,NULL);

    ioi_man_cmd(0,NULL);

    ioi_link_cmd(0,NULL);

    ioi_variable_delete(0,NULL);   /* Create was called by the _init */
    ioi_variable_shift(0,NULL);
  }

  return called = TRUE;
}

int ioi_man_add(char *name, ioi_token *token)
/**************************************************************************
?  Create a argv array out of the tokens.
|  The tokens are in reverse order!
************************************o*************************************/
{
  ioi_token *temp  = token;
  int        count = 0;
  char     **argv;

  while( temp )
    count++ , temp = temp->next;

  if( !count ) return FALSE;

  if( ! ( argv=(char **)ALLOC(sizeof(char *)*(count+1)) ) )
  {
    ioi_token_delete(token,TRUE);
    return ioi_out(FALSE,IOI_ERR,"IOI-MAN-ARGV:No mem.");
  }

  argv[count] = NULL;
  temp        = token;

  while( temp )
  {
    argv[--count] = temp->text;    /* Steel the string from the token */
    temp->text = NULL;
    temp = temp->next;
  }
  ioi_token_delete(token,TRUE);    /* Should remove the empty tokens */

  if( ioi_exe_add(name,NULL,NULL,NULL,argv) )
    return TRUE;

  while( argv[count] )
    { IFFREE(argv[count]) ; count++; }
  free(argv);

  return FALSE;
}

int ioi_man_read(char *name)
/**************************************************************************
?  Load the manual pages.
************************************o*************************************/
{
  ioi_token  *root = NULL,         /* To read the current man */
             *line = NULL;
  FILE       *fp;
  char        buff[MAXLEN];        /* Input buffer to read the file */
  char       *s;                   /* To scan the buffer */
  char       *cmd  = NULL;         /* The manual page name */
  int         len;
  int         ok=TRUE;

  if( !name )
    if(!ioi_._in)
      return ioi_out(0,IOI_ERR,"IOI-MAN-READ:Can't read stdin");
    else
      fp = stdin;
  else
    if( ! (fp=fopen(name,"r")) )
      return ioi_out(FALSE,IOI_ERR,"IOI-MAN-READ:Couldn't read file %s",name);

  /* if( ! (fp=fopen(name,"r")) ) */

  while( fgets(buff,MAXLEN,fp) && ok )
  {
    line = NULL;

    if( len = strlen( s = buff ) )
     if( buff[len-1] == '\n' )
       buff[--len] = '\0';

    switch( *s )
    {
      case '#' : break;             /* A comment */
      case '\0':
        if( !cmd ) break;           /* We are not building a man page */
        if( root )                  /* No empty lines in the beginning */
        {
          line = (ioi_token *)ioi_token_create("");
          line->next = root;
          root = line;
        }
        break;
      case ' ' :                    /* A line for the manual */
        if( !cmd ) break;
        line = (ioi_token *)ioi_token_create(++s);
        line->next = root;
        root = line;                /* In the reverse order */
        break;
      default:
        if( cmd )                   /* Lets get rid of the old one */
        {
          ok=ioi_man_add(cmd,root);
          root = line = NULL;
          cmd = NULL;
        }

        if( ! (cmd=strdup(s)) )
          ok=ioi_out(FALSE,IOI_ERR,"IOI-EXE-READ:No mem.");
    }
  }

  if( cmd ) ioi_man_add(cmd,root);
  IFFREE(cmd);

  if( name ) fclose(fp);

  return( ok );
}
