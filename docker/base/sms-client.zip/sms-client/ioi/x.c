#include <stdio.h>

main()
{
  long double x = 2;
  long double y = 3;
  int i;

  for(i=0; i<100; i++)
  {
    x = (x+y)/2.0;
    printf("iter %d %40.39Lg\n",i,x);
  }
}
