/**************************************************************************
.TITLE    Input Output Interface
.NAME     FUNCTION
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     30-MAR-1992 / 13-NOV-1990 / OP
.VERSION  2.1
.FILE     function.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*  The function in IOI could be described as an internal file. It is a
*  collection of lines containing characters. All lines are included as
*  they were typed, even the comments. This allows the functions to be
*  edited and stored back as they originally was defined.
*
*  The definition starts with the command define followed by the name
*  and opening curly barcet (rest of the command line is ignored.)
*  Then follows the text for the function followed by a line containing
*  just the closing bracet (rest of that line is also ignored.)
*
*  Example:
*
*  define small_status {
*    alias    # print out the alias-definitions
*    set      # print out teh variable-defs
*    history  # print out the last input lines
*  }
*
*  10-FEB-1991:
*
*  New definition for small functions allowing the single-liners.
*
*  NOTICE! The function substitution is carriend after alias substitution.
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

int ioi_function_create(int argc, char **argv)
/**************************************************************************
?  Define a function or print the contents of the functio.
************************************o*************************************/
{
  static int    called;
  static char  *dummy,*curly;
  static int    all;               /* List all the functions */

  ioi_token    *token,*last;
  ioi_function *function;

  char *name;
  char *s;                         /* Temp only */
  int   rc=FALSE;                  /* Return code, by default error */

  if( called )
  {
    if( dummy ) argc++,argv--;
    if( curly ) argc++,argv--;

    if( argc<1 && !all )           /* Print the names of all the functions */
      return ioi_list_print_all(IOI_L_FUNCTION,80);

    if( argc<2 )                   /* List the named function */
      return ioi_list_print(IOI_L_FUNCTION,all?NULL:*argv);

    name = *argv++; argc--;

    if( !strlen( name ) )
      return ioi_out(FALSE,IOI_ERR,"IOI-FUNCTION-CREATE:Null function name");

    if(function = (ioi_function *)ioi_list_get(IOI_L_FUNCTION,name,FALSE))
      if( function->in_use )
        return ioi_out(FALSE,IOI_ERR,"IOI-FUNCTION-CREATE:Function in use");

    if( argv[0][0] != '{' || argv[0][1] != '\0' )
      return ioi_out(FALSE,IOI_ERR,"IOI-FUNCTION-CREATE:Syntax error '{'");

    argv++; argc--;

    if( !(function=SALLOC(ioi_function)) )
      return ioi_out(0,IOI_ERR,"IOI-FUNCTION-CREATE-1:No mem.");

    if( !(function->name=strdup(name)) )
    {
      free( function );
      return ioi_out(0,IOI_ERR,"IOI-FUNCTION-CREATE-2:No mem.");
    }

    last = NULL;

    ioi_._in_def = TRUE;

    if(argc)                       /* Small function definition */
    {
      int len = 0;                 /* Count the buffer */
   
      s = ioi_._line;
      *s = '\0';

      while(argc-- >1)             /* Last gotta be '}' */
      {
        len += strlen(*argv);

        if(len > ioi_._lsize)
        {
          ioi_out(0,IOI_ERR,"IOI-FUNCTION-CREATE:Small def line too long.");
          goto error;
        }

        strcat(s,*argv);
        if(argc>1) strcat(s," ");
        s = ioi_._line+len;

        argv++;
      }

      if( strcmp(*argv,"}") )
        ioi_out(0,IOI_ERR,"IOI-FUNCTION-CREATE:Small def, expecting '}'");
      else
        if( function->lines = (ioi_token *)ioi_token_create(ioi_._line) )
          rc=TRUE;
        else
          ioi_out(0,IOI_ERR,"IOI-FUNCTION-CREATE:Small def, no mem.");
    }
    else
      while( rc=ioi_file_read(TRUE) )
      {
        s = ioi_._line;

        while( *s && IS_SPACE(*s) ) s++;
        if( *s == '}' )
          break;

        token = (ioi_token *)ioi_token_create(ioi_._line);

        if(!last)
          function->lines = last = token;
        else
          last->next = token;
    
        last = token;
      }

    error:

    if( !rc )                      /* Free the structure */
    {
      if(function->lines) ioi_token_delete(function->lines,TRUE);
      IFFREE(function->name);
      free(function);
      return( FALSE );
    }

    function->in_use = FALSE;
  
    ioi_._in_def = FALSE;
  
    ioi_list_add(IOI_L_FUNCTION,(ioi_gen *)function);
  }
  else
    ioi_exe_add("define:ioi",ioi_function_create,
      ioi_exe_link_param(
        ioi_exe_param("-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "To print out the definition of all the functions.",
            "This only effects the command without parameters.",
            NULL
          ),NULL,1,&all
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param("name",IOI_L_STRING,ioi_exe_argv(
           "The function name in question.",
           "The name must to start with a letter.",
           NULL
          ),NULL,1,&dummy
        ),
        ioi_exe_param("\"{\"",IOI_L_STRING,ioi_exe_argv(
            "The opening brace starts the definition of the function. To",
            "end the definition give a separate line starting with closing",
            "brace. See below for examples.",
            NULL
          ),NULL,1,&curly
        ),
        NULL
      ),
      ioi_exe_argv(
#include "function.h"
      )
    );

  return called=TRUE;
}

int ioi_function_delete(int argc, char **argv)
/**************************************************************************
?  Delete the function named
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    argc++,argv--;
    while( argc-- )
      ioi_list_delete(IOI_L_FUNCTION,*argv++);
  }
  else
    ioi_exe_add("undefine:ioi",ioi_function_delete,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param("functionname(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the function(s) to be removed.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
#include "undefine.h"
      )
   );

  return called=TRUE;
}

int ioi_function_check(void)
/**************************************************************************
?  Check the syntax of the function (?)
=  TRUE if substitution was ok,or there was nothin' to do.
|  FALSE otherwise.
|  NOTICE  At the moment this is obsolate
************************************o*************************************/
{
  ;   /* Donno! */
  return(TRUE);
}

int ioi_function_substitute(void)
/**************************************************************************
?  Substitute the first token if a function can be found.
=  TRUE if substitution was made
|  FALSE otherwise.
************************************o*************************************/
{
  ioi_function *function; 
  ioi_call     *call;
  char         *name;

  if( ! ioi_._argc ) return( FALSE );

  name = ioi_._argv[0];

  if( function=(ioi_function *)
      ioi_list_get(IOI_L_FUNCTION,name,FALSE) )
  {
    ioi_file_redirection_create();

    if(!(call=SALLOC(ioi_call)))
      return ioi_out(0,IOI_ERR,"IOI-FUNCTION-SUBSTITUTE:No mem. %s",name);

    call->next = ioi_._action;     /* Link the action stack */
    ioi_._action = (ioi_gen *) call;

    call->name = strdup(name);     /* Steal the name! */
    call->type = IOI_L_CALL;

    call->stack = ioi_._stack;
    ioi_._stack = NULL;            /* Rem the stack! */

    call->function = function;
    call->ifile    = function->lines;
    function->in_use++;

    /* Move arg(s) into tokens to be positional parameters and delete old */

    call->params = (ioi_token *)ioi_token_build(ioi_._argc,ioi_._argv);
    ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,TRUE);

    return( TRUE );
  }

  return( FALSE );
}

int ioi_function_execute(char *name, double *arg)
/**************************************************************************
?  Execute the user function named, if found, with the argument given
|  and return the value of the function (must be in the $rc)
=  TRUE if the function was found and return was ok
|  FALSE otherwise.
************************************o*************************************/
{
  ioi_function *function; 
  ioi_call     *call;

  if( function=(ioi_function *)
      ioi_list_get(IOI_L_FUNCTION,name,FALSE) )
  {
    char carg[MAXNAM];

    ioi_file_redirection_create(); /* ??? */

    if(!(call=SALLOC(ioi_call)))
      return ioi_out(0,IOI_ERR,"IOI-FUNCTION-EXECUTE:No mem. %s",name);

    call->next = ioi_._action;     /* Link the action stack */
    ioi_._action = (ioi_gen *) call;

    call->name = strdup(name);     /* Steal the name! */
    call->type = IOI_L_CALL;

    call->stack = ioi_._stack;
    ioi_._stack = NULL;            /* Rem the stack! */

    call->function = function;
    call->ifile    = function->lines;
    function->in_use++;

    /* Build the one and only argument */

    sprintf(carg,"%g",*arg);

    call->params = (ioi_token *)ioi_token_create(carg);

    ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,TRUE);

    return( TRUE );
  }

  return( FALSE );
}

int ioi_function_return(int argc, char **argv)
/**************************************************************************
?  Terminate execution of the function
=  return code given (or -1 for error)
!  This should loop for the IOI_L_FUNCTION and remove from the stack
|  everything above it.
|  At the moment, just remove the function if it's the first in the stack.
************************************o*************************************/
{
  static int    called;
  static int    rc,imin=0,idef=TRUE;

  if( called )
  {
    if( argc<0 ) rc = TRUE;        /* Called from file.c or the handler */

    if( ioi_action_is_there(IOI_L_CALL) )
    {
      ioi_call   *call;

      while( ioi_._action->type != IOI_L_CALL )
        ioi_action_break();

      call = (ioi_call *)ioi_._action;

      call->function->in_use--;
      ioi_._action = call->next;
      ioi_._stack  = call->stack;

      ioi_token_delete(call->params,TRUE);
      if(call->local) ioi_variable_pop(call->local);

      IFFREE(call->name);
      free(call);

      if( argc>0 && argv ) ioi_variable_set("rc",*argv);

      return( rc );
    }

   /*
    * This should have been prepared by the action handler
    */
    return
      ioi_out(-1,IOI_WAR,"IOI-FUNCTION-RETURN:Not executing a function");
  }
  else
    ioi_exe_add("return:ioi",ioi_function_return,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param("code",IOI_L_INTEGER,ioi_exe_argv(
            "The return code placed into the IOI-variable rc.",
            NULL
          ),NULL,1,&rc,&imin,NULL,&idef
        ),
        NULL
      ),
      ioi_exe_argv(
        "Return from the function.",
        "This is used to return from the user functions. The default",
        "action in the end of the function is return 1. Use this to",
        "specify other return code or to terminate in the middle of",
        "the function.",
        NULL
      )
    );

  return called=TRUE;
}
