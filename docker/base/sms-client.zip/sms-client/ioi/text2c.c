/**************************************************************************
.TITLE    Utility Package Functions
.NAME     text2c
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     16-SEP-1993 / 18-JUL-1991 / OP
.VERSION  1.1
.DATE     11-FEB-1998 / OP
.VERSION  1.2
.FILE     text2c
.USAGE    text2c file.h   [file2.h   ...]
|         reads: file.txt  file2.txt ...
.SYNOPSIS Convert ascii file to C-language strings.
|         The output file (*.h) can then be included into C-code
|
|         Lines in *.txt file are read and replaced with double quotes
|         and comma in the end of the line.
|
|         A line starting with "*" is ignored in output.
|
|         A line with NULL is added in the end of the file.
*
*  compile: cc -o text2c text2c.c
************************************o*************************************/

#include <stdio.h>

/**************************************************************************
.TITLE   Utility Library Functions
.NAME    NONE
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    06-SEP-1991 / 09-DEC-1989 / OP
.VERSION 1.0
.FILE    strext.c
************************************o*************************************/

char *strext(new,old,ext)
/**/char *new;                 /* New name with the ext */
/**/char *old;                 /* Name to be derivated */
/**/char *ext;                 /* Extension to be added */
/**************************************************************************
?  Add the file-extension to the OLD name by removing the old extension
|  Extension starts from the last dot "." found in the OLD and is
|  replaced by EXT.
|  If the dot cann't be found, a dot and EXT is added to the OLD.
|
|  The strings given must be null terminated and NEW must be large
|  enough to hold the new name.
=  *new
************************************o*************************************/
{
  int i;
  int dot=0;                       /* Flag was the dot found? */

  i=strlen(old);

  while(!dot && i) if(old[--i] == '.') dot=1;

  if(!dot) i=strlen(old);

  strncpy(new,old,i);
  new[i]='.';
  new[i+1]='\0';
  strcat(new,ext);      
  return(new);
}

#define MAXLINE 1024

main(argc,argv) int argc; char **argv;
{
  FILE *fp,*gp;

  char  line[MAXLINE];             /* Just be big enough */
  char  name[MAXLINE];
  char *s;

  while( --argc )
    if( fp=fopen(strext(name,*++argv,"txt"),"r") )
    {
      if( gp=fopen(*argv,"w") )
      {
        while( fgets(line,MAXLINE,fp) )
          if( line[0] != '*' )
          {
            putc('"',gp);

            for( s=line ; *s && *s != '\n' ; s++ )
            {
              if( *s=='\\' || *s=='"' )
                putc( '\\',gp );
              putc( *s,gp );
            }
      
            putc('"',gp);
            putc(',',gp);
            putc('\n',gp);
          }

        fprintf(gp,"NULL\n");
        fclose(gp);
      }
      else
        fprintf(stderr,"couldn't open %s for writing\n",name);
      fclose(fp);
    }
    else
      fprintf(stderr,"couldn't open %s for reading\n",argv[0]);

  exit(0);
}

