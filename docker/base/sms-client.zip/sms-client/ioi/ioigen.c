/**************************************************************************
.TITLE    Input Output Interface
.NAME     ioigen
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     29-NOV-1991 / 15-JUL-1991 / OP
.VERSION  2.0
*  Never  ready in version 2.0
.DATE     12-NOV-1993 / 26-OCT-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
*  First  working version
*  Output is ANSI-C
.FILE     ioigen.c
.DATE     20-OCT-1998 / 20-OCT-1998 / OP
.VERSION  3.3
*         With prototypes
*
*  The ioigen is meant to be run as a filter.
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#define D(x)    fprintf(stderr,"TRAP %d\n",(x))

/**************************************************************************
*  typedefs for the IOIGEN.
************************************o*************************************/

typedef struct _igen_param {
  int                  type;       /* === GEN === */
  char                *name;       /* !see above! */
  struct _igen_param  *next;       /* !see above! */
  char                *oname;      /* Character name of the option       */
  char                *value;      /* Pointer to the value(s) (type def!) */
  char                *def;        /* Default value(s) (address('s))       */
  char                *min,*max;   /* Limits for the value(s) if applicable */
  int                  dim;        /* Number of values in this parameter     */
  int                  must;       /* Is't necessary for this param to exist */
  ls_gen              *man;
  char                *coupled;    /* Parameter is coupled with variable */
} igen_param;

typedef struct _igen_exe {
  int                  type;       /* Always 0 */
  char                *name;       /* name of the command */
  struct _igen_exe    *next;       /* LS-GEN stuff */
  char                *call;       /* Function to call with params     */
  igen_param          *options;    /* If any (use one letter ones)     */
  igen_param          *parameters; /* If any (extra can be supplied)   */
  ls_gen              *man;
  ls_gen              *code;
} igen_exe;

/**************************************************************************
*  .
************************************o*************************************/

#define IGEN_L_BOOLEAN    0        /* Different parameter types           */
#define IGEN_L_INTEGER    1        /* These must be in alphabetical orded */
#define IGEN_L_DOUBLE     2        /* and the boolean to be the first one */
#define IGEN_L_CHARACTER  3
#define IGEN_L_STRING     4
#define IGEN_L_ENUM       5
#define IGEN_L_PATH       6

char *igen_types[] = {
  "IOI_L_BOOLEAN",
  "IOI_L_INTEGER",
  "IOI_L_DOUBLE",
  "IOI_L_CHARACTER",
  "IOI_L_STRING",
  "IOI_L_ENUM",
  "IOI_L_PATH",
  NULL
};

char *igen_names[] = {
  "boolean",
  "integer",
  "double",
  "character",
  "string",
  "enum",
  "path",
  NULL
};

char *igen_ctypes[] = {
  "int    ",
  "int    ",
  "double ",
  "char   ",
  "char  *",
  "int    ",
  "char  *",
  NULL
};

static igen_exe    *root;
static int          line_no;

static igen_exe    *last_cmd;      /* These are kept for the manual pages */
static igen_param  *last_param;
static igen_param  *last_option;

static char        *generate_loader;
static ls_gen      *ioi_files;

static int          preprocess;    /* Add some preprocessor symbols */

static char *cplusplus = 0;        /* Generate CC-class */

/**************************************************************************
.TITLE   Utility Library Functions
.NAME    NONE
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    06-SEP-1991 / 09-DEC-1989 / OP
.VERSION 1.0
.FILE    strext.c
************************************o*************************************/

char *strext(
          char *new,               /* New name with the ext */
    const char *old,               /* Name to be derivated */
    const char *ext)               /* Extension to be added */
/**************************************************************************
?  Add the file-extension to the OLD name by removing the old extension
|  Extension starts from the last dot "." found in the OLD and is
|  replaced by EXT.
|  If the dot cann't be found, a dot and EXT is added to the OLD.
|
|  The strings given must be null terminated and NEW must be large
|  enough to hold the new name.
=  *new
************************************o*************************************/
{
  int i;
  int dot=0;                   /* Flag was the dot found? */

  i=strlen(old);

  while(!dot && i && ! old[i-1]!='/') if(old[--i] == '.') dot=1;

  if(!dot) i=strlen(old);

  strncpy(new,old,i);
  new[i]='.';
  new[i+1]='\0';
  strcat(new,ext);
  return(new);
}

static void error(int code)
{
  fprintf(stderr,"ioigen:exiting on line %d\n",line_no);

  exit(code);
}

static getit(char *buff, int maxlen)
/**************************************************************************
*  A simple input routine for the IOI. Normally you want to display your
*  own prompt in this routine, so the IOI should be advised not to prompt.
************************************o*************************************/
{
  int rc;
  int len;

  extern int spit(int);

  rc = fgets(buff,maxlen,stdin) != NULL;

  if( !rc ) 
  {
    char newname[MAXLEN];

    fclose(stdout);

    if(ioi_files && ioi_files->next)
      fprintf(stderr,"%s\n",strext(newname,ioi_files->name,
              cplusplus? "cc" : "c"));

    if( ! fopen(strext(newname,ioi_files->name,
              cplusplus? "cc" : "c"),"w") )
      error( ioi_out(1,IOI_ERR,"ioigen:can not open file %s",newname) );
    spit(-1);

    fclose(stdout);

    fclose(stdin);

    ioi_files = ioi_files->next;
    if( !ioi_files ) exit(0);

    fprintf(stderr,"%s:\n",ioi_files->name);
    fflush(stderr);

    if(!fopen(ioi_files->name,"r"))
      error(ioi_out(1,IOI_ERR,"ioigen:can not open file %s",*ioi_files->name));

    clear_cmd(0,NULL);

    rc = fgets(buff,maxlen,stdin) != NULL;
  }

  line_no++;

  len=strlen(buff);

  if(len && buff[len-1] == '\n') buff[--len] = '\0';

  return rc;
}

read_lines(ls_gen **root, char *filename, char *terminate, int indent)
/**************************************************************************
?  Read following lines until
************************************o*************************************/
{
  FILE  *fp = stdin;
  char   text[MAXLEN];
  int    len;

  if( !filename || !*filename || (*filename=='-' && !filename[1]) )
  {
    if( !ioi_._in && (!terminate || !*terminate) )
      return ioi_out(0,IOI_ERR,"read-lines:Can't cat stdin");
  }
  else
    if( ! (fp=fopen(filename,"r")) )
      return ioi_out(0,IOI_ERR,"read-lines:cann't open file %s",filename);

  while( (fp==stdin)? ioi_file_read(0) : fgets(text,MAXLEN,fp)!=NULL )
  {
    if(fp==stdin)
      strcpy(text,ioi_._line);

    len=strlen(text);

    if(len && text[len-1] == '\n') text[--len] = '\0';

    if(terminate)
      if( strncmp(text,terminate,strlen(terminate)) == 0 )
      {
        if(fp != stdin) fclose(fp);
        return TRUE;
      }

    if(indent && strlen(text)>=indent) 
      strcpy(text,&text[indent]);

    ls_add(root,ls_create(0,text));
  }

  if(fp != stdin) fclose(fp);

  return TRUE;
}

void man_add(ls_gen *start)
/**************************************************************************
?  Add the manual to the right place
************************************o*************************************/
{
  if(last_param && ! last_param->man)
    last_param->man = start;
  else if(!last_param && last_option && ! last_option->man)
    last_option->man = start;
  else if(last_cmd && !last_cmd->man)
    last_cmd->man = start;
  else
    error( ioi_out(1,IOI_ERR,"manual:donno where to put the manual?") );
}

void man_create(char *filename, char *terminate, int indent)
{
  ls_gen *start = NULL;

  read_lines(&start,filename,terminate,indent);
  man_add(start);
}

#define INDENT(f,x) { int i; for(i=0;i<(x);i++) putc(' ',(f)); }

void man_print(FILE *fp,int indent, ls_gen *lp)
/**************************************************************************
?  Print the C-code out of the man page.
************************************o*************************************/
{
  char *s;
  int   i;

  if(!lp)
  {
    printf("NULL");
    return;
  }

  printf("ioi_exe_argv(\n");

  for( ; lp ; lp = lp->next )
  {
    s = lp->name;
    if( *s != '*' )
    {
      INDENT(fp,indent);
      putc('"',fp);

      for( s=lp->name ; *s && *s != '\n' ; s++ )
      {
        if( *s=='\\' || *s=='"' )
          putc( '\\',fp );
        putc( *s,fp );
      }

      fprintf(fp,"\",\n");
    }
  }

  INDENT(fp,indent);
  fprintf(fp,"NULL)");
}

void static_print(FILE *fp, igen_param *pp)
/**************************************************************************
?  Print the C-code for a static declaration for a parameter
************************************o*************************************/
{
  int dim = pp->dim;

  fprintf(fp,"  static %s%s",igen_ctypes[pp->type],pp->name);
  if(dim>1) fprintf(fp,"[%d]",dim);
  fprintf(fp,";\n");

  if(pp->type == IGEN_L_ENUM)
  {
    if( pp->min[0] == '[' )
    {
      char   *s    = strdup(&(pp->min[1]));       /* Zap [           */
      ls_gen *root = NULL;
      ls_gen *lp;

      s[strlen(s)-1] = '\0';                      /* Zap the other ] */

      ls_parse(&root,s,',');

      fprintf(fp,"  static char *%s_ascii[] = {",pp->name);

      for( lp=root ; lp ; lp=lp->next )
        fprintf(fp,"\"%s\",", lp->name );

      fprintf(fp,"NULL};\n");
      ls_delall(&root);
      free(s);
    }
    else if( pp->min[0] == '{' )
      fprintf(fp,"  static char *%s_ascii[] = %s;\n",pp->name,pp->min);
    else
      fprintf(fp,"  static char **%s_ascii = %s;\n",pp->name,pp->min);
  }
  else
  {
    if(pp->min && pp->min[0])
    {
      fprintf(fp,"  static %s%s_min",igen_ctypes[pp->type],pp->name);
      if(dim>1) fprintf(fp,"[%d]",dim);
      fprintf(fp," = %s;\n",pp->min);
    }

    if(pp->max && pp->max[0])
    {
      fprintf(fp,"  static %s%s_max",igen_ctypes[pp->type],pp->name);
      if(dim>1) fprintf(fp,"[%d]",dim);
      fprintf(fp," = %s;\n",pp->max);
    }
  }

    if(pp->def && pp->def[0])
    {
      fprintf(fp,"  static %s%s_def",igen_ctypes[pp->type],pp->name);
      if(dim>1) fprintf(fp,"[%d]",dim);
      fprintf(fp," = %s;\n",pp->def);
    }
}

void param_print(FILE *fp, igen_param *pp)
/**************************************************************************
?  Print the C-code for a parameter/option creation.
************************************o*************************************/
{
  fprintf(fp,"        ioi_exe_param(\n");

  fprintf(fp,"          \"%s%s%s\",",
          pp->oname?"-":"",pp->oname?pp->oname:"",pp->name);

  fprintf(fp,"%s,",igen_types[pp->type]);

  man_print(fp,12,pp->man);

  fprintf(fp,",\n");

  INDENT(fp,10);

  if(pp->coupled) fprintf(fp,"\"%s\",",pp->coupled);
  else            fprintf(fp,"NULL,");

  fprintf(fp,"%s%d,",(pp->must)?"-":"",pp->dim);

  fprintf(fp,"%s%s",(pp->dim==1)?"&":"",pp->name);

  if( pp->type == IGEN_L_INTEGER || pp->type == IGEN_L_DOUBLE )
  {
    if(pp->min && pp->min[0])
      fprintf(fp,",%c%s_min",(pp->dim==1)?'&':' ' , pp->name);
    else
      fprintf(fp,",NULL");

    if(pp->max && pp->max[0])
      fprintf(fp,",%c%s_max",(pp->dim==1)?'&':' ' , pp->name);
    else
      fprintf(fp,",NULL");

    if(pp->def && pp->def[0])
      fprintf(fp,",%c%s_def",(pp->dim==1)?'&':' ' , pp->name);
    else
      fprintf(fp,",NULL");

  }

  if(pp->type == IGEN_L_ENUM)
  {
    fprintf(fp,",%s_ascii",pp->name);

    if(pp->def && pp->def[0]) fprintf(fp,",&%s_def", pp->name);
    else                      fprintf(fp,",NULL");
  }

  fprintf(fp,"\n");

  INDENT(fp,8);
  fprintf(fp,"),\n");
}

void print_exe(FILE *fp, igen_exe *exe)
/**************************************************************************
?  Print the C-code out of the current executable (endcommand)
************************************o*************************************/
{
  igen_param *pp;
  ls_gen    *lp;
  int        i;

  if( !exe ) return;

  if( !exe->call )                 /* This is user code, copy out */
  {
    for( lp=exe->code ; lp ;  lp=lp->next )
      fprintf(fp,"%s\n",lp->name);

    return;
  }

  if( preprocess )                /* Add pre-processor symbols */
  {
    fprintf(fp,"#undef  COMMAND_NAME\n");
    fprintf(fp,"#define COMMAND_NAME \"%s\"\n",exe->name);
    fprintf(fp,"\n");
    fprintf(fp,"#undef  FUNCTION_NAME\n");
    fprintf(fp,"#define FUNCTION_NAME \"%s\"\n",exe->call);
    fprintf(fp,"\n");
  }

  if(cplusplus)
    fprintf(fp,"static ");

  fprintf(fp,"%sint %s(int argc, char **argv)\n",
          generate_loader? "static " : "" , exe->call);

  fprintf(fp,"{\n");
  fprintf(fp,"  static int called=0;\n");
  fprintf(fp,"\n"); 

  for( pp=exe->options ; pp ; pp=pp->next )
    static_print(fp,pp);

  if( exe->options ) 
    fprintf(fp,"\n");

  for( pp=exe->parameters ; pp ; pp=pp->next )
    static_print(fp,pp);

  if( exe->parameters ) 
    fprintf(fp,"\n");

  fprintf(fp,"  if(called)\n");
  fprintf(fp,"  {\n");

  for( lp=exe->code ; lp ;  lp=lp->next )
    fprintf(fp,"  %s\n",lp->name);

  fprintf(fp,"  }\n");
  fprintf(fp,"  else\n");
  fprintf(fp,"    ioi_exe_add(\"%s\",%s,\n", exe->name , exe->call );

  for( i=0 ; i<2 ; i++ )
  {
    pp = i? exe->parameters : exe->options;

    if(pp)
    {
      fprintf(fp,"      ioi_exe_link_param(\n");

      while( pp )
      {
        param_print(fp,pp);
        pp = pp->next;
      }
      fprintf(fp,"        NULL\n");
      fprintf(fp,"      ),\n");
    }
    else
      fprintf(fp,"      NULL,\n");
  }

  INDENT(fp,6);
  man_print(fp,8,exe->man);

  fprintf(fp,"\n    );\n");
  fprintf(fp,"\n");
  fprintf(fp,"  return called=1;\n");
  fprintf(fp,"}\n\n");

  if(cplusplus)
  {
    fprintf(fp,"class %s {\n",cplusplus);
    fprintf(fp,"public:\n");
    fprintf(fp,"  %s () { %s(0,0); } \n",cplusplus,exe->call);
    fprintf(fp,"};\n");
    fprintf(fp,"\n");
    fprintf(fp,"static %s %s_instance;\n",cplusplus,cplusplus);
    fprintf(fp,"\n");
  }
}

void write_loads(FILE *fp, igen_exe *ep, char *name)
/**************************************************************************
?  Write a loader function
+  load:ioigen
************************************o*************************************/
{
  fprintf(fp,"void %s(void)\n",name);
  fprintf(fp,"{\n");

  for( ; ep ; ep=ep->next )
    if( ep->call )
      fprintf(fp,"  %s(0,(void *)0)\n",ep->call);

  fprintf(fp,"}\n");
  fprintf(fp,"\n");
}

int spit(int code)
/**************************************************************************
?  Generate the code from the tree structure.
=  On errors (code != 0) just exit.
************************************o*************************************/
{
  igen_exe *ep = root;

  if( code > 1 )
    exit( code );

  printf("/*\n");
  printf(" * This code was generated by ioigen(IOI)\n");
  printf(" *\n");
  printf(" * Please do NOT edit this file, edit the original\n");
  printf(" */\n");
  printf(" \n");
  if(cplusplus) printf("extern \"C\" { \n");
  printf("#include \"ioi.h\"\n");
  if(cplusplus) printf("}\n");
  printf(" \n");

  while(ep)
  {
    printf("\n");
    print_exe(stdout,ep);
    ep=ep->next;
  }

  if( generate_loader )
    write_loads(stdout,root,generate_loader);

  if(code==0)
    exit(0);

  return 0;
}

command_cmd(int argc, char **argv)
{
  static int   called;

  static char *terminate;
  static int   indent,indent_min=0,indent_max=80,indent_def=0;

  static char *name,*cfun;

  if( called )
  {
    igen_exe *ep;
    igen_exe *ip = (igen_exe *)calloc(sizeof(igen_exe),1);

    if( ls_find(&root,name) )
      error(ioi_out(1,IOI_ERR,"command:duplicate name, IOI doesn't like em"));

    for( ep=root ; ep ; ep=ep->next )
      if(ep->call && strcmp(ep->call,cfun)==0)
        error(ioi_out(1,IOI_ERR,
              "command:duplicate call, C-compiler doesn't like em"));

    ip->name = strdup(name);
    ip->call = strdup(cfun);

    ls_add(&root,ip);

    last_cmd    = ip;
    last_param  = NULL;
    last_option = NULL;

    if(terminate) man_create(NULL,terminate,indent);
  }
  else
    ioi_exe_add("command:ioigen",command_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-iindent",IOI_L_INTEGER,ioi_exe_argv(
            "Remove this many characters form the input on every line",
            NULL
          ),"indentation",1,&indent,&indent_min,&indent_max,&indent_def
        ),
        ioi_exe_param(
          "-tterminate",IOI_L_STRING,ioi_exe_argv(
            "Stop reading when a line starting with this token is read.",
            NULL
          ),"terminator",1,&terminate
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param("name",IOI_L_STRING,
          ioi_exe_argv(
            "The name of the command for the user when executing IOI.",
            "The section name is concatenated into the name in format:",
            "command:section",
            NULL
          ),
          NULL,-1,&name
        ),
        ioi_exe_param("routine",IOI_L_STRING,
          ioi_exe_argv(
            "The C-routine name to be called to execute the command name.",
            "The call is of format:",
            "  int routine(int argc, char **argv)",
            "Where the values of the argv are valid only for the call time.",
            "That is to use them later on they must be duplicated.",
            NULL
          ),
          NULL,-1,&cfun
        ),
        NULL
      ),
      ioi_exe_argv(
        "Start the definition of a new command.",
        "Command can have options parameters and manual page.",
        NULL
      )
    );

  return called=TRUE;
}

option_cmd(int argc, char **argv)
{
  static int    called;

  static char   letter[3];         /* Option letter to be used */
  static char  *ioivar;            /* Follow IOI-variable name */
  static char *terminate;
  static int   indent,indent_min=0,indent_max=80,indent_def=0;

  static char  *name;
  static int    type,type_def=0;
  static int    dim,dim_min=1,dim_def=1,dim_max=99999;
  static char  *defs,*mins,*maxs,*enums;

  if( called )
  {
    igen_param *op = (igen_param *)calloc(sizeof(igen_param),1);

    if(!last_cmd)
      error( ioi_out(1,IOI_ERR,"option:must have command definition first") );

    if( ! (letter[0]>='a' && letter[0]<='z') &&
        ! (letter[0]>='A' && letter[0]<='Z') )
    error(ioi_out(1,IOI_ERR,"option:letter %c is not valid option",letter[0]));

    if( ls_find(&(root->options),name) || ls_find(&(root->parameters),name) )
      error(ioi_out(1,IOI_ERR,
            "option:duplicate name, C-compiler doesn't like em"));

    op->type  = type;
    op->name  = strdup(name);
    op->oname = strdup(letter);
    op->dim   = dim;

    if(ioivar) op->coupled = strdup(ioivar);
    if(defs)   op->def     = strdup(defs);
    if(mins)   op->min     = strdup(mins);
    if(maxs)   op->max     = strdup(maxs);

    ls_add(&(last_cmd->options),op);

    last_option = op;

    if(type==IGEN_L_ENUM)
      if( !mins )
        error( ioi_out(1,IOI_ERR,"option:enum must have the list") );

    if(terminate) man_create(NULL,terminate,indent);
  }
  else
    ioi_exe_add("option:ioigen",option_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ddim",IOI_L_INTEGER,ioi_exe_argv(
            "The dimension of the option.",
            "Ignored if type is STRING or ENUM",
            NULL
          ),NULL,1,&dim,&dim_min,&dim_max,&dim_def
        ),
        ioi_exe_param(
          "-iindent",IOI_L_INTEGER,ioi_exe_argv(
            "Remove this many characters form the input on every line",
            "Characters are removed, what's out if using TABs.",
            NULL
          ),"indentation",1,&indent,&indent_min,&indent_max,&indent_def
        ),
        ioi_exe_param(
          "-tterminate",IOI_L_STRING,ioi_exe_argv(
            "Stop reading when a line starting with this token is read.",
            NULL
          ),"terminator",1,&terminate
        ),
        ioi_exe_param(
          "-vioivar",IOI_L_STRING,ioi_exe_argv(
            "IOI-variable name that is a default for this option",
            "The option follows the variable unless an option is used.",
            NULL
          ),NULL,1,&ioivar
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param("letter",IOI_L_CHARACTER,
          ioi_exe_argv( "The option letter [a-z][A-Z].", NULL),
          NULL,-2,letter
        ),
        ioi_exe_param("name",IOI_L_STRING,ioi_exe_argv(
            "The name of the option. both in manual page and in C-code",
            "If option has default/min/max there C-code name will be the",
            "same but _def/_min/_max appended respectively.",
            NULL
          ),NULL,-1,&name
        ),
        ioi_exe_param("type",IOI_L_ENUM,
          ioi_exe_argv( "The IOI-type of the option", NULL),
          NULL,-1,&type,igen_names,NULL
        ),
        ioi_exe_param("def(s)",IOI_L_STRING,
          ioi_exe_argv( "The default values for this option", NULL),
          NULL,1,&defs
        ),
        ioi_exe_param("min(s)",IOI_L_STRING,ioi_exe_argv(
            "The minimum values for this option",
            "For enumbered option this is the list of possible values in ascii",
            NULL
          ), NULL,1,&mins
        ),
        ioi_exe_param("max(s)",IOI_L_STRING,
          ioi_exe_argv( "The maximum values for this parameter", NULL),
          NULL,1,&maxs
        ),
        NULL
      ),
      ioi_exe_argv(
        "Start the definition of a new option.",
        NULL
      )
    );

  return called=TRUE;
}

param_cmd(int argc, char **argv)
{
  static int    called;

  static int    compulsory;
  static char  *ioivar;            /* Follow IOI-variable name */
  static char *terminate;
  static int   indent,indent_min=0,indent_max=80,indent_def=0;

  static char  *name;
  static int    dim,dim_min=1,dim_def=1,dim_max=99999;
  static int    type,type_def=0;
  static char  *defs,*mins,*maxs,*enums;

  if( called )
  {
    igen_param *pp = (igen_param *)calloc(sizeof(igen_param),1);

    if(!last_cmd)
      error( ioi_out(1,IOI_ERR,"param:must have command definition first") );

    if( last_param )
      if( ! last_param->must && compulsory )
        error(ioi_out(1,IOI_ERR,"param:compulsory parameters must be first"));

    if( ls_find(&(last_cmd->options),name) || 
        ls_find(&(last_cmd->parameters),name) )
      error(ioi_out(1,IOI_ERR,
            "param:duplicate name, C-compiler doesn't like em"));

    pp->must = compulsory;
    pp->type = type;
    pp->name = strdup(name);
    pp->dim  = dim;

    if(ioivar) pp->coupled = strdup(ioivar);
    if(defs)   pp->def     = strdup(defs);
    if(mins)   pp->min     = strdup(mins);
    if(maxs)   pp->max     = strdup(maxs);

    ls_add(&(last_cmd->parameters),pp);

    last_param = pp;

    if(type==IGEN_L_ENUM)
      if( !mins )
        error( ioi_out(1,IOI_ERR,"param:enum must have the list") );

    if(terminate) man_create(NULL,terminate,indent);
  }
  else
    ioi_exe_add("param:ioigen",param_cmd,
      ioi_exe_link_param(
        ioi_exe_param("-ccompulsory",IOI_L_BOOLEAN,ioi_exe_argv(
            "This parameter must be given."
            "Use of this command is not possible without suppling this param.",
            "Compulsory parameter must be given before optional parameters.",
            NULL
          ),NULL,1,&compulsory
        ),
        ioi_exe_param("-ddim",IOI_L_INTEGER,ioi_exe_argv(
            "The dimension of the parameter.",
            NULL
          ),NULL,1,&dim,&dim_min,&dim_max,&dim_def
        ),
        ioi_exe_param("-vioivar",IOI_L_STRING,ioi_exe_argv(
            "IOI-variable name that is a default for this option",
            "The option follows the variable unless an option is used.",
            NULL
          ),NULL,1,&ioivar
        ),
        ioi_exe_param(
          "-iindent",IOI_L_INTEGER,ioi_exe_argv(
            "Remove this many characters form the input on every line",
            NULL
          ),"indentation",1,&indent,&indent_min,&indent_max,&indent_def
        ),
        ioi_exe_param(
          "-tterminate",IOI_L_STRING,ioi_exe_argv(
            "Stop reading when a line starting with this token is read.",
            NULL
          ),"terminator",1,&terminate
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param("variablename",IOI_L_STRING,
          ioi_exe_argv( "The C-code variable name.", NULL),
          NULL,-1,&name
        ),
        ioi_exe_param("type",IOI_L_ENUM,
          ioi_exe_argv( "The IOI-type of the parameter", NULL),
          NULL,-1,&type,igen_names,NULL
        ),
        ioi_exe_param("def(s)",IOI_L_STRING,
          ioi_exe_argv( "The default values for this parameter", NULL),
          NULL,1,&defs
        ),
        ioi_exe_param("min(s)",IOI_L_STRING,ioi_exe_argv(
            "The minimum values for this parameter",
            "For enumbered param this is the list of possible values in ascii",
            NULL
          ),NULL,1,&mins
        ),
        ioi_exe_param("max(s)",IOI_L_STRING,
          ioi_exe_argv( "The maximum values for this parameter", NULL),
          NULL,1,&maxs
        ),
        NULL
      ),
      ioi_exe_argv(
        "Start the definition of a new parameter.",
        "",
        "For enumerated parameter the defaults must be given.",
        "",
        "The def/min/max must be given as if for C-compiler. ioigen(ioi)",
        "does not check the contents of them. They are simply copied into",
        "the output.",
        "If the dimension is one then the parameter value is simpy given,",
        "","EXAMPLE","",
        "param -d 3 color double {0.5,0.5,0.5} {0.0,0.0,0.0} {1.0,1.0,1.0}",
        "",
        "defines a  three \"long\" double parameter with arrays for the",
        "default/min and max values. By default this color is medium gray.",
        NULL
      )
    );

  return called=TRUE;
}

manual_cmd(int argc, char **argv)
{
  static int   called;

  static int   indent,indent_min=0,indent_max=80,indent_def=0;
  static char *terminate;

  static char *filename;

  if( called )
  {
    ls_gen *start = NULL;

    read_lines(&start,filename,terminate,indent);

    man_add(start);
  }
  else
    ioi_exe_add("manual:ioigen",manual_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-iindent",IOI_L_INTEGER,ioi_exe_argv(
            "Remove this many characters form the input on every line",
            NULL
          ),"indentation",1,&indent,&indent_min,&indent_max,&indent_def
        ),
        ioi_exe_param(
          "-tterminate",IOI_L_STRING,ioi_exe_argv(
            "Stop reading when a line starting with this token is read.",
            NULL
          ),"terminator",1,&terminate
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "filename",IOI_L_STRING,ioi_exe_argv(
            "Read the manual page from the file named.",
            "(-) as a filename is stdin. You must use HERE-document",
            "to read stdin.",
            NULL
          ),NULL,1,&filename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Create a manual page for a option/parameter/command.",
        "This applies to the last entity being added. That is after",
        "option(ioigen) command you will add manual page to the option.",
        "",
        "If, however, you have not added manual to the command(ioigen),",
        "but you have used, let's say param(ioigen), and given manual",
        "for it. Using manual(ioigen) again will add the manual page",
        "for the command not for the option.",
        NULL
      )
    );

  return called=TRUE;
}

code_cmd(int argc, char **argv)
{
  static int   called;
  static char *filename;

  static char *terminate;
  static int   indent,indent_min=0,indent_max=80,indent_def=0;

  if( called )
  {
    ls_gen *start = NULL;

    if(last_cmd && last_cmd->code)
      error(ioi_out(1,IOI_ERR,"code:cann't have multiple code segments"));

    read_lines(&start,filename,terminate,indent);

    if(last_cmd)
      last_cmd->code = start;
    else
    {
       igen_exe *ip = (igen_exe *)calloc(sizeof(igen_exe),1);

       ip->name = strdup("initial_code");
       ip->code = start;
       ls_add(&root,ip);
    }
  }
  else
    ioi_exe_add("code:ioigen",code_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-iindent",IOI_L_INTEGER,ioi_exe_argv(
            "Remove this many characters form the input on every line",
            NULL
          ),"indentation",1,&indent,&indent_min,&indent_max,&indent_def
        ),
        ioi_exe_param(
          "-tterminate",IOI_L_STRING,ioi_exe_argv(
            "Stop reading when a line starting with this token is read.",
            NULL
          ),"terminator",1,&terminate
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "filename",IOI_L_STRING,ioi_exe_argv(
            "Read the code from the file named.",
            "(-) as a filename is stdin. You must use HERE-document",
            "to read stdin.",
            NULL
          ),NULL,1,&filename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Add code segment to the command.",
        "Only one code segment can be added. This is placed before the",
        "commands are listed.",
        NULL
      )
    );

  return called=TRUE;
}

class_cmd(int argc, char **argv)
{
  static int   called;
  static char *name;

  if( called )
  {
    ls_gen *start = NULL;

    cplusplus = strdup(name);

    return 0;
  }
  else
    ioi_exe_add("class:ioigen",class_cmd,
      0,
      ioi_exe_link_param(
        ioi_exe_param(
          "classname",IOI_L_STRING,ioi_exe_argv(
            "Define CC class name.",
            NULL
          ),NULL,1,&name
        ),
        NULL
      ),
      ioi_exe_argv(
        "Add class definition to the .ioi file.",
        NULL
      )
    );

  return called=TRUE;
}

int load_cmd(int argc, char **argv)
{
  static int called=0;

  static char  *name;

  if(called)
  {
    generate_loader = strdup(name);
  }
  else
    ioi_exe_add("load:ioigen",load_cmd,
      NULL,
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The name of the function to load all these commands.",
          NULL),
        NULL,-1,&name
      ),
      ioi_exe_argv(
        "Create a \"loader\" function to initialize all commands in this file.",
        "If loader function is created all commands in the output file will be",
        "static to speed up loader and avoid name conflicts.",
        "",
        "Loader is placed into the end of the output file.",
        "",
        "NOTICE",
        "",
        "  On some variations of UNIX even static name does not protect",
        "  against name conflict of some functions. This will be problem",
        "  at compilation time (although it should)",
        NULL)
    );

  return called = TRUE;
}


int show_cmd(int argc, char **argv)
{
  static int called=0;

  if(called)
    spit(-1);
  else
    ioi_exe_add("show",show_cmd,NULL,NULL,
      ioi_exe_argv(
        "Print out the current definition.",
        "Not a very clever thing in a batch mode.",
        NULL
      )
    );

  return called=1;
}

int clear_cmd(int argc, char **argv)
{
  static int called=0;

  if(called)
  {
    root = NULL;                   /* Ok, Ok, we waste a bit of memory */
    line_no = 0;                   /* BFD! */

    last_cmd   = NULL;
    last_param  = NULL;
    last_option  = NULL;
    generate_loader = NULL;
  }
  else
    ioi_exe_add("clear",clear_cmd,NULL,NULL,
      ioi_exe_argv(
        "Remove all the definitions of commands and code segments.",
        "Typically done in between the input files.",
        NULL
      )
    );

  return called=1;
}

main(argc,argv) int argc; char **argv;
/**************************************************************************
*                     T H E   M A I N   P R O G R A M
************************************o*************************************/
{
  ioi_exe     *exe;

  static int     called;
  static int     includes;
  static char   *filename;

  if(called)
  {
     char buff[MAXLEN];
     char newname[MAXLEN];

     if( filename )
     {
       argc++;
       argv--;

       fclose(stdout);
       fopen("/dev/null","w");

#if 0
       while( argc-- )
       {
         sprintf(buff,"< %s",*argv);
         ioi_file_input(buff);
         sprintf(buff,"show > %s",strext(newname,*argv,"c"));
         ioi_file_input(buff);
         sprintf(buff,"\\clear");
         ioi_file_input(buff);
         argv++;
       }

       sprintf(buff,"\\exit 0");
       ioi_file_input(buff);
#else
       fclose(stdin);
       if(!fopen(*argv,"r"))
         error( ioi_out(1,IOI_ERR,"ioigen:can not open file %s",*argv) );
         
       if(argc) fprintf(stderr,"%s:\n",*argv);
       fflush(stderr);

       while( argc-- )
         ls_add(&ioi_files,ls_create(0,*argv++));
#endif

     }

    return 1;                      /* We are here only cause the subsitute */
  }
  exe = (ioi_exe *)
    ioi_exe_add("ioigen:ioigen",main,
      ioi_exe_link_param(
        ioi_exe_param(
          "-ppreprocess",IOI_L_BOOLEAN,ioi_exe_argv(
            "Add preprocessor symbols of command and function names.",
            NULL
          ),NULL,1,&preprocess
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "filename",IOI_L_STRING,ioi_exe_argv(
            "Name(s) of the input files",
            NULL
          ),NULL,1,&filename
        ),
        NULL
      ),
      ioi_exe_argv(
        "Input Output Interface code generator.",
        NULL
      )
    );

  called = TRUE;
  if(!exe) exit(1);

  ioi_open(argc,argv,NULL);
  ioi_variable_set("prompt","");
  ioi_user_input(getit);
  ls_open();
  ioi_user_exit( spit );

  command_cmd(0,NULL);
  option_cmd(0,NULL);
  param_cmd(0,NULL);
  manual_cmd(0,NULL);
  code_cmd(0,NULL);
  class_cmd(0,NULL);
  show_cmd(0,NULL);
  load_cmd(0,NULL);
  clear_cmd(0,NULL);

  if( ioi_exe_substitute(exe,--argc,++argv) == 1 )
    exit(1);                       /* Manual page only */

  exe->call = NULL;                /* This can not be called anymore */

  ioi_execute();                   /* Let the IOI to process input */
  ioi_close();                     /* We really shouldn't get this far! */

}

#if 0

command rename:ilib rename_cmd
param -c name string
manual -i 2 << EOF
  This is the first line
  This is xxx line
EOF
param -c newname string
manual -i 2 << EOF
  This is the first line
  This is xxx line
EOF
code << endcode
  il_img *img;

  if(!(img=il_find(name)))
    return ioi_out(0,IOI_ERR,"rename:%s not found",name);
  if(il_find(newname))
    return ioi_out(0,IOI_ERR,"rename:%s -> %s duplicate name",name,newname);

  free(img->name);
  img->name = strdup(newname);
endcode

manual -i 2 << endman
  This is the first line
  This is xxx line
endman

command -t end load:ioigen load_cmd
  Create a "loader" function to initialize all commands in this file.
  If loader function is created all commands in the output file will be
  static to speed up loader and avoid name conflicts.

  NOTICE On some variations of UNIX even static name does not protect against
         name conflict of some functions. This will be problem at compilation
         time.
end
param -c -t end name string
  The name of the function to load all these commands.
end
code -t end
  generate_loader = strdup(name);
end

set indentation 2
set terminator end
command -i0 ioigen:ioigen main
  Input Output Interface code generator.
  ioigen(IOI) reads inputfiles and generates C-code to be linked with IOI
  library to form shell like applications.

  There are six basic parts in every input file which corresponds to the same
  ioigen command.

  CODE     To include code before commands are generated. There is a comment
           block in the beginning of every output file and these lines are
           copied after that.

           Inside COMMAND this will be the code to be executed.

  COMMAND  This is the command to be executed by the user. You define 
           the name of the called function

           Manual page can be given with an option or explisitely with
           MANUAL command.

  OPTION   Define an option for a the previously defined command. The letter
           to be used and the name (also the C-language name) and the type
           of the parameter must be defined. Limits and default values can
           be given.

           Manual page can be given with an option or explisitely with
           MANUAL command.

  PARAM    Same as OPTION but no option-letter and a compulsory requirement
           can be given.

  MANUAL   An expilsite manul page definition. Following lines are copied
           until line beginning with terminator string is found.

           The manual page can be made compulsory (although user can specify
           an empty manual page) by following IOI command which also defines
           the teminator to be same (bt default) to all manual pages

           set terminator end

           If this is set, COMMAND, OPTION and PARAM all start reading manual
           page without the manual command.

  LOAD     If used, will generate a loader function into the end of the file
           and all the other functions generated will be static.

  Indentation of the manual pages and code segments can also be defined
  globally by using following IOI command

  set indentation 2

  ioigen is based on IOI itself, so all IOI commands are available inside 
  all the files.

  Define a suffix rule in Makefile for .ioi-files as per following example

    .SUFFIXES: .ioi

    .ioi.c:
          ioigen $<
          
  CAVEATS  Since this is an IOI application, definitions are carried over 
           from one file to another. Eg there is terminarot definition in
           the first file and the second file tries to define a param without
           a manual page.
end
param filename string
  Filename(s) to be processed.
  If no filename is given ioigen run in an interactive fashion or as a filter.
  There is a possibility get bad output into output since IOI can add messages
  into the output.
end

NOTICE
  Global indentation can be achieved by the following IOI command

  set indentation 2

  Global manual terminator can be set by the following IOI command, but
  this also forces the put manual pages everywhere, althoug empty pages
  can obviously provided. Manual terminator must start from the 1st column

  set terminator end
#endif
