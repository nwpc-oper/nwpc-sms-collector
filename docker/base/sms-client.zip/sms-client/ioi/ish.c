/**************************************************************************
.TITLE   Input Output Interface
.NAME    ish
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    14-JUL-1992 / 07-MAY-1990 / OP
.VERSION 2.0
.FILE    ish.c
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#ifndef TODAY
#define TODAY "date unknown"
#endif

test_it(argc,argv) int argc; char **argv;
/**************************************************************************
?  Test multi dim array
************************************o*************************************/
{
  static int   called;
  static float  x[3];
 
  if( called )
  {
    printf("TEST IT: %g %g %g\n",x[0],x[1],x[2]);
  }
  else
    ioi_exe_add("array:ioi",test_it,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "xoordinates",IOI_L_DOUBLE,ioi_exe_argv(
            "The corrdinates x,y,z",
            NULL
          ),NULL,3,x,NULL,NULL,NULL
        ),
        NULL
      ),
      ioi_exe_argv(
        "Test multi dim array",
        "Line two?",
        NULL
      )
    );
 
  return called = TRUE;
}
 

ish_exit( code )
{
  printf("Goodbye %s\n",cuserid(NULL));
  exit( code );
}

main(argc,argv) int argc; char **argv;
{
  printf("Welcome to IOI-shell version 3.2, compiled on %s\n",TODAY);

  ioi_open(argc,argv,NULL);
  ioi_try_name("ISHRC");

  ioi_variable_set("prompt","ish");
  ioi_user_exit(ish_exit);

  test_it(0,NULL);

  while( ioi_user_cmd(&argc,&argv) )
    if(argc)
      fprintf(stderr,"ish: unknown command %s\n",*argv);

    /* ioi_misc_arg("ish",argc,argv); */

  ioi_close();
}
