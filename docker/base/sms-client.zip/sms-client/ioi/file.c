/**************************************************************************
.TITLE    Input Output Interface
.NAME     FILE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-DEC-1992 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     file.c
.DATE     10-MAR-1994 / 05-NOV_1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-SEP-1994 / 15-JUN-1994 / OP
.VERSION  3.1
*         Added external application output handling
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#ifdef AIX
/* AIX is a pain . B.R. */
#undef _ALL_SOURCE
#endif

#include <stdio.h>

#define IOI_MODULE
#include "ioi.h"

/**************************************************************************
*
*  The signal handling for the popen.
*
*  A separate signal handling is created for the external processes.
*
************************************o*************************************/

static void (*hstat)(), (*istat)(), (*qstat)(), (*pstat)(), (*tstat)();
static int    sigstored;

static ioi_token *file_stack;      /* Used by substitute/purge */

int ioi_perror(char *callname, char *arg)
/**************************************************************************
?  Produce perror to come via the IOI.
=  FALSE.
************************************o*************************************/
{
  register const char *errorname = "Unknown error";

  if(errno < sys_nerr)
    errorname = sys_errlist[errno];

  if (callname && *callname)
    return ioi_out(FALSE,IOI_ERR,"%s:%s %s",callname,arg?arg:"",errorname);

  return ioi_out(FALSE,IOI_ERR,"%s",errorname);
}

void ioi_file_input(char *line)
/**************************************************************************
?  Place the input line to be used next time the IOI needs to input from 
|  the stdin.
************************************o*************************************/
{
  ioi_token *start = ioi_._usrinput;
  ioi_token *token = (ioi_token *)ioi_token_create(line);

  if( !token ) return;

  if( !ioi_._usrinput )
    ioi_._usrinput = token;
  else
  {
    while( start->next )
      start = start->next;
    start->next = token;
  }
}

int ioi_printf(int code, char *fmt, ...)
/**************************************************************************
?  IOI-output to stdout/stderr (can be redirected to a user function,
|  eg for GUI applications)
-CALL  ioi_printf(int code, char *fmt, ...)
************************************o*************************************/
{
  int     len;                     /* If err is IOI_RAW          */
  va_list ap;

  va_start(ap,fmt);

  if(code==IOI_RAW)
  {
    len = va_arg(ap, int);

    if(ioi_._output && ! ioi_action_is_there_redir(FALSE) )
      ioi_._output(IOI_RAW,fmt,len);
    else
      fwrite(fmt,1,len,stdout);
  }
  else
    if(ioi_._output && ! ioi_action_is_there_redir(code) )
    {
      vsprintf(ioi_._logmsg,fmt,ap);
      ioi_._output(IOI_ECHO,ioi_._logmsg);
      ioi_._logmsg[0] = '\0';
    }
    else
    {
      vfprintf(code?stderr:stdout,fmt,ap);
    }

  va_end(ap);

  return 1;
}

int ioi_out(
    int     code,                  /* Requested return code */
    int     type,                  /* Output type */
    char   *fmt,                   /* Output format for the args */
    ...)
/**************************************************************************
?  IOI-output requests that may be copied into IOI-log-file
|  Called ioi_out(returncode,msg_type,format[,args...])
|  The newline is appended into the output, it's not needed in the format.
=  Return code supplied. This siplyfies the error handling in many cases.
|  Eg  if( ... ) return ioi_out(retcode , IOI_ERR , "Illegal... %d" , i );
-NOTICE  -1 is retured if type mismatch.
************************************o*************************************/
{
  static char *stypes[] = { "","# ERR","# WAR","# MSG","# LOG","# DBG" };
  static char *types[sizeof(stypes)/sizeof(char *)];

  static int   first_time = TRUE;  /* In the beginning */

  va_list ap;

  if( first_time )                 /* Keep the stypes read_only */
  {
    int i;

    for(i=0 ; i<(sizeof(stypes)/sizeof(char *)) ; i++)
      types[i] = strdup(stypes[i]);

    first_time = FALSE;
  }

  va_start(ap,fmt);

  if(ioi_._logmsg)
    ioi_._logmsg[0] = '\0';        /* The saved message for users */

  if(type < 0 || type > IOI_LOGS) return(-1);

  if(ioi_._brief && type != IOI_DBG)  /* Let's check the format! */
  {
    char *t = fmt;

    while( *t && !(*t == ':' || *t == '%') ) t++;
      if(*t == ':') fmt = ++t;
  }

  if(type != IOI_ECHO)
    types[type][0] = ioi_._comment;

  if(ioi_._msg[type])
/*3.1*/
    if(ioi_._output)
    {
      if( type != IOI_ECHO )
        sprintf(ioi_._logmsg,"%s:",types[type]);
      vsprintf(ioi_._logmsg+strlen(ioi_._logmsg),fmt,ap);
      sprintf(ioi_._logmsg+strlen(ioi_._logmsg),"\n");
      ioi_._output(type,ioi_._logmsg);
      ioi_._logmsg[0] = '\0';
    }
    else
    {
      if(!ioi_._brief)
        fprintf((type==IOI_ERR)?stderr:stdout,"%s:",types[type]);
      vfprintf((type==IOI_ERR)?stderr:stdout,fmt,ap);
      fprintf((type==IOI_ERR)?stderr:stdout,"\n");
    }
/*3.1*/

  if(ioi_._logfile)
    if(ioi_._log[type])
    {
      if( type != IOI_ECHO )
        sprintf(ioi_._logmsg,"%s:",types[type]);

      vsprintf(ioi_._logmsg+strlen(ioi_._logmsg),fmt,ap);
      fprintf(ioi_._logfile,"%s\n",ioi_._logmsg);

      fflush(ioi_._logfile);
    }

  va_end(ap);

  /*  fflush( (type==IOI_ERR)?stderr:stdout );  */
  /*  fflush(stdout); fflush(stderr);  */

  return(code);
}

void ioi_file_prompt(int level)
/**************************************************************************
?  Print the IOI-prompt of different levels.
|  For applications that has their own input routine but wants to use
|  IOI-prompting.
************************************o*************************************/
{
  int i;

  if( level )
  {
    for( i=0 ; i<level ; i++ )
      ioi_printf(TRUE,">");
    ioi_printf(TRUE," ");
  }
  else
    if( *ioi_._prompt )
      ioi_printf(TRUE,"%s> ",ioi_._prompt);

  fflush(stdout);
  fflush(stderr);
}

int ioi_file_read(int secondary)       /* Use sec. prompt? */
/**************************************************************************
|  Read in the next physical input line (stdin/file/function/(internal))
|  If any include file is open the line is read there without a prompt.
|  Or if there is a function in the stack read it.
|  End of file will close that file and continue reading the previous file
|  If no files remain open stdin is read
=  TRUE in normal conditions, which means there is character(s) in buffer
|  FALSE if EOF is reached in stdin.
-NOTICE  Line concatenation may exceed the file boundary.
************************************o*************************************/
{
  register int    def = ioi_._in_def;  /* Are we defining a function? */
  ioi_file       *file;
  ioi_call       *call;
  ioi_control    *control;
  ioi_command    *command;
  int             len  = 0;        /* Current input buffer lenght */
  int             goon = TRUE;     /* Continue reading? */
  char           *s;               /* Temp for scanning */
  char            last = '\0';     /* Temp for scanning */
  int             i;
  int             inside;          /* Quotations? */
  int             echos;           /* To clarify the echoing! */

  ioi_._line[0] = '\0';
  ioi_._line[ioi_._lsize-1] = '\0';

  while( !len || goon )            /* Empty or continues line */
  {
    if( ioi_._action )             /* File, function, ... */
    {
      switch( ioi_._action->type )
      {
        case IOI_L_REDIR:
          ioi_file_redirection_delete();
          break;
        case IOI_L_FILE:
          file = (ioi_file *)ioi_._action;

          if(!fgets(ioi_._line+len,ioi_._lsize-len-1,file->fp))
          {
            ioi_file_escape( FALSE );
            if( ioi_._stack )      /* Was left over previously */
              /* NOT CORRECT */    /* Line-buffer discarded! */
              return(TRUE);
          }
          break;
        case IOI_L_CMD:            /* Tokens added into the stack */
          command = (ioi_command *) ioi_._action;

          ioi_._stack = command->cmd;
          ioi_._action = ioi_._action->next;

          free(command);
          return TRUE;

        case IOI_L_CALL:           /* It's an internal function */
          call = (ioi_call *) ioi_._action;

          if( !call->ifile )
          {
            if( len )
              ioi_._line[len] = '\0';
            else
            {
              ioi_function_return(-1,NULL);

              if( ioi_._stack )    /* Was left over previously */
                /* NOT CORRECT */  /* Line-buffer discarded! */
                return(TRUE);
            }
          }
          else
          {
            strncpy(ioi_._line+len,call->ifile->text,ioi_._lsize-len);
            call->ifile = call->ifile->next;
          }
          ioi_._line[ioi_._lsize-1] = '\0';
          break;
        case IOI_L_VARIABLE:
          ioi_action_break();
          break;
        CASE_CONTROL:              /* Can be here after stack manipualtion */
          return TRUE;             /* Control execute will handle this one */

        default:                   /* To be on the safe side! */
          return
            ioi_out(FALSE,IOI_ERR,"IOI-FILE-READ:Internal trap, sorry");

      }
    }
    else                           /* Read from stdin */
    {
      if( !ioi_._usrinput )        /* Not application loaded lines    */
        if( !ioi_._input )         /* Users routine should print this */
          if( secondary )          /* Distinguist between the prompts */
          {
            for( i=0 ; i<secondary ; i++ )
              ioi_printf(TRUE,">"); /* Prompt size reflects the depth */
            ioi_printf(TRUE," ");   /* Much clearer */
          }
          else
            if( *ioi_._prompt )
              ioi_printf(TRUE,"%s> ",(len)? "":ioi_._prompt);

      fflush(stdout);

      if( ioi_._usrinput )
      {
        ioi_out(0,IOI_DBG,"IOI-FILE-READ:User input :%s",ioi_._usrinput->text);
        strncpy(ioi_._line+len,ioi_._usrinput->text,ioi_._lsize-len);
        ioi_._usrinput = (ioi_token *)ioi_token_delete(ioi_._usrinput,FALSE);
      }
      else
        if( ioi_._input )
          if( !ioi_._input(ioi_._line+len,MAXLEN-len,len?1:secondary) )
          {
            /* ioi_._input = NULL; */  /* Donno? Do ya? */

            if(ioi_._input != ioi_user_dummy)
              ioi_out(FALSE,IOI_MSG,":EOF in user input routine!");
            return FALSE;
          }
          else
            ;
        else
          if( !fgets(ioi_._line+len,MAXLEN-len,stdin) )
            if( feof(stdin) )
              return ioi_out(FALSE,IOI_MSG,":EOF in stdin!");
            else
              ;
          else
            if(ioi_._output) ioi_printf(0,"%s",ioi_._line+len);
    }

    ioi_._line[ioi_._lsize-1] = '\0';

    s = ioi_._line+len;
    i = strlen(s);

    if(i && s[i-1]=='\n')          /* Remove the newline char! */
       s[--i]='\0';

    if( ioi_._action )             /* After FILE or CALL */
      ioi_out( 0,IOI_DBG,"%s",ioi_._line+len);
    else
    {
      echos = ioi_._msg[IOI_ECHO]; /* Log this only in the file */
      ioi_._msg[IOI_ECHO] = FALSE;
      ioi_out( 0,IOI_ECHO,"%s",ioi_._line+len);
      ioi_._msg[IOI_ECHO] = echos;
    }

    if( def )                      /* Defining a function -> don't process */
      return( TRUE );              /* Not even the continues lines! */

    inside = 0;

    if( len=strlen(ioi_._line) )   /* Hymm, got something! */
    {
      if(ioi_._line[len-1] == '\n')
        ioi_._line[--len] = '\0';  /* Remove the newline character */

      if( goon=(len &&             /* Check the continuing line */
                IS_JOIN(ioi_._line[len-1]) &&
                (len>1 && !IS_ESCAPE(ioi_._line[len-2]))
               ) 
        )
        ioi_._line[--len] = '\0';

      last = '\0';                 /* To detect the quotations */

      for( s=ioi_._line,i=0 ; i<len ; i++, last = *s , s++) 
        if(inside)                 /* Inside quotient? */
          inside = (*s == inside)? '\0' : inside;
        else
          if( *s == '\'' || *s == '"' || *s == '`' &&
              /* !(i && IS_ESCAPE(s[-1])) ) */
              !IS_ESCAPE(last) )
            inside = *s;
          else
            /* if( IS_COMMENT(*s) && !(i && IS_ESCAPE(s[-1])) ) */
            if( IS_COMMENT(*s) && !(IS_ESCAPE(last) || last=='$') )
            {
              len=i;
              *s=0;
              break;
            }

      if(!len) goon=TRUE;
    }
  }

  echos = ioi_._log[IOI_ECHO];     /* Log (echo) this only on terminal */
  ioi_._log[IOI_ECHO] = FALSE;     /* Log the full (joined) line       */
  ioi_out( 0,IOI_ECHO,"%s",ioi_._line);
  ioi_._log[IOI_ECHO] = echos;

  return( TRUE );
}

char *ioi_file_substitute(char *name)
/**************************************************************************
?  Check the home character in the file name.
|  And build a new name if expanded.
@  ioi_._work, the result is here.
=  The new name (in the ioi_._work)
|  NULL in case of error
|  If no name was given this results to a NULL
************************************o*************************************/
{
/* Move these into ioi.h, if needed */

#define IOI_TILDE      '~'         /* For username matching */
#define IOI_SLASH      '/'         /* For username matching */

#define IS_TILDE(c) ((c)==IOI_TILDE)
#define IS_SLASH(c) ((c)==IOI_SLASH)

#ifdef UNIX
#include <pwd.h>
#  if (defined(mips) && ! defined(__sgi)) || defined(AIX)
     extern struct passwd *getpwuid();
     extern struct passwd *getpwnam();
#  endif
  struct passwd *pwd;
#endif
  char          *s = ioi_._work;
  char          *n = name;
  ioi_token     *temp = NULL;

  if( !name ) return NULL;

  strncpy(s,name,ioi_._lsize);

#ifdef UNIX
  if( IS_TILDE(*name)  )
  {
    if( IS_SLASH(name[1]) )
    {
      pwd = getpwuid(getuid());
      n++;
    }
    else
    {
      n++;

      while( isalnum(*n) || *n=='_')   /* Get the user name into _work */
        *s++ = *n++;
      *s = '\0';

      pwd = getpwnam( s = ioi_._work );
    }
    endpwent();

    if( pwd )
      sprintf(ioi_._work,"%s%s",pwd->pw_dir,n);
    else
    {
      ioi_out(0,IOI_WAR,"IOI-FILE-TILDE:[%s] no match.",name);
      return NULL;
      /* strncpy(s,name,ioi_._lsize); */
    }
  }
#endif

  temp = (ioi_token *)ioi_token_create(s);
  temp->next = file_stack;
  file_stack = temp;

  return temp->text;
}

void ioi_file_purge(void)
/**************************************************************************
?  Get rid of the used memory.
-CALLED-BY  ioi_token_stack()
************************************o*************************************/
{
  file_stack = (ioi_token *)ioi_token_delete(file_stack,TRUE);
}

int ioi_file_include(char *name)
/**************************************************************************
?  Add file named into input list. (On top of the stack.)
|  If the file doesn't exist or couldn't be opened, an error is printed
|  and the operation cancelled.
|  The new file will be on top of the file list and reading of the
|  previous file continues after the new file is closed.
|  The parameters left in the token stack are processed after this file
|  is closed.
=  TRUE if ok.
+  Input line:
|    cmd1; < file ; cmd2
|  Will process the command 1 first, then read next commands from the file
|  given and then process command 2.
************************************o*************************************/
{
  FILE      *fp;
  ioi_file  *f;
  ioi_token *token;
  int        argc = ioi_._argc;

  if( !name )
    return ioi_out(0,IOI_ERR,"IOI-FILE-INCLUDE:Supply a name");

  if( ! (name=ioi_file_substitute(name)) )
    return FALSE;

  if(!(fp=fopen(name,"r")))
    return ioi_out(0,IOI_ERR,"IOI-FILE-INCLUDE:Cann't read %s",name);

  if(!(f=SALLOC(ioi_file)))
  {
    fclose(fp);
    return ioi_out(0,IOI_ERR,"IOI-FILE-INCLUDE:No mem. (1)%s",name);
  }

  ioi_file_redirection_create();
    
  f->name     = strdup(name);
  f->next     = ioi_._action;      /* Chain the action stack */
  f->type     = IOI_L_FILE;
  f->fp       = fp;

  token = ioi_._token;

  if(argc > 2)
    ioi_out(0,IOI_WAR,"IOI-FILE-INCLUDE:Extra parameters discarded");

  while(argc && token)             /* Delete the unused tokens */
  { 
    token = (ioi_token *)ioi_token_delete(token,FALSE);
    argc--;
  }

  f->stack = ioi_._stack;

  ioi_._token  = NULL;
  ioi_._stack  = NULL;
  ioi_._action = (ioi_gen *)f;
  ioi_._argc = 0;

  return TRUE;
}

char *ioi_file_here_document(char *eof, int strip)
/**************************************************************************
?  Build a temporarily file for the here document.
=  Name of the temporarily file. (In static area)
|  The temporarily file is visible during the time of writing and before
|  it is removed by the reading/redirecting routines.
************************************o*************************************/
{
  static char  name[MAXNAM];       /* Return file name */
  FILE        *fp;                 /* Temp file */
  char        *s;                  /* Work space */
  int          len = strlen(eof);  /* How much the compare */
  int          return_code;

  tmpnam(name);

  if( !(fp=fopen(name,"w")) )
    return (char *)ioi_out((int)NULL,IOI_ERR,"IOI-FILE-HERE-DOCUMENT:open failed");

  s = ioi_._line;

  while( TRUE )                    /* Just keep on readin' */
  {
    return_code = ioi_file_read(TRUE);

    if( strip && return_code )     /* Remove the white space */
    {
      s = ioi_._line;
      while( *s && ( *s==' ' || *s=='\t' ) ) s++;
    }

    if( !strncmp(eof,s,len) || !return_code ) /* Check HERE-terminator */
    {
      fclose(fp);
      return(name);
    }

    fprintf(fp,"%s\n",s);          /* Newline was stripped my read */
  }
}

char *ioi_file_redirect_fd(
    int   fd,                      /* File descriptor (0,1,2,3(pipe)) */
    char *name,                    /* Input / output file name */
    int   compress,                /* Special in/output? */
    int   append,
    int   join)
/**************************************************************************
?  Redirect file (descriptor=fd) to the name.
|  If the descriptor is one of 0,1,2 the stdin.stdout/stderr is used.
|  If the descriptor is 3 and this is UNIX system, a pipe is opened for
|  the stdout to execute command name.
|  If the name is empty stderr is attached to the stdout.
=  Error message. NULL indicates ok!
************************************o*************************************/
{
  /*-----------------+-------------+---------------+-----------------+
  |  FILE-DESCRIPTOR | Mode/append | Open/compress | NAME  or    if  |
  +------------------+-------------+---------------+-----------------+
  |  0 (stdin)       |   r    Nan  |  F      P     | name  cmd  Comp |
  |  1 (stdout)      |   w     a   |  F      P     | name  cmd  Comp |
  |  2 (stderr)      |   w     a   |  F     Nan    | name  null Join |
  |  3 (stdout/pipe) |   w    Nan  |  P     Nan    | name            |
  +------------------+-------------+---------------+----------------*/
 
#if defined(CRAY) || defined(__hpux) || defined(hpux)
  static char buff0[BUFSIZ];
  static char buff1[BUFSIZ];
  static char buff2[BUFSIZ];
#endif

  char *mode;                      /* File open mode       */
  char  cmd[MAXNAM];               /* For compress command */
  FILE  tmp;                       /* Memory for swapping  */
  FILE *fp;                        /* The new file         */
  FILE *temp;                      /* Temp only            */

#ifdef UNIX
  /*
   *  Some systems have these, some need things like POSIX_SOURCE (!!!)
   */
#  ifdef AIX 
     extern FILE    *popen(const char *, const char *);
#  endif

  /* FILE *(*ffile)() = (fd==3 || compress)? popen : fopen; */

  FILE *(*ffile)();                /* To keep convex happy! */

  if(fd==3 || compress) ffile = popen;    
  else                  ffile = fopen;
#else
  FILE *(*ffile)() = fopen;

  if(fd==3 || compress)
    return "Pipes not supported in this OS";
#endif 

  if( (ioi_._in   && fd == 0) ||
      (ioi_._out  && fd == 1) ||
      (ioi_._err  && fd == 2) ||
      (ioi_._out  && fd == 3) ||
      (fd < 0 || fd > 3) ||
      ioi_._pipe )
    return "illegal redirect request.";

  sprintf( cmd , "%scompress -c %c %s" , (fd==0)?"un":"" , 
           (fd==0)?'<':'>' , name );

  mode = (fd==0)? "r":"w";
  if( append ) mode = "a";

  if( join ) name = "/dev/null";
  if( compress ) name = cmd;

  /*
   *  The 'popened' file will have the caught signals set to the defaults
   *  see execve(2) for more details.
   *  (We want the child to respond to interrupt, even if we caught it)
   */
  if( !(name=ioi_file_substitute(name)) )
    return "substitution failed";

  if( !(fp=ffile(name,mode)) )
  {
    return
      (fd==3 || compress)?
        "Pipe open error."
      : 
        "Couldn't open file for redirection.";
  }

  switch( fd )
  {
    case 0:
      ioi_._in   = fp;
      ioi_._cin  = strdup(name);
      temp = stdin;
      break;
    case 3:
      istat = signal(SIGINT , SIG_IGN);
      qstat = signal(SIGQUIT, SIG_IGN);
      hstat = signal(SIGHUP , SIG_IGN);
      pstat = signal(SIGPIPE, SIG_IGN);
      tstat = signal(SIGTERM, SIG_IGN);
      sigstored = TRUE;

      ioi_._pipe = TRUE;
    case 1:
      ioi_._out  = fp;
      ioi_._cout = strdup(name);
      temp = stdout;
      fflush(stdout);
      break;
    case 2:
      ioi_._err  = fp;
      ioi_._cerr = strdup(name);
      temp = stderr;
      fflush(stdin);
      break;
  }

#if defined(CRAY) || defined(__hpux) || defined(hpux)
  /* Something silly in the cray! and HP (check _bufendtab???) */
  if(fd==0) setvbuf(fp,buff0,_IOLBF,BUFSIZ);
  if(fd==1 || fd==3) setvbuf(fp,buff1,_IOLBF,BUFSIZ);
  if(fd==2) setvbuf(fp,buff2,_IOLBF,BUFSIZ);
#endif

  memcpy(&tmp , fp   , sizeof(FILE));  /* Swap the contents of the buffs */
  memcpy( fp  , temp , sizeof(FILE));
  memcpy(temp , &tmp , sizeof(FILE));

  if( join )
    if( dup2(fileno(stdout),fileno(stderr)) == (-1) )
      return
        "Dup problem.";

  return( NULL );                  /* OK! */
}

int ioi_file_redirect(void)
/**************************************************************************
?  Redirect current command.
|  Process tokens in the list until COMMAND or if pipe make a rest to be
|  the process opened.
=  TRUE if ok, FALSE if file couldn't be opened or multiple open requests.
************************************o*************************************/
{
  ioi_token *last,*token;
  char      *s;
  char      *name;                 /* Name of the ior-file */
  char      *msg = NULL;           /* The error message */

  /* if( !(last=ioi_._token) ) return( TRUE ); */

  last=ioi_._token;
  token = last->next;

  while( token && !IS_COMMAND(token->text[0]) )
  {
     s = token->text;

     if( IS_INPUT(*s) || IS_OUTPUT(*s) || IS_PIPE(*s) )
     {
       if( !(token = token->next) || IS_COMMAND(token->text[0]) )
         msg = "Null io-request.";
       else
       {
         name = token->text;

         if( IS_INPUT(*s) )        /* <=== STANDARD INPUT ===> */
         {
           if( ! *++s )                               /*((((( <   )))))*/
             msg = ioi_file_redirect_fd(0,name,0,0,0);
           else
             if( IS_COMPRESS(*s) )                    /*((((( <=  )))))*/
               msg = ioi_file_redirect_fd(0,name,1,0,0);
             else
               if( IS_INPUT(*s) )                     /*((((( <<  )))))*/
               {                                      /*((((( <<= )))))*/
                 if( !(name=ioi_file_here_document(name,*++s)) )
                   msg = "Here document open."; 
                 else
                 {
                   msg = ioi_file_redirect_fd(0,name,0,0,0);
                   unlink(name);   /* It's open now! */
                 }
               }
               else
                 msg = "Extra characters in io-directive?";
         }
         else if( IS_OUTPUT(*s) )  /* <=== STANDARD OUTPUT ===> */
         {
           if( ! *++s )                               /*((((( >   )))))*/
             msg = ioi_file_redirect_fd(1,name,0,0,0);
           else
             if( IS_COMPRESS(*s) )                    /*((((( >=  )))))*/
               msg = ioi_file_redirect_fd(1,name,1,0,0);
             else
               if( IS_OUTPUT(*s) )
               {
                  if( ! *++s )                        /*((((( >>  )))))*/
                    msg = ioi_file_redirect_fd(1,name,0,1,0);
                  else
                    if( IS_ERROR(*s) ) 
                    {                                 /*((((( >>& )))))*/
                      if( ! ioi_._out )
                        msg = ioi_file_redirect_fd(1,name,0,0,0);
                      if( ! msg )
                        msg = ioi_file_redirect_fd(2,name,0,0,1);
                    }
                    else if( ! *s )
                      msg = "Extra characters in io-directive?";
               }
               else
                 if( IS_ERROR(*s) )                   /*((((( >&  )))))*/
                 {
                    if( ! ioi_._out )
                      msg = ioi_file_redirect_fd(1,name,0,0,0);
                    if( ! msg )
                      msg = ioi_file_redirect_fd(2,name,0,0,1);
                 }
                 else
                   msg = "Extra characters in io-directive?";

         }
         else if( IS_PIPE(*s) )    /* <=== PIPE REQUEST ===> */
         {
            int   len2,len=0;

            s = ioi_._work;                           /*((((( |   )))))*/

            while( token )         /* Build the command for the pipe */
            {
              len2 = strlen( token->text );

              if(len + len2 >= ioi_._lsize)
              {
                msg = "Too big pipe command.";
                break;
              }

              strcpy(&s[len],token->text);
              len += len2;
              s[ len++ ] = ' ';

              token = token->next;
            }
            s[len] = '\0';

            if( ! msg )
              msg = ioi_file_redirect_fd(3,ioi_._work,0,0,0);

            last->next = (ioi_token *)ioi_token_delete(last->next,TRUE);
         }
       }

       if( !msg && token )         /* Skip tokens */
       {
         token = token->next;
         last->next = (ioi_token *)ioi_token_delete(last->next,FALSE);
         last->next = (ioi_token *)ioi_token_delete(last->next,FALSE);
       }
     }
     else
     {
       last = token;
       token = token->next;
     }

     if( msg )
     {
       ioi_file_restore();
       return ioi_out(FALSE,IOI_ERR,"IOI-FILE-REDIRECT:%s",msg);
     }
  }

  return( TRUE );
}

void ioi_file_restore(void)
/**************************************************************************
?  Restore files after redirection.
|  In UNIX systems the piped process is terminated.
************************************o*************************************/
{
  FILE  tmp;

  if(ioi_._err)
  {
    fflush(stderr);
    memcpy( &tmp      , ioi_._err ,sizeof(FILE));
    memcpy( ioi_._err , stderr    ,sizeof(FILE));
    memcpy( stderr    , &tmp      ,sizeof(FILE));
    FCLOSE(ioi_._err);
  }

  if(ioi_._in)
  {
    fflush(stdin);
    memcpy( &tmp      , ioi_._in  ,sizeof(FILE));
    memcpy( ioi_._in  , stdin     ,sizeof(FILE));
    memcpy( stdin     , &tmp      ,sizeof(FILE));
    FCLOSE(ioi_._in);
  }

  if(ioi_._out)
  {
    fflush(stdout);
    memcpy( &tmp      , ioi_._out ,sizeof(FILE));
    memcpy( ioi_._out , stdout    ,sizeof(FILE));
    memcpy( stdout    , &tmp      ,sizeof(FILE));

#ifdef UNIX
    if(ioi_._pipe)
    {
      pclose(ioi_._out);

      if( sigstored )
      {
        (void) signal(SIGINT , istat);
        (void) signal(SIGQUIT, qstat);
        (void) signal(SIGHUP , hstat);
        (void) signal(SIGPIPE, pstat);
        (void) signal(SIGTERM, tstat);
      }
      sigstored = FALSE;

      ioi_._out  = NULL;
      ioi_._pipe = FALSE;
    }
#endif
    FCLOSE(ioi_._out);
  }

  IFFREE( ioi_._cin  );
  IFFREE( ioi_._cout );
  IFFREE( ioi_._cerr );

  fflush(stdout); fflush(stderr);  /* FIX 16-JUL-1991 */
}

int ioi_file_redirection_create(void)
/**************************************************************************
?  Create the redirection action if necessary and place it into the stack.
|  If any of the stdin, stdout or stderr is currently open they are 
|  copied into action stack (all of them as a single action)
=  TRUE if successfull, FALSE if no mem.
~  ioi_file_redirection_delete
************************************o*************************************/
{
  ioi_redir *redir;

  if( ioi_._in || ioi_._out || ioi_._err )
  {
    if( !(redir = SALLOC(ioi_redir)) )
      return ioi_out(FALSE,IOI_ERR,"IOI-FILE-REDIRECTION-CREATE:No mem.");

    redir->in    = ioi_._in;
    redir->out   = ioi_._out;
    redir->err   = ioi_._err;
    redir->cin   = ioi_._cin;
    redir->cout  = ioi_._cout;
    redir->cerr  = ioi_._cerr;
    redir->pipe  = ioi_._pipe;

    redir->type  = IOI_L_REDIR;
    redir->next  = (ioi_redir *)ioi_._action;
    ioi_._action = (ioi_gen *)redir;

    ioi_._in   = ioi_._out  = ioi_._err  = NULL;
    ioi_._cin  = ioi_._cout = ioi_._cerr = NULL;
    ioi_._pipe = FALSE;
  }

  return TRUE;
}

int ioi_file_redirection_delete(void)
/**************************************************************************
?  Remove the redirection action from the stack.
=  TRUE
************************************o*************************************/
{
  ioi_redir *redir;

  if( redir = (ioi_redir *)ioi_._action )
    if( redir->type == IOI_L_REDIR )
    {
      ioi_._action = (ioi_gen *)redir->next;

      ioi_._in    = redir->in   ;
      ioi_._out   = redir->out  ;
      ioi_._err   = redir->err  ;
      ioi_._cin   = redir->cin  ;
      ioi_._cout  = redir->cout ;
      ioi_._cerr  = redir->cerr ;
      ioi_._pipe  = redir->pipe ;

      free(redir);
      ioi_file_restore();
    }

  return TRUE;
}

int ioi_file_escape(int force)     /* Force escape? */
/**************************************************************************
?  Close currently open include file.
!  This should loop for the IOI_L_FILE and remove it from the stack!
|  At the moment it just closes the file if it's the first in the stack.
************************************o*************************************/
{
  ioi_file *file;

  /*
   *  The checking here should be removed, but kept until we are sure.
   *  All this is should prepared by the action_handler().
   */

  if( file = (ioi_file *)ioi_._action )
    if( file->type == IOI_L_FILE )
    {
      fclose( file->fp );

      if( force )
        ioi_out(0,IOI_LOG,"IOI-FILE-ESCAPE:EOF forced for %s",file->name);
      else
        ioi_out(0,IOI_LOG,"EOF reached for %s",file->name);

      ioi_._action = (ioi_gen *)file->next;
      ioi_._stack  = file->stack;

      IFFREE(file->name);

      if( force )
        ioi_._stack = (ioi_token *)
           ioi_token_delete(ioi_._stack,TRUE);

      if(file->local) ioi_variable_pop(file->local);

      free( file );
    }
    else 
      return ioi_out(0,IOI_WAR,"IOI-FILE-ESCAPE:Top of the stack != file.");
  else
    return ioi_out(0,IOI_WAR,"IOI-FILE-ESCAPE:Stack is empty, ignored");


  return(TRUE);
}

int ioi_file_log(char *name, int append)
/**************************************************************************
?  Startup the log file. If the logfile was open, close it first.
|  If the name is NULL, the previous file is simply closed.
=  TRUE if ok.
************************************o*************************************/
{
  if(ioi_._logfile)
  {
    ioi_out(0,IOI_MSG,"IOI-FILE-LOG:Closing logfile %s.",
      ioi_._logname ? ioi_._logname : "" );

    FCLOSE(ioi_._logfile);
    IFFREE(ioi_._logname);
  }

  if( !name ) return( TRUE );

  /* if( !(ioi_._logfile=fopen(name,append?"a":"w")) ) */

  if( !(name=ioi_file_substitute(name)) )
    return FALSE;

  if( !(ioi_._logfile=fopen(name,append?"a":"w")) )
    return ioi_out(0,IOI_ERR,"IOI-FILE-LOG:Open failed for %s.",name);

  sprintf( ioi_._work,"%s%s",name, append? " (append)" : "" );
  ioi_._logname = strdup(ioi_._work);

  return TRUE;
}

int ioi_file_close(int argc, char **argv)
/**************************************************************************
?  Close command.
=  TRUE if ok.
************************************o*************************************/
{
  static int   called;
  static int   all;

  if( called )
  {
    if( all )
      ioi_action_handler(-1);
    else
      if(ioi_action_is_there(IOI_L_FILE))
        ioi_action_handler(IOI_L_FILE);
      else
        return
          ioi_out(0,IOI_WAR,"IOI-FILE-CLOSE:Not including files");
  }
  else
    ioi_exe_add("close:ioi",ioi_file_close,
      ioi_exe_link_param(
        ioi_exe_param("-aall",IOI_L_BOOLEAN,ioi_exe_argv(
            "Close all input files. This may be used in an emergency exits.",
            NULL
          ),NULL,1,&all
        ),
        NULL
      ),
      NULL,
      ioi_exe_argv(
        "Close the current input file (not stdin) or all files.",
        "If the current input is a file and not the stdin it is closed.",
        "This can be used to escape from the include files.",
        "",
        "With all option all the files are closed and the whole action",
        "stack is removed. The IOI will be reading from the input handler",
        "(stdin by deafult).",
        NULL
      )
    );

  return called=TRUE;
}
