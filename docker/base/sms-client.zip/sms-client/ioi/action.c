/**************************************************************************
.TITLE    Input Output Interface
.NAME     ACTION
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     03-MAR-1992 / 16-SEP-1991 / OP
.VERSION  2.0
.FILE     action.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.LANGUAGE ANSI-C
.VERSION  3.0
.DATE     14-JUL-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*  The signal handling for the IOI and stack manipulation routines
*  for the commands like break, continue.
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

void ioi_action_catch(int sig)
/**************************************************************************
?  Act onto the terminal interrupt.
|  Clear the action stack and issue the prompt.
*  The sig parameter is the only one that is used in ANSI/UNICOS5-6
*  Check this on SGI/Iris 3.x / 4.x
*
*  OS        ver     # of params   reload?
*
*  SunOS     4.0     4             na
*  UNICOS    6.0     1             yes
*  ConvexOS  9.1     3             na
*  IRIX      3.3     3             yes
*  ANSI-C            1             yes?
*  VMS       5.4     3             ? donno
*  min               1
*  needed            1 (OK!)
************************************o*************************************/
{
  int empty;

  empty = ioi_._action? FALSE:TRUE;

#ifdef SIGCONT
  if( sig == SIGCONT )
  {
    if( empty ) ioi_printf(FALSE,"%s> ",ioi_._prompt?ioi_._prompt:"");
    fflush(stdout);
    signal(sig,ioi_action_catch);  /* In SVR3 you have to load it again! */
    return;
  }
#endif

  ioi_out(0,IOI_MSG,"IOI-ACTION-CATCH:signal %d",sig);
  ioi_action_handler(-1);

  ioi_printf(FALSE,"\n");

#ifdef IMPOSSIBLE
#ifndef CRAY
  if( empty )
    ioi_printf(FALSE,"%s> ",ioi_._prompt?ioi_._prompt:"");
#endif
#endif

  fflush(stdout);

  signal(sig,ioi_action_catch);    /* In SVR3 you have to load it again! */
  longjmp(ioi_._jmpenv,sig);
}

int ioi_action_c_break(int mode)
/**************************************************************************
?  Turn the terminal kill signal handling on/off
|  If activated, the default action is to clear the action stack complete
|  on user interrupt.
************************************o*************************************/
{
  static void (* old)();
  static int  loaded;

  if( mode )
  {
    if( ! loaded )                 /* Not already catching it! */
    {
      ioi_out(0,IOI_MSG,"IOI-ACTION-C-BREAK:Interrupt handler loaded");
      old = signal(SIGINT,ioi_action_catch);
#ifdef SIGCONT
      signal(SIGCONT,ioi_action_catch);
#endif
    }
    loaded = TRUE;
  }
  else
  {
    if( loaded )                   /* Return the previous value */
    {
      signal(SIGINT,old);
      old = (void (*)())NULL;
      ioi_out(0,IOI_MSG,"IOI-ACTION-C-BREAK:Interrupt handler removed");
    }
    loaded = FALSE;
  }

  return 1;
}

int ioi_action_is_there(int what)
/**************************************************************************
?  Find out is there action of type WHAT in the stack.
=  BOOLEAN status.
************************************o*************************************/
{
  ioi_gen *gen = ioi_._action;

  while( gen )
  {
    if( gen->type == what ) 
      return TRUE;

    gen = gen->next;
  }

  return FALSE;
}

int ioi_action_is_there_redir(int err)
/**************************************************************************
?  Find out is there action of type WHAT in the stack.
=  BOOLEAN status.
************************************o*************************************/
{
  ioi_redir *rp = (ioi_redir *)ioi_._action;

  if( (err && ioi_._err) || (!err && ioi_._out) )
    return TRUE;

  while( rp )
  {
    if( rp->type == IOI_L_REDIR ) 
      if( (err && rp->err) || (!err && rp->out) )
        return TRUE;

    rp = rp->next;
  }

  return FALSE;
}

int ioi_action_handler(int level)
/**************************************************************************
?  Process the action stack up to the level given.
|  The level is the type to be processd.
|  -1 is used to get rid of everything.
************************************o*************************************/
{
  int go_on = TRUE;

  while( go_on && ioi_._action )
  {
    if( level == ioi_._action->type )
      go_on = FALSE;

    if( !ioi_action_break() )
      return FALSE;
  }

  if( !ioi_._action )
    ioi_out(0,IOI_DBG,"IOI-ACTION-HANDLER:Stack is empty");
  else
    ioi_out(0,IOI_DBG,"IOI-ACTION-HANDLER:Continuing with %s [%d]",
            ioi_._action->name,ioi_._action->type);

  return 0;
}

int ioi_action_break(void)
/**************************************************************************
?  Process the action stack, just break out of the top most one.
=  TRUE if ok, FALSE is an internal error. (Shouldn't happed, though.)
************************************o*************************************/
{
  ioi_gen *temp;

  switch( ioi_._action->type )
  {
    case IOI_L_REDIR:
      ioi_file_redirection_delete();
      break;

    case IOI_L_FILE:
      ioi_file_escape(TRUE);       /* Force close! */
      break;

    case IOI_L_CALL:
      ioi_function_return(-1,NULL);
      break;

    case IOI_L_CMD:
      ioi_token_delete( ((ioi_command *)ioi_._action)->cmd , TRUE );
      ioi_._action = (ioi_gen*)ioi_token_delete((ioi_token *)ioi_._action,FALSE);
      break;

    case IOI_L_VARIABLE:
      ioi_variable_pop(NULL);
      break;

    CASE_CONTROL:
      temp = ioi_._action->next;
      ioi_language_delete((ioi_control *)ioi_._action);
      ioi_._action = temp;
      break;

    default:
      ioi_out(0,IOI_ERR,"BREAK on %d is not applicable",ioi_._action->type);
      ioi_._action = ioi_._action->next;
      return( FALSE );
  }
  return( TRUE );
}
