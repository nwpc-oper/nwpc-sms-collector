/**************************************************************************
.TITLE    Input Output Interface
.NAME     LANGUAGE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     16-SEP-1991 / 29-NOV-1990 / OP
.VERSION  2.0
.FILE     language.c
.DATE     24-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.DATE     29-JUN-1994 / 15-JUN-1994 / OP
.VERSION  3.1
*         Added "STOP" capability for graphics programs
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*  Control structure
*    keywords       : "case"  "for"  "if"  "loop"  "while"
*    escapes        : "break" [-a]
*    terminators    : "end"keyword
*    other keywords : "in"  "step"  "then"  "else"  "do"
*
*  The control structure definition starts with one of the keywords followed
*  by the necessary tokens. While the new tokens are processed new lines may
*  be read and parsed into tokens.
*
*  The language substitution is carried out before the tokens are processed
*  for the command.
*
*  Examples:
*
*    case answer
*      in ( yes ok 1 ) do echo "--> $name"; < $name; endin
*      in ( )          do echo "skipping $name"; endin
*    endcase
*    for i 1 13 step 2 do echo File$i; cat $name$i; endfor
*    for i (s+10) (s*30-5) step (s/2.5+1) do echo $s; endfor
*    if($a == "b") then echo Yeah!; cat banner; else echo Nop!; endif
*    loop a (`ls -C *.ioi`) do include $a; endloop
*    while(a>1) do a=a-1; echo $a; endwhile
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

#define OUTLEN 80

static char *keys[] = { "case", "for", "if", "loop", "while" };
static int   maxcmd = sizeof(keys)/sizeof(char *);

int ioi_language_initialize(ioi_control *control)
/**************************************************************************
?  Initialize the control structure to be executed.
|  Move the current command pointer into the beginning of the commands
|  Start pointing the first value in IN_LIST and set VALUE to the START.
************************************o*************************************/
{
  ioi_command *command;

  if( !control ) return FALSE;

  if( IS_CONTROL(control->type) )
  {
    command        = control->command;
    control->cmd   = control->command;

    if( control->item )            /* Lets remove this later on */
      ioi_out(0,IOI_ERR,"IOI-LANGUAGE-INITIALIZE:Control item!");

    control->item  = NULL;

    if( control->type == IOI_L_FOR )
    {
      control->value = ioi_math_evaluate( control->start );
      ioi_variable_set_double(control->variable,control->value);
    }

    while( command )
    {
      if( IS_CONTROL(command->type) )
        ioi_language_initialize( (ioi_control *)command );
      command = command->next;
    }
  }

  return TRUE;
}

int ioi_language_execute(ioi_control *control)
/**************************************************************************
?  Execute the control structure.
|
|  Evulate the expression for IF and WHILE statements if the first command
|  is to be executed.
|
|  Advance the loop pointer for LOOP statement and value for FOR statement
|  if the last command has been executed.
|
|  CASE statement ???
|
|  Copy the tokens (copy the pointer value) for the next command if the
|  command is a simple command. Otherwise initialize the structure and
|  execute it.
|
|  Advance the current command pointer if the command was a simple one or
|  if the structure ended.
|
=  TRUE if a new command was made ready for execution
|  FALSE otherwise (expression was FALSE, end of loop, or end of commands)
************************************o*************************************/
{
  double end,step;                 /* for the FOR-statement */

  if( ioi_._disabled ) return FALSE;

  if( ioi_._event )
    if( (ioi_._disabled=ioi_._event()) )
      return FALSE;

  if( !control ) return( FALSE );

  if( !control->cmd )              /* End of the structure reached */
  {
    switch( control->type )
    {
      case IOI_L_CASE:
        break;
      case IOI_L_FOR:              /* GET THE VALUE OF THE VARIABLE! */
        control->value = ioi_variable_get_double(control->variable);
        step           = ioi_math_evaluate( control->step );
        end            = ioi_math_evaluate( control->end );

        control->value += step;
        ioi_variable_set_double(control->variable,control->value);

        if( ( step > 0  &&  end < control->value ) ||
            ( step < 0  &&  end > control->value ) )
          ;                        /* Last time in this loop? */
        else
          control->cmd = control->command;

        break;
      case IOI_L_IF:
        break;
      case IOI_L_LOOP:
        control->item = (ioi_token *)ioi_token_delete(control->item,FALSE);
        if( !strcmp(control->item->text,")") && !control->item->next )
        {
          control->item = (ioi_token *)ioi_token_delete(control->item,TRUE);
          return( FALSE );
        }
        else
          ioi_variable_set(control->variable,control->item->text);
        control->cmd = control->command;
        break;
      case IOI_L_WHILE:
        control->cmd = control->command;
        break;
    }
    if( !control->cmd )
      return( FALSE );
    ioi_language_initialize((ioi_control *)control->cmd);
  }

  if( control->cmd == control->command )
    switch( control->type )        /* In the beginning of the structure */
    {
      case IOI_L_CASE:             /* Nothin' */
        break;
      case IOI_L_FOR:
        ioi_variable_set_double(control->variable,control->value);
        break;
      case IOI_L_IF:
        if( ! ioi_math_truth( control->expression ) )
          control->cmd = control->other;
        break;
      case IOI_L_LOOP:

        if( !control->item ) 
        {
          ioi_token *temp = ioi_._token;
          ioi_._token  = (ioi_token *)ioi_token_copy(control->in_list);

          if( ioi_variable_substitute() )
            if( ioi_shell_substitute() )
              ; /* Donno! this should work! */

          control->item = ioi_._token;
          ioi_._token = temp;      /* Should be NULL anyway! */

          if( !strcmp(control->item->text,"(") )
            control->item = (ioi_token *)ioi_token_delete(control->item,FALSE);
        }

        if( !strcmp(control->item->text,")") && !control->item->next )
        {
          control->item = (ioi_token *)ioi_token_delete(control->item,TRUE);
          control->cmd=NULL;
          return( FALSE );
        }
        else
          ioi_variable_set(control->variable,control->item->text);

        break;
      case IOI_L_WHILE:
        if( ! ioi_math_truth( control->expression ) )
          control->cmd = NULL;
        break;
    }

  if( control->cmd )
  {
    if( IS_CONTROL(control->cmd->type) )
    {
      if( ioi_language_execute((ioi_control *)control->cmd) )
        return( TRUE );
      else
        control->cmd = control->cmd->next;

      ioi_language_initialize((ioi_control *)control->cmd);
    }
    else
      if( control->type==IOI_L_CASE )
      {
        ioi_variable *variable;
        ioi_control  *control2;
        ioi_token    *token;

        if( control->casecmd )     /* Check current case branch */
        {
          if( IS_CONTROL(control->casecmd->type) )
          {
            if( ioi_language_execute((ioi_control *)control->casecmd) )
              return( TRUE );
            else
              control->casecmd = control->casecmd->next;

            ioi_language_initialize((ioi_control *)control->casecmd);

            if( !control->casecmd )/* Next in-branch if this is last cmd */
              /* control->cmd = control->cmd->next; */
              control->cmd = NULL; /* Break out from the case */
          }
          else                     /* Just copy the commands and advance */
          {
            ioi_._stack = (ioi_token *)
            ioi_token_copy(control->casecmd->cmd);

            control->casecmd = control->casecmd->next;
            ioi_language_initialize((ioi_control *)control->casecmd);

            if( !control->casecmd )/* Next in-branch if this is last cmd */
              /* control->cmd = control->cmd->next; */
              control->cmd = NULL; /* Break out from the case */
          }
        }
        else          /* Let's find out does variable belong into this list */
          if( variable=(ioi_variable *)    /* Variable exists? */
              ioi_list_get(IOI_L_VARIABLE,control->variable,FALSE) )
          {
            ioi_token *temp = ioi_._token;

            control2 = (ioi_control *)control->cmd;
            ioi_._token = (ioi_token *)ioi_token_copy(control2->in_list);

            if( ioi_variable_substitute() )
              if( ioi_shell_substitute() )
                ; /* Donno! this should work! */

            token    = ioi_._token;

            token = token->next;   /* Remove if '(' not in list! */

            if( ls_len(&token) == 1 ) /* Change if () not in list */
            {
              control->casecmd = control2->command;
              ioi_language_initialize((ioi_control *)control->casecmd);
            }
            else                   /* Scan the in-list */
            {
              while( token )       /* Change this if ... */
              {
                if( token->next && ! strcmp(token->text,variable->definition) )
                {
                  control->casecmd = control2->command;
                  ioi_language_initialize((ioi_control *)control->casecmd);
                  break;           /* Found match, let's break out! */
                }
                token = token->next;
              }
              if( ! token )        /* Nop. Check next branch, next time */
              {
                control->cmd = control->cmd->next;
                ioi_language_initialize((ioi_control *)control->cmd);
              }
            }

            ioi_token_delete(ioi_._token,0);
            ioi_._token = temp;      /* Should be NULL anyway! */
          }
          else                     /* ERROR in variable! */
          {
            control->cmd = NULL;   /* Terminate this structure */
            return( FALSE );       /* Generate warning? */
          }
      }
      else                         /* Just copy the commands and advance */
      { 
        if(!(ioi_._stack=(ioi_token *)ioi_token_copy(control->cmd->cmd)))
          return( FALSE );
        control->cmd = control->cmd->next;
        ioi_language_initialize((ioi_control *)control->cmd);
      }
  }
  else
    return( FALSE );

  return( TRUE );
}

int ioi_language_break(int argc, char **argv)
/**************************************************************************
?  Break out from the innermost control structure (the cmd is plain break)
|  or the innermost named break (eg breakfor breaks out of innermost for.)
=  TRUE if the break was successfull
|  FALSE if the named control structure couldn't be found.
************************************o*************************************/
{
  static int   called;
  static int   all;

  ioi_control *control;

  if( called )
  {
    if( all )
      ioi_action_handler(-1);
    else
      return ioi_out(0,IOI_WAR,"IOI-LANGUAGE-BREAK:Break is NA");
  }
  else
    ioi_exe_add("break:ioi",ioi_language_break,
      ioi_exe_param("-aall",IOI_L_BOOLEAN,ioi_exe_argv(
          "Break out of all loops. This may be used in an emergency exits.",
          NULL
        ),NULL,1,&all
      ),
      NULL,
      ioi_exe_argv(
        "Break out from the loops.",
        "Break out form the for, loop and while structures.",
        "","NOTICE","",
        "At the moment, only the all option works",
        NULL
      )
    );

  return called=TRUE;
}

/**************************************************************************
*
*           D E F I N I T I O N S   F O R   C L A R I T Y (joke)
*
************************************o*************************************/

#define DELETE if(!(token=(ioi_token *) \
                 ioi_token_pop(TRUE,TRUE,depth))) goto error
#define NEXT   if(!(token=(ioi_token *) \
                 ioi_token_pop(FALSE,TRUE,depth))) goto error
#define POP    token=(ioi_token *)ioi_token_pop(TRUE,FALSE,depth)
#define THIS       token = ioi_._token
#define NUMBER(x)  if( ! ioi_token_number(token,(x)) ) goto error;
#define IFWORD(x)  if( ! strcmp(x,token->text) )

#define MATH(x,exp,tmp)  \
      tmp = ioi_._token; ioi_._token = exp; \
      ioi_math_token(FALSE); (x) = (ioi_node *)ioi_math_make(); \
      ioi_token_delete(exp,TRUE); ioi_._token = tmp;

ioi_token *ioi_language_create_list(
    ioi_token *token,              /* The first token */
    int        type,
    int        depth)
/**************************************************************************
?  Create a necessary list for different type of commands
|  The token should be pointing at the current token, AFTER the keyword.
=  NULL in case of any errors, otherwise a list of token.
************************************o*************************************/
{
  ioi_token *start = NULL;
  ioi_token *last  = NULL;
  int        paran = 1;

  if( type == IOI_L_FOR )
    IFWORD("(") ; else 
    {
      ioi_token *temp = token;
      NEXT;
      temp->next = NULL;
      return( temp );
    }

  IFWORD("(") ; else return( NULL );

  start = last = token;
  NEXT;

  switch( type )
  {
    case IOI_L_CASE:               /* We shouldn't be here */
      break;
    case IOI_L_CASEIN:             /* in   ( list ) do ... done */
    case IOI_L_LOOP:               /* loop ( list ) do ... done */
      while( TRUE )
      {
        last->next = token;
        last = last->next;

        IFWORD(")") { NEXT; last->next=NULL; return( start ); }
        NEXT;
      }
      /* break; */

    case IOI_L_FOR:                /* for x (exp) (exp) step (exp) do ... */
    case IOI_L_IF:                 /* if    ( expression ) then ... xx */
    case IOI_L_WHILE:              /* while ( expression ) do ... done */
      while( TRUE )
      {
        last->next = token;

        IFWORD("(") { paran++; depth++; }

        last = last->next;

        IFWORD(")")
          if( --paran )
            depth--;
          else
          { NEXT; last->next=NULL; return( start ); }

        NEXT;
      }
      /* break; */

    default:
      return( NULL );
  }

  error:

  if( start ) ioi_token_delete(start,TRUE);

  return( NULL );
}

ioi_command *ioi_language_create_command(int depth)
/**************************************************************************
?  Create a command from the token list.
=  NULL in case of any errors, otherwise a list of token.
************************************o*************************************/
{
  ioi_token   *token;
  ioi_control *control;
  ioi_command *command = NULL;
  int          type;

  THIS;

  if( (type = ioi_user_cmdf(token->text,keys,NULL,maxcmd)) != (-1) )
  {
    if( !(control = ioi_language_create(type+IOI_L_CASE,depth)))
      goto error;

    return( (ioi_command *)control );
  }

  if( !(command=SALLOC(ioi_command)) )
  {
    ioi_out(0,IOI_ERR,"IOI-LANGUAGE-CREATE-CMD:No mem.");
    return 0;
  }

  command->cmd = token;
  command->type = IOI_L_CMD;

  ioi_._token = NULL;

  return( command );

  error:

  ioi_out(0,IOI_ERR,"IOI-LANGUAGE-CREATE-COMMAND:Control creation failed");

  if( command )
  {
    ioi_token_delete( command->cmd  , TRUE );
    free( command );
  }

  return( NULL );
}

ioi_control *ioi_language_delete(ioi_control *control)
/**************************************************************************
?  Delete the control structure created by the _create().
|  Even an unfinished one can be deleted.
************************************o*************************************/
{
  ioi_command *command,*tmp_command;
  ioi_token   *token;

  if( !control ) return( NULL );

  while( control->command || control->other )
  {
    command = control->command?control->command:control->other;
    if(control->command) control->command = NULL;
    else control->other = NULL;
    while(command)
    {
      tmp_command = command->next;
      if( IS_CONTROL(command->type) )
        ioi_language_delete( (ioi_control *)command );
      else
      {
        ioi_token_delete(command->cmd,TRUE);
        free(command);
      }
      command = tmp_command;
    }
  }

  if(control->expression) ioi_math_delete( control->expression );
  ioi_token_delete( control->in_list,TRUE );

  if( control->item ) ioi_token_delete(control->item,TRUE);

  if( control->type == IOI_L_FOR || control->type == IOI_L_LOOP )
  {
    IFFREE( control->variable );
    if(control->start) ioi_math_delete( control->start );
    if(control->end  ) ioi_math_delete( control->end   );
    if(control->step ) ioi_math_delete( control->step  );
  }

  free(control);
  return( NULL );
}

ioi_control *ioi_language_create(int type, int depth)
/**************************************************************************
?  Create a command structure from the input token stream. If not enough
|  tokens ask for more until matchimg pair of begin and close structures
|  have been found.
=  NULL if errors, otherwise the pointer for the command structure.
************************************o*************************************/
{
  ioi_token   *token,*expression,*temp;
  ioi_control *control;
  ioi_command *start=NULL,*last=NULL,*command=NULL;
  char        end_cmd[20];
  int         newtype;
  int         more_commands = TRUE;

  depth++;
  expression = NULL;

  if( !(control=SALLOC(ioi_control)) )
    return (ioi_control *)
      ioi_out(0,IOI_ERR,"IOI-LANGUAGE-CREATE-1:No mem.");

  control->type = type;

  THIS; sprintf(end_cmd,"end%s",token->text);
  DELETE;

  switch( type )
  {
    case IOI_L_CASE:
      if( !(control->variable = strdup(token->text)) ) goto error;
      DELETE;
      break;
    case IOI_L_CASEIN:
      if( !(control->in_list = ioi_language_create_list(token,type,depth)) )
        goto error;
      THIS;
      IFWORD("do") ; else goto error;
      DELETE;
      break;
    case IOI_L_FOR:
      if( !(control->variable = strdup(token->text)) ) goto error;
      DELETE;

      if( !(expression = ioi_language_create_list(token,type,depth)) )
        goto error;
      MATH( control->start,expression,temp );
      THIS;

      if( !(expression = ioi_language_create_list(token,type,depth)) )
        goto error;
      MATH( control->end,expression,temp );
      THIS;

      IFWORD("step")
      {
        DELETE;
        if( !(expression = ioi_language_create_list(token,type,depth)) )
          goto error;
      }
      else
        expression = ioi_token_create("1");
      MATH( control->step,expression,temp );
      THIS;

      IFWORD("do") ; else goto error;
      DELETE;
      break;
    case IOI_L_IF:
      if( !(expression = ioi_language_create_list(token,type,depth)) )
        goto error;
      THIS;
      IFWORD("then") ; else goto error;
      DELETE;
      MATH( control->expression,expression,temp );
      break;
    case IOI_L_LOOP:
      if( !(control->variable = strdup(token->text)) ) goto error;
      DELETE;
      if( !(control->in_list = ioi_language_create_list(token,type,depth)) )
        goto error;
      THIS;
      IFWORD("do") ; else goto error;
      DELETE;
      break;
    case IOI_L_WHILE:
      if( !(expression = ioi_language_create_list(token,type,depth)) )
        goto error;
      THIS;
      IFWORD("do") ; else goto error;
      DELETE;
      MATH( control->expression,expression,temp );
      break;
  }

  /* LOOP FOR THE COMMANDS */

  while( more_commands )
    if( ! strcmp(end_cmd,token->text) || 
      ( type == IOI_L_IF && ! strcmp("else",token->text) ) )
    {
      more_commands = FALSE;
    }
    else
    {
      if( !(command =
             (type==IOI_L_CASE)?
               (ioi_command *)ioi_language_create(IOI_L_CASEIN,depth) :
               ioi_language_create_command(depth)
           )   ) goto error;

      if( !start )
        start = last = command;
      else
      {
        last->next = command;
        last = command;
      }
      NEXT;
    }

  control->command = start;

  if( type == IOI_L_IF && !strcmp("else",token->text) )
  {
    DELETE;
    more_commands = TRUE;
    start = last = NULL;

    while( more_commands )
      IFWORD(end_cmd)
      {
        more_commands = FALSE;
      }
      else
      {
        if( ! (command=ioi_language_create_command(depth)) )
          goto error;

        if( !start )
          start = last = command;
        else
        {
          last->next = command;
          last = command;
        }
        NEXT;
      }
    control->other = start;
  }

  POP;

  return( control );

  error:

  ioi_language_delete(control);
  ioi_token_delete_command();
  return( NULL );
}

void ioi_language_here_documnet(int depth)
/**************************************************************************
?  Extract here document and genereate a temp file for if.
|  Use tempname for the file name.
!  Currently unimplemented!
************************************o*************************************/
{
  depth++; 
}

/**************************************************************************
*
*       C A L L E D   O U T S I D E   O F   T H I S   M O D U L E
*
************************************o*************************************/

int ioi_language_substitute(void)
/**************************************************************************
?  Check the current command against the control statements. If control
|  is found, build the internal structure.
=  ?
************************************o*************************************/
{
  ioi_control *control;
  int          type;

  if( ! ioi_._token ) return( TRUE );

  if( (type = ioi_user_cmdf(ioi_._token->text,keys,NULL,maxcmd)) == (-1) ||
      type == maxcmd )
    return( TRUE );

  if( !(control = (ioi_control *)
    ioi_language_create(type+IOI_L_CASE,0)))
      return
        ioi_out(TRUE,IOI_ERR,"IOI-LANGUAGE-SUBSTITUTION:Substitution failed");

  ioi_language_initialize( control );

/*
  ioi_language_list(control,2);
*/

  if( ioi_._stack )                /* Rest of the tokens ==> action stack */
  {
    ioi_command *command;

    if( !(command=SALLOC(ioi_command)) )
    {
      ioi_language_delete(control);
      return ioi_out(FALSE,IOI_ERR,"IOI-LANGUAGE-SUBSTITUTION:No mem.");
    }

    command->cmd = ioi_._stack;
    command->type = IOI_L_CMD;

    ioi_._stack = NULL;

    command->next = (ioi_command *) ioi_._action; /* Add into action stack */
    ioi_._action  = (ioi_gen *) command;
  }

  control->next = (ioi_gen *) ioi_._action;       /* Add into action stack */
  ioi_._action  = (ioi_gen *) control;

  return( TRUE );
}

/**************************************************************************
*
*  D E B U G G I N G   O F   T H E   C O N T R O L   S T R U C T U R E S
*
************************************o*************************************/

#define INDENT for(i=0;i<indentation;i++) printf(" ") /* Effective? Jee! */

int ioi_language_list_tokens(ioi_token *token, int indentation)
/**************************************************************************
?  Print out a list of tokens using indentation given.
|  Used for debugging.
************************************o*************************************/
{
  int i;
  int len;

  len = indentation;

  while( token )
  {
    printf("%s",token->text);
    len += strlen(token->text);

    if( token = token->next )
    {
      if(len > OUTLEN)
      {
        printf(" \\\n");
        INDENT;
        len = indentation;
      }
      else
      {
        printf(" "); len++; 
      }
    }
  }
  printf("\n");

  return 0;
}

void ioi_language_list_command(ioi_command *command, int indentation)
/**************************************************************************
?  Print out a single command structure
|  Used for debugging.
************************************o*************************************/
{
  ioi_token *token;
  int        i;

  if(!command) return;

  if( command->type == IOI_L_CMD )
  {
    INDENT;
    ioi_language_list_tokens( command->cmd,indentation );
  }
  else
    ioi_language_list((ioi_control *)command,indentation);
}

void ioi_language_list(ioi_control *control, int indentation)
/**************************************************************************
?  Print out the command structure
|  Used for debugging.
************************************o*************************************/
{
  ioi_command *command;
  int          i;
  char         *name;              /* Keyword name */

  if( !(IS_CONTROL(control->type) || control->type==IOI_L_CASEIN) ) return;

  name = (control->type==IOI_L_CASEIN)? "in" : keys[control->type-IOI_L_CASE];

  INDENT; printf("%s",name);

  switch(control->type)
  {
    case IOI_L_CASE:
      printf(" %s\n",control->variable);
      break;
    case IOI_L_CASEIN:
      ioi_language_list_tokens( control->in_list,indentation );
      INDENT; printf("do\n");
      break;
    case IOI_L_FOR:
      printf(" %s ",control->variable );
      ioi_math_list( stdout,control->start,1 );
      printf(" ");
      ioi_math_list( stdout,control->end  ,1 );
      printf(" step ");
      ioi_math_list( stdout,control->step ,1 );
      printf("\n");
      INDENT; printf("do\n");
      break;
    case IOI_L_IF:
      ioi_math_list( stdout,control->expression,TRUE );
      printf("\n");
      INDENT; printf("then\n");
      break;
    case IOI_L_LOOP:
      printf(" %s ",control->variable);
      ioi_language_list_tokens( control->in_list,indentation );
      INDENT; printf("do\n");
      break;
    case IOI_L_WHILE:
      ioi_math_list( stdout,control->expression,TRUE );
      printf("\n");
      INDENT; printf("do\n");
      break;
  }

  indentation += 2;

  if( !(command = control->command) )
  {
    INDENT; printf(";\n");
  }
  else
    while( command )
    {
      if( control->type == IOI_L_CASE )
        ioi_language_list( (ioi_control *)command,indentation );
      else
        ioi_language_list_command( command,indentation );
      command = command->next;
    }
  
  if( control->type == IOI_L_IF && (command = control->other) )
  {
    indentation -= 2;
    INDENT; printf("else\n");
    indentation += 2;

    while( command )
    {
      ioi_language_list_command( command,indentation );
      command = command->next;
    }
  }

  indentation -= 2;
  INDENT; printf("end%s\n",name);
}
