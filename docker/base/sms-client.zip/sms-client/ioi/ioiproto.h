/**************************************************************************
.TITLE   Input Output Interface
.NAME    PROTOTYPES HEADER FILE
.SECTION LIB
.AUTHOR  Otto Pesonen
.DATE    01-FEB-1999 / 31-JUL-1998 / OP
.VERSION 3.4
.FILE    ioiproto.h
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991-1998
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#ifndef IOI_PROTO_H
#define IOI_PROTO_H

/* action.c */

void ioi_action_catch(int sig);
int  ioi_action_c_break(int mode);
int  ioi_action_is_there(int what);
int  ioi_action_is_there_redir(int err);
int  ioi_action_handler(int level);
int  ioi_action_break(void);

/* alias.c */

int ioi_alias_substitute(void);
int ioi_alias_create(int argc, char **argv);
int ioi_alias_delete(int argc, char **argv);

/* cmd.c */

int   ioi_cmd_args(int argc, char **argv);
int   ioi_cmd_cat(int argc, char **argv);
int   ioi_cmd_cd(int argc, char **argv);
char *ioi_cmd_date_str(void);
int   ioi_cmd_echo(int argc, char **argv);
int   ioi_cmd_exit(int argc, char **argv);
int   ioi_cmd_input(int argc, char **argv);
int   ioi_cmd_ioi(int argc, char **argv);
int   ioi_cmd_local(int argc, char **argv);
int   ioi_cmd_memcheck(int argc, char **argv);
int   ioi_cmd_sleep(int argc, char **argv);
char *ioi_cmd_time_str(void);
int   ioi_cmd_time(int argc, char **argv);

/* ed.c */

void ioi_ed_init(FILE *in, FILE *out);
void ioi_ed_exit(void);
void ioi_ed(int truth);

/* exe.c */

char     **ioi_exe_argv(char *first, ...);
int        ioi_exe_delete_argv(int argc, char **argv);
int        ioi_exe_argc(char **argv);
ioi_param *ioi_exe_param(char *pname, ...);
ioi_param *ioi_exe_link_param(ioi_param *first, ...);
void       ioi_exe_param_list(ioi_param *param);
int        ioi_exe_list(char *name,int level, char *section);
ioi_exe   *ioi_exe_create(char *name, int (* call)(int, char**),
                          ioi_param *options, ioi_param  *parameters, char **man);
ioi_exe   *ioi_exe_add(char *name, int (* call)(int, char **), ioi_param *options,
                       ioi_param  *parameters, char **man);
int        ioi_exe_delete(ioi_exe *exe);
void       ioi_exe_def_param(ioi_param *param);
int        ioi_exe_check_param(ioi_param *param);
int        ioi_exe_substitute(ioi_exe *prg, int ac, char **av);
char      *ioi_exe_options(char *s);
void       ioi_execute(void);

/* file.c */

int   ioi_perror(char *callname, char *arg);
void  ioi_file_input(char *line);
int   ioi_printf(int code, char *fmt, ...);
int   ioi_out(int code, int type, char *fmt, ...);
void  ioi_file_prompt(int level);
int   ioi_file_read(int secondary);
char *ioi_file_substitute(char *name);
void  ioi_file_purge(void);
int   ioi_file_include(char *name);
char *ioi_file_here_document(char *eof, int strip);
char *ioi_file_redirect_fd(int fd, char *name, int compress, int append, int join);
int   ioi_file_redirect(void);
void  ioi_file_restore(void);
int   ioi_file_redirection_create(void);
int   ioi_file_redirection_delete(void);
int   ioi_file_escape(int force);
int   ioi_file_log(char *name, int append);
int   ioi_file_close(int argc, char **argv);

/* function.c */

int ioi_function_create(int argc, char **argv);
int ioi_function_delete(int argc, char **argv);
int ioi_function_check(void);
int ioi_function_substitute(void);
int ioi_function_execute(char *name, double *arg);
int ioi_function_return(int argc, char **argv);

/* history.c */

int  ioi_history_create(void);
int  ioi_history_substitute(void);
void ioi_history_set(int len);
int  ioi_history_cmd(int argc, char **argv);

/* ioi.c */

int  ioi_try_name(char *name);
int  ioi_open(int argc, char **argv, char *name);
int  ioi_set_stack_size(int newsize);
int  ioi_set_line_size(int newsize);
void ioi_close(void);
int  ioi_check_internal(void);
int  ioi_internal_help(void);
int  ioi_internal(int help_return);
int  ioi_cmd(int help_return);
int  ioi_load_command(void);
int  ioi_parse_args(int *ac, char ***av, char c);

/* language.c */

int          ioi_language_initialize(ioi_control *control);
int          ioi_language_execute(ioi_control *control);
int          ioi_language_break(int argc, char **argv);
ioi_token   *ioi_language_create_list(ioi_token *token, int type, int depth);
ioi_command *ioi_language_create_command(int depth);
ioi_control *ioi_language_delete(ioi_control *control);
ioi_control *ioi_language_create(int type, int depth);
void         ioi_language_here_documnet(int depth);
int          ioi_language_substitute(void);
int          ioi_language_list_tokens(ioi_token *token, int indentation);
void         ioi_language_list_command(ioi_command *command, int indentation);
void         ioi_language_list(ioi_control *control, int indentation);

/* link.c */

int ioi_link_cmd(int argc, char **argv);
int ioi_unlink_cmd(int argc, char **argv);

/* list.c */

ioi_gen *ioi_list_start(int type);
ioi_gen *ioi_list_get(int type, char *name, int numflag);
int      ioi_list_mlen(int type);
int      ioi_list_print_all(int type, int columns);
int      ioi_list_print(int type, char *name);
int      ioi_list_add(int type, ioi_gen *newone);
ioi_gen *ioi_list_copy(int type, ioi_gen *old, int all);
int      ioi_list_delete(int type, char *name);
int      ioi_list_delete_all(int type);

/* man.c */

char *ioi_man_title(char *buff, int len, ioi_exe *exe);
int   ioi_man_cmd(int argc, char **argv);
int   ioi_man_manload(int argc, char **argv);
int   ioi_man_add(char *name, ioi_token *token);
int   ioi_man_read(char *name);

/* math.c */

int       ioi_math_token(int nmode);
int       ioi_math_next(void);
ioi_node *ioi_math_new(void);
ioi_node *ioi_math_make(void);
double    ioi_math_function(ioi_node *node);
double    ioi_math_evaluate(ioi_node *node);
int       ioi_math_truth(ioi_node *node);
int       ioi_math_is_set(void);
int       ioi_math_is_calc(void);
int       ioi_math_delete(ioi_node *node);
int       ioi_math_list(FILE *fp, ioi_node *node, int mode);
void      ioi_math_list_tree(ioi_node *node, int indent);

/* misc.c */

int ioi_misc_arg(char *name, int argc, char **argv);
int ioi_misc_token(char *name, ioi_token *token);
int ioi_misc_arg_fill(char **argv, ...);
int ioi_misc_no_args(int argc, char **argv);
int ioi_misc_file_ptr(char *name, FILE *fp);
int ioi_misc_status(int mode);

/* shell.c */

ioi_token *ioi_shell_get(char *cmd);
int        ioi_shell_substitute(void);
int        ioi_shell_system(int mode, int argc, char **argv);

/* token.c */

int        ioi_token_number(ioi_token *token, int *x);
ioi_token *ioi_token_create(const char *text);
ioi_token *ioi_token_delete(ioi_token *token, int all);
int        ioi_token_join(ioi_token *token, char *text);
int        ioi_token_replace(ioi_token **token, char **to, ioi_token *by, int mode);
void       ioi_token_skip_command(void);
ioi_token *ioi_token_pop(int purge, int more, int depth);
int        ioi_token_push(ioi_token *token);
void       ioi_token_rethink(void);
void       ioi_token_remove_empty(void);
void       ioi_token_delete_command(void);
ioi_token *ioi_token_copy(ioi_token *token);
ioi_token *ioi_token_build(int argc, char **argv);
ioi_token *ioi_token_parse(char *buff, int mode);
int        ioi_token_stack(int secondary);
void       ioi_token_group(void);

/* user.c */

int  ioi_user_prompt_load(char *prompt);
int  ioi_user_prompt_add(char *newone);
void ioi_user_prompt_delete(void);
int  ioi_user_cmd(int *argc, char ***argv);
int  ioi_user_menu(char *name, int *argc, char ***argv, char **cmds,
                   char **helps, int *lengths, int *parameters, int maxcmd);
int  ioi_user_menu_display(char **cmds, char **helps, int *lengths,
                          int *parameters, int maxcmd);
int  ioi_user_cmdf(char *command, char **cmds, int *cmdlen, int maxcmd);
int  ioi_user_fmcl(char **cmd, int *cmdl, int maxcmd);
int (* ioi_user_input(int (*routine)()))();
int ioi_user_dummy(char *buff, int size, int prompt);
int  ioi_user_execute(char *line);
int (* ioi_user_output (int (*routine)()))();
int (* ioi_user_exit(int (*routine)()))();
int (* ioi_user_event(int (*routine)()))();
int ioi_user_enable(void);

/* variable.c */

void   ioi_variable_pop(ioi_variable *var);
int    ioi_variable_push(char *name);
void   ioi_variable_init(void);
int    ioi_variable_help(void);
int    ioi_variable_internal(int cmd, int argc, char **argv);
int    ioi_variable_flag(char *text);
int    ioi_variable_create(int argc, char **argv);
int    ioi_variable_delete(int argc, char **argv);
char  *ioi_variable_specials(char *name);
int    ioi_variable_shift(int argc, char **argv);
int    ioi_variable_substitute(void);
int    ioi_variable_set_int(char *name, int value);
int    ioi_variable_set_double(char *name, double value);
int    ioi_variable_set(char *name, char *text);
double ioi_variable_get_double(char *name);
int    ioi_variable_get_int(char *name);
char  *ioi_variable_get(char *name);
int    ioi_variable_unset(char *name);

#endif  /* IOI_PROTO_H */
