/**************************************************************************
.TITLE    Input Output Interface
.NAME     VARIABLES
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     11-SEP-1992 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     variable.c
.DATE     24-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-JUL-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     12-MAY-1995 / 12-MAY-1995 / OP
.VERSION  3.2
*         Command line editing added
-NOTICE Some of this stuff will be superseded by the libls
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

void ioi_variable_pop(ioi_variable *var)
/**************************************************************************
?  Pop the global variable back from the stack.
************************************o*************************************/
{
  if( var )                        /* From the CALL or FUNCTION */
  {
/*
    for(temp=var->next ; var ; var=temp,temp=temp?temp->next:NULL )
*/
    while( var )
    {
      ioi_variable *temp;

      temp = var->next;
      ioi_variable_unset(var->name);   /* Remove the current */

      if(var->definition)              /* If it was defined put it back */
        ioi_variable_set(var->name,var->definition);

      IFFREE(var->definition);         /* Remove the copy */
      free(var->name);
      free(var);
      var = temp;
    }
    return;
  }
  
  if( var = (ioi_variable *)ioi_._action )   /* Command line local */
    if( var->type == IOI_L_VARIABLE )
    {
      ioi_variable_unset(var->name);

      if(var->definition)
        ioi_variable_set(var->name,var->definition);

      ioi_._action = ioi_._action->next;

      IFFREE(var->definition);
      free(var->name);
      free(var);
    }
    else
      ; /* Not a variable */
  else
    ; /* No action */
}

int ioi_variable_push(char *name)
/**************************************************************************
?  Push a global variable into the stack.
************************************o*************************************/
{
  ioi_call     *call;              /* Function or file call */
  ioi_variable *var,*old;
  char         *definition = NULL; /* MUST be empty if not found! */

  if(!(var=SALLOC(ioi_variable)))
    return ioi_out(0,IOI_ERR,"IOI-VARIABLE-PUSH:No mem.");

  if( (old=(ioi_variable *)ioi_list_get(IOI_L_VARIABLE,name,0)) )
  {
    definition = strdup(old->definition);
    ioi_list_delete(IOI_L_VARIABLE,name);
  }

  var->definition = definition;
  var->name       = strdup(name);
  var->type       = IOI_L_VARIABLE;

  for(
    call = (ioi_call *)ioi_._action;
    call && ! (call->type==IOI_L_FILE || call->type==IOI_L_CALL);
    call = (ioi_call *)call->next
     ) ;

  if( call )                       /* Mark it to be restored @ EOF */
  {
    var->next   = (ioi_variable *)call->local;
    call->local = var;
  }
  else                             /* Push it into action stack */
  {
    var->next = (ioi_variable *)ioi_._action;
    ioi_._action = (ioi_gen *)var;
  }

  return 0;
}

/**************************************************************************
*                DEFAULT VALUES FOR INTERNAL VARIABLES
************************************o*************************************/
                      /* ECHO   ERR    WAR    MSG    LOG    DBG  */
static int def_msg[] = { FALSE, TRUE,  TRUE,  TRUE,  FALSE, FALSE };
static int def_log[] = { TRUE,  TRUE,  TRUE,  TRUE,  TRUE,  FALSE };

static char *cmds[] = {
  "echo",     "error",    "warning",  "message",  "logging",  "debug",
  "_echo",    "_error",   "_warning", "_message", "_logging", "_debug",
  "brief",    "break",
  "editor",

  "history",   "line",      "arguments",

  "prompt",    "time",      "date",
};

/*
  "ignorespace",
  "automenu",
  "autoapth",
  "sensitive",

  "line concatenating character may be followed by spaces",
  "display the menus automatically before issuing the prompt",
  "the prompt should reflect the menu structure",
  "case sensitivity for commands",
*/

static char *helps[] = {
  "on/off input on the stdout",
  "on/off on the stdout",
  "on/off on the stdout",
  "on/off on the stdout",
  "on/off on the stdout",
  "on/off on the stdout",

  "on/off echo the input into the log-file",
  "on/off into the log-file",
  "on/off into the log-file",
  "on/off into the log-file",
  "on/off into the log-file",
  "on/off into the log-file",

  "on/off output from messages",
  "on/off the terminal kill action",
  "on/off line editing a'la vi",

  "number of lines to store in the history",
  "internal line buffer size",
  "internal argument buffer size (read only)",

  "issued before the input",
  "current time (read only)",
  "current date (read only)",
};  

static int params[] = {
  1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1,
  1, 1, 1,
  1, 1, 1 ,
  1, 0, 0 
};

static int maxcmd = sizeof(cmds) / sizeof(char *);

void ioi_variable_init(void)
/**************************************************************************
?  Internal variable initialization
************************************o*************************************/
{
  int i;

  ioi_variable_create(0,NULL);

  for( i=0 ; i<6 ; i++ ) ioi_variable_set_int(cmds[i  ],def_msg[i]);
  for( i=0 ; i<6 ; i++ ) ioi_variable_set_int(cmds[i+6],def_log[i]);

  ioi_variable_set_int("brief",FALSE);
  ioi_variable_set_int("break",FALSE);
  ioi_variable_set_int("editor",FALSE);

  ioi_variable_set_int("history",52);
  ioi_variable_set_int("line",MAXLEN);

  sprintf(ioi_._line,"%d",MAXARG);
  ioi_variable_set("arguments",ioi_._line);

  ioi_variable_set("prompt","IOI");
}

int ioi_variable_help(void)
/**************************************************************************
?  Print help messages of the variables
************************************o*************************************/
{
  ioi_printf(FALSE,"IOI-INTERNAL-VARIABLES\n\n");
  ioi_user_menu_display(cmds,helps,NULL,params,maxcmd);

  return( TRUE );
}

int ioi_variable_internal(int cmd, int argc, char **argv)
/**************************************************************************
?  Internal variable manipulation.
************************************o*************************************/
{
  int    truth = 0;                /* For the boolean variables */

  if( cmd>=0 && cmd<=14 )          /* Boolean variables */
  {
    truth = ioi_variable_flag(argv[1]);

    argv[1][0] = (truth)? '1' : '0';
    argv[1][1] = '\0';

    if( cmd>=0 && cmd<=5 )
      ioi_._msg[cmd] = truth;
    if( cmd>=6 && cmd<=11 )
      ioi_._log[cmd-6] = truth;
    switch(cmd)
    {
      case 12:
        ioi_._brief = truth;
        break;

      case 13:
        ioi_action_c_break(truth);
        break;

      case 14:
        ioi_ed(truth);
        break;
    }
  }

  if( cmd >= 15 && cmd <= 17 )     /* Integer variables */
  {
    truth = atoi(argv[1]);

    switch( cmd )
    {
      case 15:
        ioi_history_set(truth);
        truth = ioi_._hist_len;
        break;

      case 16:
        if( !ioi_set_line_size(truth) ) return FALSE;
        break;

      case 17:
        return FALSE;
/*
        return ioi_out(0,IOI_WAR,"IOI-VARIABLE-INTERNAL:Read only [%s]",*argv);
*/
        /* if( !ioi_set_stack_size(truth) ) return FALSE; */
        /* break; */
    }

    sprintf(argv[1],"%d",truth);
  }

  if( cmd >= 18 && cmd <= 20 )     /* Character variables */
  {
    switch( cmd )
    {
      case 18:
        ioi_user_prompt_load(argv[1]);
        break;

      case 19:
      case 20:
        return ioi_out(0,IOI_WAR,"IOI-VARIABLE-INTERNAL:Read only [%s]",*argv);
        /* break; */
    }
  }

  return( TRUE );
}

int ioi_variable_flag(char *text)
/**************************************************************************
?  Check what was given to the status for a boolean variable.
|  The boolean value may be given as (case doesn't matter)
|    FALSE: "off"   "no"   "false"   0
|    TRUE:  "on"    "yes"   "true"   any nonzero number
|  The words can be shortened as long as they are unambiguous.
=  FALSE or TRUE if ok
|  -1 for any errors
************************************o*************************************/
{
  static char *cmds[] = { "off","on", "no","yes", "false","true" };
  static int   lengths[ sizeof(cmds) / sizeof(char *) ];
  static int   first_time = TRUE;
  int          maxcmd     = sizeof(cmds) / sizeof(char *);
  int          sensitive  = ioi_._sensitive;
  int          rc;

  ioi_._sensitive = FALSE;         /* NOT in 2.0 but may come later on */

  if(first_time)
  {
    ioi_user_fmcl(cmds,lengths,maxcmd);
    first_time = FALSE;
  }

  if( isdigit(*text) )
  {
    rc = atoi(text);
    while( *text )
      if( ! isdigit(*text) )
        return NIL;
      else
        text++;

    return rc? TRUE:FALSE;
  }

  rc = ioi_user_cmdf(text,cmds,lengths,maxcmd);
  ioi_._sensitive = sensitive;

  if( rc == (-1) ) return (-1);
 
  return (rc % 2); 
}

int ioi_variable_create(int argc, char **argv)
/**************************************************************************
?  Set a new value to an existing variable or create a new one.
=  TRUE if set, FALSE otherwise
-NOTICE  At the moment only single value strings are supported.
************************************o*************************************/
{
  static int    called;
  static char  *dummy,*definition;
  static int    i_names;           /* List the internal names */
  static int    o_names;           /* List the names only! */

  ioi_variable *variable;
  char         *name,*s;
  int           legal = TRUE;      /* Characters in name legal? */
  int           cmd   = (-1);      /* For the internal variables */

  if( called )
  {

    if( dummy ) argc++,argv--;
    if( definition ) argc++,argv--;

    dummy = definition = NULL;     /* Rc ERROR! 16-SEP-1991 */

    if( argc<1 && o_names )
    {
      if( o_names ) ioi_list_print_all(IOI_L_VARIABLE,80);
      if( i_names ) ioi_variable_help();
      return TRUE;
    }

    if( argc<2 )
      return ioi_list_print(IOI_L_VARIABLE,argc?*argv:NULL);

    name = *argv;

    for( s=name ; *s ; s++ )
      if( !(isalnum(*s) || *s=='_') )
      { legal = FALSE; break; }

    if( !legal || !*name)
      return
        ioi_out(FALSE,IOI_ERR,"IOI-VARIABLE-SET:Name illegal %s.",name);
    
    if( (cmd = ioi_user_cmdf( name,cmds,NULL,maxcmd )) >= 0 )
      if( !ioi_variable_internal(cmd,argc,argv) )
        return( FALSE );

    argv++;
    argc--;                        /* For future! */

    if( !(variable=SALLOC(ioi_variable)) )
      return ioi_out(FALSE,IOI_ERR,"IOI-VARIABLE-SET-1:No mem.");

    if( (variable->name=strdup(name)) == NULL )
    {
      free(variable);
      return ioi_out(0,IOI_ERR,"IOI-VARIABLE-SET-2:No mem\n");
    }

    if( (variable->definition=strdup(*argv)) == NULL )
    {
      free(variable->name);
      free(variable);
      return ioi_out(0,IOI_ERR,"IOI-VARIABLE-SET-3:No mem\n");
    }

    return ioi_list_add(IOI_L_VARIABLE,(ioi_gen *)variable);
  }
  else
    ioi_exe_add("set:ioi",ioi_variable_create,
      ioi_exe_link_param(
        ioi_exe_param("-iinternal",IOI_L_BOOLEAN,ioi_exe_argv(
            "List the meaning of the internal variables.",
            NULL
          ),NULL,1,&i_names
        ),
        ioi_exe_param("-nnames",IOI_L_BOOLEAN,ioi_exe_argv(
            "To print out just the variable names.",
            "This only effects the command without parameters.",
            NULL
          ),NULL,1,&o_names
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param("name",IOI_L_STRING,ioi_exe_argv(
            "The name of the variable to be displayed/created.",
            NULL
          ),NULL,1,&dummy
        ),
        ioi_exe_param(
          "definition",IOI_L_STRING,ioi_exe_argv(
            "The token to be stored as the value of the variable.",
            "","NOTICE! The extra parameters are silently discarded.",
            NULL
          ),NULL,1,&definition
        ),
        NULL
      ),
      ioi_exe_argv(
#include "variable.h"
      )
    );

  return called = TRUE;
}

int ioi_variable_delete(int argc, char **argv)
/**************************************************************************
?  Delete the variable named
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    argc++,argv--;                 /* Compulsory parameter! */

    while( argc-- )
      ioi_list_delete(IOI_L_VARIABLE,*argv++);
  }
  else
    ioi_exe_add("unset:ioi",ioi_variable_delete,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param("name(s)",IOI_L_STRING,ioi_exe_argv(
            "The name(s) of the variable(s) to be removed.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
#include "unset.h"
      )
   );

  return called=TRUE;
}


char *ioi_variable_specials(char *name)
/**************************************************************************
?  Return special variable
|  ${integer} == positional parameter
|  $*         == all positional parameters // FIX
|  $#         == number of positional parameters
|  $$         == PID 
@  ioi_._line
************************************o*************************************/
{
  ioi_token *token;
  ioi_call  *call;
  ioi_gen  *gen = ioi_._action;

  char      *w      = ioi_._line;
  int        argc   = 0;
  int        number = (-1);
  int        len    = 0;
  int        lsize  = ioi_._lsize;

  w[0] = '\0';

  if( isdigit(*name) )
  {
    number = atoi(name);
    if(number < 0)
      number = (-1);
  }
  else
    if( *name == '$' )
    {
      sprintf(w,"%d",getpid());
      return( w );
    }

  while( gen && gen->type != IOI_L_CALL )
    gen = gen->next;               /* Loop stack down to find function */

  if( gen )
    {
      call = (ioi_call *) gen;
      token = call->params;

      if( number >= 0)
      {
        while( token &&  argc < number )
        {
          token = token->next;
          argc++;
        }

        return( (token)? token->text : "" );
      }
      else
      {
        switch( *name )
        {
          case '$':
            sprintf(w,"%d",getpid());
            break;
          case '#':
            sprintf(w,"%d",ls_len(&call->params) - 1);
            break;
          case '*':
            token = token->next;

            while(token)
            {
              strncpy(w+len,token->text,lsize-len);
              len += strlen(token->text);
              if( token=token->next )
                w[len++] = ' ';
            }

            w[len] = '\0';
            break;
          default:
            return NULL;
            /* break; */
        }
        return( w );
      }
    }
    else
      ;

  return( NULL );
}

int ioi_variable_shift(int argc, char **argv)
/**************************************************************************
?  Shift positional variables
|  If executing a function, it's variables are effected otherwise the
|  global positional variables are effected.
|  This will permanently delete the positional variable(s) in question.
-NOTICE  It isn't an error to shift while there is no variables left.
************************************o*************************************/
{
  static int   called;
  static int   how_much;
  static int   imin = 0, idef = 1;

  ioi_call    *call;
  ioi_gen     *gen = ioi_._action;

  if( called )
  {
    if( how_much <= 0 ) return TRUE;

    while( gen && gen->type != IOI_L_CALL )
      gen = gen->next;             /* Loop stack down to find function */

    if( gen )
    {
      call = (ioi_call *)gen;
      while( call->params && (how_much--)>0 )
        call->params = (ioi_token *)ioi_token_delete(call->params,FALSE);
    }
    else
    {
      /* It's the global positionals! */
      ioi_out(0,IOI_WAR,"shift: global positionals not implemented yet.");
    }
  }
  else
    ioi_exe_add("shift:ioi",ioi_variable_shift,
      NULL,
      ioi_exe_param("positions",IOI_L_INTEGER,ioi_exe_argv(
           "Number of positions to shift.",
           NULL
         ),NULL,1,&how_much,&imin,NULL,&idef
      ),
      ioi_exe_argv(
        "Shift the positional parameters.",
        "If the IOI is executing a function, its positional parameters",
        "are shifted. If a function has called an other function the",
        "inner most function is affected.",
        "","The global positionals not implemented yet!",
        NULL
      )
    );

  return called=TRUE;
}

int ioi_variable_substitute(void)
/**************************************************************************
?  Substitute the variable references in the tokens up till IOI_COMMAND or
|  if IOI_PIPE scan all tokens.
=  TRUE if the variable substitution was successfull, FALSE otherwise.
|  (should be true unless memory problems.)
|  Inside double quotes a variable is substituted as is.
|  Inside single quotes a variable is not substituted
|  Outside quotes the variable is cut into tokens and hence can form 
|  multiple tokens.
|
|  set x " 1  2   3  "
|
|  aa${x}bb    ==> [aa] [1] [2] [3] [bb]
|  "aa${x}bb"  ==> [aa 1  2   3  bb]
|  'aa${x}bb'  ==> [aa${x}bb]
|
|  set x "1  2  3"
|
|  aa${x}bb    ==> [aa1] [2] [3bb]
************************************o*************************************/
{
  ioi_token    *token = ioi_._token;
  ioi_variable *variable;

  char         *s;                 /* Current string in token    */
  char          last     = '\0';   /* Previuos character         */
  char          inside   = '\0';   /* Inside quotes?             */
  char         *before;            /* The start of the reference */

  char          name[MAXNAM];      /* Variable name to search    */
  char         *n;                 /* To build the name & copy   */

  int           got_pipe = FALSE;  /* Full scan, pipe output     */

  char         *definition=NULL;

  /* At this point the variables are inside tokens! */
  /* Not necessarily in separate tokens             */

  if( token )                      /* The first token is a commnad */
    token = token->next;           /* It can't be a variable       */

  while( token )
  {
    variable = NULL;
    inside   = '\0';
    last     = '\0';
    s        = token->text;

    if( !got_pipe && IS_COMMAND(*s) )
      return( TRUE );

    if( !got_pipe )
      got_pipe = ( IS_PIPE(*s) && strlen(s)==1 );

    while( *s )
    {
      if( inside )
        if( inside == *s )
          inside = '\0';
        else
          ;
      else
        if( (*s=='\'' || *s=='"' || *s=='`') && ! IS_ESCAPE(last) )
          inside = *s;

      if(IS_VARIABLE(*s) && !IS_ESCAPE(last) && inside != '\'')
      {
        n      = name;
        before = s;                /* The point to add   */
        *s++   = '\0';             /* The dollar sign    */

        if( *s=='{' ) s++;         /* ${NAME} */

        if( *s=='$' || *s=='*' || *s=='#' )
          *n++ = *s++;
        else
          while( isalnum(*s) || (*s=='_') )
            *n++ = *s++;
        *n = '\0';

        if( *s=='}' ) s++;

        if( !name[0] ) return
          ioi_out(FALSE,IOI_ERR,"IOI-VARIABELE-SUBSTITUTE:Variable syntax");

        if( ! (definition=ioi_variable_specials(name)) )
          if( variable=(ioi_variable *)
                     ioi_list_get(IOI_L_VARIABLE,name,FALSE) )
              ;
          else
            return ioi_out(FALSE,IOI_ERR,
                "IOI-VARIABELE-SUBSTITUTE:Undefined variable %s",name);

        last = '\0';
      }

      if( definition || variable ) /* Non null variables only */
      {
        ioi_token *temp;

        if( variable )
          definition = variable->definition;

        strcpy(ioi_._work,definition);
        temp = (ioi_token *)ioi_token_parse(ioi_._work,FALSE);

        ioi_token_replace(&token,&s,temp, inside?FALSE:TRUE );

        variable   = NULL;
        definition = NULL;
      }

      last = *s++;
    }

    token = token->next;
  }

  return( TRUE );
}

/**************************************************************************
*
*       C A L L E D   O U T S I D E   O F   T H I S   M O D U L E
*
************************************o*************************************/

int ioi_variable_set_int(char *name, int value)
/**************************************************************************
?  Set (create) a variable with the values given.
=  ioi_variable_create()
************************************o*************************************/
{
  char *argv[2];

  argv[0] = name;
  argv[1] = ioi_._work;

  sprintf(ioi_._work,"%d",value);

  return(ioi_variable_create(2,argv));
}

int ioi_variable_set_double(char *name, double value)
/**************************************************************************
?  Set (create) a variable with the values given.
=  ioi_variable_create()
************************************o*************************************/
{
  char *argv[2];

  argv[0] = name;
  argv[1] = ioi_._work;

  sprintf(ioi_._work,"%.15g",value);

  return(ioi_variable_create(2,argv));
}

int ioi_variable_set(char *name, char *text)
/**************************************************************************
?  Load (create) a variable with the text given.
=  ioi_variable_create()
************************************o*************************************/
{
  char *argv[2];

  argv[0] = name;
  argv[1] = ioi_._work;            /* Fix for convex readonly */

  strcpy(ioi_._work,text);

  return(ioi_variable_create(2,argv));
}

double ioi_variable_get_double(char *name)
/**************************************************************************
?  Get the value of the variable. If the variable is not defined the
|  value is zero.
=  ioi_variable_create()
************************************o*************************************/
{
  ioi_variable *variable;
  double        value = 0.0;

  if( !name ) return( 0.0 );

  if( IS_VARIABLE(*name) )
  {
    name++;

    if( ! isalpha(*name) )
    {
      char *s = ioi_variable_specials(name);

      if(s)
        if(! isalpha(*s))
        {
          sscanf(s,"%lf",&value);
          return( value );
        }
        else
         name=s; /* OK get it again! */
      else
        return 0.0;
    }
  }

  variable = (ioi_variable *)ioi_list_get(IOI_L_VARIABLE,name,FALSE);

  if( variable )
    sscanf(variable->definition,"%lf",&value);
  else
  {
    if( isdigit(name[0]) || name[0]=='.' || name[0]=='+' || name[0]=='-' )
      sscanf(name,"%lf",&value);
  }
  
  return( value );
}

int ioi_variable_get_int(char *name)
/**************************************************************************
?  Get the value of the variable. If the variable is not defined the
|  value is zero.
!  ioi_variable_get_double()
************************************o*************************************/
{
  return (int) ioi_variable_get_double(name);
}

char *ioi_variable_get(char *name)
/**************************************************************************
?  Get the definition of the variable. If the variable is not defined the
|  value is NULL.
************************************o*************************************/
{
  ioi_variable *variable;

  if( !name ) return( NULL );

  variable = (ioi_variable *)ioi_list_get( IOI_L_VARIABLE,name,FALSE );

  return( variable ? variable->definition : NULL );
}

int ioi_variable_unset(char *name)
/**************************************************************************
?  Remove the variable.
************************************o*************************************/
{
  if(name) ioi_list_delete(IOI_L_VARIABLE,name);

  return 0;
}
