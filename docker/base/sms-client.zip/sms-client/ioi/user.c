/**************************************************************************
.TITLE    Input Output Interface
.NAME     USER
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     11-SEP-1991 / 04-OCT-1990 / OP
.VERSION  2.0
.FILE     user.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.DATE     29-JUN-1994 / 15-JUN-1994 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-JUL-1994 / 14-JUL-1994 / op
.VERSION  3.1
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

int ioi_user_prompt_load(char *prompt)
/**************************************************************************
?  Set the prompt to be string given, if NULL IOI uses it's name.
-NOTICE  Maximum length of the prompt is MAXNAM defined in ioi.h.
************************************o*************************************/
{
  ioi_._prompt[MAXNAM-1] = '\0';

  if( prompt )
    strncpy(ioi_._prompt,prompt,MAXNAM-1);
  else
    ioi_._prompt[0] = '\0';

  return 0;
}

int ioi_user_prompt_add(char *newone)
/**************************************************************************
?  Add a path in to the prompt.
-NOTICE  Maximum length of the prompt is MAXNAM defined in ioi.h.
************************************o*************************************/
{
  char *s = ioi_._prompt;
  int len = strlen(s);

  s += len;
  *s++ = '/';

  while( ++len < MAXNAM && *newone ) *s++ = *newone++;

  *s = '\0';

  return 0;
}

void ioi_user_prompt_delete(void)
/**************************************************************************
?  Delete the last part of the prompt.
************************************o*************************************/
{
  char *s = ioi_._prompt;
  int len = strlen(s);

  s += len-1;

  while( len && *s != '/' ) { s--; len--; }

  *s = '\0';
}

int ioi_user_cmd(int *argc, char ***argv)
/**************************************************************************
?  Get an array of tokens for one single command.
|  Simplest way to access IOI.
=  Continue status, FALSE means end of the file in stdin.
************************************o*************************************/
{
  if( !ioi_cmd(FALSE) )
    return( FALSE );

  *argc = ioi_._argc;
  *argv = ioi_._argv;

  return( TRUE );
}

int ioi_user_menu(
    char  *name        ,           /* Name of this menu */
    int   *argc        ,
    char ***argv       ,           /* NICE! */
    char **cmds        ,           /* Full names of the commands   */
    char **helps       ,           /* Syntax & online help of cmds */
    int   *lengths     ,           /* Minimum length of the cmds   */
    int   *parameters  ,           /* Number of parameters         */
    int    maxcmd      )           /* Number of cmds in this menu  */
/**************************************************************************
?  Display a menu of commands and accept only IOI-commands or one of
|  given. The commands may be shortened by default as long as they
|  distinguish from each other.
************************************o*************************************/
/**************************************************************************
?  Display a menu of commands and accept only IOI-commands or one of
=  The number between 0 - maxcmd. maxcmd means backup (exit?).
|  -1 means end of the file in stdin.
-NOTICE:
|  If commands may not be shorted       set lengths    == NULL
|  If parameter checking is not needed  set parameters == NULL
|  If no help is available              set helps      == NULL
************************************o*************************************/
{
  int    added=FALSE;              /* Prompt path was added? */
  int    rc = (-1);

  ioi_token_delete_command();      /* Remove the old garbage */

  if( ioi_._autopath && !ioi_._action )
  {
    ioi_user_prompt_add(name);
    added = TRUE;
  }

  while( rc == (-1) )
  {
    if( ioi_._automenu && !ioi_._action )
      ioi_user_menu_display(cmds,helps,lengths,parameters,maxcmd);

    if(!ioi_._argc)
    {
      if( !ioi_cmd(TRUE) )
        return( -1 );
    }

    if(*ioi_._argv)
      if( (rc=ioi_user_cmdf(*ioi_._argv,cmds,lengths,maxcmd)) == (-1) )
      {
        if( IS_HELP(ioi_._argv[0][0]) )
        {
          ioi_internal_help();
          ioi_printf(FALSE,"\nOr one of the following\n\n");
          ioi_user_menu_display(cmds,helps,lengths,parameters,maxcmd);
        }
        else
          ioi_out(0,IOI_ERR,"IOI-USER-MENU:Illegal command:%s",*ioi_._argv);
      }
      else
      {
        if(rc==maxcmd)
          ;
        else
        if(parameters && parameters[rc] > ioi_._argc-1)
        {
          ioi_out(0,IOI_ERR,"IOI-USER-MENU:%d parameters needed for command %s",
                  parameters[rc],cmds[rc]);
          rc = (-1);
        }
      }

    if( rc == (-1) )
      ioi_token_delete_command();
  }

  if( added )
    ioi_user_prompt_delete();

  *argc = ioi_._argc;
  *argv = ioi_._argv;

  return( rc );
}

ioi_user_menu_display(
    char **cmds       ,            /* Full names of the commands   */
    char **helps      ,            /* Syntax & online help of cmds */
    int   *lengths    ,            /* Minimum length of the cmds   */
    int   *parameters ,            /* Number of parameters         */
    int    maxcmd     )            /* Number of cmds in this menu  */
/**************************************************************************
?  Display the currently availabe commands on the screen.
************************************o*************************************/
{
  char fmt[MAXNAM];
  int  mlen = 0;
  int  i;

  for( i=0 ; i<maxcmd ; i++ )
    mlen = MAX(mlen,strlen(cmds[i]));

  sprintf(fmt,"%%-%ds",++mlen);

  for( i=0 ; i<maxcmd ; i++ )
  {
    ioi_printf(FALSE,fmt,cmds[i]);
    ioi_printf(FALSE,"%s",helps[i]);
    ioi_printf(FALSE,"\n");
  }

  return 0;
}

ioi_user_cmdf(
    char  *command ,               /* token, parsed by clp or OS    */
    char **cmds    ,               /* valid commands                */
    int   *cmdlen  ,               /* min length of the cmds        */
    int    maxcmd  )               /* number of cmds to search      */
/**************************************************************************
?  CoMmanD Finder.
|  Find out quietly the matching command from an array of commands
-NOTICE  if commands may not be shortened, set cmdlen == NULL
=  Which cmd was found. The first one is zero.
|  -1 if none
************************************o*************************************/
{
  int reqlen;                      /* Chars to recognize the command*/
  int sensitive = ioi_._sensitive; /* Case sensitive? */
  int clen      = strlen(command);
  int i         = 0;
  char *s,*t;

  while( i<maxcmd )
  {
    reqlen = cmdlen ? cmdlen[i] : strlen(cmds[i]);

    s = cmds[i];
    t = command;
    reqlen = MAX( reqlen , clen );

    if( sensitive )
    {
      while( tolower(*s) == tolower(*t) && *s && *t && --reqlen )
      { s++; t++; }
      if( tolower(*s)-tolower(*t) == 0 && !reqlen )
        return( i );
    }
    else
    {
      while( *s == *t && *s && *t && --reqlen )
      { s++; t++; }
      if( *s == *t && !reqlen )
        return( i );
    }

    i++;
  }

  if( *command == '\\' && clen == 1 ) return( maxcmd );

  return( -1 );
}

ioi_user_fmcl(
    char **cmd    ,                /* Command names  */
    int   *cmdl   ,                /* Min length     */
    int    maxcmd )                /* Number of cmds */
/**************************************************************************
?  Find Minimum Command Lenghts to identify them from each other
|  Fill the maxcmd commands in the lenght table.
************************************o*************************************/
{
  int i,j;                         /* Loop counters             */
  int k;                           /* Matching chars in .i & .j */
  int m;                           /* Min length of .i          */
  int sensitive;                   /* Case sensitive? */

  sensitive = ioi_._sensitive;

  for(i=0 ; i<maxcmd ; i++) cmdl[i]=strlen(cmd[i]);

  for(i=0 ; i<maxcmd ; i++)
  {
    m = 1;
    for(j=0,m=1 ; j<maxcmd ; j++)
    {
      if(i != j)
      {
        k=0;
        if(sensitive)
          while( cmd[i][k] == cmd[j][k] && k<cmdl[i] && k<cmdl[j] )
            k++;
        else
          while( tolower(cmd[i][k]) == tolower(cmd[j][k]) &&
                 k<cmdl[i] && k<cmdl[j] )
            k++;
        k++;
        m=MAX(m,k);                /* Max so far */
      }
    }
    cmdl[i]=MIN(m,strlen(cmd[i]));
  }

  return 0;
}

int (* ioi_user_input(int (*routine)()))()
/**************************************************************************
?  Load the user routine for the input.
|
|  This should be used when the input can come from various sources eg in
|  graphic applications where the input is coming from many different
|  windows and/or devices. Or if the user has it's own terminal handling.
|
|  Then call the user_menu/ioi_cmd and IOI will jump into your routine to
|  get characters.
|
|  The user is then responsible of the prompt. The internal prompt will
|  be issued by the IOI.
=  The old value of the routine.
|  You can stack the routines and return the old value by keeping it 
|  while excuting your own input routine and when it doesn't need any
|  more data it can return the previous input handler.
NOTICE  To return to "normal" IOI-operation load routine as NULL.
************************************o*************************************/
{
  int (* old_routine)();

  old_routine = ioi_._input;

  ioi_._input = routine;

  return old_routine;
}

int ioi_user_dummy(char *buff, int size, int prompt)
/**************************************************************************
?  Dummy input routine
************************************o*************************************/
{
  return 0;
}

int ioi_user_execute(char *line)
/**************************************************************************
?  Execute command(s) in line
=  TRUE for success and FALSE for failure
************************************o*************************************/
{
  int  argc;
  char **argv = 0;

  int (* old_routine)();

  old_routine = ioi_user_input(ioi_user_dummy);
  ioi_file_input(line);
  ioi_user_cmd(&argc,&argv);
  ioi_user_input(old_routine);

  return ioi_variable_get_int("rc");
}

int (*ioi_user_output (int (*routine)()))()
/**************************************************************************
?  This should be used when the output should be handled by user own routine
|  eg in graphic applications where the output should be placed in a separate
|  window.
|  Then call the user_menu/ioi_cmd and IOI will jump into your routine to
=  The old value of the routine.
NOTICE  To return to "normal" IOI-operation load routine as NULL,
|  that is to use (stdout/stderr)
************************************o*************************************/
{
  int (* old_routine)();

  old_routine = ioi_._output;

  ioi_._output = routine;

  return old_routine;
}

int (* ioi_user_exit(int (*routine)()))()
/**************************************************************************
?  Load the user routine for the exit. (exit command)
|
|  The normal routine to be called upon exit and quit commands is C-exit().
|  The routine is expected to be called with the exit status and is
|  expected not to return.
=  The old value of the routine.
|  You can stack the routines and return the old value by keeping it
|  until the conditions change and the return the previous exit handler.
|  Normally the handler is simply loaded and the return value discarded.
************************************o*************************************/
{
  int (* old_routine)();

  old_routine = ioi_._exit;

  ioi_._exit = routine;

  return old_routine;
}

int (* ioi_user_event(int (*routine)()))()
/**************************************************************************
?  Load the user routine for the exit. (exit command)
|
|  The normal routine to be called upon exit and quit commands is C-exit().
|  The routine is expected to be called with the exit status and is
|  expected not to return.
=  The old value of the routine.
|  You can stack the routines and return the old value by keeping it
|  until the conditions change and the return the previous exit handler.
|  Normally the handler is simply loaded and the return value discarded.
************************************o*************************************/
{
  int (* old_routine)();

  old_routine = ioi_._event;

  ioi_._event = routine;

  return old_routine;
}

int ioi_user_enable(void)
{
  ioi_._disabled = FALSE;

  return 0;
}

