
#include "smslib.h"

int foo(int argc, char **argv)
{
  static int   called;
  static char *dummy;

  if( called )
  {
    sms_node *np;

    if( dummy ) { argc++; argv--; } /* GOT 2 B */

    while( argc-- )
    {
      if( (np=sms_node_net_find(*argv)) )
        printf("FOO: %s is %s\n",*argv,sms_node_net_name(np));
      else
        printf("FOO: could not find %s\n",*argv);
      argv++;
    }

    return TRUE;
  }
  else
    ioi_exe_add("foo:cdp",foo,NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "netname",IOI_L_STRING,ioi_exe_argv(
            "Network name of an SMS-node.",
            NULL
          ),NULL,-1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "We are testing something in the CDP/SMS.",
        "Currently testing network names.",
        NULL
       )
    );

  return called = TRUE;
}

