/**************************************************************************
.TITLE    Input Output Interface
.NAME     CMD
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     07-MAR-1992 / 10-NOV-1990 / OP
.VERSION  2.0
.FILE     cmd.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-SEP-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     31-JUL-1998 / 18-AUG-1995 / OP
.VERSION  3.3
*         Added the str functions for time and date for ^T in command line
*         (see ed.c)
*         Cleaning up + prototypes
.DATE     11-FEB-1999 / 11-FEB-1999 / OP
.VERSION  3.4
*         Added setenv command
.DATE     05-MAR-2001 / 05-MAR-2001 / OP
.VERSION  3.5
*         gets replaced by fgets
*
*  NOTICE!
*
*  In these commands the first argument (argv[0]) is not the name
*  but the real argument.
*
*  Current commands are:
*
*  setenv
*  args  cat  cd  date  echo  exit  input  ioi  local
*  memcheck  sleep  time
*
*  Eventually every command in the IOI will be an exe. The general idea here
*  is that all the commands have their static variables in the function
*  itself and they are made known to the exe-mudule by the first time called
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE


#include "ioi.h"

#if defined(__STDC__) && ! defined(__digital__)
#  define environ _environ
#endif

int ioi_cmd_setenv(int argc, char **argv)
/**************************************************************************
?  Make IOI variables out of environment variables
************************************o*************************************/
{
  static int   called;
  static int   import;
  static char *dummy;

  if( called )
  {
    extern char **environ;
    char  **ep = environ;

    char  name[MAXLEN];
    char *value;

    if( dummy ) argc++,argv--;

    if( import )
    {
      for( ; *ep ; ep++ )
      {
        int i, match=0;

        strcpy(name,*ep);
        if( (value=strchr(name,'=')) )
        {
          *value = 0; value++;
        }
        else
          value = "";

        if(!argc)
          match = 1;
        else
          for(i=0 ; i<argc ; i++)
            if(strcmp(name,argv[i]) == 0)
              match = 1;

        if(match)
          ioi_variable_set(name, value);
      }
    }
    else
    {
      if( argc>2 ) return ioi_out(0,IOI_ERR,"setenv:Too many arguments");

      if( argc )
      {
        sprintf(name,"%s=%s",argv[0], (argc>1)? argv[1] : "");
        putenv(name);

        /* Make a IOI-variable also? */

        ioi_variable_set(argv[0], (argc>1)? argv[1] : "");
      }
      else
        for( ; *ep ; ep++ )
          printf("%s\n",*ep);
    }

    return TRUE;
  }
  else
    ioi_exe_add("setenv:ioi",ioi_cmd_setenv,
      ioi_exe_link_param(
        ioi_exe_param(
          "-iimport",IOI_L_BOOLEAN,ioi_exe_argv(
            "Make CDP variables out of the environment variables If",
            "arguments are given only those variables are being imported.",
            "(default is to import all the variables)",
            NULL
          ),NULL,1,&import
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "arguments",IOI_L_STRING,ioi_exe_argv(
            "Name and value a'la csh style",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Manage environment variables.",
        "Without arguments all environment variables are printed, or if",
        "import option is used all are imported",
        "","NOTICE","",
        "IOI does not use environment variables, it has it's own set",
        "of variables which are not exported to other programs.",
        "Setting an environment variable also updates the CDP variable, but",
        "not the other way around.",
        "","Examples","",
        "  setenv         # print all variables",
        "  setenv x y     # update a value of x to be y (if x doesn't exist create)",
        "  setenv -i      # import all variables",
        "  setenv -i x y  # import variables x and y only",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_args(int argc, char **argv)
/**************************************************************************
?  Echo arguments, at least a new line.
************************************o*************************************/
{
  static int   called;
  static int   separate;
  static char *dummy;              /* To load parameter properly */

  if( called )
  {
    if( dummy ) argc++,argv--;

    while( argc-- )
      if( separate )
        ioi_printf(FALSE,"[%s]\n",*argv++);
      else
        ioi_printf(FALSE,"[%s] ",*argv++);

    if( !separate )
      ioi_printf(FALSE,"\n");
  }
  else
    ioi_exe_add("args:ioi",ioi_cmd_args,
      ioi_exe_link_param(
        ioi_exe_param(
          "-sseparate",IOI_L_BOOLEAN,ioi_exe_argv(
            "Print only one argument at a line.",
            NULL
          ),NULL,1,&separate
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "arguments",IOI_L_STRING,ioi_exe_argv(
            "The argument(s) to be printed.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Echo argument(s), at least a new line.",
        "The argument(s) are printed by wrapping them inside square brakets.",
        "This is usefull to check that the different substitution phases",
        "transform your characters properly.",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_cat(int argc, char **argv)
/**************************************************************************
?  Cat the stdin or files given (argc>0)
|  An error is generated, if the stdin is to be displayed and it is 
|  the control terminal of the module. HERE documents can be catted.
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  FILE *fp;

  char *w  = ioi_._work;
  int   sz = ioi_._lsize;
  int   got;
  int   bug = 0;

  if( called )
  {
    if( dummy ) argc++,argv--;

    if( !argc )
    {
      if(!ioi_._in)
        return( ioi_out(0,IOI_ERR,"IOI-CMD-CAT:Can't cat stdin") );
  
      while( got=fread(w,1,sz,stdin) )
        /* 3.1 fwrite(w,1,got,stdout); */
        ioi_printf(IOI_RAW,w,got);
    }
    else
      while( argc )
      {
        if( fp=fopen(*argv,"r") )
        {
          while( got=fread(w,1,sz,fp) )
            /* 3.1 fwrite(w,1,got,stdout); */
            ioi_printf(IOI_RAW,w,got);
          fclose(fp);
        }
        else
          bug += ioi_out(1,IOI_ERR,"IOI-CMD-CAT:Coulnd't open file %s",*argv);
        argv++; argc--;
      }
  }
  else
    ioi_exe_add("cat:ioi",ioi_cmd_cat,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "file(s)",IOI_L_STRING,ioi_exe_argv(
            "The file(s) to be printed in the standard output.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Concatenate and display.",
        "Cat reads file(s) given and prints them on the standard output.",
        "This cat is not able to read from the standard input if it is the",
        "control terminal (here documnet works).",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_cd(int argc, char **argv)
/**************************************************************************
?  Change the current (working) directory of the current process.
************************************o*************************************/
{
  static int   called;
  static char *path;

#ifdef IMPOSSIBLE                  /* Problem in the VAX */
  extern int errno;
  extern char *sys_errlist[ ];
  extern int sys_nerr;             /* Check this later! */
#endif

  extern char *getenv();

  if( called )
  {
    char  tmppath[MAXPATHLEN];     /* Got 2 B big enough, = temp anyway! */

    if(argc != NIL)                /* Not me calling myself! */
      if( chdir( path ? path : getenv("HOME")) )
        return ioi_out(FALSE,IOI_WAR,"IOI-CMD-CD:%s",
               (errno<sys_nerr)?sys_errlist[errno]:"UNKNOWN SYSTEM error.");
      else
        ;                           /* remember it? nah! */

#if 1
#if 1
    if( ! getcwd(tmppath,MAXPATHLEN) )
#else
    if( ! getwd(tmppath) )
#endif
      ioi_out(FALSE,IOI_ERR,"IOI-CMD-CD:getwd %s",tmppath);
    else
      ioi_variable_set("cwd",tmppath);

#else
      ioi_variable_set("cwd","unknown");
#endif

  }
  else
  {
    ioi_exe_add("cd:ioi",ioi_cmd_cd,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "path",IOI_L_PATH,ioi_exe_argv(
            "The directory path that comes the new working directory.",
            NULL
          ),NULL,1,&path
        ),
        NULL
      ),
      ioi_exe_argv(
        "Change working directory.",
        "If called without argument, your home directory becomes the current",
        "working directory. Otherwise an attempt is made to change to the",
        "path given, if successful CD is quiet, otherwise a system error is",
        "printed.",
        "",
        "The new Current Working Directory is stored in variable \"cwd\".",
        "","EXAMPLE","",
        "define cd {",
        "  if($#>0) then /cd $1; else /cd; endif",
        "  set prompt ${cwd}\"-ish\"",
        "}",
        "IOI> cd ~map",
        "/tmp_mnt/home/ma/map-ish> ...",
        NULL
      )
    );
    called = TRUE;
    ioi_cmd_cd(NIL,NULL);
  }

  return TRUE;
}

static char *date[] = {
  "Sun","Mon","Tue","Wed","Thu","Fri","Sat",  /* Sun=0 idiots!!! */
};
static char *month[] = {
  "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"
};

char *ioi_cmd_date_str(void)
{
  static char str[80];
  time_t      stamp;
  struct tm  *tod;

  stamp=time(NULL);

  tod = localtime(&stamp);

  sprintf(str,"%s %s %02d %02d:%02d:%02d %04d",
    date[tod->tm_wday], month[tod->tm_mon], tod->tm_mday,
    tod->tm_hour, tod->tm_min, tod->tm_sec,
    /* tod->tm_zone, */
    tod->tm_year+1900 );

  return str;
}

int ioi_cmd_date(int argc, char **argv)
/**************************************************************************
?  Get the current date and time of the day.
|  If no args are given just print it otherwise store it in to the args.
=  TRUE
************************************o*************************************/
{
  static int    called = FALSE;
  static int    universal;
  static char  *dummy;

  char        str[80];
  time_t      stamp;
  struct tm  *tod;

  if( called )
  {
    if( dummy ) argc++,argv--;

    stamp=time(NULL);

    tod = (universal)?gmtime(&stamp):localtime(&stamp);

    sprintf(str,"%s %s %02d %02d:%02d:%02d %04d",
      date[tod->tm_wday], month[tod->tm_mon], tod->tm_mday,
      tod->tm_hour, tod->tm_min, tod->tm_sec,
      /* tod->tm_zone, */
      tod->tm_year+1900 );

    switch( argc )
    {
      default:
      case 10: ioi_variable_set(argv[9],month[tod->tm_mon]);
      case  9: ioi_variable_set(argv[8],date[tod->tm_wday]);
      case  8: ioi_variable_set_int(argv[7],tod->tm_year+1900);
      case  7: ioi_variable_set_int(argv[6],tod->tm_mon+1);
      case  6: ioi_variable_set_int(argv[5],tod->tm_mday);
      case  5: ioi_variable_set_int(argv[4],tod->tm_hour);
      case  4: ioi_variable_set_int(argv[3],tod->tm_min);
      case  3: ioi_variable_set_int(argv[2],tod->tm_sec);
      case  2: ioi_variable_set_int(argv[1],stamp);
      case  1: ioi_variable_set(argv[0],str);
        break;
      case  0: ioi_printf(FALSE,"%s\n",str); break;
    }

    return TRUE;
  }

  ioi_exe_add("dates:ioi",ioi_cmd_date,
    ioi_exe_link_param(
      ioi_exe_param(
        "-uGMT",IOI_L_BOOLEAN,ioi_exe_argv(
          "Generate GMT (universal  time) instead local time.",
          NULL
        ),NULL,1,&universal
      ),
      NULL
    ),
    ioi_exe_link_param(
      ioi_exe_param(
        "variables(s)",IOI_L_STRING,ioi_exe_argv(
          "Name(s) of the variable(s) to store the requested date",
          "The following order must be user for the variables:",
          "all unix-time sec min hour day month year weekday montname",
          "" , "IOI> dates str gsec se mi ho da mo ye we mn;echo $str",
          "Wed Jul 17 13:23:32 1991",
          "" , "IOI> echo $we $mn $da $ho:$mi:$se $ye",
          "Wed Jul 17 13:23:32 1991",
          NULL
        ),NULL,1,&dummy
      ),
      NULL
    ),
    ioi_exe_argv(
      "Print the current system date and time in a fidex format.",
      "If parameters are given they are taken to be variable names to",
      "to receive the full/parts of the date string.",
      NULL
    )
  );

  return called = TRUE;
}

#define CASE(x,c) case (x): ioi_printf(0,"%c",(c)); break;

int ioi_cmd_echo(int argc, char **argv)
/**************************************************************************
?  Echo arguments, if none just a newline.
|  This conforms in to the SYS V echo command with character escaping.
************************************o*************************************/
{
  static int    called;
  static int    nonl;
  static char  *dummy;

  char *s;
  int   len,value;

  if( called )
  {
    if( dummy ) argc++,argv--;

    if(!argc)
      if(nonl)
        ;
      else
        ioi_printf(0,"\n");
    else
      while( argc-- )
      {
        for(s = *argv++; *s; s++)  /* Loop the current argument */
          if(*s == '\\')           /* It is a character escape! */
            switch(*++s)
            {
              CASE('b','\b');
              case 'c': return(0);
              CASE('f','\f');
              CASE('n','\n');
              CASE('r','\r');
              CASE('t','\t');
              CASE('v','\v');
              CASE('\\','\\');
              case '0':            /* Ok, it's an octal number */
                  len = value = 0;
                  while ((*++s >= '0' && *s <= '7') && len++ < 3)
                  {
                  value <<= 3;
                    value |= (*s - '0');
                  }
                  ioi_printf(0,"%c", value );
                  s--;             /* Let's get back cause of for++ */
              break;
    
              default: s--;
            }
          else
            ioi_printf(0,"%c",*s);
    
        if( argc )
          ioi_printf(0," ");       /* A space between args */
        else
          if(!nonl)
            ioi_printf(0,"\n");         /* A CR in the end */
      }
  }
  else
    ioi_exe_add("echo:ioi",ioi_cmd_echo,
      ioi_exe_link_param(
        ioi_exe_param(
          "-nno-newline",IOI_L_BOOLEAN,ioi_exe_argv(
            "Do not add the NEWLINE to the output.",
            NULL
          ),NULL,1,&nonl
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "text-token(s)",IOI_L_STRING,ioi_exe_argv(
            "The tokens to be displayed separated by a single space.",
            NULL
          ),NULL,1,&dummy
        ),
        NULL
      ),
      ioi_exe_argv(
        "Echo arguments to the standard output.",
        "If the arguments contain C-like escape characters they are",
        "processed according to following rules:",
        "",
        "  \\b   BACKSPACE",
        "  \\c   Print line without NEWLINE",
        "  \\f   FORMFEED",
        "  \\n   NEWLINE",
        "  \\r   RETURN",
        "  \\t   TAB",
        "  \\v   vertical TAB",
        "  \\\\   backslash",
        "  \\n   the 8-bit character whose ASCII code is the 1-, 2-",
        "       or 3-digit octal number n, which must start with a",
        "       zero.",
        "",
        "Notice that anything after \\c is left unprocessed.",
        "","EXAMPLE","",
        "echo 'date is \\c';dates str;echo $str",
        NULL
      )
    );
  
  return called = TRUE;

#undef CASE
}

int ioi_cmd_exit(int argc, char **argv)
/**************************************************************************
?  Exit the program with the exit status given.
************************************o*************************************/
{
  static int   called;
  static int   status;
  static int   def = 0;

  if( called )
  {
    ioi_ed_exit();
    if( ioi_._exit ) ioi_._exit( status );
    exit( status );
  }
  else
    ioi_exe_add("exit:ioi",ioi_cmd_exit,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "status",IOI_L_INTEGER,ioi_exe_argv(
            "The exit status to give back to the caller program.",
            NULL
          ),NULL,1,&status,NULL,NULL,&def
        ),
        NULL
      ),
      ioi_exe_argv(
        "Exit the program with the status given.",
        "The program is terminated and the status returned to the caller",
        "program.",
        "","Users are advised to alias quit to be exit 0.",
        NULL
      )
    );

  called = TRUE;                   /* This should never return! */

  return 0;
}

int ioi_cmd_input(int argc, char **argv)
/**************************************************************************
?  Read the variable(s) from the keyboard
=  How many times a variable vas actually set.
************************************o*************************************/
{
  static int    called;
  static char  *prompt;
  static char  *dummy;             /* We'll get them in argv! */
  static int    must;

  ioi_token *token;
  int        read_first = TRUE;    /* Read at least one line! */
  int        got        = 0;

  if( called )
  {
    if( dummy ) argc++,argv--;

    if( !prompt ) prompt = "> ";

    while( must || read_first )
    {
      token = NULL;
      ioi_printf(FALSE,"%s",prompt); fflush(stdout);

      ioi_._work[0] = '\0';

      if( ! fgets(ioi_._work,ioi_._lsize,stdin) )
        return ioi_out(0,IOI_ERR,"input:EOF reached\n:");

      token = (ioi_token *)ioi_token_parse(ioi_._work,TRUE); 
      /* TRUE ==> perform full token parsing */

      while( token && argc )
      {
        if( token->text[0] )
        {
          ioi_variable_set(*argv++,token->text);
          argc--;
          got++;
        }
        token = (ioi_token *)ioi_token_delete(token,FALSE);
      }

      if( !argc ) must=FALSE;
      read_first = FALSE;
    }
    return got;
  }

  ioi_exe_add("input:ioi",ioi_cmd_input,
    ioi_exe_link_param(
      ioi_exe_param(
        "-mmust",IOI_L_BOOLEAN,ioi_exe_argv(
          "The variable(s) must be given. The IOI will keep on reading until",
          "all the variable(s) have been read. A null string is not accepted.",
          NULL
        ),NULL,1,&must
      ),
      ioi_exe_param(
        "-pprompt",IOI_L_STRING,ioi_exe_argv(
          "The prompt to be printed before reading the value(s) for the",
          "variable(s). The default is '> '",
          "The prompt given is take literally and no extra characters are",
          "printed. Normally you would give eg \"my-prompt> \".",
          NULL
        ),NULL,1,&prompt
      ),
      NULL
    ),
    ioi_exe_link_param(
      ioi_exe_param(
        "name(s)",IOI_L_STRING,ioi_exe_argv(
          "Name(s) of the variable(s) to be input.",
          NULL
        ),NULL,-1,&dummy
      ),
      NULL
    ),
    ioi_exe_argv(
      "Read in the variable(s) from the current standard input.",
      "A prompt is issued, a line is read and the line is parsed into the",
      "token(s). The names are then scanned and tokens are stored into the",
      "variables. If all the names aren't satisfied and the must option was",
      "given further lines are read. Util all the variables has been read.",
      "",
      "To input without a prompt use input -p \"\" name(s)",
      "","FUTURE","",
      "The unread variables are printed before the prompt with must option.",
      NULL
    )
  );

  called = TRUE;

  return 0;
}

int ioi_cmd_ioi(int argc, char **argv)
/**************************************************************************
?  Display some status of the IOI
************************************o*************************************/
{
  static int   called;
  static int   mode;

  if( called )
    ioi_misc_status(mode);
  else
    ioi_exe_add("ioi:ioi",ioi_cmd_ioi,
      ioi_exe_param("-ffull",IOI_L_BOOLEAN,ioi_exe_argv(
          "To have the full listing of the different lists.", NULL
        ),NULL,1,&mode
      ),
      NULL,
      ioi_exe_argv(
        "Misc status of IOI (internal use only)",
        "Display some statistics of the current status of the IOI.",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_local(int argc, char **argv)
/**************************************************************************
?  Declare the variables to be local for the block
|  Wot is a block is not compleately defined yet!
************************************o*************************************/
{
  static int   called;
  static char *dummy;

  if( called )
  {
    if( dummy )
    {
      for(argc++,argv-- ; argc ; argc--,argv++)
        ioi_variable_push(*argv);
    }
    else
    {
      ioi_printf(FALSE,"Not yet local listingd!\n");
      return TRUE;
    }

  }
  else
    ioi_exe_add("local:ioi",ioi_cmd_local,
      NULL,
      ioi_exe_param("name(s)",IOI_L_STRING,ioi_exe_argv(
          "The variable(s) to be declared as local.",NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Declare local variable(s)",
        "If no variables are given the local variables are listed.",
        "Otherwise the listed variables are marked to be deleted at the",
        "end of the block.",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_memcheck(int argc, char **argv)
/**************************************************************************
?  Print the next free character.
************************************o*************************************/
{
  static int   called;
  static char *dummy;
  static int   logit;
  static int   size,size_min = -2,size_def = -2,size_max = 1<20;
  char        *mem;

  if( called )
  {
    if( !(mem=(char *)malloc(64*1024)) )
      return ioi_out(0,IOI_ERR,"IOI-CMD-MEMCHECK:No mem.");

    if( dummy )
      ioi_variable_set_int(*--argv,(int)mem);
    else
      ioi_printf(FALSE,"next free: %d\n",mem);

    if( logit )
      ioi_out(0,IOI_LOG,"memcheck: next free %d",mem);

/*
    if( size >= -1 )
      print_alloc(size);
*/

    free(mem);
  }
  else
    ioi_exe_add("memcheck:ioi",ioi_cmd_memcheck,
      ioi_exe_link_param(
        ioi_exe_param(
          "-llog",IOI_L_BOOLEAN,ioi_exe_argv(
            "Generate log message into file also.",
            NULL
          ),NULL,1,&logit
        ),
/*
        ioi_exe_param(
          "-ssize",IOI_L_INTEGER,ioi_exe_argv(
            "Output a dump of memory size specifies the max lenght",
            "or the dump:"
            " -2==no dump,",
            " -1==summary only",
            "  0==addresses only",
            " >0==dump all used and free memory, hex int and character",
            NULL
          ),NULL,1,&size,&size_min,NULL,&size_def
        ),
*/
/*
        ioi_exe_param(
          "-mmallocmap",IOI_L_BOOLEAN,ioi_exe_argv(
            "Generate memory usage using system call mallocmap(3)",
            "This option may generate a lot of output.",
            "The l-option doesn't work with this, the output is always",
            "placed in stdout.",
            NULL
          ),NULL,1,&mmap
        ),
*/
        NULL
      ),
      ioi_exe_param(
        "name",IOI_L_STRING,ioi_exe_argv(
          "The possible variable to hold the current value.",
          NULL
        ),NULL,1,&dummy
      ),
      ioi_exe_argv(
        "Print/store the next free address in memory after malloc(3).",
        "Used to check the memory status. After repeated things the memory",
        "allocator should return same address, unless garbage collection is",
        "implemented.",
        "","IOI> memcheck ; cmd(s) ... ; memcheck",
        "next free: 1223",
        "next free: 1223",
        "","Currently doing it with 64k chunk",
        NULL
      )
    );

  return called = TRUE;
}

int ioi_cmd_sleep(int argc, char **argv)
/**************************************************************************
?  Sleep seconds.
|  The process is hybernated for the time given or untill signal arrives.
************************************o*************************************/
{
  static int called;
  static int seconds;
  static int min = 0;
  static int max = 9999999;
  static int def = 1;

  if( called )
    sleep(seconds);
  else
    ioi_exe_add("sleep:ioi",ioi_cmd_sleep,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "time",IOI_L_INTEGER,ioi_exe_argv(
            "The tme to sleep expressed in the seconds..",
            NULL
          ),NULL,1,&seconds,&min,&max,&def
        ),
        NULL
      ),
      ioi_exe_argv(
        "Suspend execution for a specified interval.",
        "Sleep  suspends execution for time seconds or until a signal",
        "arrives.",
        NULL
      )
    );

  return called = TRUE;
}

char *ioi_cmd_time_str(void)
{
  static char str[80];
  struct tms   tms;
  struct tm   *tod;
  time_t       elapsed;            /* Elapsed time since ioi_open() */

  times(&tms);
  elapsed = time(NULL) - ioi_._stime;
  tod     = gmtime(&elapsed);

  sprintf(str,"%.2fu %.2fs %.2fcu %.2fcs %02d:%02d:%02d",
    tms.tms_utime  / (double)HZ , tms.tms_stime  / (double)HZ,
    tms.tms_cutime / (double)HZ , tms.tms_cstime / (double)HZ,
    tod->tm_hour,tod->tm_min,tod->tm_sec
  );

  return str;
}

int ioi_cmd_time(int argc, char **argv)
/**************************************************************************
?  Get the current time used by this process and its children.
|  Also the elapsed time since the IOI was last initialized (opened.)
=  TRUE
************************************o*************************************/
{
  static int    called = FALSE;
  static char  *dummy;
  static int    s_option;

  char         str[80];
  struct tms   tms;
  struct tm   *tod;
  time_t       elapsed;            /* Elapsed time since ioi_open() */

  if( called )
  {
    if( dummy ) argc++,argv--;

    times(&tms);

    elapsed = time(NULL) - ioi_._stime;
    tod     = gmtime(&elapsed);

    if( s_option )
    {
      ioi_printf(FALSE,"%02d:%02d:%02d\n",tod->tm_hour,tod->tm_min,tod->tm_sec);
      return TRUE;
    }

    sprintf(str,"%.2fu %.2fs %.2fcu %.2fcs %02d:%02d:%02d",
      tms.tms_utime  / (double)HZ , tms.tms_stime  / (double)HZ,
      tms.tms_cutime / (double)HZ , tms.tms_cstime / (double)HZ,
      tod->tm_hour,tod->tm_min,tod->tm_sec
    );

    switch( argc )
    {
      default:
      case  6: ioi_variable_set_double(argv[5],tms.tms_cstime / (double)HZ);
      case  5: ioi_variable_set_double(argv[4],tms.tms_cutime / (double)HZ);
      case  4: ioi_variable_set_double(argv[3],tms.tms_stime  / (double)HZ);
      case  3: ioi_variable_set_double(argv[2],tms.tms_utime  / (double)HZ);
      case  2: ioi_variable_set_int(argv[1],elapsed);
      case  1: ioi_variable_set(argv[0],str);
        break;
      case  0: ioi_printf(FALSE,"%s\n",str); break;
    }

    return TRUE;
  }

  ioi_exe_add("times:ioi",ioi_cmd_time,
    ioi_exe_link_param(
      ioi_exe_param(
        "-sshort",IOI_L_BOOLEAN,ioi_exe_argv(
          "Generate a short output only, no substitution.",
          "Only the elapsed time is printed.",
          NULL
        ),NULL,1,&s_option
      ),
      NULL
    ),
    ioi_exe_link_param(
      ioi_exe_param(
        "variables(s)",IOI_L_STRING,ioi_exe_argv(
          "Name(s) of the variable(s) to store the requested time",
          "The following order must be user for the variables:",
          "all elapsed-time user system child_u child_s",
          "" , "IOI> time str elapsed u s cu cs ;echo $str",
          "0.22u 0.13s 0.13cu 0.18cs 00:00:41",
          "" , "IOI> echo ${u}u ${s}s ${cu}cu ${cs}cs",
          "41u 0.216667s 0.133333cu 0.133333cs",
          NULL
        ),NULL,1,&dummy
      ),
      NULL
    ),
    ioi_exe_argv(
      "Display the times used by this process and its childred.",
      "There is five fields in the output.",
      "process/user process/sys child/user child/sys elapsed HH:MM:SS.",
      "The elapsed time is calculated since the IOI was initialized.",
      "",
      "The process and childred times are divided into user and system",
      "times. The system time is time spend executing system calls and",
      "the user time while executing user code. The childred time is a",
      "sum of the times spend executing forked processes.",
      "",
      "The times are given in seconds.",
      "",
      "If parameters are given they are taken to be variable names to",
      "receive the values.",
      NULL
    )
  );

  called = TRUE;
  return TRUE;
}
