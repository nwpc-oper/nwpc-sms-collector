/**************************************************************************
.TITLE    Input Output Interface
.NAME     SHELL
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     16-FEB-1993 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     shell.c
.DATE     10-MAR-1994 / 05-NOV-1993 / OP
.VERSION  3.0
.DATE     15-JUL-1994 / 29-JUN-1994 / OP
.VERSION  3.1
*         Fixed SIG-CLD / SIG-CHLD incompatibility (POSIX/BSD4.3)
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*  Shell interface. Operating system dependent!
*  
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#if !defined(CRAY) && !defined(__uxppx__) && !defined(__sgi)
/* #  define _POSIX_SOURCE */
#endif

#ifdef AIX
#  define _XOPEN_SOURCE
#endif

#include "ioi.h"

#ifdef UNIX
  /*
   *  Some systems have these, some need things like POSIX_SOURCE (!!!)
   */
#endif

#ifdef UNIX
static int shell_read(int shell, char *cmd)
/**************************************************************************
?  Read text from the command. 
=  NULL if the command couldn't be executed.
!  If the internal buffer fills, the rest is simply discarded
-NOTICE  The current line is used for the buffer.
************************************o*************************************/
{
  char  buff[MAXLEN];
  char *w   = buff;
  int   sz  = MAXLEN;
  int   got = 0;
  FILE *fp;

  ioi_out(0,IOI_LOG,"IOI-SHELL-READ:[%s]",cmd);

  if(!(fp=popen(cmd,"r")))
    return ioi_out(FALSE,IOI_ERR,"IOI-SHELL-READ:Process open error:%s",cmd);

  while( got=fread(w,1,sz,fp))
    ioi_printf(IOI_RAW,w,got);

  pclose(fp);

  return TRUE;
}
#endif                             /* UNIX */

ioi_token *ioi_shell_get(char *cmd)
/**************************************************************************
?  Read text from the command. 
=  NULL if the command couldn't be executed.
!  If the internal buffer fills, the rest is simply discarded
-NOTICE  The current line is used for the buffer.
************************************o*************************************/
{
  char *line   = ioi_._line;
  int   maxlen = ioi_._lsize;
  int   len    = 0;
  FILE *fp;

  ioi_out(0,IOI_LOG,"IOI-SHELL-GET:[%s]",cmd);

#ifdef UNIX
  if(!(fp=popen(cmd,"r")))
  {
    ioi_out(0,IOI_ERR,"IOI-SHELL-GET:Process open error:%s",cmd);
    return 0;
  }

  while(fgets(line+len,maxlen-len,fp))
  {
    char *s = line+len;

    len += strlen(line+len);
    if(line[len-1] == '\n') line[len-1]=' ';
    ioi_out(0,IOI_DBG,"%s",s);
  }
  line[len] = '\0';

  pclose(fp);

  return( (ioi_token *)ioi_token_parse(line,FALSE) );

#else
  strncpy(line,cmd,maxlen);
  return( (ioi_token *)ioi_token_create(line) );
#endif                             /* UNIX */

}

int ioi_shell_substitute(void)
/**************************************************************************
?  Read text from the command. 
=  NULL if the command couldn't be executed.
!  If the internal buffer fills, the rest is simply discarded
************************************o*************************************/
{
  ioi_token    *token = ioi_._token;
  ioi_token    *temp;

  char         *s;                 /* Current string in token        */
  char          last     = '\0';   /* Previuos character             */
  char          inside   = '\0';   /* Inside quotes?                 */
  char         *before;            /* The start of the shell command */

  if( token )                      /* The first token is a commnad   */
    token = token->next;           /* It can't be a variable         */

#ifdef UNIX

  while( token )
  {
    inside   = '\0';
    last     = '\0';
    s        = token->text;

    while( *s )
    {
      if( inside )
        if( inside == *s && !IS_ESCAPE(last))
        {
          if( inside == '`' )
          { 
            *before++ = '\0';
            *s++      = '\0';

            temp=ioi_shell_get(before);

            ioi_token_replace( &token,&s,temp,TRUE );
          }
          inside = '\0';
        }
        else
          ;
      else
        if( (*s=='\'' || *s=='"' || *s=='`') && ! IS_ESCAPE(last) )
        {
          inside = *s;
          if( *s=='`' )
            before = s;            /* Mark the start of the shell-cmd */
        }

      last = *s++;
    }

    token = token->next;
  }

#endif
  return( TRUE );
}

#ifdef UNIX
static int _system(int shell, char *s)
/**************************************************************************
?  Execute a UNIX system call
=  TRUE if ok.
************************************o*************************************/
{
  void (*cstat)(), (*istat)(), (*qstat)();
  int   status,pid,w;

  if( (pid=fork())==0 )
  {
    (void) execl( shell? "/bin/sh" : "/bin/csh" ,
                  shell? "sh"      : "csh" ,
                  "-c", s, NULL);
    _exit(127);
  }

#if defined(SIGCHLD) && !defined(SIGCLD)
#define SIGCLD SIGCHLD
#endif

  istat = signal(SIGINT,  SIG_IGN);
  qstat = signal(SIGQUIT, SIG_IGN);
  cstat = signal(SIGCLD,  SIG_DFL);

  while((w = wait(&status)) != pid && w != -1)
    ;

  (void) signal(SIGINT,  istat);
  (void) signal(SIGQUIT, qstat);
  (void) signal(SIGCLD,  cstat);

  return (w == -1)? w : status;
}
#endif /* UNIX for _system() */


int ioi_shell_system(int mode, int argc, char **argv)
/**************************************************************************
?  Execute a system call in the current operating system.
|  UNIX + VAX/VMS + AMIGA
=  TRUE if ok.
************************************o*************************************/
{
  char *work    = ioi_._work;
  int  len     = 0;
  int  maxlen  = ioi_._lsize;
  int  tmplen;
  int  rc      = FALSE;

  if(strlen(*argv) > 1)
  {
    strcpy(work,&argv[0][1]);
    len = strlen(work);
    work[len++] = ' ';
  }

  argc--; argv++;

  while(argc--)
  {
    tmplen = strlen(*argv);

    if(len+tmplen+1 >= maxlen)
      return
        ioi_out(FALSE,IOI_ERR,"IOI_SYSTEM:Cmd too long.");

    strcpy(work+len,*argv++);
    len += tmplen;
    if(argc) work[len++] = ' ';
  }

  work[len] = '\0';

  ioi_out(0,IOI_LOG,"IOI-SHELL-SYSTEM:[%s]",work);

#ifdef UNIX

  if(*work)
  {
    if(ioi_._output)
      shell_read(mode,work);
    else
      _system(mode,work);
  }
  else
  {
    char *getenv();
    char *home = getenv("SHELL");

    if(home)
      _system(TRUE,home);
    else
      _system(FALSE,"csh");
  }
  rc = TRUE;

#endif

#ifdef VMS                         /* In VMS */
  {
    struct descr { int len; char *addr; };

    struct descr  blanko ;         /* Well, in the VAX/VMS the call */
    blanko.addr = work;            /* is build for FORTRAN */

    blanko.len  = strlen(blanko.addr);
    lib$spawn(&blanko);
    printf("\n");                  /* In VAX/VMS linefeed is in the */
  }                                /* beginning of the line */
  rc = TRUE;
#endif

#ifdef AMIGA                       /* Commodore amiga (1000) */
  Execute(work);
  rc = TRUE;
#endif

  return( rc );
}
