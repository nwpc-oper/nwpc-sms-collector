/**************************************************************************
.TITLE    Input Output Interface
.NAME     MISC
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     11-DEC-1992 / 18-OCT-1990 / OP
.VERSION  2.1
.FILE     misc.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-SEP-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
*  Misc routines for debugging(?) and for systems lacking even the most
*  basic routines!
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

#if defined(VMS) || defined(ultrix)
char *strdup(char *s)
{
  int   len = strlen(s)+1;
  char *t = (char *)malloc(sizeof(char)*len);

  if(t) memcpy(t,s,len);

  return t;
}
#endif

#if defined(VMS) || defined(hpux)
char *getwd(char *path)            /* MAXPATHLEN at least */
{
#if defined(hpux)
  return getcwd(path,MAXPATHLEN);/* in UNIX format */
#else
  return getcwd(path,MAXPATHLEN,0);/* in UNIX format */
#endif
}
#endif

#if defined(VMS) 
int unlink(char *path)
{
  return remove(path);
}
#endif

int ioi_misc_arg(char *name, int argc, char **argv)
/**************************************************************************
?  Print the argc-argv
|  Used for debugging the module.
************************************o*************************************/
{
  int i;

  ioi_printf(FALSE,"<<< %s >>> ARGUMENTS: %d\n",name,argc);

  for( i=0 ; i<argc ; i++ )
    ioi_printf(FALSE,"%-5d |%s|\n",i,*argv++);

  return 0;
}

int ioi_misc_token(char *name, ioi_token *token)
/**************************************************************************
?  Print the list of tokens.
|  Used for debugging the module.
************************************o*************************************/
{
  int i=0;

  ioi_printf(FALSE,"\n<<< %s >>> TOKENS %d\n",name,ls_len(&token));

  while(token)
  {
    ioi_printf(FALSE,"%4d |%s|\n",i++,token->text);
    token = token->next;
  }

  return 0;
}

int ioi_misc_arg_fill(char **argv, ...)
/**************************************************************************
?  Fill in argv from the argumnets given.
-SYNTAX argc = ioi_misc_arg_fill(argv,par1,par2,...,NULL);
************************************o*************************************/
{
  va_list   ap;
  int       argc = 0;

  va_start(ap,argv);
  /* argv = va_arg(ap, char **); */
  while( argv[argc] = va_arg(ap, char *) ) argc++;
  va_end(ap);

  return( argc );
}

int ioi_misc_no_args(int argc, char **argv)
/**************************************************************************
?  Free a argv-array
|  Used for debugging the module.
************************************o*************************************/
{
  char **av = argv;

  while(argc)
  {
    IFFREE(*argv)
    argc--;
    argv++;
  }

  IFFREE(av);

  return 0;
}

int ioi_misc_file_ptr(char *name, FILE *fp)
/**************************************************************************
?  Print the file pointer information
|  Used for debugging the module.
************************************o*************************************/
{
  ioi_printf(FALSE,"<<< %s >>> FILE %d\n",name,fp);

#if 0
#ifndef VMS
  ioi_printf(FALSE,"CNT    %d\n",fp->_cnt);
  ioi_printf(FALSE,"PTR    %d\n",fp->_ptr);
    if(fp->_ptr)
  ioi_printf(FALSE,"PTR,0  %d\n",fp->_ptr[0]);
  ioi_printf(FALSE,"BASE   %d\n",fp->_base);
    if(fp->_base)
  ioi_printf(FALSE,"BASE,0 %d\n",fp->_base[0]);
/*
  ioi_printf(FALSE,"SIZE   %d\n",fp->_bufsiz);
*/
  ioi_printf(FALSE,"FLAG   %d\n",fp->_flag);
#ifndef _HPUX_SOURCE
  ioi_printf(FALSE,"FILE   %d\n",fp->_file);
#endif
#endif
#endif /* 0 */

  return 0;
}

int ioi_misc_status(int mode)
/**************************************************************************
?  Print the status of the IOI system
|  If mode is set the list's will be printed
************************************o*************************************/
{
  char s[MAXNAM];
  int  rem = ioi_._msg[IOI_MSG];
  int  i;

  ioi_._msg[IOI_MSG] = TRUE;

  ioi_out(0,IOI_MSG,"IOI-MISC-STATUS:Status of the module IOI");

  sprintf(s,"Terminal filters    ");
  for( i=0 ; i<IOI_LOGS ; i++ )
    sprintf(s,"%s %d",s,ioi_._msg[i]);
  ioi_out(0,IOI_MSG,s);

  sprintf(s,"Logfile filters     ");
  for( i=0 ; i<IOI_LOGS ; i++ )
    sprintf(s,"%s %d",s,ioi_._log[i]);
  ioi_out(0,IOI_MSG,s);

  if( ioi_._logname ) sprintf(ioi_._line," ===> %s", ioi_._logname);
  else                ioi_._line[0] = '\0';

  ioi_out(0,IOI_MSG,"Logging              %s%s",ioi_._logfile?"on":"off",
    ioi_._line);
  ioi_out(0,IOI_MSG,"Input buffer size    %d",ioi_._lsize);
  ioi_out(0,IOI_MSG,"History number       %d",ioi_._hist_num);
  ioi_out(0,IOI_MSG,"History stack size   %d",ioi_._hist_len);
  ioi_out(0,IOI_MSG,"Argument buffer size %d",ioi_._asize);

  ioi_out(0,IOI_MSG,"The lists::");
  ioi_out(0,IOI_MSG,"ALIAS                %d",ls_len(&ioi_._alias));
  ioi_out(0,IOI_MSG,"FUNCTION             %d",ls_len(&ioi_._function));
  ioi_out(0,IOI_MSG,"HISTORY              %d",ls_len(&ioi_._history));
  ioi_out(0,IOI_MSG,"MANUALS              %d",ls_len(&ioi_._exe));
  ioi_out(0,IOI_MSG,"VARIABLE             %d",ls_len(&ioi_._variable));

  ioi_out(0,IOI_MSG,"FILES:               %d %d %d %d",
    ioi_._in , ioi_._out , ioi_._err , ioi_._pipe );

/*
  ioi_out(0,IOI_MSG,"The files::");
  ioi_out(0,IOI_MSG,"Stdin                %s%s",ioi_._in?"on":"off",
*/

  if( mode )
  {
    ioi_printf(FALSE,"ALIAS::\n"); ioi_list_print(IOI_L_ALIAS,NULL);
    ioi_printf(FALSE,"FUNCTION::\n"); ioi_list_print(IOI_L_FUNCTION,NULL);
    ioi_printf(FALSE,"HISTORY::\n"); ioi_list_print(IOI_L_HISTORY,NULL);
    ioi_printf(FALSE,"VARIABLE::\n"); ioi_list_print(IOI_L_VARIABLE,NULL);
  }

  ioi_._msg[IOI_MSG] = rem;

  return 0;
}
