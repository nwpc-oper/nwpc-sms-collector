"Remove the definition of the function(s) named.",
"The definition(s) of the function(s) named are removed.",
"",
"Notice! It's not an error to remove a function even if it doesn't",
"exist.",
NULL
