/**************************************************************************
.TITLE    Input Output Interface
.NAME     ALIAS
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     29-MAR-1992 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     alias.c
.DATE     02-MAR-1994 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

int ioi_alias_substitute(void)
/**************************************************************************
?  Substitute the first token if an alias can be found.
|  If alias is found, it's protected against further substitution and
|  the new first token is searched for alias. This continues until the
|  first token cann't be aliased.
=  TRUE if substitution was ok,or there was nothin' to do.
|  FALSE otherwise.
************************************o*************************************/
{
  ioi_alias *alias;
  ioi_token *token,*start,*last;
  int               hits = 0;      /* Total number of alias hits */
  int               rc   = TRUE;   /* Default return code */

  if( ! ioi_._token ) return( TRUE );

  while( rc && (alias=(ioi_alias *)
         ioi_list_get(IOI_L_ALIAS,ioi_._token->text,FALSE)) )
    if( !alias->hit )
    {
      alias->hit = TRUE; hits++;
      if( !( start = token = (ioi_token *)
             ioi_token_build( alias->argc , alias->argv )) )
      {
        rc = FALSE;                /* Terminate the loop */
        alias = NULL;
      }
      else                         /* Chain the tokens */
      {
        ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,FALSE);
        while(token->next) token = token->next;
        token->next = ioi_._token;
        ioi_._token = start;
      }
    }
    else
      break;

  if( hits )                       /* Remove the hit marks */
  {
    alias = (ioi_alias *)ioi_list_start(IOI_L_ALIAS);
    while(alias && hits)
    {
      if(alias->hit) { alias->hit = FALSE; hits--; }
      alias = alias->next;
    }

    ioi_token_rethink();
  }

  return( rc );
}

int ioi_alias_create(int argc, char **argv)
/**************************************************************************
?  Set the alias to the name in argv[0]
|  Build a new one and replace/add it into the alias list.
=  TRUE if ok.
|  FALSE if out of memory.
************************************o*************************************/
{
  static int   called;
  static char *name,*definition;

  ioi_alias   *alias;
  char       **av;
  int          i;

  if( called )
  {
    if( name ) argc++,argv--;      /* There can be many definitions */
    if( definition ) argc++,argv--;

    if( argc<2 )
      ioi_list_print(IOI_L_ALIAS,(argc==0)?NULL:*argv);
    else
    {
      if( !(alias=SALLOC(ioi_alias)) )
        return ioi_out(0,IOI_ERR,"IOI-ALIAS-CREATE-1:No mem.");

      if( !(alias->name = strdup(*argv)) )
      {
        free( alias );
        return ioi_out(0,IOI_ERR,"IOI-ALIAS-CREATE-2:No mem.");
      }

      argv++;
      argc--;

      if( !(alias->argv = av = (char **)ALLOC(sizeof(char *)*argc)) )
      {
        free( alias->name );
        free( alias );
        return ioi_out(0,IOI_ERR,"IOI-ALIAS-CREATE-3:No mem.");
      }

      alias->argc = argc;
      alias->hit  = FALSE;

      for( i=0 ; i<argc ; i++ )
      {
        if( (av[i] = strdup(*argv++)) == NULL )
        {
          for( --i ; i>=0 ; i-- )
            free(av[i]);
          free( alias->name );
          free( alias );
          return ioi_out(0,IOI_ERR,"IOI-ALIAS-SET-4:No mem.");
        }
      }
      ioi_list_add(IOI_L_ALIAS,(ioi_gen *)alias);
    }
  }
  else
    ioi_exe_add("alias:ioi",ioi_alias_create,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The name of the alias.",
            NULL
          ),NULL,1,&name
        ),
        ioi_exe_param(
          "definition(s)",IOI_L_STRING,ioi_exe_argv(
            "The tokens to replace the name when substituted.",
            NULL
          ),NULL,1,&definition
        ),
        NULL
      ),
      ioi_exe_argv(
#include "alias.h"
      )
    );

  return called = TRUE;
}

int ioi_alias_delete(int argc, char **argv)
/**************************************************************************
?  Remove the definition of the named alias
=  TRUE.
************************************o*************************************/
{
  static int   called;
  static char *name;

  if( called )
  {
    argc++,argv--;                 /* Compulsory parameter! */

    while( argc-- )
      ioi_list_delete(IOI_L_ALIAS,*argv++);
  }
  else
    ioi_exe_add("unalias:ioi",ioi_alias_delete,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name(s)",IOI_L_STRING,ioi_exe_argv(
            "The alias name(s) to be removed.",
            NULL
          ),NULL,-1,&name          /* Must be -1 for the above -- to work */
        ),
        NULL
      ),
      ioi_exe_argv(
#include "unalias.h"
      )
    );

  return called = TRUE;
}
