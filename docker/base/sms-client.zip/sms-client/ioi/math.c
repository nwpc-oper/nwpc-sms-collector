/**************************************************************************
.TITLE    Input Output Interface
.NAME     MATH
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     11-DEC-1992 / 14-DEC-1990 / OP
.VERSION  2.1
.FILE     math.c
.DATE     21-JAN-1994 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     14-JUL-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"
#include <math.h>

/**************************************************************************
*  Local variables for the math-module
*
*  The operators are recognized by either the token (like ==) or by the
*  name (line or).
*
*  These should be in same order as the above M_TYPES.
************************************o*************************************/

static int precedence[] = {        /* Of the operands */
   1    ,  1    ,
   2    ,  2    ,
   3    ,  3    ,  3    ,  3    ,
   4    ,  4    ,
   5    ,  5    ,  5    ,
   6    ,
   7    ,  7    ,
   8    ,  8    ,  9
};

static char *operator_c[] = {      /* C-language style */
  "||"  , "&&"  ,
  "=="  , "!="  ,
  "<"   , "<="  , ">"   , ">="  ,
  "+"   , "-"   ,
  "*"   , "/"   , "%"   ,
  "^"   ,
  "!"   , "~"   ,
  "("   , ")"   ,
};

static char *operator_s[] = {      /* String style */
  "or"  , "and" ,
  "eq"  , "ne"  ,
  "lt"  , "le"  , "gt"  , "ge"  ,
  "+"   , "-"   ,
  "*"   , "/"   , "mod" ,
  "^"   ,
  "not" , "~"   ,
  "("   , ")"   ,
};

static char *single_c[] = {        /* Single character operators */
  "<"   , ">"   ,
  "+"   , "-"   ,
  "*"   , "/"   , "%"   ,
  "^"   ,
  "!"   , "~"   ,
  "("   , ")"   ,
};

static char *twin_c[] = {          /* Two character operators */
  "||"  , "&&"  ,
  "=="  , "!="  ,
  "<="  , ">="  ,
};

static int max_operators = sizeof(operator_c) / sizeof(char *);
static int max_singles   = sizeof(single_c)  /  sizeof(char *);
static int max_twins     = sizeof(twin_c)   /   sizeof(char *);

static int               this_one;
static int               last_one;
static ioi_token        *this_token;
static ioi_token        *next_token;

int ioi_math_token(int nmode)      /* Can the name include [:,.,/] ? */
/**************************************************************************
?  Parse tokens given for the mathematical expression.
|  At this point we already know that these tokens are for the math.
|  The tokens are cutted so that a single token may contain
|  name             a variable name or a constant or character operator
|  $name            a variable reference (for the string operations)
|  operator         like || && == != < <= > >= + - * / % ^ ! 
|  paranthesis      opening or closing one
************************************o*************************************/
{
  ioi_token    *token  = ioi_._token;
  ioi_token    *start  = token;
  char          inside = '\0';     /* Inside quotes? (not ok yet)  */
  int           cut    = FALSE;    /* Cut the current token at s    */
  char         *s;                 /* Temp for scanning the token    */
  char         *w;                 /* Temp for scanning the operators */
  int           i;                 /* To loops the singles & twins    */

  this_one   = M_NIL;
  last_one   = M_NIL;

  this_token = NULL;
  next_token = ioi_._token;

  if(!token) return( FALSE );

  while( token )
  {
    s      = token->text;
    cut    = FALSE;
    inside = '\0';

    for( i=0 ; i<max_twins ; i++ ) /* Two character operator? */
    {
      w = twin_c[i];

      if( *w == *s )
      {
        w++;

        if( !s[1] && token->next && token->next->text[0] == *w )
        {
          ioi_token *temp;

          ioi_token_join(token,token->next->text);   /* Join the tokens */
          temp = token->next;
          token->next = token->next->next;
          ioi_token_delete(temp,FALSE);
          s = token->text;
        }

        if( s[1] == *w )
        {
          cut = TRUE;
          s += 2;
          break;
        }
      }
    }

    if( !cut )                     /* Single character operator? */
      for( i=0 ; i<max_singles ; i++ )
        if( cut = ((*s==single_c[i][0]) && ! (nmode && *s=='/')) )
        {
          s++;
          break;
        }

    if( !cut )
      if( (*s=='\'' || *s=='"' || *s=='`') )
      {
        inside = TRUE;             /* It's a string */
        s++;

        while( *s && inside )
        {
          if( inside == *s )
          {
            inside = '\0';
            cut = TRUE;
          }
          s++;
        }
        /* CHECK the syntax using the inside! */
        /* Should be ok after the parser */
      }
      else
        if( isdigit(*s) || (*s=='.' && !nmode) ) /* It's a number */
        {
          /* FORM [xxxxx] [<.>[xxxxx]] [<E|e>[+|-][xxxx]] */
         
          while( isdigit(*s) ) s++;
          if( *s=='.' )
          {
            s++;
            while( isdigit(*s) ) s++;
          }
          if( *s=='E' || *s=='e' )
          {
            s++;
            if( *s=='+' || *s=='-' )
              s++;
            while( isdigit(*s) ) s++;
          }
  
          if( *s && s != token->text )
            cut = TRUE;
        }
        else                       /* It must be a name */
        {
          if(IS_VARIABLE(*s)) s++; /* Reference! */

          if( *s=='#' || *s=='$' ) /* Special names */
            s++;
          else
            if(nmode)
              while( isalnum(*s) || 
                     *s=='_' || *s=='/' || *s=='.' || *s==':') s++;
            else
              while( isalnum(*s) || *s=='_' ) s++;

          if( *s && s != token->text )
            cut = TRUE;
        }

    if( cut && *s &&               /* Don't cut if last character */
        s != token->text )         /* Don't cut if first character */
    {
      ioi_token *temp;

      if( !(temp = (ioi_token *)ioi_token_create(s)) )
      {
        ioi_token_delete_command();
        return
          ioi_out(FALSE,IOI_ERR,"IOI-MATH-TOKEN:No mem.");
      }

      *s = '\0';                   /* Terminate the previous one */

      temp->next  = token->next;   /* Link em and */
      token->next = temp;          /* Scan this one next! */
    }

    token = token->next;
  }

  return( TRUE );
}

int ioi_math_next(void)
/**************************************************************************
?  Read the next operator / operand (variable or constant)
=  Type of the next one.
************************************o*************************************/
{
  if( !this_one )
  {
    if(!next_token)
      this_one = M_NIL;
    else
    {
      this_token = next_token;
      next_token = next_token->next;

      if( !(this_one = ioi_user_cmdf(this_token->text,operator_c,
                                     NULL,max_operators) + 1) )
        if( !(this_one = ioi_user_cmdf(this_token->text,operator_s,
                                       NULL,max_operators) + 1) )
          this_one = M_NAME;

      if( this_one == M_SUB && 
          ( last_one > M_NIL && last_one < M_UNARY || last_one == M_OPEN ) )
        this_one = M_UNARY;
    }
    last_one = this_one;
  }

  return this_one;
}

ioi_node *ioi_math_new(void)
/**************************************************************************
?  Allocate a new branch for math-tree.
************************************o*************************************/
{
  ioi_node *new;

  if(!(new=SALLOC(ioi_node)))
  {
    ioi_out(0,IOI_ERR,"IOI-MATH-NEW:No mem.");
    return( NULL );
  }

  new->type  = IOI_L_MATH;
  new->mtype = this_one;

  if( this_one == M_NAME )
  {
    if(!(new->name = strdup(this_token->text)))
    {
      ioi_out(0,IOI_ERR,"IOI-MATH-NEW:No mem.");
      free( new );
      return( NULL );
    }
    new->level = M_PRECEDENCE;
  }
  else
    new->level = precedence[this_one-1];

  return( new );
}

ioi_node *ioi_math_make(void)
/**************************************************************************
?  Make the expression tree out of the tokens.
************************************o*************************************/
{
  ioi_node *root = NULL,           /* Root node for this sub-tree */
           *new  = NULL,           /* New sub-tree or leaf      */
           *temp;                  /* Temp for scanning       */

  while( TRUE )
  {
    if( !ioi_math_next() ) break;

    if( this_one == M_CLOSE ) break;

    if( this_one == M_OPEN )
    {
      new        = ioi_math_new();
      this_one   = M_NIL;
      new->right = ioi_math_make();

      if( this_one != M_CLOSE )
      {
        ioi_out(0,IOI_ERR,"IOI-MATH-MAKE:Closing paranthesis expected!");
        break;
      }
/*
      this_one = M_NIL;
*/

      if( !root )
        root = new;
      else
      {
        temp = root;
        while( temp->right ) temp = temp->right;
        temp->right = new;
      }
    }
    else
    {
      /* if(!(new=ioi_math_new())) break; */
      new = ioi_math_new();

      if( this_one == M_NAME )
      {
        if( !root )
          root = new;
        else
        {
          temp = root;
          while( temp->right ) temp = temp->right;
          temp->right = new;
        }
/*
        this_one = M_NIL;
*/
      }
      else                         /* It's an operator! */
      {
        if( !root )
          root = new;
        else
          if( new->level <= root->level )
          {
            new->left = root;
            root = new;
          } 
          else
          {
            temp = root;
            while( temp->right && temp->right->level < new->level )
              temp = temp->right;

            if( temp->right )
            {
              new->left = temp->right;
              temp->right = new;
            }
            else
              temp->right = new;
          }
/*
        this_one = M_NIL;
*/
      }
    }
    this_one = M_NIL; /* ADD */
    new = NULL;
  }

  return( root );
}

#if defined(CRAY) || defined(__convexc__) || defined(VMS)
/*
    arg ch = ln(x+sqrt(x*x-1))
    arg sh = ln(x+sqrt(x*x+1))
    arg th = 0.5 * ln((1+x)/(1-x))
    arg coth = 0.5 * ln((x+1)/(x-1))
*/
/*
  extern double exp(),log(),pow();
*/

  double acosh (x) double x; { return log(x+sqrt(x*x-1)); }       /* BR */
  double aint  (x) double x; { return (double)((int)x); }
  double anint (x) double x; { return (double)((int)(x+0.5)); }
  double asinh (x) double x; { return log(x+sqrt(x*x+1)); }
  double atanh (x) double x; { return 0.5*log((x+1.0)/(1.0-x)); }
  double cbrt  (x) double x; { return pow(x,1.0/3.0); }
  double exp10 (x) double x; { return pow(10.0,x); }
  double exp2  (x) double x; { return pow(2.0,x); }
  double expm1 (x) double x; { return exp(x)-1.0; }
  double lgamma(x) double x; { return 0.0; }
  double log1p (x) double x; { return log(x+1); }
  double log2  (x) double x; { return log(x)/log(2); }
  double logb  (x) double x; { return (double)((int)(log2(x)+0.000000001)); }
  double rint  (x) double x; { return (double)( (int)(x+((x<0)?(-.5):(.5))) ); }
#endif /* CRAY || __convexc__ || VMS */

#if defined(__sgi) || defined(mips) || defined(AIX) || defined(hpux) || defined(FUJITSU) || defined(linux) || defined(__alpha) || defined(__SVR4)
#  if ! defined(__sgi)
     /*extern double pow();*/
     extern double pow(double,double);
#  endif
#if 0
#ifdef hpux
  double acosh (x) double x; { return log(x+sqrt(x*x-1)); }       /* BR */
  double asinh (x) double x; { return log(x+sqrt(x*x+1)); }
  double atanh (x) double x; { return 0.5*log((x+1.0)/(1.0-x)); }
  double cbrt  (x) double x; { return pow(x,1.0/3.0); }
  double expm1 (x) double x; { return exp(x)-1.0; }
  double log1p (x) double x; { return log(x+1); }
  int    logb  (x) double x; { return (double)((int)(log2(x)+0.000000001)); }
  double rint  (x) double x; { return (double)( (int)(x+((x<0)?(-.5):(.5))) ); }
#endif
#endif

  double aint  (x) double x; { return (double)((int)x); }
  double anint (x) double x; { return (double)((int)(x+0.5)); }
  double exp10 (x) double x; { return pow(10.0,x); }
  double exp2  (x) double x; { return pow(2.0,x); }
  double log2  (x) double x; { return log(x)/log(2); }
#endif

#ifdef FUJITSU
  double expm1 (x) double x; { return exp(x)-1.0; }
  double log1p (x) double x; { return log(x+1); }
#endif

#if 0
#ifdef linux
  int    logb  (x) double x; { return (double)((int)(log2(x)+0.000000001)); }
#endif
#endif

#if defined(VMS)
#  include "erf.c"
#endif

#if defined(__convexc__) || defined(VMS)
  double drand48(x) double x; { return (double)(rand()/((1<<31)-1)); }
#endif

double ioi_math_function(ioi_node *node)
/**************************************************************************
?  Calculate the value of the function.
|  The name of the fuction is expressed in the name part of the node.
************************************o*************************************/
#define CASE(x,f) case (x): value = f( value ); break
{
  static char *funcs[] = {
    "acos",   "acosh",  "aint",   "anint",
    "asin",   "asinh",  "atan",   "atanh",
    "cbrt",   "ceil",   "cos",    "cosh",
    "erf",    "erfc",   "exp",    "expm1",
    "exp2",   "exp10",  "fabs",   "floor",
    "lgamma", "log",    "logb",   "log1p",
    "log2",   "log10",  "rint",   "sin",
    "sinh",   "sqrt",   "tan",    "tanh",
    "rand",
  };

  static int max_funcs = sizeof(funcs) / sizeof(char *);

  extern double ioi_math_evaluate();
  extern double drand48();
  double value;
  int    int_fun;

  if( !node ) return 0.0;

  int_fun = ioi_user_cmdf(node->name , funcs , NULL, max_funcs );

  value = ioi_math_evaluate( node->right );

  switch( int_fun )
  {
    CASE( 0,acos);    CASE( 1,acosh);   CASE( 2,aint);    CASE( 3,anint);
    CASE( 4,asin);    CASE( 5,asinh);   CASE( 6,atan);    CASE( 7,atanh);
    CASE( 8,cbrt);    CASE( 9,ceil);    CASE(10,cos);     CASE(11,cosh);
    CASE(12,erf);     CASE(13,erfc);    CASE(14,exp);     CASE(15,expm1);
    CASE(16,exp2);    CASE(17,exp10);   CASE(18,fabs);    CASE(19,floor);
    CASE(20,lgamma);  CASE(21,log);     CASE(22,logb);    CASE(23,log1p);
    CASE(24,log2);    CASE(25,log10);   CASE(26,rint);    CASE(27,sin);
    CASE(28,sinh);    CASE(29,sqrt);    CASE(30,tan);     CASE(31,tanh);
    case 32: value = drand48(); break;

    default:
      
      ioi_printf(FALSE,"UNKNOWN FUNCTION: ",node->name);
      ioi_math_list(stderr,node,1);
      ioi_printf(FALSE,"\n");
      value=0.0;
  }

  return value;
}

double ioi_math_evaluate(ioi_node *node)
/**************************************************************************
?  Calculate the value of the expression.
************************************o*************************************/
{
#ifdef CRAY
  void (* sig)() = signal(SIGFPE,SIG_IGN);
  /* int a = D(9999); */
#endif

  double left=0.0 , right=0.0 , rc=0.0;
  extern double ioi_variable_get_double();

  if( !node ) return( 0.0 );       /* If the root is empty! */

  if( node->mtype == M_NAME )
    if( node->right )              /* A fuction call */
      return ioi_math_function(node);
    else
      return ioi_variable_get_double(node->name);

  if( node->left )
    left = ioi_math_evaluate(node->left);

  if( node->right )
    right = ioi_math_evaluate(node->right);

  switch( node->mtype )
  {
    case M_OR   : rc = (left || right); break;
    case M_AND  : rc = (left && right); break;
    case M_EQ   : rc = (left == right); break;
    case M_NE   : rc = (left != right); break;
    case M_LT   : rc = (left <  right); break;
    case M_LE   : rc = (left <= right); break;
    case M_GT   : rc = (left >  right); break;
    case M_GE   : rc = (left >= right); break;
    case M_ADD  : rc = (left +  right); break;
    case M_SUB  : rc = (left -  right); break;
    case M_MUL  : rc = (left *  right); break;
    case M_DIV  : rc = (left /  right); break;
    case M_MOD  : rc = (((int)left) % ((int)right)); break;
    case M_POW  : rc = pow(left,right); break;
    case M_NOT  : rc = (right)?0:1; break;
    case M_UNARY: rc = -right; break;
    case M_OPEN : rc = right; break;
  }

  return rc;
}

int ioi_math_truth(ioi_node *node)
/**************************************************************************
?  Calculate the truth value of the expression (for the language module)
=  TRUE/FALSE
************************************o*************************************/
{
  if( ioi_math_evaluate(node) == 0.0 ) return FALSE;
  return TRUE;
}

int ioi_math_is_set(void)
/**************************************************************************
?  Check if this command could be an assignment statement.
|  If so execute it!
=  Boolean status. (FALSE if this was executed!)
************************************o*************************************/
{
  ioi_token *token = ioi_._token;
  ioi_node  *node  = NULL;
  char      *s;
  char      *name=NULL;

  if(!token) return( TRUE );

  s = token->text;

  while( isalnum(*s) || *s=='_' )  /* Scan the first token to detect x=... */
    s++;

  if( (*s && *s != '=') || s == token->text )
    return( TRUE );                /* Not a assignment statement */

  if( *s )                         /* It's name=xxx type */
  {
    *s = '\0';
    name = strdup(token->text);
    strcpy(token->text,++s);

    if( ! token->text[0] )         /* Is it a name= xxx type? */
      token = ioi_._token = (ioi_token *)ioi_token_delete(token,FALSE);
  }
  else
    if( token->next && token->next->text[0] == '=' )
    {
      name = strdup(token->text);
      token = ioi_._token = (ioi_token *)ioi_token_delete(token,FALSE);
      if(token->text[1])
        strcpy(token->text,&token->text[1]);
      else
        token = ioi_._token=(ioi_token *)ioi_token_delete(token,FALSE);
    }
    else
      return( TRUE );

  ioi_math_token(FALSE);           /* Normal naming */

/*
  if( ioi_token_count(ioi_._token) < 2 )
  {
    if( ioi_._token )
      ioi_variable_set(name,ioi_._token->text);
    else
      ioi_variable_set(name,"");
  }
  else
*/
  {
    node = ioi_math_make();

    ioi_variable_set_double(name,ioi_math_evaluate(node));

    if( ! ioi_._action )
      ioi_list_print(IOI_L_VARIABLE,name);

    ioi_math_delete(node);
  }

  ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,TRUE);

  IFFREE(name);
  return( FALSE );                 /* It was a assignment statement! */
}

int ioi_math_is_calc(void)
/**************************************************************************
?  Check if this command could be an expression statement. (Calculator!)
=  Boolean status. (FALSE if this was executed!)
-NOTICE  The expression can be invoked by the current math-character.
|  The default is '@'.
************************************o*************************************/
{
  ioi_node  *node;
  ioi_token *token = ioi_._token;
  char      *s;

  if(token)
  {
    if( IS_MATH(token->text[0]))   /* @-command ? */
    {
      if(token->text[1])
        strcpy(token->text,&token->text[1]); /* Shift the MATH-character */
      else
        ioi_._token = (ioi_token *)ioi_token_delete(token,FALSE);
    }
    else
      if( token->text[0] != '(' )       /* Expression in paranthesis */
        if( !isdigit(token->text[0])  ) /* Number! */
          if( token->text[0] != '-'   ) /* Unary */
            if( token->text[0] != '.' ) /* Dot */
          return TRUE;

    ioi_math_token(FALSE);              /* Normal naming */

    node = ioi_math_make();

    ioi_printf(FALSE,"%.15g\n",ioi_math_evaluate(node));

    /* printf("\n\n"); ioi_math_list_tree(node,2); */

    ioi_math_delete(node);

    ioi_._token = (ioi_token *)ioi_token_delete(ioi_._token,TRUE);
    return FALSE;
  }

  return( TRUE );
}

int ioi_math_delete(ioi_node *node)
/**************************************************************************
?  Delete the expression tree.
************************************o*************************************/
{
  if( !node ) return 0;

  if( node->left )
    ioi_math_delete( node->left );

  if( node->right )
    ioi_math_delete( node->right );

  IFFREE(node->name);

  free(node);

  return 0;
}

/**************************************************************************
*
*        D E B U G G I N G   O F   T H E   E X P R E S S I O N S 
*
************************************o*************************************/

int ioi_math_list(FILE *fp, ioi_node *node, int mode)
/**************************************************************************
?  Print the expression.
************************************o*************************************/
{
  char *s;

  if( !node ) return 0;

  if( node->mtype == M_NAME )
  {
    fprintf(fp,"%s",node->name);
    if(node->right)
      ioi_math_list( fp,node->right,mode );
    return 0;
  }

  if( node->left )
    ioi_math_list( fp,node->left,mode );

  s = (mode & 1) ? operator_c[(node->mtype)-1] : operator_s[(node->mtype)-1] ;

  fprintf( fp , (isalpha(*s) || mode>1)? " %s " : "%s" , s);
   
  if( node->right )
    ioi_math_list( fp,node->right,mode );

  if( node->mtype == M_OPEN ) fprintf(fp,")");

  return 0;
}

#define INDENT for(i=0;i<indent;i++) ioi_printf(FALSE," ")

void ioi_math_list_tree(ioi_node *node, int indent) 
/**************************************************************************
?  Print the expression in tree format.
************************************o*************************************/
{
  int i;

  if( !node ) return;

  INDENT;

  if( node->mtype == M_NAME )
  {
    ioi_printf(FALSE,"%s\n",node->name);
    if(node->right)
      ioi_math_list_tree(node->right,indent+2);
    return;
  }

  if( node->mtype != M_NAME )
    ioi_printf(FALSE, "%s\n", operator_c[(node->mtype)-1] );

  indent += 2;

  INDENT; ioi_printf(FALSE,"LEFT\n");
  ioi_math_list_tree(node->left,indent);
  INDENT; ioi_printf(FALSE,"RIGHT\n");
  ioi_math_list_tree(node->right,indent);
}

/**************************************************************************
* Logical trees:
*
* a && b || c   a || b && c   (a || b) && c   a && (b || c)
*
*       or         or               and           and
*   and    c     a    and        or     c       a     or
*  a   b             b   c      a  b                 b  c
*
* String operations:
*
*   If the name begins with $-sign or is insizde quotations the operation
*   is carried out in string format, otherwise using C-double arithmetic.
*
* Tree builder should parse the tokes on at the time while building the
* formula. The operands table is used for valid operand names.
*
*  EXAMPLE:
*
*  2/3/4/5
*
*  (2)    (/)     (/)        (/)       (/)         (/)        (/)
*         / \     / \        / \       / \         / \        / \
*       (2)     (2) (3)    (/)       (/) (4)     (/)        (/) (5)
*                          / \       / \         / \        / \
*                        (2) (3)   (2) (3)     (/) (4)    (/) (4)
*                                              / \        / \
*                                            (2) (3)    (2) (3)
*
* 2+3*4+5
*
* (2)   (+)    (+)      (+)       (+)          (+)        (+)
*       / \    / \      / \       / \          / \        / \
*     (2)    (2) (3)  (2) (*)   (2) (*)      (+)        (+) (5)
*                         / \       / \      / \        / \
*                       (3)       (3) (4)  (2) (*)    (2) (*)
*                                              / \        / \
*                                            (3) (4)    (3) (4)
*
************************************o*************************************/

