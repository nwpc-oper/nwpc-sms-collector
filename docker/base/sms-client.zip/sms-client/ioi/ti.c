
/* Test IOI */


#include "ioi.h"

main(int argc, char **argv)
{
  char line[MAXLEN];

  ioi_open(argc,argv,NULL);

  printf(" rc is %d\n",ioi_user_execute("< test"));

  while( fgets(line,MAXLEN,stdin) )
    printf(" rc is %d\n",ioi_user_execute(line));

  ioi_close();

  return 0;
}

