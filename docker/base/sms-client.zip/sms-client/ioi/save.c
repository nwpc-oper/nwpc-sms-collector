/**************************************************************************
.TITLE    Input Output Interface
.NAME     SAVE
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     26-OCT-1993 / 26-OCT-1993 / OP
.VERSION  3.0
.FILE     save.c
.LANGUAGE ANSI-C
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#include <a.out.h>
#include <fcntl.h>

ioi_save(int argc, char **argv)
/**************************************************************************
?  Dump to create executable
************************************o*************************************/
{
  static int   called;
  static char *name;

  if( called )
  {
    int file;
    struct exec executable;       /* The a.out header */

    if((file=open(ioi_._myname,O_RDONLY))<0) return
      ioi_out(0,IOI_ERR,"SAVE:can not open original file [%s]",ioi_._myname);

    read( file, &executable ,sizeof(executable));
    close(file);

    if((file=open(name,O_WRONLY|O_CREAT|O_TRUNC, 0755))<0)
      ioi_out(0,IOI_ERR,"SAVE:can not open original file [%s]",ioi_._myname);

    executable.a_bss = 0;
    executable.a_syms = 0;
    executable.a_data = sbrk(0) - 
    close(file);
  }
  else
    ioi_exe_add("save:ioi",ioi_save,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "name",IOI_L_STRING,ioi_exe_argv(
            "The file name of the new executable.", NULL
          ),NULL,-1,&name          /* Must be -1 for the above -- to work */
        ),
        NULL
      ),
      ioi_exe_argv(
        "Dump the current state of the program into a executable file",
        "The file can be executed and program continues where it was left.",
        "Programs using pipes/socets or open files is a problem.",
        NULL
      )
    );

  return called = TRUE;
}
