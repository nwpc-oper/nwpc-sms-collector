/**************************************************************************
.TITLE   Input Output Interface
.NAME    DEBUG
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    23-JUN-1991 / 31-JAN-1991 / OP
.VERSION 1.0
.FILE    debug.c
* NA
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#define OUTLEN 132


static int pos;                    /* Current character position */
static int ident;                  /* Current indentation */

#define INDENT for(i=0;i<indentation;i++) printf(" ") /* Effective? Jee! */

ioi_debug_()
/**************************************************************************
?  .
************************************o*************************************/
{

}

ioi_debug_output()
/**************************************************************************
?  .
************************************o*************************************/
{

}

ioi_debug_output()
/**************************************************************************
?  .
************************************o*************************************/
{

}

