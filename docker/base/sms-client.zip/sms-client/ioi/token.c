/**************************************************************************
.TITLE    Input Output Interface
.NAME     TOKEN
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     27-FEB-1993 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     token.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
-NOTICE Most of this stuff will be superseded by the libls
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

int ioi_token_number(ioi_token *token, int *x)
/**************************************************************************
?  Create a number and store it into integer given.
=  TRUE  if the token is a number.
|  FALSE otherwise.
*  Implement hex & octal codes!
************************************o*************************************/
{
  char *s = token->text;

  *x=0;

  if( *s == '-' ) s++;

  while( *s )
  {
    if( ! isdigit(*s) )
      return( FALSE );
    s++;
  }

  *x = atoi(token->text);

  return( TRUE );
}

ioi_token *ioi_token_create(const char *text)
/**************************************************************************
?  Make a new token. The next is cleared. Next field is cleared.
=  NULL if no memory, otherwise the new token.
************************************o*************************************/
{
  register ioi_token *token;

  text = text?text:"";

  if( !(token=SALLOC(ioi_token)) )
  {
    ioi_out(0,IOI_ERR,"IOI-TOKEN-MAKE-1:No mem.");
    return 0;
  }

  if( (token->text=strdup(text)) == NULL )
  {
    ioi_out(0,IOI_ERR,"IOI-TOKEN-MAKE-2:No mem.");
    return 0;
  }

  token->next = NULL;

  return( token );
}

ioi_token *ioi_token_delete(ioi_token *token, int all /* Delete all */)
/**************************************************************************
?  Delete the token given. If all is true all the tokens are deleted.
=  The next one. (NULL if all is selected!)
************************************o*************************************/
{
  ioi_token *temp;

  while(token)
  {
    temp = token->next;
    IFFREE(token->text);
    free(token);

    if( !all ) return( temp );
    token = temp;
  }

  return( NULL );                  /* Nothin' left! */
}

int ioi_token_join(ioi_token *token, char *text)
/**************************************************************************
?  Add the text into the token.
=  expanded text in the token itself
************************************o*************************************/
{
  ioi_token *temp;
  char      *w = ioi_._work;

  strcpy(w,token->text);
  strcat(w,text);

  temp = ioi_token_create(w);      /* Create a temp token */

  w           = token->text;       /* SWAP `em */
  token->text = temp->text;
  temp->text  = w;

  ioi_token_delete(temp,FALSE);    /* And delete the temp */

  return 0;
}

int ioi_token_replace(
    ioi_token  **token,           /* Token to be replaced               */
    char       **to   ,           /* The next character to process      */
    ioi_token   *by   ,           /* Replace the range by these         */
    int          mode )           /* 0==single token, 1==expand         */
/**************************************************************************
?  Replace a part of the TOKEN by the tokens given.
|  Used by the substitution routines (shell & variable)
=  *token == the next token to process in the calling routine
|  *to    == is the last character now "processed"
|  (that is caller performs ++ on *to)
|  The list BY will be deleted.
************************************o*************************************/
{
  ioi_token *undone = NULL;
  int        len;                  /* The skip in the last part */

  if( !by )                        /* Empty substitution */
    mode = 0;
  else
    if( ! by->next )
      mode = 0;                    /* Build into the original */

  if( **to )
    undone = ioi_token_create(*to);

  if( by )                         /* Add the first token into the */
  {                                /* end of the original token    */
    ioi_token_join(*token,by->text);

    by = ioi_token_delete(by,FALSE);
  }

  if( mode )                       /* Possible multiple tokens */
  {
    ioi_token *temp = (*token)->next;

    (*token)->next = by;

    while( by->next )
      by = by->next;

    by->next = temp;
    *token = by;
  }
  else                             /* A single token operation       */
  {                                /* Build it in the original token */
    ioi_token *orig = by;

    while( by )
    {
      ioi_token_join(*token," ");
      ioi_token_join(*token,by->text);
      by = by->next;
    }
    ioi_token_delete(orig,TRUE);
  }

  len = strlen((*token)->text);

  if( undone )
    ioi_token_join(*token,undone->text);

  *to = (*token)->text + len - 1;  /* The next is not processed yet */

  ioi_token_delete(undone,TRUE);

  return 0;
}

void ioi_token_skip_command(void)
/**************************************************************************
?  Skip the command separators in token stack.
|  The current token is jumped over the IOI_COMMAND tokens and empty ones.
************************************o*************************************/
{
  ioi_token *token = ioi_._stack;

  if( !token ) return;

  while( token && ( IS_COMMAND(token->text[0]) || !token->text[0] ) )
    token = ioi_token_delete(token,FALSE);

  ioi_._stack = token;
}

ioi_token *ioi_token_pop(
    int purge,                     /* Remove the current topmost? */
    int more  ,                    /* Wanna next token? */
    int depth )                    /* For nested prompt */
/**************************************************************************
?  Pop the top most token from the head of the stack.
|  Give pointer to the next token for the language module.
|  If the stack was empty, enquire more.
=  NULL if no more input is provided, otherwise the next token.
************************************o*************************************/
{
  if( purge )
    ioi_._token = ioi_token_delete(ioi_._token,FALSE);
  else
    if(ioi_._token)
      ioi_._token = ioi_._token->next;

  if( more )
  {
    if( !ioi_._token )             /* Stack empty? */
      if( !ioi_token_stack(depth) ) /* Get it, man! */
        return( NULL );
  }
  else
    if( ioi_._token )
    {
      ioi_token *start,*token;

      start = ioi_._stack;
      token = ioi_._token;

      ioi_._stack = token;
      ioi_._token = NULL;

      while( token->next )
        token = token->next;
      token->next = start;
    }

  return( ioi_._token );
}

int ioi_token_push(ioi_token *token)
/**************************************************************************
?  Push the token back into the head of the stack. (Current cmd!)
|  UNUSED at a moment!
************************************o*************************************/
{
  token->next = ioi_._token;
  ioi_._token = token;

  return 0;
}

void ioi_token_rethink(void)
/**************************************************************************
?  Reorganize the two token stacks.
************************************o*************************************/
{
  ioi_token *token,*start,*last;

  last  = NULL;
  token = ioi_._token;

  if( !token ) return;             /* No joining needed */

  while( token && !IS_COMMAND(token->text[0])) 
  {
    last  = token;
    token = token->next;
  }

  if( !token ) return;             /* No joining needed */

  if( last ) last->next = NULL;

  start = ioi_._stack;
  ioi_._stack = token;

  while( token && token->next )
    token = token->next;

  token->next = start;
}

void ioi_token_remove_empty(void)
/**************************************************************************
?  Remove the empty tokens from the token stack
|  Used after various substitutions.
************************************o*************************************/
{
  ioi_token *token = ioi_._stack;
  ioi_token *last;

  if( !token ) return;

  while(token && !token->text[0])  /* The first one */
    ioi_._stack = token = ioi_token_delete(token,FALSE);

  last = token;

  while(token)
    if(!token->text[0])
      last->next = token = ioi_token_delete(token,FALSE);
    else
    {
      last  = token;
      token = token->next;
    }
}

void ioi_token_delete_command(void)
/**************************************************************************
?  Delete the tokens assosiated with the previous command.
************************************o*************************************/
{
  ioi_._argc = 0;
  ioi_._token = ioi_token_delete(ioi_._token,TRUE);
}

ioi_token *ioi_token_copy(ioi_token *token)
/**************************************************************************
?  Make a copy of the tokens.
=  Start of the list if ok, NULL otherwise.
************************************o*************************************/
{
  ioi_token *start,*last;

  if( !token ) return( NULL );

  if( !(start = last = ioi_token_create(token->text)) ) return( NULL );
  token = token->next;

  while(token)
  {
    if( !(last->next = ioi_token_create(token->text)) )
      return
        ioi_token_delete(start,TRUE);

    last  = last->next;
    token = token->next;
  }

  return( start );
}

ioi_token *ioi_token_build(int argc, char **argv)
/**************************************************************************
?  Build a list of tokens out of argc-argv.
=  Start of the list if ok, NULL otherwise.
************************************o*************************************/
{
  ioi_token *token,*start;

  if( !argc ) return( NULL );

  if( !(start = token = ioi_token_create(*argv++)) ) return( NULL );
 
  while(--argc)
  {
    if( !(token->next = ioi_token_create(*argv++)) )
      return
        ioi_token_delete(start,TRUE);
    token = token->next;
  }

  return( start );
}

ioi_token *ioi_token_parse(
    char *buff,                    /* Characters to be parsed */
    int   mode)                    /* Parse really or just cut? */ /* NA */
/**************************************************************************
?  Parse buffer given into the tokens.
|  If the mode is FALSE the string is simply cutted into token at spaces.
*  NOTICE  This routine uses pointer to 1L as a catch. (not any more)
************************************o*************************************/
{
  ioi_token *token,*start,*last;
  char      *s      = buff;
  char      *first  = buff;
  char       inside = '\0'; /* Inside which quotes ' " ` */
  char       c;             /* Temp space */
  int        goon   = TRUE;

  token = start = last = NULL;

  if( !buff || !buff[0] ) return( NULL );  /* Fast fix for null input! */

  while( goon )
  {
    if( inside  )
      if( inside == *s && !IS_ESCAPE(s[-1]) )
        inside = '\0';           /* Only matching pairs! */
      else
        ;
    else
      if( (*s=='\'' || *s=='"' || *s=='`') && (s==first || !IS_ESCAPE(s[-1])) )
        inside = *s;

    if( !inside )
      if( IS_ESCAPE(*s) && s[1] )
        s++;                       /* Skip over next one */
      else
        if( s==buff && IS_SPACE(*s) )
          buff++;
        else
          if(IS_COMMAND(*s) || *s=='(' || *s==')' ||
             IS_INPUT(*s) || IS_OUTPUT(*s) || IS_PIPE(*s))
          {
            if( s != buff )        /* Terminate previous token */
            {
              c = *s;
              *s = '\0';
              if( !(token=ioi_token_create(buff)) )
                goon = FALSE;
              *s = c;
               buff = s;           /* Next for the new one */
               s--;                /* Examine this one next time */
            }
            else                   /* IOE-request */
            {
              if( IS_INPUT(*s) )                      /*  <    */
              {
                if( IS_INPUT(s[1]) )                  /*  <<   */
                {
                  s++; 
                  if( IS_COMPRESS(s[1]) ) s++;        /*  <<=  */
                }
                else
                  if( IS_COMPRESS(s[1]) ) s++;        /*  <=   */
              }
              else
                if( IS_OUTPUT(*s) )                   /*  >    */
                {
                  if( IS_OUTPUT(s[1]) )               /*  >>   */
                  {
                    s++;
                    if( IS_ERROR(s[1]) ) s++;         /*  >>&  */
                  }
                  else
                    if( IS_ERROR(s[1]) ) s++;         /*  >&   */
                    else
                      if( IS_COMPRESS(s[1]) ) s++;    /*  >=   */
                }
              c = *++s;                               /* Can be |;() */
              *s = '\0';
              if( !(token=ioi_token_create(buff)) )
                goon = FALSE;
              buff = s;
              *s-- = c;
            }
          }
          else
            if( IS_SPACE(*s) || !s[1] )  /* Terminate previous token */
            {
              if( IS_SPACE(*s) ) *s = '\0';
              if( !(token=ioi_token_create(buff)) )
                 goon = FALSE;
              buff = s+1;
            }

    if( token )
    {
      if( !start )
      {
        start = token;
        last  = token;
      }
      else
      {
        last->next = token;
        last       = token;
      }
      token = NULL;
    }
    else if( goon == FALSE )
    {
      if( start ) ioi_token_delete( start,TRUE );
      ioi_out(FALSE,IOI_ERR,"IOI-TOKEN-PARSE:Token creation failed.");
      return( NULL );
    }

    /* if( ! *++s ) goon = FALSE; */

    s++;
    if( ! *s && !IS_ESCAPE(s[-2]) ) goon = FALSE;
  }

  if( inside )
  {
    if( start ) ioi_token_delete( start,TRUE );
    ioi_out(FALSE,IOI_ERR,"IOI-TOKEN-PARSE:Unmatched %c.",inside);
    return( NULL );
  }

  return( start );
}

int ioi_token_stack(int secondary)
/**************************************************************************
?  Form the next command from the current input.
|  Possible sources for the input are:
|    - Token stack
|    - Command stack:
|      - Include file
|      - Function
|      - Command structure
|    - Stdin
=  The number of tokens in the current stack.
|  NULL, if end of input.
************************************o*************************************/
{
  ioi_token *token=NULL,*last=NULL;

  if( ioi_._token )
    ioi_token_delete(ioi_._token,TRUE);

  ioi_file_purge();

  ioi_._token = NULL;

  if( ioi_._stack )
    ioi_token_skip_command();
/*
  printf("Entering -stack (after skip)\n");
  ioi_misc_token("ioi-token",ioi_._token);
  ioi_misc_token("ioi-stack",ioi_._stack);

  printf("action=%d\n",ioi_._action?ioi_._action->type:(-1));
  if( ioi_._action && IS_CONTROL(ioi_._action->type) )
    ioi_language_list(ioi_._action,10);
*/

  while( !ioi_._stack )
  {
    if( ioi_._action && IS_CONTROL(ioi_._action->type) )
    {
      ioi_._line[0] = '\0';
      if( !ioi_language_execute((ioi_control *)ioi_._action))
      {
        ioi_action_break();
        continue;
      }
    }
    else
      if( !ioi_file_read(secondary) )
        return( FALSE );
      else
      {
        if( !ioi_._stack )
          if( ioi_._action )
            ioi_._stack=(ioi_token *)ioi_token_parse(ioi_._line,TRUE);
          else
            if( ioi_history_substitute() )
              if( ioi_._stack=(ioi_token *)ioi_token_parse(ioi_._line,TRUE) )
                ioi_history_create();
      }

    if( ioi_._stack ) ioi_token_skip_command();
  }

  last  = NULL;
  token = ioi_._token = ioi_._stack;

#ifdef IMPOSSIBLE
  if( IS_GROUP_IN(token->text[0]) )
  {
    int in_count = 1;

    while( token && in_count )
    {
      if( IS_GROUP_IN(token->text[0]) ) in_count++;
      if( IS_GROUP_OUT(token->text[0]) ) in_count--;

      last = token;
      token = token->next;
    }
  }
#endif

  while( token && !IS_COMMAND(token->text[0]))
  {
    last  = token;
    token = token->next;
  }

  if( last ) last->next = NULL;

  ioi_._stack = token;

/*
  printf("Leaving -stack\n");
  ioi_misc_token("ioi-token",ioi_._token);
  ioi_misc_token("ioi-stack",ioi_._stack);
*/
  return( TRUE );
}

void ioi_token_group(void)
/**************************************************************************
?  Process the command grouping. Replace the ( xxx ) by a null command.
=  TRUE always.
************************************o*************************************/
{
  if( TRUE ) return;
}

/**************************************************************************
*  Remark from the clp/unix system.
************************************o*************************************/

/**************************************************************************
*  History: / OP
*                                                               
*    V1 original argc & argv parser                      12.11.86
*    V2 help removed / bugs removed                        .11.86
*    V3 vax/vms version                                  21.11.86
*    V4 utility procedures removed (stand alone version)   .01.87
*    V5 cmd parser                                       13.02.88
*    V6 help handling in to cmdp                         16.02.88
*       +fmcl
*    V7 operating system call into the clp ($cmd)        25.02.88
*       +help & comment parsing improved in cmdp
*       +standard cmds [ ! ; ? $ he*lp ]
*    V8 input from a file
*    V9 expand special characters to cmds                30.08.88
*       parse special characters correctly               27.09.88
*   V10 pipe handlig | leaves rest of the line untouched 02.04.89
*   V11 included in to IOI                               11.07.90
*                                                               
************************************o*************************************/
