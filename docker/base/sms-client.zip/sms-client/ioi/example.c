/**************************************************************************
.TITLE   Utility Package Functions
.NAME    example
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    30-JUL-1992 / 23-JAN-1991 / OP
.VERSION 2.0
.DATE    11-FEB-1998 / 11-FEB-1998 / OP
.VERSION 3.2
.FILE    example.c
*
*  compile: cc -o example example.c ioi.a -lm
*
*  Test the IOI-module.
*
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#ifndef TODAY
#define TODAY "date unknown"
#endif

/**************************************************************************
*
*  Test the EXE module
*
************************************o*************************************/

ioi_exe_2(int argc, char **argv)
/**************************************************************************
?  Just test this module (temp only)
************************************o*************************************/
{
  static int called;

  static int   opt_dith[2];
  static int   opt_dith_min[2] = {  0, 0 };
  static int   opt_dith_max[2] = { 16, 8 };
  static int   opt_dith_def[2] = {  4, 4 };
  static int   opt_follow;
  static int   opt_inplace;
  static int   opt_to;
  static int   def_to = 5;
  static char *par_image;

  if( called )
  {
    ioi_misc_arg("il_ioi_convert",argc,argv);

    printf("opt_dith    %d x %d\n",opt_dith[0],opt_dith[1]);
    printf("opt_follow  %d\n",opt_follow);
    printf("opt_inplace %d\n",opt_inplace);
    printf("opt_to      %d\n",opt_to);
    printf("def_to      %d\n",def_to);
    printf("par_image   [%s]\n",par_image);
  }
  else

  ioi_exe_add("convert:ilib", ioi_exe_2,
    ioi_exe_link_param(
      ioi_exe_param(
        "-ddither",IOI_L_INTEGER,ioi_exe_argv(
          "The dither pattern size",
          "Notice that the with the variable the pattern is equal-sided.",
          NULL
        ),"il_dither",2,opt_dith,opt_dith_min,opt_dith_max,opt_dith_def
      ),
      ioi_exe_param(
        "-ffollow",IOI_L_BOOLEAN,ioi_exe_argv(
          "The new image(s) will have the original name(s). The name 'follows'",
          "the image(s) been converted. The old one(s) will be renamed to have",
          "the extension .old. Eg: x.fb -> x.fb + x.old.",
          NULL
        ),"il_follow",1,&opt_follow
      ),
      ioi_exe_param(
        "-iinplace",IOI_L_BOOLEAN,ioi_exe_argv(
          "The new image(s) will have the original name and the original ",
          "one(s) will be removed. The operation happens virtually 'in place'",
          "since the user refers the new image(s) with the same name(s). The",
          "image(s) won't actually be in the same memory.",
          NULL
        ),"il_inplace",1,&opt_inplace
      ),
      ioi_exe_param(
        "-tto",IOI_L_ENUM,ioi_exe_argv(
          "bw      Black and white image    (8-bit, no colormap)",
          "cmap    Colormap image           (8-bit, colormap-256)",
          "clen    Long Colormap image      (12/16-bit, colormap-4096)",
          "rgb     RGB image                (3x8-bit)",
          "rgba    RGB-alpha image          (4x8-bit)",
          "fb      ABGR image               (32-bit 0xaabbggrr)",
          "rbw     Real Black & White image (float, no colormap)",
          "rrgb    Real RGB image           (3xfloat)",
          "rrgba   Real RGB-alpha image     (4xfloat, alpha can be z-value)",
          "",
          "The new image(s) will be converted to the type given. It must be",
          "one of the enumerated types.",
          NULL
        ),"il_type",1,&opt_to,
        ioi_exe_argv(
          "bw","cmap","clen","rgb","rgba","fb","rrbw","rrgb","rrgba",NULL
        ),&def_to
      ),
      NULL
    ),
    ioi_exe_link_param(
      ioi_exe_param(
        "image",IOI_L_STRING,ioi_exe_argv(
          "Image name to be converted. The image named must exist.",
          NULL
        ),NULL,-1,&par_image
      ),
      NULL
    ),
    ioi_exe_argv(
      "Convert image(s) given into the type specified by the t-option.",
      "The image(s) are converted and the names of the resulting image(s) are",
      "derived from the originals. The default new name is the original base",
      "name plus the extension of the target type. Eg: x -> x.fb.",
      NULL
    )
  );

  return called = TRUE;
}

example(int argc, char **argv)
{
  ioi_exe_2(0,NULL);

  return main4(0,NULL);
}

/**************************************************************************
*
*  Just a simple argc-argv command display example
*
************************************o*************************************/

main4(int argc, char **argv)
{
  ioi_open(argc,argv,NULL);

  while( ioi_user_cmd(&argc,&argv) )
  {
    ioi_misc_arg("Main",argc,argv);
  }

  ioi_close();

  return 0;
}

/**************************************************************************
*
*  A simple input routine for the IOI. Normally you want to display your 
*  own prompt in this routine, so the IOI should be advised not to prompt.
*
************************************o*************************************/

int getit(char *buff, int max)
{
  printf("oh jee> ");
  return (int)
    fgets(buff,max,stdin);
}

int getit_v2_0(char *buff, int max, int depth)
{
  if( ! depth )
    printf("oh jee>");
  else
    while( depth-- ) putchar('>');
  putchar(' ');

  return (int)
    fgets(buff,max,stdin);
}

/**************************************************************************
*
*  A simple example how to generate a string menu.
*  The user has decided to use own input routine.
*  NOTICE the use of static variables and sizeof function.
*
************************************o*************************************/
main3(int argc, char **argv)
{
  static char *cmds[] = {
    "abc", "efg", "hij", "klm"
  };

  static char *helps[] = {
    "help1", "help2", "help3", "help4"
  };

  static int params[] = {
    0, 0, 0, 1
  };

  static int first_time = TRUE;
  static int lengths[ sizeof(cmds) / sizeof(char *) ];

  int    maxcmd = sizeof(cmds) / sizeof(char *);

  int    keep_going = TRUE;
  int    rc;

  ioi_open(argc,argv,NULL);
  ioi_user_input(getit);
  ioi_variable_set("prompt","");
/*
  ioi_user_prompt_load(NULL);
*/

  if( first_time )
  {
    ioi_user_fmcl(cmds,lengths,maxcmd);
    first_time = FALSE;
  }

  while( keep_going )
  {
    if( (rc=ioi_user_menu("example",&argc,&argv,cmds,helps,lengths,params,maxcmd))
         == maxcmd )
      keep_going = FALSE;
    else 
    {
      switch( rc )
      {
        case 0: case 1: case 2: case 3:
          printf("cmd %d\n",rc+1);
          break;
      }
      ioi_token_delete_command();
    }
  }

  ioi_close();

  return 0;
}


/**************************************************************************
*
*  Just a simple argc-argv command display example
*
************************************o*************************************/

/**************************************************************************
.TITLE   Utility Package Functions
.NAME    ish
.SECTION L
.AUTHOR  Otto Pesonen
.DATE    29-NOV-1991 / 07-MAY-1990 / OP
.VERSION 2.0
.FILE    example.c
*
*  Compile: cc -Dish=main -o ish example.c ioi.a -lm
*
************************************o*************************************/

int ish_exit( int code )
{
  ioi_printf(IOI_ECHO,"Goodbye %s\n",cuserid(NULL));
  exit( code );
  return 0;
}

test_it(int argc, char **argv)
/**************************************************************************
?  Test multi dim array
************************************o*************************************/
{
  static int    called;
  static double x[3];
 
  if( called )
  {
    printf("TEST IT: %g %g %g\n",x[0],x[1],x[2]);
  }
  else
    ioi_exe_add("array:ioi",test_it,
      NULL,
      ioi_exe_link_param(
        ioi_exe_param(
          "xoordinates",IOI_L_DOUBLE,ioi_exe_argv(
            "The corrdinates x,y,z",
            NULL
          ),NULL,3,x,NULL,NULL,NULL
        ),
        NULL
      ),
      ioi_exe_argv(
        "Test multi dim array",
        "Line two?",
        NULL
      )
    );
 
  return called = TRUE;
}

char *get_tput(char *name)
{
  char  buff[MAXLEN];
  FILE *pp;
  int   len=0;

  sprintf(buff,"tput %s",name);
#if defined(unix) || defined(UNIX)
  pp = popen(buff,"r");
  len = fread(buff,1,MAXLEN,pp);
  pclose(pp);
#endif

  buff[len]=0;

  return strdup(buff);
}

ish_out(int type, char *line, int len)
{
  static FILE *fp;
  static char *bold,*normal,*reverse;

  if( !fp )
  {
    fp=fopen("foo","a");
    bold = get_tput("bold");
    normal = get_tput("rmso");
    reverse = get_tput("smso");
  }

  if(type==IOI_RAW)
    fwrite(line,1,len,fp);
  else if(type==IOI_ERR)
  {
    fprintf(fp,"%s",reverse);
    fprintf(fp,"%s",line);
    fprintf(fp,"%s",normal);
  }
  else if(type==IOI_WAR)
  {
    fprintf(fp,"%s",bold);
    fprintf(fp,"%s",line);
    fprintf(fp,"%s",normal);
  }
  else
    fprintf(fp,"%s",line);

  fflush(fp);

  return 0;
}
 
ish(argc,argv) int argc; char **argv;
{
  ioi_open(argc,argv,NULL);
/*
  ioi_try_name("ISHRC");
*/

  ioi_variable_set("prompt","ish");
  ioi_user_exit(ish_exit);
/*
  ioi_user_output(ish_out);
*/

  ioi_printf(IOI_ECHO,"Wellcome to IOI-shell version 3.3, compiled on %s\n",
             TODAY);

  test_it(0,NULL);

  while( ioi_user_cmd(&argc,&argv) )
    if(argc)
      ioi_printf(IOI_ERR,"ish: unknown command %s\n",*argv);

    /* ioi_misc_arg("ish",argc,argv); */

  ioi_close();
}


/**************************************************************************
*
*  Just an example to show how to use the ioi_ routines. A bit dumb.
*
************************************o*************************************/

main1(argc,argv) int argc; char **argv;
{
  ioi_open(argc,argv,NULL);

  argc = ioi_misc_arg_fill(argv,"Atest","IOI","List","all",NULL);
  ioi_alias_create(argc,argv);
  ioi_list_print(IOI_L_ALIAS,NULL);
  argc = ioi_misc_arg_fill(argv,"Atest","List","all",NULL);
  ioi_alias_create(argc,argv);
  ioi_list_print(IOI_L_ALIAS,NULL);

  argc = ioi_misc_arg_fill(argv,"Vtest","Vdef",NULL);
  ioi_variable_create(argc,argv);
  argc = ioi_misc_arg_fill(argv,"Vtest2","Vdef22",NULL);
  ioi_variable_create(argc,argv);
  ioi_list_print(IOI_L_VARIABLE,NULL);
  ioi_list_delete(IOI_L_VARIABLE,"Vtest");
  ioi_list_print(IOI_L_VARIABLE,NULL);

  ioi_close();

  return 0;
}
