/**************************************************************************
.TITLE    Input Output Interface
.NAME     LIST
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     23-MAR-1992 / 04-OCT-1990 / OP
.VERSION  2.0
.FILE     list.c
.DATE     05-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.NOTICE   This module is going to ge superseded by libls
.DATE     14-JUL-1994 / 14-JUL-1994 / OP
.VERSION  3.1
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

ioi_gen *ioi_list_start(int type)
/**************************************************************************
?  Get the start of the list of type given.
=  NULL if not found or type incorrect, otherwise pointer to the item.
************************************o*************************************/
{
  switch(type)
  {
    case IOI_L_ALIAS:    return (ioi_gen *) ioi_._alias;
    case IOI_L_HISTORY:  return (ioi_gen *) ioi_._history;
    case IOI_L_VARIABLE: return (ioi_gen *) ioi_._variable;
    case IOI_L_FUNCTION: return (ioi_gen *) ioi_._function;
    case IOI_L_EXE:      return (ioi_gen *) ioi_._exe;
    default: return NULL;
  }
}

ioi_gen *ioi_list_get(int type, char *name, int numflag /* history number? */)
/**************************************************************************
?  Get an item NAME from the list of TYPE.
|  If history is requested by the name, all history lines are scanned and
|  the latest line that matches with the name is returned.
=  NULL if not found or type incorrect, otherwise pointer to the item.
************************************o*************************************/
{
  ioi_gen *gen;
  int      line;

  if( !numflag && !name ) return NULL;

  gen = ioi_list_start( type );

  if( type==IOI_L_HISTORY )
  {
    ioi_history *history = (ioi_history *)gen;

    if( numflag )                  /* Search by the number */
    {
      line=(int)name;

      while( history )
      {
        if( history->num == line )
          return (ioi_gen *) history ;
        history = history->next;
      }
    }
    else                           /* Search the last mathcing name */
    {
      int   len = strlen(name);

      gen = NULL;                  /* Not found so far */

      while( history )
      {
        if( !strncmp( history->name , name , len ) )
          gen = (ioi_gen *)history;
        history = history->next;
      }

      return gen;
    }
  }
  else
    while( gen )                   /* Otherwise it gotta be full name */
    {
      if( !strcmp( gen->name , name ) ) 
        return gen;
      gen = gen->next;
    }

  return NULL;
}

int ioi_list_mlen(int type)
/**************************************************************************
?  Calculate the longest name length.
=  Maximum length of the items of the type given. If zero the list of
|  type is empty.
************************************o*************************************/
{
  ioi_gen *gen;

  int      mlen = 0;               /* Count the max length of the name */
  int      len; 

  gen=ioi_list_start(type);

  while( gen )
  {
    len  = strlen( gen->name );
    mlen = MAX(mlen,len);
    gen  = gen->next;
  }

  return mlen;
}

int ioi_list_print_all(int type, int columns)
/**************************************************************************
?  Print all names in the list. Count the maximum length of the items and
|  format output accordingly.
=  TRUE
************************************o*************************************/
{
  ioi_gen *gen;
  int      mlen = 0;               /* Count the max length of the name */
  int      i    = 0;               /* Current position */
  char     fmt[MAXLEN];            /* Format string for the printf */

  if( ! (mlen = ioi_list_mlen(type)) ) return TRUE;

  gen   = ioi_list_start(type);
  mlen += 2;
  sprintf(fmt,"%%-%ds",mlen);

  while( gen )
  {
    ioi_printf(FALSE, fmt,gen->name );
    i += mlen;
    if( i+mlen>80 )
      ioi_printf(FALSE,"\n") , i=0;
    gen = gen->next;
  }

  if(i) ioi_printf(FALSE,"\n");
  ioi_printf(FALSE,"\n");

  return TRUE;
}

int ioi_list_print(int type, char *name)
/**************************************************************************
?  Print all items in the list of type TYPE in the stdout or if the name
|  is not NULL search for that item and print it.
************************************o*************************************/
{
  ioi_token     *token;
  ioi_alias     *alias;
  ioi_history   *history;
  ioi_function  *function;
  ioi_variable  *variable;
  ioi_gen       *gen;
  ioi_exe       *exe;
  char        **argv;              /* Temp to scan the args   */
  int           number = FALSE;    /* For the history request */
  int           i;


  if( type==IOI_L_HISTORY && name )
  {
    number = atoi(name);
    name = NULL;
    if(number<0) number = 0;
  }

  gen = ( name )? ioi_list_get( type,name,FALSE ) : ioi_list_start( type );

  while( gen )
  {
    switch( type )
    {
      case IOI_L_ALIAS:
        ioi_printf(FALSE,"%-20s :",gen->name);
        alias = (ioi_alias *)gen;
        for( i=alias->argc , argv=alias->argv ; i ; i--)
          ioi_printf(FALSE," %s",*argv++);
        ioi_printf(FALSE,"\n");
        break;
      case IOI_L_HISTORY:
        history = (ioi_history *)gen;
        if(!number || (ioi_._hist_num - history->num < number) )
        {
          ioi_printf(FALSE,"%-6d",history->num);
          for( i=history->argc , argv=history->argv ; i ; i--)
            ioi_printf(FALSE," %s",*argv++);
          ioi_printf(FALSE,"\n");
        }
        break;
      case IOI_L_VARIABLE:
        ioi_printf(FALSE,"%-20s :",gen->name);
        variable = (ioi_variable *)gen;
        ioi_printf(FALSE," %s",variable->definition);
        ioi_printf(FALSE,"\n");
        break;
      case IOI_L_FUNCTION:
        function = ( ioi_function * )gen;
        token    = function->lines;
        ioi_printf(FALSE,"define %s {",gen->name);

        if( !token || (token && !token->next && token->text[0]!=' ') )
          ioi_printf(FALSE," %s ",token?token->text:"");
        else
        {
          ioi_printf(FALSE,"\n");
          while( token )
          {
            ioi_printf(FALSE,"%s\n",token->text);
            token = token->next;
          }
        }
        ioi_printf(FALSE,"}\n\n",gen->name);
        break;
      case IOI_L_EXE:
        ioi_printf(FALSE,"%-10s :",gen->name);
        exe = (ioi_exe *)gen;
        ioi_printf(FALSE,"%s\n",(exe->margv)?exe->margv[0]:"");
        break;
      default:
        return FALSE;
    }

    gen = gen->next;
    if( name ) gen = NULL;
  }

  return TRUE;
}

int ioi_list_add(int type, ioi_gen *newone)
/**************************************************************************
?  Add a newone(?) item into the list of type.
|  If the item already exists in the list the old one is removed.
=  Always TRUE
-NOTICE  At the moment there is no sorting of the list.
************************************o*************************************/
{
  ioi_gen       *gen,*tmp;
  char         **argv;
  int            i;

  newone->next = NULL;

  gen = ioi_list_start(type);

  switch( type )
  {
    case IOI_L_ALIAS:
      if( tmp=ioi_list_get(type,newone->name,FALSE) )
      {
        ioi_alias *old = (ioi_alias *)tmp;
        ioi_alias *die = (ioi_alias *)newone;

        for( i=old->argc , argv=old->argv ; i ; )
          free(argv[--i]);
        free(argv);

        old->argv = die->argv;
        old->argc = die->argc;
        free(die->name);
        free(die);
      }
      else
      {
        if( gen )
        {
          while(gen) { tmp = gen; gen = gen->next; }
          tmp->next = newone;
        }
        else
           ioi_._alias = (ioi_alias *)newone;
      }
      break;
    case IOI_L_HISTORY:
      if( gen )
      {
        while(gen) { tmp = gen; gen = gen->next; }
        tmp->next = newone;
      }
      else
         ioi_._history = (ioi_history *)newone;
      break;
    case IOI_L_VARIABLE:
      if( tmp=ioi_list_get(type,newone->name,FALSE) )
      {
        ioi_variable *old = (ioi_variable *)tmp;
        ioi_variable *die = (ioi_variable *)newone;

        free(old->definition);
        old->definition = die->definition;
        free(die->name);
        free(die);
      }
      else
      {
        if( gen )
        {
          while(gen) { tmp = gen; gen = gen->next; }
          tmp->next = newone;
        }
        else
          ioi_._variable = (ioi_variable *)newone;
      }
      break;
    case IOI_L_FUNCTION:
      if( tmp=ioi_list_get(type,newone->name,FALSE) )
      {
        ioi_function *old = (ioi_function *)tmp;
        ioi_function *die = (ioi_function *)newone;

        ioi_token_delete(old->lines,TRUE);
        old->lines = die->lines;
        free(die->name);
        free(die);
      }
      else
      {
        if( gen )
        {
          while(gen) { tmp = gen; gen = gen->next; }
          tmp->next = newone;
        }
        else
          ioi_._function = (ioi_function *)newone;
      }
      break;
    case IOI_L_EXE:
      if( gen )
      {
        while(gen) { tmp = gen; gen = gen->next; }
        tmp->next = newone;
      }
      else
        ioi_._exe = (ioi_exe *)newone;
      break;
  }

  return TRUE;
}

ioi_gen *ioi_list_copy(
    int      type,                 /* List type           */
    ioi_gen *old,                  /* Generic list entity */
    int      all)                  /* Copy all of them?   */
/**************************************************************************
?  Copy the entity old of type given. 
|  The new one's won't have names.
************************************o*************************************/
{
  ioi_gen *gen,*start=NULL;
  int      size=0;

  while(old)
  {
    switch( type )
    {
      case IOI_L_ALIAS   : size = sizeof(ioi_alias);    break;
      case IOI_L_VARIABLE: size = sizeof(ioi_variable); break;
      case IOI_L_TOKEN   : size = sizeof(ioi_token);    break;
    }
    old = (all)? old->next : NULL;
  }

  return start;
}

int ioi_list_delete(int type, char *name)
/**************************************************************************
?  Unset (delete) an item from the list.
-NOTICE  It's not an error to delete something that doesn't exist.
************************************o*************************************/
{
  ioi_alias     *alias;
  ioi_function  *function;
  ioi_history   *history;
  ioi_variable  *variable;
  ioi_exe       *exe;

  ioi_gen       *start,*die,*last;
  char         **argv;
  int            i;

  start = ioi_list_start(type);

  die   = ioi_list_get(type,name,TRUE);

  if(!start || !die) return 0;

  if( start==die )                 /* Delete the very first one */
  {
    switch( type )
    {
      case IOI_L_ALIAS:    ioi_._alias    = ioi_._alias->next;    break;
      case IOI_L_HISTORY:  ioi_._history  = ioi_._history->next;  break;
      case IOI_L_VARIABLE: ioi_._variable = ioi_._variable->next; break;
      case IOI_L_FUNCTION: ioi_._function = ioi_._function->next; break;
      case IOI_L_EXE:      ioi_._exe      = ioi_._exe->next;      break;
    }
  }
  else
  {
    while(start != die) { last = start; start = start->next; }
    last->next = die->next;
  }

  switch( type )
  {
    case IOI_L_ALIAS:
      alias = (ioi_alias *)die;
      
      for( i=alias->argc , argv=alias->argv ; i ; )
          free(argv[--i]);
      free(argv);
      free(alias->name);
      break;
    case IOI_L_HISTORY:
      history = (ioi_history *)die;

      for( i=history->argc , argv=history->argv ; i ; )
        free(argv[--i]);
      free(argv);
      free(history->name);
      break;
    case IOI_L_VARIABLE:
      variable = (ioi_variable *)die;
      IFFREE(variable->definition);
      IFFREE(variable->name);
      break;
    case IOI_L_FUNCTION:
      function = (ioi_function *)die;
      IFFREE(function->name);
      ioi_token_delete(function->lines,TRUE);
      break;
    case IOI_L_EXE:
      ioi_exe_delete((ioi_exe *)die);
      break;
  }

  free(die);

  return 0;
}

int ioi_list_delete_all(int type)
/**************************************************************************
?  Delete all items in the list of type.
-NOTICE  For type IOI_L_HISTORY this is obsole. (use ioi_history_set(0))
************************************o*************************************/
{
  ioi_gen *gen;

  if( type==IOI_L_HISTORY ) return 0;

  gen = ioi_list_start(type);

  while( gen )
  {
    ioi_gen *next = gen->next;
    ioi_list_delete(type,gen->name);
    gen = next;
  }

  return 0;
}

