/**************************************************************************
.TITLE    Input Output Interface
.NAME     HISTORY
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     15-DEC-1992 / 04-OCT-1990 / OP
.VERSION  2.1
.FILE     history.c
.DATE     24-NOV-1993 / 05-NOV-1993 / OP
.VERSION  3.0
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

static int save(char *name)
/**************************************************************************
?  Save the history in to the file NAME
=  Boolean status.
************************************o*************************************/
{
  ioi_history *history = (ioi_history *)ioi_list_start(IOI_L_HISTORY);
  FILE        *fp;
  int          i;
  char       **argv;
  int          rc;

/*
  if( ! (name=(char *)ioi_file_substitute(name)) )
    return FALSE;
*/

  if(!(fp=fopen(name,"w")))
    ioi_out(FALSE,IOI_ERR,"IOI-HISTORY-SAVE:Open failed for %s",name);
  else
    while(history)
    {
      for( i=history->argc , argv=history->argv ; i ; i--)
        fprintf(fp," %s",*argv++);
      fprintf(fp,"\n");

      history = history->next;
    }

  rc = fp?1:0;

  FCLOSE(fp);

  return rc;
}

static int load(char *name)
/**************************************************************************
?  Load the history back from the file NAME
=  Boolean status.
************************************o*************************************/
{
  ioi_token   *stack = ioi_._stack;
  char         buff[MAXLEN];
  FILE        *fp;
  int          rc;

/*
  if( ! (name=(char *)ioi_file_substitute(name)) )
    return FALSE;
*/

  if(!(fp=fopen(name,"r")))
    ioi_out(0,IOI_ERR,"IOI-HISTORY-LOAD:Open failed for %s",name);
  else
    while( fgets(buff,MAXLEN,fp) )
    {
      ioi_._stack = (ioi_token *)ioi_token_parse(buff,TRUE);
      ioi_history_create();
      ioi_token_delete(ioi_._stack,TRUE);
    }

  rc = fp?1:0;

  FCLOSE(fp);
  ioi_._stack = stack;

  return rc;
}

int ioi_history_create(void)
/**************************************************************************
?  Create a history line (if history turned on) and add it into the stack.
|  Empty lines are not added.
*  (FUTURE) File reading may prevent adding.
************************************o*************************************/
{
  ioi_history *history;
  ioi_token   *token = ioi_._stack;

  int          tokens = ls_len(&ioi_._stack);
  int          i,j;
  char       **argv;

  if( ioi_._hist_len <= 0 ) return 0;
  if( tokens < 1 ) return 0;

  if( !(history=SALLOC(ioi_history)) )
    return ioi_out(0,IOI_ERR,"IOI-HISTORY-ADD-1:No mem\n");

  if( (history->name=strdup(token->text)) == NULL )
  {
    free(history);
    return ioi_out(0,IOI_ERR,"IOI-HISTORY-ADD-2:No mem\n");
  }

  if( !(argv=(char **)ALLOC(tokens*sizeof(char *) + 1)) )
  {
    free(history->name);
    free(history);
    return ioi_out(0,IOI_ERR,"IOI-HISTORY-ADD-3:No mem\n");
  }

  for( i=0 ; i<tokens ; i++)
  {
    if( (argv[i]=strdup(token->text)) == NULL )
    {
      for(j=0 ; j<i ; j++)
        free(argv[j]);
      free(argv);
      free(history->name);
      free(history);
      return ioi_out(0,IOI_ERR,"IOI-HISTORY-ADD-4:No mem\n");
    }
    token = token->next;
  }
 
  history->next = NULL;
  history->argc = tokens;
  history->argv = argv;
  history->num  = ++ioi_._hist_num;

  ioi_list_add(IOI_L_HISTORY,(ioi_gen *)history);
  ioi_list_delete(IOI_L_HISTORY,(char *)(ioi_._hist_num-ioi_._hist_len));

  return TRUE ;
}

int ioi_history_substitute(void)
/**************************************************************************
?  Substitute the history references in the current line.
|  History reference:
|  <history> ::= <'!'>[<num>|<token>|<'!'>]
|  <num>     ::= [<integer> ! <0>]
|  <token>   ::= <part_of_first_token>
=  TRUE if the history substitution was successfull, FASLE otherwise.
************************************o*************************************/
{
  ioi_history *history;
  char        *work   = ioi_._work;
  char        *w     = work;
  char        *line  = ioi_._line;
  char         last  = '\0';
  int          copy  = FALSE;
  int          sign;
  int          num;                /* History reference number */

  if( ioi_._hist_len < 1) return(TRUE);

  while(*line)
  {
    if( IS_HISTORY(*line) && !IS_ESCAPE(last) )
    {
      last    = *line++;
      sign    = FALSE;
      num     = 0;
      history = NULL;

      switch(*line)
      {
        case '\n':
        case '\0':
        case ' ' :
        case '(' :
        case '=' :
        case ';' :
          *w++ = last;
          *w++ = *line++;
          break;

        case '-' :                 /* Is it a number (negative?) */
          sign = TRUE;
        case '1': case '2': case '3': case '4': case '5':
        case '6': case '7': case '8': case '9': case '0':
          if(*line != '-') num = (*line) - '0';

          while( isdigit(*++line) )
            num = num*10 + (*line) - '0';

          if(sign) num = ioi_._hist_num-num;
          last = '\0';

          if( !(history = (ioi_history *)
                ioi_list_get(IOI_L_HISTORY,(char *)num,TRUE)) )
            return ioi_out(FALSE,IOI_ERR,
              "IOI-HISTORY-SUBSTITUTION:%d: Event not found.",num);
          break;

        case '?':
          return ioi_out(FALSE,IOI_WAR,
              "IOI-HISTORY-SUBSTITUTION:? Not implemented yet! Sorry.");

        default:
          if( IS_HISTORY(*line) )  /* Previous command */
          {
            history = (ioi_history *)
              ioi_list_get(IOI_L_HISTORY,(char *)ioi_._hist_num,TRUE);
            line++;
          }
          else
          {
            char  name[MAXLEN];
            char *n = name;

            if( IS_SHELL(*line) || IS_MATH(*line) ||
                IS_INPUT(*line) || IS_OUTPUT(*line) )
              *n++ = *line++;

            while( isalnum(*line) || (*line=='.') || (*line=='/') ||
                   (*line=='-') || (*line=='_') )
              *n++ = *line++;

            *n='\0';

            if( !name[0] )
              return
                ioi_out(FALSE,IOI_ERR,"IOI-HISTORY-SUBSTITUTE:Bad name.");
            if( !(history = (ioi_history *)
                ioi_list_get(IOI_L_HISTORY,name,FALSE)) )
              return
                ioi_out(FALSE,IOI_ERR,"%s: Event not found.",name);
          }
      }

      if(history)
      {
        int    i;
        char **argv;
        int    len    = w - work;
        int    maxlen = ioi_._lsize;
        int    tmplen;

        for( i=history->argc , argv=history->argv ; i ; i-- )
        {
          tmplen = strlen(*argv);

          if(len+tmplen+1 >= maxlen)
            return
              ioi_out(FALSE,IOI_ERR,"IOI-HISTORY-SUBSTITUTE:Result too long.");

          strcpy(w,*argv++);
          len += tmplen;

          if(i > 1) work[len++] = ' ';   /* Don't advance the last one */

          w = work+len;
        }
        copy = TRUE;
        last = '\0';
      }
    }
    else
    {
      last = *line;
      *w++ = *line++;
    }
  }

  if( copy )
  {
    *w = '\0';
    strcpy( ioi_._line , work );

    ioi_out(0,IOI_MSG,"%s",ioi_._line);
  }

  return( TRUE );
}

void ioi_history_set(int len)
/**************************************************************************
?  Set the history to be of length len.
|  Negative length is treated to be equal to zero.
************************************o*************************************/
{
  int i;

  if( len<2 ) len=0;

  if(ioi_._hist_len > len)         /* Need to delete old lines? */
    for( i=ioi_._hist_num-ioi_._hist_len+1 ;
         i<ioi_._hist_num-len+1 ; i++ )
      ioi_list_delete(IOI_L_HISTORY,(char *)i);

  if(len == 0) ioi_._history = NULL;

  ioi_._hist_len = len;
}

int ioi_history_cmd(int argc, char **argv)
/**************************************************************************
?  Execute the history command.
=  TRUE
************************************o*************************************/
{
  static int   called;
  static int   len     ,
               imin = 0;
  static char *load_name;
  static char *save_name;

  if( called )
  {
    char         cmd[MAXLEN];      /* List printing is a bit stupid! */

    if( load_name )
      return load(load_name);

    if( save_name )
      return save(save_name);

    sprintf(cmd,"%d",len);         /* Let's change this later on */
    ioi_list_print(IOI_L_HISTORY,cmd);
  }
  else
    ioi_exe_add("history:ioi",ioi_history_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-lload",IOI_L_PATH,ioi_exe_argv(
            "The history file name to be loaded.",
            "To do it automatically, put following lines into the IOIRC",
            "  history -l ~/.ioihistory",
            NULL
          ),NULL,1,&load_name
        ),
        ioi_exe_param(
          "-ssave",IOI_L_PATH,ioi_exe_argv(
            "The file name where to save the current history.",
            "To do it automatically at the end of the execution, IOIRC:",
            "  alias exit history -s ~/.ioihistory \\; /exit",
            "  <warining> the '/' before last exit MUST BE THERE!!!",
            NULL
          ),NULL,1,&save_name
        ),
        NULL
      ),
      ioi_exe_link_param(
        ioi_exe_param(
          "lenght",IOI_L_INTEGER,ioi_exe_argv(
            "Number of lines to be printed.",
            NULL
          ),NULL,1,&len,&imin,NULL,&ioi_._hist_len
        ),
        NULL
      ),
      ioi_exe_argv(
#include "history.h"
      )
    );


  return called=TRUE;
}
