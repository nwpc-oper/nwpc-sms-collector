/**************************************************************************
.TITLE    Input Output Interface
.NAME     EDITOR
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     t.c
.LANGUAGE ANSI-C
.DATE     27-JUL-1995 / xx-MAY-1995 / OP
.VERSION  3.3
*         Termio based line-editing added
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#ifdef sun
#define memmove memcpy
#endif

#include <curses.h>
#include <term.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>

void dump(char *s)
{
  char *ss = s;

  printf("%p\n",s);
  if( s == (char *)(-1) ) return;

  if( s )
  {
    printf("contains: hex:");

    for( s=ss; *s ; s++ )
      printf(" 0x%02x",*s);
    printf("\n");

    printf("          dec:");

    for( s=ss; *s ; s++ )
      printf(" (%02d)",*s);
    printf("\n");

    printf("        ascii:");

    for( s=ss; *s ; s++ )
      printf("   %c ",isprint(*s)? *s : ' ');
    printf("\n");
  }
}

list(char *header, char **names, char **codes, char **fnames)
{
  printf("<<< %s >>>\n\n",header);

  while(*names)
  {
    printf("%-25s %-25s %-25s\n",*names, *codes?*codes:"",  *fnames?*fnames:"");
    dump(*codes);
    names++;
    if(*codes) codes++;
    if(*fnames) fnames++;
  }
}

int out(int c)
{
  char cc = c;
  return write(1,&cc,1);
}

static int in_wait(int fd, int wait_usec)
/**************************************************************************
?  Read a character form file "fd" with delay specified as "wait_usec"
|  in micro-seconds ( -1 as wait_usec blocks indefinetely)
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
  char            c;
  fd_set          readfds;
  struct timeval  timeout;

  timeout.tv_sec  = 0;
  timeout.tv_usec = wait_usec;

  FD_ZERO(&readfds);
  FD_SET(fd,&readfds);

#ifdef FD_SETSIZE
  switch( select(FD_SETSIZE,&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#else
  switch( select(8*sizeof(readfds),&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#endif
  {
    case -1:
      return -1;
      break;

    case 0:
      return -1;
      break;

    case 1:
      if( read(fd, &c, 1) == 1 )
        return (int)c;
      else
        return -1;
      break;

    default: /* hymm... donno, must be some sort of an error */
      return -1;
      break;
  }
}


static _KEY_MAP *keys[10];

#define GET_KEY(key_send,key_code)             \
  if( (key_send) )                             \
  {                                            \
    _KEY_MAP *kp = calloc(sizeof(_KEY_MAP),1); \
    if(!kp) return 0;                          \
    kp->_sends = strdup((key_send));           \
    kp->_keyval = (key_code);                  \
    keys[i++] = kp;                            \
printf("got key %s\n",#key_code); \
dump(kp->_sends); \
  } else

static int get_keys(void)
{
  int i=0;

  GET_KEY(key_left,KEY_LEFT);
  GET_KEY(key_right,KEY_RIGHT);
  GET_KEY(key_up,KEY_UP);
  GET_KEY(key_down,KEY_DOWN);
  GET_KEY(key_home,KEY_HOME);
  GET_KEY(key_end,KEY_END);
  GET_KEY(key_home,KEY_EOL);
  GET_KEY(key_backspace,KEY_BACKSPACE);

  printf("Found %d keys\n",i);
  return 1;
}

static int in(int fd)
/**************************************************************************
?  Read a character form file "fd" 
|  If an escape is pressed and more characters apper withing a timeout
|  a function key value may be returned
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
#define MAX_TYPE_AHEAD 10

  int c;
  static char type_ahead[MAX_TYPE_AHEAD];  /* If we read for function keys */
  static int  type_ahead_len;              /* but there is no match        */
  _KEY_MAP  *kp;
  int        num_matches = 1;

printf("In function in()\n");

  if( type_ahead_len )
  {
    c = type_ahead[0];
    memmove(type_ahead,type_ahead+1,--type_ahead_len);
    return c;
  }

  if( (c=in_wait(fd, -1)) == -1 )
    return -1;

  type_ahead[type_ahead_len++] = c;

  while( type_ahead_len < MAX_TYPE_AHEAD && num_matches )
  {
    int i;
    num_matches = 0;

printf("type_ahead_len %d ",type_ahead_len);
for(i=0 ; i<type_ahead_len ; i++)
  printf("%d ",type_ahead[i]);
printf("\n");

    for( i=0, kp=keys[i]; kp ; kp=keys[++i] )
    {
printf("Key %d?\n",kp->_keyval);
      if( strncmp( kp->_sends , type_ahead , type_ahead_len ) == 0 )
      {
        num_matches++;
        if( strlen( kp->_sends ) == type_ahead_len )
        {
          type_ahead_len = 0;
          return kp->_keyval;
        }
      }
    }

printf("num_matches %d\n",num_matches);

    if( num_matches )              /* Beginning macthes but not completely */
    {                              /* Get more, with small delay           */
      if( (c=in_wait(fd, 100000)) == -1 )
      {
        c = type_ahead[0];
        memmove(type_ahead,type_ahead+1,--type_ahead_len);
printf("No FC\n");
        return c;
      }

      type_ahead[type_ahead_len++] = c;
    }
  }

  /* No match, buffer full => return the first */

  c = type_ahead[0];
  memmove(type_ahead,type_ahead+1,--type_ahead_len);
  return c;
}

void init(void)
{
  TERMINAL *tp;
  int c;

#if 1
  setupterm(NULL,fileno(stdin),NULL);
#else
  newterm(NULL,stdin,stdout);
#endif

  tp = cur_term;
  set_curterm(tp);

/* printf("Termial 0x%x\n",tp); *.

#if 1
  setkeymap();
#endif

/*
  list("boolean caps",boolnames, boolcodes, boolfnames);
  list("integer caps",numnames, numcodes, numfnames);
  list("stirng caps",strnames, strcodes, strfnames);
*/

  printf("%d x %d\n",tigetnum("cols"), tigetnum("lines"));

  def_shell_mode();
  def_prog_mode();

  cbreak();

  tputs(enter_ca_mode, 1, out);
  tputs(enter_bold_mode, 1, out);
  printf("JIHAA\n"); fflush(stdout);
  tputs(exit_standout_mode, 1, out);
  printf("JIHAA\n"); fflush(stdout);

/*
  tputs(tparm(cursor_address,5,5), 1, out);

  printf("JIHAA\n"); fflush(stdout);
*/


#if 0
{
  _KEY_MAP **keys = cur_term->_keys;

  printf("Keys 0x%x\n",cur_term->_keys);

  if( keys )
  while( *keys )
  {
    _KEY_MAP *kp = *keys;
    char *s = kp->_sends;

#ifdef FUDGE_TERMIO
    if( s[1] == 0x4f )
      s[1] = 0x5b;
#endif

    printf("Key %d:",kp->_keyval);
    
    while( s && *s )
      printf(" %02x",*s++);
    printf("\n");
    keys++;
  }
}

#endif

  printf("enter_dim_mode:");
  dump(enter_dim_mode);
  printf("enter_blink_mode:");
  dump(enter_blink_mode);

  printf("123456789"); fflush(stdout);

  tputs(cursor_left,1, out);
  tputs(cursor_left,1, out);
  tputs(cursor_left,1, out);
  tputs(cursor_left,1, out);

  tputs(enter_insert_mode, 1, out);
  out( 0x1b ); out( '[' ); out( '@' );
  out( 'T' );
  tputs(exit_insert_mode, 1, out);
  
  tputs(cursor_right,1, out);
  tputs(cursor_right,1, out);
  tputs(cursor_right,1, out);
  out( 'T' );

/* get_keys(); */

/*
  printf("type!\n");
  while( (c = in(fileno(stdin))) != (-1) && c != 'q' )
    printf("got %d\n",c);
*/

  tputs(exit_ca_mode, 1, out);
  reset_shell_mode();

#if 0
  endwin();
  sleep(1);
#endif
}

main(int argc, char **argv)
{
  init();
}
