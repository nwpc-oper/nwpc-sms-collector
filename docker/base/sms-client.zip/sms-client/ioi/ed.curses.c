/**************************************************************************
.TITLE    Input Output Interface
.NAME     ED
.SECTION  L
.AUTHOR   Otto Pesonen
.DATE     22-MAY-1995 / 12-MAY-1995 / OP
.VERSION  3.2
.FILE     ed.c
.LANGUAGE ANSI-C
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1991,1992,1993,1994,1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE

#include "ioi.h"

#include <curses.h>

#define CONTROL(x) ((x)-64)

static SCREEN *screen = NULL;

static void init()
/**************************************************************************
?  Start-up curses but only once per application
************************************o*************************************/
{
  if( screen ) return;

  filter();
  if( ! (screen = newterm(NULL,stdout,stdin) ) )
  {
    ioi_out(0,IOI_ERR,"SET:can not turn editor on");
    return;
  }

  cbreak();
  noecho();

  nonl();
  idlok(stdscr,TRUE);
  intrflush(stdscr,FALSE);
  keypad(stdscr,TRUE);
  scrollok(stdscr,TRUE);
  move(LINES-1,0);
}

static char buff[MAXLEN];

static void history(int line)
/**************************************************************************
?  Fill the line buffer with the history line 
************************************o*************************************/
{
  ioi_history *history = (ioi_history *)ls_item(&ioi_._history,line);
  int    i;
  int    len = 0;
  char  *s;
  char **argv;
  char  *bp = buff;

  if( history )
    for( i=history->argc , argv=history->argv ; i ; i--)
    {
      s = *argv++;
      while( len < MAXLEN && *s )
      {
        *bp++ = *s++;
        len++;
      }
      if( i>1 && len<MAXLEN )
      {
        *bp++ = ' ';
        len++;
      }
    }

  *bp = '\0';
}

static void input_line(char *prompt)
/**************************************************************************
?  Edit the current line
************************************o*************************************/
{
  int len=0;                       /* Current length of the input  */
  int pos=0;                       /* Current position on the line */
  int rch;
  int prompt_len = strlen(prompt);

  int history_lines = ls_len(&ioi_._history);
  int current_line  = history_lines;

  move(LINES-1,0);
  addstr(prompt);
  clrtoeol();

  while( (rch=getch()) != ERR )
  {
    if( rch == '\r' || rch == '\n' || len == MAXLEN )
    {
      buff[len] = '\0';

      if( pos != len )
        move(LINES-1,prompt_len + len);
      /* addch('\n'); */
      refresh();

      return;
    }

    switch(rch)
    {
      case CONTROL('U'):           /* Clear the line to the beginning */
        if(len>0)
        {
          move(LINES-1,prompt_len);
          clrtoeol();
          buff[(pos=len=0)] = '\0';
        }
        break;

      case '\b':                   /* Clear the last character   */
      case 127:                    /* DEL (like in SYSV           */
#ifdef KEY_BACKSPACE
      case KEY_BACKSPACE:
#endif
        if(pos>0)
        {
          if(pos != len)
            memmove(buff+pos-1, buff+pos, len-pos);
          pos--;
          buff[len--] = '\0';
          move(LINES-1,pos+prompt_len);
          delch();
        }
        else
          beep();
        break;

      case CONTROL('P'):
      case KEY_UP:
        if(current_line)
        {
          history(--current_line);
          move(LINES-1,0);
          addstr(prompt);
          addstr(buff);
          clrtoeol();
          pos = len = strlen(buff);
        }
        else
          beep();
        break;

      case CONTROL('N'):
      case KEY_DOWN:
        if(current_line<history_lines)
        {
          history(++current_line);

          move(LINES-1,0);
          addstr(prompt);
          addstr(buff);
          clrtoeol();
          pos = len = strlen(buff);
        }
        else
          beep();
        break;

      case CONTROL('F'):
      case KEY_RIGHT:
        if(pos==len)
          beep();
        else
          move(LINES-1,prompt_len + ++pos);
        break;

      case CONTROL('B'):
      case KEY_LEFT:
        if(pos)
          move(LINES-1,prompt_len + --pos);
        else
          beep();
        break;

      case CONTROL('A'):
      case KEY_HOME:
        pos = 0;
        move(LINES-1,prompt_len);
        break;

      case CONTROL('E'):
      case KEY_END:
        pos = len;
        move(LINES-1,prompt_len+pos);
        break;

      case CONTROL('K'):
      case KEY_EOL:
        if(len && pos != len )
        {
          len = pos;
          move(LINES-1,prompt_len + len);
          clrtoeol();
        }
        break;

      default:
        if( rch <= 0xff && 
            (isalnum(rch) || rch==' ' || rch=='_' || ispunct(rch)) )
        {
          if( len<MAXLEN )
          {
            if( pos == len )
            {
              addch(rch);
              buff[len++] = rch;
              pos++;
            }
            else
            {
              memmove(buff+pos+1,buff+pos,len-pos);
              buff[pos++] = rch;
              len++;
              insch(rch);
              move(LINES-1,prompt_len + pos);
            }
          }
          else
            beep();
        }
        else                       /* Fix this if needed */
          beep();
    }
  }

  /* Process error in getch ... one of these days */
  buff[MAXLEN-1] = '\0';

  refresh();
}

static void dump(char *line, int len)
{
  while(len-- > 0)
    addch(*line++);
}

static void output(int type, char *line, int len)
{
  static char *bold,*normal,*reverse;

  if(type==IOI_RAW)
    dump(line,len);
  else if(type==IOI_ERR)
  {
    attron(A_REVERSE);
    dump(line,strlen(line));
    attroff(A_REVERSE);
  }
  else if(type==IOI_WAR)
  {
    attron(A_BOLD);
    dump(line,strlen(line));
    attroff(A_BOLD);
  }
  else
    dump(line,strlen(line));

  /* refresh(); */
}

static int input(char *line, int maxlen, int depth)
/**************************************************************************
?  Read the next line using curses 
=  BOOLEAN status.
************************************o*************************************/
{
  int i;
  char prompt[MAXNAM];

  init();

  if( depth )                      /* Distinguist between the prompts */
  {
    for( i=0 ; i<depth ; i++ )
      prompt[i]='>';               /* Prompt size reflects the depth */
      prompt[i++] = ' ';           /* Much clearer */
      prompt[i++] = '\0';
  }
  else
    if( *ioi_._prompt )
      sprintf(prompt,"%s> ",(depth)? "":ioi_._prompt);

  set_term(screen);
  input_line(prompt /* ,line,maxlen */ );
  endwin();
  printf("\n"); fflush(stdout);

  strcpy(line,buff);

  return TRUE;
}

void ioi_ed_exit()
{
  if(! screen ) return;

  endwin();
  ioi_._output = NULL;
}

void ioi_ed(int truth)
{
  ioi_user_input( truth? input : NULL );
/*
  ioi_user_output( truth? output : NULL );
*/

  if( ! truth && screen ) endwin();
}
