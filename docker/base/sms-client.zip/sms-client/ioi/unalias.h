"Remove the definition of the named alias.",
"The named alias is removed from the definition table. You may need this",
"is you accidentally define a function and an alias of same name.",
"",
"Notice! It's not an error to remove an alias even if it doesn't exist.",
"",
NULL
