/**************************************************************************
.TITLE    Input Output Interface
.NAME     EDITOR
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     ed.c
.LANGUAGE ANSI-C
.DATE     31-JUL-1998 / xx-MAY-1995 / OP
.VERSION  3.3
*
*  Termio based line-editing added
*  Only for ANSI (VT100/xterm) like terminals
*  The reason for writing my own, istead of using the curses lib,
*  is that you can not easily have two applications using curses
*  at the same time. Eg routines like filter(CURSES) change this
*  permanently.
*
*  This module is called to read a line at the time. While reading that
*  line, the terminal parameters might be edited for line control.
*  The module restores terminal settings before returning.
*
*  Currently this has only been tested on SGI
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE


#include "ioi.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>

#include <termio.h>
#include <sys/ioctl.h>


#ifdef AIX
#include <sys/select.h>
#endif

/**************************************************************************
*  Definitions that are borrowed from curses
************************************o*************************************/

#ifndef KEY_DOWN                   /* if curses.h not included */
#  define KEY_DOWN        0402     /* Sent by terminal down arrow key */
#  define KEY_UP          0403     /* Sent by terminal up arrow key */
#  define KEY_LEFT        0404     /* Sent by terminal left arrow key */
#  define KEY_RIGHT       0405     /* Sent by terminal right arrow key */
#  define KEY_HOME        0406     /* Sent by home key. */
#  define KEY_BACKSPACE   0407     /* Sent by backspace key */
#  define KEY_END         0550     /* end key */
#  define KEY_EOL         0517     /* Sent by clear-to-end-of-line key. */
#endif

#ifndef KEY_BACKSPACE
#  define KEY_BACKSPACE   07777777 /* Some big number */
#endif

/**************************************************************************
*  Own definitions
************************************o*************************************/

#define ESC 27
#define ERR (-1)
#define BACKSPACE 8
#define CONTROL(x) ((x)-64)

#define MAX_TYPE_AHEAD 10

typedef struct {
  char *_sends;
  int   _keyval;
} key_map;

/**************************************************************************
*  Globals for this module
************************************o*************************************/

static key_map keys[] = {
  { "[A" , KEY_UP },
  { "[B" , KEY_DOWN },
  { "[C" , KEY_RIGHT },
  { "[D" , KEY_LEFT },
};
static int num_keys = sizeof(keys) / sizeof(key_map);

static struct {
  FILE             *_of;           /* Output file pointer */
  FILE             *_if;           /* Input file pointer */
  struct termio     _iprog;        /* Input setting in program mode */
  struct termio     _ishell;       /* Input setting in shell mode */
  struct termio     _oprog;        /* Output setting in program mode */
  struct termio     _oshell;       /* Output setting in shell mode */
} ed_;

static int in_program_mode;
static int current_pos;
static int has_output;

static char buff[MAXLEN];
static int  interrupted;

static void history(int line)
/**************************************************************************
?  Fill the line buffer with the history line
************************************o*************************************/
{
  ioi_history *history = (ioi_history *)ls_item(&ioi_._history,line);
  int    i;
  int    len = 0;
  char  *s;
  char **argv;
  char  *bp = buff;

  if( history )
    for( i=history->argc , argv=history->argv ; i ; i--)
    {
      s = *argv++;
      while( len < MAXLEN && *s )
      {
        *bp++ = *s++;
        len++;
      }
      if( i>1 && len<MAXLEN )
      {
        *bp++ = ' ';
        len++;
      }
    }

  *bp = '\0';
}

static void enter_program_mode(void)
/**************************************************************************
?  Set the termio parameters for line-editing mode
************************************o*************************************/
{
  if(in_program_mode) return;

  (void) ioctl(fileno(ed_._if), TCSETAF, &ed_._iprog);

  in_program_mode = TRUE;
}

static void exit_program_mode(void)
/**************************************************************************
?  Set the termio parameters for normal (line-by-line) mode
************************************o*************************************/
{
  if( in_program_mode )
    (void) ioctl(fileno(ed_._if), TCSETA , &ed_._ishell);
  in_program_mode = FALSE;
}

void ioi_ed_init(FILE *in, FILE *out)
/**************************************************************************
?  Set the termio parameters for the very first time
************************************o*************************************/
{
#if 0
  struct winsize win;
  (void) ioctl(fileno(ed_._if), TIOCGWINSZ, &win);
  printf("WIN: %d % d\n",win.ws_row, win.ws_col);
#endif

  if( ed_._if ) return;

  ed_._if = in;
  ed_._of = out;

/*
  setbuf(ed_._of,0);
  setbuf(ed_._if,0);
*/

  ioctl(fileno(ed_._if), TCGETA, &ed_._ishell);
  memcpy(&ed_._iprog,&ed_._ishell,sizeof(struct termio));

  ed_._iprog.c_cc[VEOF] = 1;
  ed_._iprog.c_cc[VEOL] = 1;

  ed_._iprog.c_lflag &= ~(ECHO | ECHOE | ECHOK | ECHONL);
  ed_._iprog.c_lflag &= ~(ICANON);

  return;
}

static void out(char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  vfprintf(ed_._of,fmt,ap);
  va_end(ap);

  has_output = TRUE;
}

static void ed_sync(void)
{
  if( in_program_mode && has_output )
    fflush(ed_._of);
  has_output = FALSE;
}

static void ed_beep(void)
{
  out("%c",CONTROL('G'));
}

static void ed_bold(void)
{
  out("%c[1m",ESC);
}

static void ed_normal(void)
{
  out("%c[m",ESC);
}

static void ed_reverse(void)
{
  out("%c[7m",ESC);
}

static void ed_home(void)
{
  out("\r");
  current_pos = 0;
}

static void ed_cursor_left(void)
{
  if( current_pos > 0 )
  {
    out("%c",BACKSPACE);
    current_pos--;
  }
}

static void ed_cursor_right(void)
{
  out("%c[C",ESC);
  current_pos++;
}

static void ed_move_left(int num)
{
  out("%c[%dD",ESC,num);
  current_pos -= num;
}

static void ed_move_right(int num)
{
  out("%c[%dC",ESC,num);
  current_pos += num;
}

static void ed_move(int pos)  /* Move absolute */
{
  int off = pos - current_pos;

  if( !off ) return;

  if( off > 0 )
    ed_move_right(off);
  else
    ed_move_left(-off);
}

static void ed_clear_eol(void)
{
  out("%c[K",ESC);
}

static int ed_addch(int ch)
{
  out("%c",ch);
  current_pos++;

  return 0;
}

static int ed_addstr(char *s)
{
  for( ; *s ; s++ )
    if( isprint( *s ) )
      ed_addch( *s );

  return 0;
}

static void ed_insch(int ch)
{
  out("%c[@",ESC);
  ed_addch(ch);
}

static void ed_delch()
{
  out("%c[P",ESC);
}

static void dump(char *line, int len)
{
  while(len-- > 0)
    ed_addch(*line++);
}

static int ioi_ed_output(int type, char *line, int len)
{
  static char *bold,*normal,*reverse;

  if(type==IOI_RAW)
    dump(line,len);
  else if(type==IOI_ERR)
  {
    ed_reverse();
    dump(line,strlen(line));
    ed_normal();
  }
  else if(type==IOI_WAR)
  {
    ed_bold();
    dump(line,strlen(line));
    ed_normal();
  }
  else
    dump(line,strlen(line));

  return 0;
}

static int in_wait(int fd, int wait_usec)
/**************************************************************************
?  Read a character form file "fd" with delay specified as "wait_usec"
|  in micro-seconds ( -1 as wait_usec blocks indefinetely)
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
  int             go_on = TRUE;
  int             c = ERR;
  char            ch;
  fd_set          readfds;
  struct timeval  timeout;

  timeout.tv_sec  = 0;
  timeout.tv_usec = wait_usec;

  FD_ZERO(&readfds);
  FD_SET(fd,&readfds);

  while( go_on )
#ifdef FD_SETSIZE
  switch( select(FD_SETSIZE,&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#else
  switch( select(8*sizeof(readfds),&readfds,NULL,NULL,
          (wait_usec==(-1))? NULL : &timeout) )
#endif
  {
    case -1:
      go_on = FALSE;
      if( errno != EINTR ) 
        ;
      else
        interrupted = TRUE;
      break;

    case 0:
      go_on = FALSE;
      break;

    case 1:
      if( read(fd, &ch, 1) == 1 )
      {
        c = ch; 
        go_on = FALSE;
      }
      break;

    default: /* hymm... donno, must be some sort of an error */
      break;
  }

  return c;
}

static int in(int fd)
/**************************************************************************
?  Read a character form file "fd" 
|  If an escape is pressed and more characters apper withing a timeout
|  a function key value may be returned
=  -1 for any error or if a timeout occured
************************************o*************************************/
{
  static char type_ahead[MAX_TYPE_AHEAD];  /* If we read for function keys */
  static int  type_ahead_len;              /* but there is no match        */
  int         num_matches = 1;
  key_map    *kp;
  int         c;

  if( type_ahead_len )
  {
    c = type_ahead[0];
    memmove(type_ahead,type_ahead+1,--type_ahead_len);
    return c;
  }

  if( (c=in_wait(fd, -1)) == ERR )
    return ERR;

  type_ahead[type_ahead_len++] = c;

  while( type_ahead_len < MAX_TYPE_AHEAD && num_matches )
  {
    int i;
    num_matches = 0;

    for( i=0, kp = &keys[i]; i<num_keys ; kp = &keys[++i] )
    {
      if( strncmp( kp->_sends , type_ahead , type_ahead_len ) == 0 )
      {
        num_matches++;
        if( strlen( kp->_sends ) == type_ahead_len )
        {
          type_ahead_len = 0;
          return kp->_keyval;
        }
      }
    }

    if( num_matches )              /* Beginning macthes but not completely */
    {                              /* Get more, with small delay           */
      if( (c=in_wait(fd, 100000)) == ERR )
      {
        c = type_ahead[0];
        memmove(type_ahead,type_ahead+1,--type_ahead_len);

        return c;
      }

      type_ahead[type_ahead_len++] = c;
    }
  }

  /* No match, buffer full => return the first */

  c = type_ahead[0];
  memmove(type_ahead,type_ahead+1,--type_ahead_len);

  return c;
}

static int ioi_ed_input(char *line, int maxlen, int depth)
/**************************************************************************
?  Read a line of characters, with line editing and history processing
|  If a whole line is ready in the input queue read it and return.
|  Otherwise enter line-editing mode and process the keystorkes.
|  Always leave the terminal in the normal mode (commands that read
|  stdin, will not have line editing on)
=  -1 
************************************o*************************************/
{
  int len=0;                       /* Current length of the input  */
  int pos=0;                       /* Current position on the line */
  int rch;                         /* Character-code just read     */
  int prompt_len;                  /* Lenght of the prompt         */

  int history_lines = ls_len(&ioi_._history);
  int current_line  = history_lines;

  int i;
  char prompt[MAXNAM];

  if( depth > 0 )                  /* Distinguist between the prompts */
  {
    for( i=0 ; i<depth ; i++ )
      prompt[i]='>';               /* Prompt size reflects the depth */
      prompt[i++] = ' ';           /* Much clearer */
      prompt[i++] = '\0';
  }
  else
    if( *ioi_._prompt )
      sprintf(prompt,"%s> ",(depth)? "":ioi_._prompt);

  prompt_len = strlen(prompt);

  buff[0] = '\0';

  ed_home();
  ed_addstr(prompt);
  ed_clear_eol();
  fflush(ed_._of);

  while( (rch=in_wait(fileno(ed_._if), 1)) != ERR )
    if( rch=='\r' || rch == '\n' )
    {
      len = MIN(maxlen,len);
      buff[len] = '\0';
      strcpy(line,buff);
      return TRUE;
    }
    else
    {
      buff[len++] = rch;
      if( len >= MAXLEN || len >= maxlen )
        len--;                     /* Ignore last char */
    }

  enter_program_mode();
  interrupted = FALSE;

  while( (rch=in(fileno(ed_._if))) != ERR )
  {
    if( interrupted )
    {
      interrupted = FALSE;
      rch = CONTROL('R');
    }

    if(len<MAXLEN)
      buff[len] = '\0';

    if( rch == '\r' || rch == '\n' )
    {
      len = MIN(maxlen,len);
      buff[len] = '\0';
      strcpy(line,buff);
      exit_program_mode();
      printf("\n");
      return TRUE;
    }
  
    switch (rch)
    {
      case CONTROL('U'):           /* Clear the line to the beginning */
        if(len>0)
        {
          ed_move(prompt_len);
          ed_clear_eol();
          buff[(pos=len=0)] = '\0';
        }
        break;

      case '\b':                   /* Clear the last character   */
      case 127:                    /* DEL (like in SYSV           */
      case KEY_BACKSPACE:
        if(pos>0)
        {
          if(pos != len)
            memmove(buff+pos-1, buff+pos, len-pos);
          pos--;
          buff[len--] = '\0';
          ed_move(pos+prompt_len);
          ed_delch();
        }
        else
          ed_beep();
        break;

      case CONTROL('P'):
      case KEY_UP:
        if(current_line)
        {
          history(--current_line);
          ed_move(0);
          ed_addstr(prompt);
          ed_addstr(buff);
          ed_clear_eol();
          pos = len = strlen(buff);
        }
        else
          ed_beep();
        break;

      case CONTROL('N'):
      case KEY_DOWN:
        if(current_line<history_lines)
        {
          history(++current_line);

          ed_move(0);
          ed_addstr(prompt);
          ed_addstr(buff);
          ed_clear_eol();
          pos = len = strlen(buff);
        }
        else
          ed_beep();
        break;

      case CONTROL('F'):
      case KEY_RIGHT:
        if(pos==len)
          ed_beep();
        else
          ed_move(prompt_len + ++pos);
        break;

      case CONTROL('B'):
      case KEY_LEFT:
        if(pos)
          ed_move(prompt_len + --pos);
        else
          ed_beep();
        break;

      case CONTROL('A'):
      case KEY_HOME:
        pos = 0;
        ed_move(prompt_len);
        break;

      case CONTROL('E'):
      case KEY_END:
        pos = len;
        ed_move(prompt_len+pos);
        break;

      case CONTROL('K'):
      case KEY_EOL:
        if(len && pos != len )
        {
          len = pos;
          ed_move(prompt_len + len);
          ed_clear_eol();
        }
        break;

      case CONTROL('R'):
      case CONTROL('L'):
        ed_home();
        ed_addstr(prompt);
        ed_addstr(buff);
        ed_clear_eol();
        ed_move(prompt_len+pos);
        break;

      case CONTROL('T'):
        ed_home();
        ed_addstr(ioi_cmd_date_str());
        ed_addstr(ioi_cmd_time_str());
        ed_clear_eol();
        out("\n");
        ed_home();
        ed_addstr(prompt);
        ed_addstr(buff);
        ed_move(prompt_len+pos);
        break;

      default:
        if( rch <= 0xff &&
            (isalnum(rch) || rch==' ' || rch=='_' || ispunct(rch)) )
        {
          if( len<MAXLEN )
          {
            if( pos == len )
            {
              ed_addch(rch);
              buff[len++] = rch;
              pos++;
            }
            else
            {
              memmove(buff+pos+1,buff+pos,len-pos);
              buff[pos++] = rch;
              len++;
              ed_insch(rch);
              ed_move(prompt_len + pos);
            }
          }
          else
            ed_beep();
        }
        else                       /* Fix this if needed */
          ed_beep();

    }  /* switch(rch) */

    ed_sync();
  }

  exit_program_mode();

  return FALSE;
}

void ioi_ed_exit(void)
/**************************************************************************
?  Really a dummy routine, will only be called once at the end of an
|  IOI-application
************************************o*************************************/
{
  ed_._if = ed_._of = NULL;

  ioi_._output = NULL;
}

void ioi_ed(int truth)
/**************************************************************************
?  Set the editor on/off. Called by variable.c; command "set editor ..."
************************************o*************************************/
{
  if(truth && isatty(fileno(stdin)))
    ioi_ed_init(stdin,stdout);

  ioi_user_input( truth? ioi_ed_input : NULL );
  ioi_user_output( truth? ioi_ed_output : NULL );

  if( ! truth )
    ed_._if = ed_._of = NULL;
}
