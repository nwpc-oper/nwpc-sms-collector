/**************************************************************************
.TITLE    Input Output Interface
.NAME     LINK
.SECTION  L
.AUTHOR   Otto Pesonen
.FILE     link.c
.LANGUAGE ANSI-C
.DATE     20-MAR-1996 / 27-MAR-1995 / OP
.VERSION  3.2-3
*         Dynamic linking added
.DATE     21-OCT-1998 / 31-JUL-1998 / OP
.VERSION  3.3
*         Cleaning up + prototypes
*         -i option
************************************o*************************************/
/*
* Copyright (c) Otto E J Pesonen 1995
*
* Unpublished - all rights reserved under the copyright laws
*
* The ECMWF has been given the right to use this code as a hole or as a
* part of their products. The source code may not be further distributed.
*/

#define IOI_MODULE
#include "ioi.h"

#if defined(sun) || defined(__sgi)

#ifdef __sgi
#include <dlfcn.h>
#define CC "cc"
#define FF "f77"
#define LD "ld -shared"
#endif

#ifdef sun
#include <dlfcn.h>
#define CC "acc"
#define LD "ld -Bdynamic"
#endif

/* Cray UNICOS, IBM AIX does not have these */

static void *library;

static int compile(char *name)
/**************************************************************************
?  Compile the code using C compiler
=  Did the compilation work or not
************************************o*************************************/
{
  char cmd[MAXLEN];
  char *cflags  = 0;
  char *ldflags = 0;

  if( !(cflags=(char *)ioi_variable_get("CFLAGS")) )
    cflags = "";

  if( !(ldflags=(char *)ioi_variable_get("LDFLAGS")) )
    ldflags = "";

  sprintf(cmd,"%s %s -c %s.c",CC,cflags,name);
  printf("compiling : %s\n",cmd);
  if( system(cmd) )
    return ioi_out(FALSE,IOI_ERR,"compilation for %s.c failed",name);

  sprintf(cmd,"%s %s %s.o -o %s.so",LD,ldflags,name,name);
  printf("linking   : %s\n",cmd);
  if( system(cmd) )
    return ioi_out(FALSE,IOI_ERR,"linking for %s.o failed\n",name);

  return TRUE;
}

static void *get_entry_point(void *library, char *entry_point)
/**************************************************************************
?  Retrieve an address
=  Function pointer
************************************o*************************************/
{
  void *fun;

  if( ! (fun=dlsym(library,entry_point)) )
  {
    fprintf(stderr,"entry point %s not found\n",entry_point);
    dlclose(library);
    return NULL;
  }

  return fun;
}

static void *link_lib(char *name, int speed)
/**************************************************************************
?  Dynamically load the library
=  Handle to the library
************************************o*************************************/
{
  char cmd[MAXLEN];
  void *lib = NULL;

  sprintf(cmd,"%s%s.so",(*name=='/')?"":"./",name);
  printf("linking in: %s\n",cmd);
  if(! (lib=dlopen(cmd,(speed)?RTLD_NOW:RTLD_LAZY)) )
  {
    fprintf(stderr,"dynamic linking for %s.so failed: reason\n",name);
    fprintf(stderr,"%s\n",dlerror());
    return NULL;
  }

  return lib;
}

static int (* compile_and_link(char *name, char *entry_point))()
/**************************************************************************
?  Both compile and link and retrieve an address
=  The address of the entry point
************************************o*************************************/
{
  int (* fun)() = NULL;

  library = NULL;

  if(!compile(name)) return NULL;
  if( !(library=link_lib(name,FALSE)) ) return NULL;
  if( !(fun=get_entry_point(library,entry_point)) ) return NULL;

  return fun;
}

static int (* link_with_entry(char *name, char *entry_point))()
/**************************************************************************
?  ...
=  The address of the entry point
************************************o*************************************/
{
  int (* fun)() = NULL;

  library = NULL;

  if( !(library=link_lib(name,FALSE)) ) return NULL;
  if( !(fun=get_entry_point(library,entry_point)) ) return NULL;

  return fun;
}

int ioi_link_cmd(int argc, char **argv)
/**************************************************************************
?  Dynamically link a new function
************************************o*************************************/
{
  static int   called;
  static char *name;
  static char *entry_point;
  static int   link;
  static int   linkonly;
  static int   ioi;

  static char *man[3] = { 
    "Dynamically loaded function",
    "No manual page available, sorry :-(",
    NULL };

  if( called )
  {
    ioi_exe *exe = NULL;

    if( name ) { argc++; argv--; }

    if( linkonly )
    {
      for( ; argc > 0 ; argc--, argv++ )
        if( ! link_lib(*argv,TRUE) )
          break;
      return argc==0;
    }

    if( (exe=(ioi_exe *)ioi_list_get(IOI_L_EXE,name,FALSE)) )
    {
      if(!exe->library) return
        ioi_out(FALSE,IOI_ERR,"IOI-LINK-DYNAMIC:can not be over-loaded",name);

      ioi_out(FALSE,IOI_WAR,"IOI-LINK-DYNAMIC: %s already linked",name);
      ioi_out(FALSE,IOI_WAR,"IOI-LINK-DYNAMIC: removing old definition",name);
      dlclose(exe->library);
      ioi_list_delete(exe->type,exe->name);
    }


    while( argc-- > 0 )
    {
      int (* fun)() = NULL;

      if( link )
        fun=link_with_entry(name,entry_point?entry_point:name);
      else
        fun=compile_and_link(name,entry_point?entry_point:name);

      if( fun )
      {
        if( ioi )
        {
          fun(0,NULL);
          exe = ls_find(&ioi_._exe,name);
          if(exe) exe->library = library;
          else    ioi_out(0,IOI_WAR,"Dynamic ioi-command did not load the name %s",name);
        }
        else
        {
          char buff[MAXNAM];

          sprintf(buff,"%s:dynamic",name);

          if( (exe=(ioi_exe *)ioi_exe_add(buff,fun,NULL,NULL,man)) )
            exe->library = library;
        }
      }
      else
        ;

      if(entry_point) argc=0;
    }

  }
  else
    ioi_exe_add("link:ioi",ioi_link_cmd,
      ioi_exe_link_param(
        ioi_exe_param(
          "-Llinkonly",IOI_L_BOOLEAN,ioi_exe_argv(
            "Don't compile, just dynamically link the file(s), no entry",
            "points are given. Good eg for fortran library.",
            NULL
          ),NULL,1,&linkonly
        ),
        ioi_exe_param(
          "-llink",IOI_L_BOOLEAN,ioi_exe_argv(
            "Don't compile, just dynamically link the file and add an",
            "entry point (default is same name as file named)",
            NULL
          ),NULL,1,&link
        ),
        ioi_exe_param(
          "-eentry",IOI_L_STRING,ioi_exe_argv(
            "Use entry point (function name) named, isted of the file name.",
            "","NOTICE","",
            "Only one file can be called if this option is used",
            NULL
          ),NULL,1,&entry_point
        ),
        ioi_exe_param(
          "-iioi",IOI_L_BOOLEAN,ioi_exe_argv(
            "The function is an IOI command, add it with the manual page.",
            NULL
          ),NULL,1,&ioi
        ),
        NULL
      ),
      ioi_exe_param(
        "filename(s)",IOI_L_STRING,ioi_exe_argv(
          "The name(s) of the files to be linked. The name(s) are without",
          "the extension (.c for C-files, .so for objects) and each must",
          "have entry of the same name (unless -e or -L option is used)",
          NULL
        ),NULL,1,&name
      ),
      ioi_exe_argv(
        "Load a C-program into IOI",
        "Compile and link a C-program into running IOI application",
        "","SYNTAX","",
        "The C function is defined like following [foo.c]:","",
        "  int foo(int argc, char **argv)",
        "  {",
        "    while(argc--)",
        "      printf(\"FOO: %s\\n\",*argv++);",
        "",
        "    return 1;",
        "  }",
        NULL
      )
    );

  if( !called )
    ioi_unlink_cmd(0,NULL);

  return called = TRUE;
}

int ioi_unlink_cmd(int argc, char **argv)
/**************************************************************************
?  Un-link an old function
************************************o*************************************/
{
  static int   called;
  static char *name;

  if( called )
  {
    ioi_exe *exe = NULL;

    if( (exe=(ioi_exe *)ioi_list_get(IOI_L_EXE,name,FALSE)) )
    {
      if(!exe->library) return
        ioi_out(FALSE,IOI_ERR,"IOI-UNLINK:is not dynamic",name);

      ioi_out(FALSE,IOI_WAR,"IOI-LINK-DYNAMIC: removing old definition",name);
      dlclose(exe->library);
      ioi_list_delete(exe->type,exe->name);
    }
  }
  else
    ioi_exe_add("unlink:ioi",ioi_unlink_cmd,NULL,NULL,
      ioi_exe_argv(
        "Remove a previously loaded C-program from IOI",
        "Routines previously loaded with link(IOI) will be freed and",
        "can not be accessed anymore",
        NULL
      )
    );

  return called = TRUE;
}

#else
int ioi_link_cmd(int argc, char **argv)
{
  ; 
}
int ioi_unlink_cmd(int argc, char **argv)
{
  ;
}
#endif
